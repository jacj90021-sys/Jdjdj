Act as a Next.js / React engineer. Implement an update flow for our app with two distinct behaviors:

1. HOME TAB LAUNCH (Update Available Prompt):
   - When the user opens the Home tab (`app/page.tsx`), automatically check if a new version exists.
   - If a new version is available, display a modal popup containing the version details, changelog, "Later", and "Update Now" buttons.
   - Clicking "Update Now" switches the modal view directly to the downloading progress state.

2. SETTINGS / PROFILE TAB (Direct Download Action):
   - When the user clicks "Check for Updates" inside Settings, skip the prompt and immediately launch the Modal in the DOWNLOADING state with the progress bar animation.

FRONTEND REQUIREMENT:
- Implement this using Paper-Brutalism styling (`#F4EFE6` background, `#1A1A1A` 2px solid borders, `#EFE8DA` card background, and `#D94132` accent red).
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>App Home & Updates</title>
  <style>
    :root {
      --bg-color: #F4EFE6;
      --card-bg: #EFE8DA;
      --text-main: #1A1A1A;
      --text-muted: #666666;
      --accent-red: #D94132;
      --border-color: #1A1A1A;
      --border-width: 2px;
    }

    * {
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }

    body {
      background-color: var(--bg-color);
      color: var(--text-main);
      margin: 0;
      padding: 16px;
    }

    .container {
      max-width: 500px;
      margin: 0 auto;
    }

    /* Mock Settings Component */
    .section-title {
      font-size: 0.8rem;
      font-weight: 800;
      color: var(--accent-red);
      margin: 20px 0 8px 0;
      letter-spacing: 1px;
    }

    .section-box {
      border: var(--border-width) solid var(--border-color);
      background-color: var(--card-bg);
      border-radius: 12px;
      overflow: hidden;
    }

    .menu-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px;
      cursor: pointer;
      font-weight: 800;
      font-size: 0.95rem;
    }

    .version-tag {
      font-size: 0.8rem;
      color: var(--text-muted);
      font-weight: 700;
    }

    /* OVERLAY MODAL */
    .modal-overlay {
      position: fixed;
      inset: 0;
      background-color: rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      padding: 20px;
    }

    .modal-card {
      background-color: var(--bg-color);
      border: var(--border-width) solid var(--border-color);
      border-radius: 16px;
      width: 100%;
      max-width: 400px;
      padding: 20px;
      box-shadow: 6px 6px 0px var(--border-color);
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .modal-title {
      font-size: 1.2rem;
      font-weight: 900;
      text-transform: uppercase;
      margin: 0;
    }

    .btn-close {
      background: transparent;
      border: none;
      font-size: 1.2rem;
      font-weight: 900;
      cursor: pointer;
    }

    /* Version Banner */
    .version-banner {
      background-color: var(--card-bg);
      border: var(--border-width) solid var(--border-color);
      border-radius: 10px;
      padding: 12px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .version-num {
      font-size: 1.1rem;
      font-weight: 900;
      display: block;
    }

    .version-size {
      font-size: 0.75rem;
      color: var(--text-muted);
      font-weight: 700;
    }

    .badge-new {
      background-color: var(--accent-red);
      color: #FFFFFF;
      font-size: 0.65rem;
      font-weight: 900;
      padding: 4px 8px;
      border-radius: 6px;
      border: 1px solid var(--border-color);
    }

    .changelog-list {
      margin: 8px 0 0 0;
      padding-left: 18px;
      font-size: 0.85rem;
      font-weight: 700;
      line-height: 1.4;
    }

    .modal-actions {
      display: flex;
      gap: 10px;
    }

    .btn-update {
      flex: 1;
      background-color: var(--accent-red);
      color: #FFFFFF;
      border: var(--border-width) solid var(--border-color);
      border-radius: 10px;
      padding: 12px;
      font-weight: 900;
      cursor: pointer;
      box-shadow: 3px 3px 0px var(--border-color);
    }

    .btn-secondary {
      background-color: var(--card-bg);
      border: var(--border-width) solid var(--border-color);
      border-radius: 10px;
      padding: 12px;
      font-weight: 800;
      cursor: pointer;
    }

    /* Progress Bar */
    .progress-box {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .progress-info {
      display: flex;
      justify-content: space-between;
      font-size: 0.75rem;
      font-weight: 800;
    }

    .progress-bar {
      width: 100%;
      height: 10px;
      background-color: var(--card-bg);
      border: var(--border-width) solid var(--border-color);
      border-radius: 6px;
      overflow: hidden;
    }

    .progress-fill {
      height: 100%;
      background-color: var(--accent-red);
      width: 0%;
      transition: width 0.2s ease;
    }

    .hidden { display: none !important; }
  </style>
</head>
<body>

  <div class="container">
    <div class="section-title">APP SETTINGS</div>
    <div class="section-box">
      <!-- Setting Trigger (Direct Download) -->
      <div class="menu-row" id="settingDownloadTrigger">
        <span>Check for Updates</span>
        <span class="version-tag">v2.1.0</span>
      </div>
    </div>
  </div>

  <!-- POPUP MODAL -->
  <div class="modal-overlay hidden" id="updateModal">
    <div class="modal-card">
      
      <div class="modal-header">
        <h3 class="modal-title">App Update</h3>
        <button class="btn-close" id="closeModalBtn">✕</button>
      </div>

      <!-- VIEW 1: Home Open Prompt View -->
      <div id="viewHomePrompt" class="hidden">
        <div class="version-banner">
          <div>
            <span class="version-num">Version v2.2.0</span>
            <span class="version-size">Size: 18.4 MB</span>
          </div>
          <span class="badge-new">NEW UPDATE</span>
        </div>

        <div style="margin-top: 12px;">
          <span style="font-size:0.75rem; font-weight:800; color:var(--text-muted);">WHAT'S NEW:</span>
          <ul class="changelog-list">
            <li>SD Card storage download support</li>
            <li>New offline progress indicator</li>
            <li>Bug fixes & performance updates</li>
          </ul>
        </div>

        <div class="modal-actions" style="margin-top: 16px;">
          <button class="btn-secondary" id="skipBtn">Later</button>
          <button class="btn-update" id="startUpdateBtn">Update Now</button>
        </div>
      </div>

      <!-- VIEW 2: Direct Downloading Progress View -->
      <div id="viewDownloading" class="hidden">
        <div class="progress-box">
          <div class="progress-info">
            <span style="color: var(--accent-red);">Downloading update...</span>
            <span id="downloadPercent">0%</span>
          </div>
          <div class="progress-bar">
            <div class="progress-fill" id="progressFill"></div>
          </div>
        </div>
      </div>

    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', () => {
      const modal = document.getElementById('updateModal');
      const closeModalBtn = document.getElementById('closeModalBtn');
      const skipBtn = document.getElementById('skipBtn');
      const startUpdateBtn = document.getElementById('startUpdateBtn');
      const settingTrigger = document.getElementById('settingDownloadTrigger');

      const viewHomePrompt = document.getElementById('viewHomePrompt');
      const viewDownloading = document.getElementById('viewDownloading');
      
      const progressFill = document.getElementById('progressFill');
      const downloadPercent = document.getElementById('downloadPercent');

      // 1. AUTO OPEN PROMPT ON HOME APP LAUNCH
      setTimeout(() => {
        viewDownloading.classList.add('hidden');
        viewHomePrompt.classList.remove('hidden');
        modal.classList.remove('hidden');
      }, 500);

      // Function to start progress bar simulation
      function startDownloadSequence() {
        viewHomePrompt.classList.add('hidden');
        viewDownloading.classList.remove('hidden');
        modal.classList.remove('hidden');

        let progress = 0;
        progressFill.style.width = '0%';
        downloadPercent.textContent = '0%';

        const interval = setInterval(() => {
          progress += 10;
          progressFill.style.width = `${progress}%`;
          downloadPercent.textContent = `${progress}%`;

          if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              alert('Update Complete! Restarting app...');
              modal.classList.add('hidden');
            }, 300);
          }
        }, 150);
      }

      // 2. SETTINGS CLICK -> Direct Download
      settingTrigger.addEventListener('click', () => {
        startDownloadSequence();
      });

      // Update Now Button Click from Home Prompt
      startUpdateBtn.addEventListener('click', () => {
        startDownloadSequence();
      });

      // Close / Dismiss Actions
      closeModalBtn.addEventListener('click', () => modal.classList.add('hidden'));
      skipBtn.addEventListener('click', () => modal.classList.add('hidden'));
    });
  </script>
</body>
</html>
