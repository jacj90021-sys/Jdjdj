import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
}

// Store-build flag: `./gradlew assembleProdRelease -PstoreBuild=true` produces a
// build with the GitHub self-updater compiled OUT (for Amazon Appstore / Play
// submissions, where the store owns updates). Default: updater ON.
val storeBuild = (project.findProperty("storeBuild") as? String)?.toBoolean() ?: false

// Ad-network flag: `-PadsNetwork=unity` swaps the compiled-in ad SDK from
// AdMob (default) to Unity Ads (4.20.0); `-PadsNetwork=none` ships NO ad SDK
// at all (used for store submissions — Amazon's review rejected ad-network
// libraries, and Amazon's own ad network is sunset). Besides the dependency,
// it selects the network's source set and sets BuildConfig.AD_NETWORK so
// AdManager delegates to the right implementation. Each APK carries exactly
// one SDK — the other is never bundled.
val adsNetwork = (project.findProperty("adsNetwork") as? String)?.lowercase() ?: "admob"
val isUnityAds = adsNetwork == "unity"
val isNoAds = adsNetwork == "none"

// Test-mode flag for Unity Ads: `-PadTestMode=true` makes Unity serve
// guaranteed TEST ads (no review/fill needed) so the ad pipeline can be
// verified visually. Default off — production builds serve real ads.
val adTestMode = (project.findProperty("adTestMode") as? String)?.toBoolean() ?: false

android {
    namespace = "com.panime.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.panime.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 62
        versionName = "1.0.64"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true
    }

    signingConfigs {
        create("release") {
            val props = project.rootProject.file("local.properties")
            if (props.exists()) {
                val p = Properties().apply { load(props.inputStream()) }
                storeFile = file(p.getProperty("RELEASE_STORE_FILE", "release.keystore"))
                storePassword = p.getProperty("RELEASE_STORE_PASSWORD", "")
                keyAlias = p.getProperty("RELEASE_KEY_ALIAS", "")
                keyPassword = p.getProperty("RELEASE_KEY_PASSWORD", "")
            }
        }
        // Debug-sign the "leak" release build so it installs even when no
        // signing secrets are provided (used for the no-keystore Unity workflow).
        create("leakRelease") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            // R8 obfuscation + code shrinking: renames classes/methods/fields so a
            // decompiled APK is unreadable, and drops unused code (smaller APK).
            // keep-rules for kotlinx.serialization live in proguard-rules.pro.
            isMinifyEnabled = true
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    flavorDimensions += "env"
    productFlavors {
        create("dev") {
            dimension = "env"
            applicationIdSuffix = ".dev"
            versionNameSuffix = "-dev"
            buildConfigField("Boolean", "UPDATER_ENABLED", if (storeBuild) "false" else "true")
            buildConfigField("Boolean", "ADS_ENABLED", "true")
            buildConfigField("String", "AD_NETWORK", "\"$adsNetwork\"")
            // Unity Ads (used only when -PadsNetwork=unity)
            buildConfigField("String", "UNITY_GAME_ID", "\"800364366\"")
            buildConfigField("String", "UNITY_INTERSTITIAL_ID", "\"Interstitial_Android\"")
            buildConfigField("String", "UNITY_REWARDED_ID", "\"0th65kpettwis0id\"")
            buildConfigField("String", "UNITY_BANNER_ID", "\"Banner_Android\"")
            buildConfigField("Boolean", "UNITY_TEST_MODE", adTestMode.toString())
            buildConfigField("String", "ADMOB_APP_ID", "\"ca-app-pub-3524254806790424~3791393547\"")
            buildConfigField("String", "ADMOB_BANNER_ID", "\"ca-app-pub-3524254806790424/1782458677\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"ca-app-pub-3524254806790424/8156295338\"")
            buildConfigField("String", "ADMOB_REWARDED_ID", "\"ca-app-pub-3524254806790424/6921331219\"")
        }
        create("prod") {
            dimension = "env"
            buildConfigField("Boolean", "UPDATER_ENABLED", if (storeBuild) "false" else "true")
            // Master switch ON — remote config (provider_config.json) now controls ads live.
            buildConfigField("Boolean", "ADS_ENABLED", "true")
            buildConfigField("String", "AD_NETWORK", "\"$adsNetwork\"")
            // Unity Ads (used only when -PadsNetwork=unity)
            buildConfigField("String", "UNITY_GAME_ID", "\"800364366\"")
            buildConfigField("String", "UNITY_INTERSTITIAL_ID", "\"Interstitial_Android\"")
            buildConfigField("String", "UNITY_REWARDED_ID", "\"0th65kpettwis0id\"")
            buildConfigField("String", "UNITY_BANNER_ID", "\"Banner_Android\"")
            buildConfigField("Boolean", "UNITY_TEST_MODE", adTestMode.toString())
            buildConfigField("String", "ADMOB_APP_ID", "\"ca-app-pub-3524254806790424~3791393547\"")
            buildConfigField("String", "ADMOB_BANNER_ID", "\"ca-app-pub-3524254806790424/1782458677\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"ca-app-pub-3524254806790424/8156295338\"")
            buildConfigField("String", "ADMOB_REWARDED_ID", "\"ca-app-pub-3524254806790424/6921331219\"")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }

    // Ad-network source set: compile in ONLY the selected network's
    // implementation + its SDK so the other SDK is never bundled.
    // The Unity build also provides @xml/gma_ad_services_config in
    // src/unity/res (the AdMob build gets it from the AdMob AAR), so the main
    // manifest's AD_SERVICES_CONFIG property resolves in both.
    sourceSets {
        when (adsNetwork) {
            "unity" -> getByName("main") {
                java.srcDir("src/unity/java")
                res.srcDir("src/unity/res")
            }
            "none" -> getByName("main") {
                java.srcDir("src/none/java")
                res.srcDir("src/none/res")
            }
            else -> getByName("main").java.srcDir("src/admob/java")
        }
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }

    // Per-ABI APKs so devices don't carry FFmpeg decoders for foreign CPU
    // architectures (~halves the download). Universal stays enabled as the
    // "works everywhere" fallback.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a", "x86_64", "x86")
            isUniversalApk = true
        }
    }

    // Name the output APKs panime-<abi>.apk instead of AGP's default
    // <module>-<flavor>-<buildType>-<abi>.apk (the module is "app", so AGP
    // produces app-prod-*-release.apk). The in-app updater's fallback path
    // (GitHubUpdater.fallbackAssetName) references these names.
    // NOTE: applicationVariants is deprecated in AGP 8 (removed in AGP 9) but
    // still functional — the androidComponents replacement has no output
    // rename API.
    applicationVariants.all {
        outputs.all {
            val output = this as com.android.build.gradle.internal.api.BaseVariantOutputImpl
            val abi = (filters.find { it.filterType == com.android.build.OutputFile.ABI })
                ?.identifier ?: "universal"
            output.outputFileName = "panime-$abi.apk"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)
    testImplementation("junit:junit:4.13.2")
    // Real org.json for JVM unit tests (android.jar ships non-working stubs).
    testImplementation("org.json:json:20240303")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation("androidx.navigation:navigation-compose:2.8.5")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    debugImplementation("androidx.compose.ui:ui-tooling")

    // Networking
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.jakewharton.retrofit:retrofit2-kotlinx-serialization-converter:1.0.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jsoup:jsoup:1.18.1")

    // Images
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Player (Media3 1.10.1, HLS) — version MUST stay in sync with
    // nextlib-media3ext below (its FFmpeg renderers are compiled against this).
    implementation("androidx.media3:media3-exoplayer:1.10.1")
    implementation("androidx.media3:media3-ui:1.10.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.10.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.10.1")
    implementation("androidx.media3:media3-datasource:1.10.1")
    implementation("androidx.media3:media3-database:1.10.1")

    // FFmpeg software decoders (video/audio). Fallback when hardware MediaCodec
    // rejects a format — e.g. anizone's H.264 "High 4:4:4" encodes
    // (avc1.6E00xx) that NO Android device hardware-decodes. This is what lets
    // those titles play in-app the same way the website plays them in-browser.
    implementation("io.github.anilbeesetti:nextlib-media3ext:1.10.1-0.13.0")

    // Preferences
    // 1.1.3 fixes the first-access FileNotFoundException crash (issuetracker 337870543):
    // 1.1.0/1.1.1 throw ENOENT when the prefs file doesn't exist yet instead of
    // returning defaults, crashing e.g. the player on a fresh install.
    implementation("androidx.datastore:datastore-preferences:1.1.3")

    // Encrypted storage for OAuth access/refresh tokens
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Ad network — AdMob by default, Unity Ads when -PadsNetwork=unity,
    // no SDK at all when -PadsNetwork=none (store builds).
    if (isUnityAds) {
        implementation("com.unity3d.ads:unity-ads:4.20.0")
    } else if (!isNoAds) {
        implementation("com.google.android.gms:play-services-ads:23.6.0")
    }

    // Firebase (Crashlytics + Analytics + Remote Config + Messaging + Performance)
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-config")
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-perf")
}
