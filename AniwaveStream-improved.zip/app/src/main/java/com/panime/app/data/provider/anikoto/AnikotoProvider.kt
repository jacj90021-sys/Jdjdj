package com.panime.app.data.provider.anikoto

import android.util.Log
import com.panime.app.BuildConfig
import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.api.KotoApi
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider
import com.panime.app.player.MegaplayCdnSigner
import com.panime.app.util.Obf
import org.json.JSONObject
import java.net.URLEncoder
import java.net.URL

/**
 * On-device AniKoto (anikoto.cz) provider.
 *
 * === The slug problem (why prior versions were "still wrong") ===
 * anikoto.cz slugs look like "<kebab-title>-<5-char-random-id>"
 * (e.g. one-piece-odmau). The 5-char id is an opaque per-title token, so it
 * cannot be derived from the title, and a title-only slug returns HTTP 404.
 *
 * There is also NO working keyword search on the site: both /filter and
 * /search return an unrelated catalog, so searching for a title does not
 * return that title's page. And many titles have multiple slugs (movies,
 * OVAs, specials, arc recaps, AND per-season entries) that share the same
 * kebab-key family, so a naive "first match" picks the wrong entry (e.g.
 * "Sword Art Online" -> its Season 2 slug, "My Hero Academia Season 2" -> the
 * Season 1 slug, "Gintama Season 3" -> a completely different season).
 *
 * === The resolution strategy used here (validated, season-accurate) ===
 * 1) Build a kebab-key -> slug index from the site's authoritative sitemap
 *    list-*.xml files (cached in-memory, refreshed per process).
 * 2) Fetch AniList metadata for the requested id: idMal, episodes, all title
 *    variants, and the SEQUEL relation chain (cached). The relation chain
 *    gives the authoritative season NUMBER even when the title carries no
 *    season token (e.g. "HAIKYU!! TO THE TOP" = season 4).
 * 3) Collect candidate slugs: exact key, family-prefix keys, and token-set
 *    overlap (Jaccard >= 0.6) against the base title key — a deterministic
 *    ordering so results are identical across devices/processes.
 * 4) MAL verification: read each candidate's episode-list `data-mal` and pick
 *    the slug whose data-mal == AniList idMal. This is authoritative and
 *    resolves even slugs the site labels with a different season number
 *    (e.g. the site calls Gintama° "gintama-season-4" while its data-mal is
 *    the S3 MAL id).
 * 5) Fallback scored pick that respects the requested season: season-tagged
 *    slugs match the requested season number, base slugs (or -tv/-season-1)
 *    satisfy season-1 requests, and movies/OVAs/specials/recaps are heavily
 *    penalized. When the site keys the series under a different tokenization
 *    (romaji vs English, e.g. "…ojousama…" vs "…Ojou-sama…") and no base slug
 *    exists, a near-identical token match (>= 0.8) is accepted instead.
 * 6) Last resort: the site's own keyword search (/search?keyword=…), queried
 *    with each title variant. The search is loose and NOT relevance-ranked
 *    (a failed multi-word query dumps the whole catalog), so results are
 *    token-filtered and run through the SAME MAL/season gates. If NO candidate
 *    satisfies the requested season, resolve fails cleanly (null) instead of
 *    playing the wrong season.
 *
 * The rest of the flow (watch page -> numeric id -> episode list -> server
 * list -> embed -> m3u8) is unchanged and was already correct.
 */
class AnikotoProvider : StreamProvider, SearchableProvider {

    override val id = "anikoto"
    override val label = "KOTO"
    override val backendRequired = false

    private val TAG = "AnikotoProvider"
    private val BASE = Obf.s("Mi4uKilgdXU7NDMxNS41dDkg")
    private val PLAYER_HOSTS = listOf(
        "megaplay", "vidtube", "vidwish", "megacloud", "rabbitstream", "vidstream"
    )

    // kebab-key -> list of full slugs (e.g. "one-piece" -> ["one-piece-odmau", ...])
    private var slugIndex: Map<String, List<String>>? = null
    private val indexLock = Any()

    // slug -> stats (episode count, MAL id, Aired start year), fetched once.
    private val statsCache = mutableMapOf<String, SlugStats>()
    private val statsLock = Any()

    // AniList id -> metadata (idMal, episode count, titles, SEQUEL chain).
    private val metaCache = mutableMapOf<Int, AniMeta>()
    private val metaLock = Any()

    /** AniList metadata used to match and verify a requested anime. */
    private data class AniMeta(
        val idMal: Int = 0,
        val episodes: Int? = null,
        val startYear: Int? = null,
        val titles: List<String> = emptyList(),
        val synonyms: List<String> = emptyList(),
        val prequelIds: List<Int> = emptyList()
    ) {
        val hasInfo: Boolean get() = idMal > 0 || titles.isNotEmpty() || synonyms.isNotEmpty()
    }

    /**
     * Per-slug facts pulled from the site (cached): episode count, `data-mal`
     * and the watch page's Aired start year. `data-mal` is the authoritative
     * pin when present (verified live: e.g. the site's "Gintama Season 4"
     * slug carries data-mal 28977 = AniList Gintama°), but the site's OWN
     * English season labels are shifted +1 vs MAL from season 3 onward
     * (site "Season 4" = MAL "Season 3"), so the season-tag fallback must be
     * the LAST resort, never the pin. Count + Aired year fill the gap when
     * data-mal is absent.
     */
    private data class SlugStats(
        val eps: Int = 0,
        val mal: Int = 0,
        val startYear: Int? = null
    )

    override suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int,
        totalEpisodes: Int,
        year: Int?
    ): ResolveResult? {
        val headers = ScraperEngine.defaultHeaders(referer = "$BASE/") +
                mapOf("X-Requested-With" to "XMLHttpRequest")

        // Resolve the canonical slug (MAL-verified when possible).
        val resolvedSlug = resolveSlug(title, anilistId, seasonNumber)
        if (resolvedSlug.isNullOrBlank()) {
            if (BuildConfig.DEBUG) {
                Log.w(TAG, "FAILED: could not resolve slug for '$title' (season=$seasonNumber)")
            }
            return null
        }

        if (BuildConfig.DEBUG) {
            Log.d(TAG, "=== RESOLVE: '$title' ep=$episode type=$type ===")
            Log.d(TAG, "Resolved slug: $resolvedSlug")
        }

        return resolveFromSlug(resolvedSlug, episode, type, serverCode, headers)
    }

    /** Real released-episode count for a known watch-page slug (cached site stats).
     *  Blocking network on first call — invoke from Dispatchers.IO. */
    fun episodeCountForSlug(slug: String): Int =
        if (slug.isBlank()) 0 else slugStats(slug).eps

    /** Resolve an episode directly from a known anikoto.cz watch-page slug. */
    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? {        val headers = ScraperEngine.defaultHeaders(referer = "$BASE/") +
                mapOf("X-Requested-With" to "XMLHttpRequest")
        return resolveFromSlug(slug, episode, type, serverCode, headers)
    }

    /** Servers (type, label, link-id) available for one episode of a slug. */
    private data class ServerCtx(
        val numericId: String,
        val servers: List<Triple<String, String, String>>,
        val episodeHasDub: Boolean?
    )

    /** One parsed episode entry from the episode list: its server-id string plus
     *  the sub/dub flags (null when only the lenient regex matched that episode). */
    private data class EpisodeEntry(
        val ids: String,
        val sub: Boolean?,
        val dub: Boolean?
    )

    // numericId -> episode-number -> entry, parsed ONCE per show. The payload is
    // byte-identical for every episode of a slug, so parsing it 50x per range was
    // pure waste (see [episodeEntries]). Bounded: a long session can open many
    // shows, and each One Piece-sized map is ~0.5 MB, so clear when it bloats.
    private val episodeEntriesCache = mutableMapOf<String, Map<Int, EpisodeEntry>>()
    private val episodeEntriesLock = Any()

    /**
     * Fetch + parse the episode list for [numericId] exactly once and return the
     * per-episode server-id entries. Previously every episode of a range re-parsed
     * the full payload (~650 KB for One Piece / Case Closed): 50 parses per range,
     * each allocating ~2 MB of string copies on the phone — the heap churn that
     * OOM'd large series (1000+ eps) even after the network downloads were cached.
     * Now the payload is parsed once; episodes 2..N just look up their own entry.
     * The per-episode server list fetch stays per-episode (that's the REAL data).
     */
    private fun episodeEntries(
        numericId: String,
        ajaxHeaders: Map<String, String>
    ): Map<Int, EpisodeEntry>? {
        synchronized(episodeEntriesLock) {
            episodeEntriesCache[numericId]?.let { return it }
        }
        val ajaxRespStr = ScraperEngine.fetchText(
            "$BASE/ajax/episode/list/$numericId", ajaxHeaders, useCache = true
        ) ?: return null
        val epHtml = if (ajaxRespStr.trim().startsWith("{")) {
            runCatching { JSONObject(ajaxRespStr) }.getOrNull()
                ?.optString("result", "")?.ifBlank { ajaxRespStr }
        } else ajaxRespStr
        if (epHtml.isNullOrBlank()) return null

        val byNum = LinkedHashMap<Int, EpisodeEntry>()
        val strictRe = Regex("""data-num="(\d+)"[^>]*data-sub="([01])"[^>]*data-dub="([01])"[^>]*data-ids="([^"]+)"""")
        for (m in strictRe.findAll(epHtml)) {
            val num = m.groupValues[1].toIntOrNull() ?: continue
            byNum.putIfAbsent(
                num,
                EpisodeEntry(m.groupValues[4], m.groupValues[2] == "1", m.groupValues[3] == "1")
            )
        }
        val lenientRe = Regex("""data-num="(\d+)"[^>]*data-ids="([^"]+)"""")
        for (m in lenientRe.findAll(epHtml)) {
            val num = m.groupValues[1].toIntOrNull() ?: continue
            if (num !in byNum) byNum[num] = EpisodeEntry(m.groupValues[2], null, null)
        }
        val built = byNum.toMap()
        synchronized(episodeEntriesLock) {
            if (episodeEntriesCache.size > 10) episodeEntriesCache.clear()
            episodeEntriesCache[numericId] = built
        }
        return built
    }

    /**
     * Fetch the available servers for [episode] of [slug] from the site
     * (watch page -> numeric id -> episode list -> server list), deduplicated.
     * Returns null when the episode cannot be resolved.
     */
    private suspend fun fetchServers(
        slug: String,
        episode: Int,
        headers: Map<String, String>
    ): ServerCtx? {
        // The watch page and episode-list payload are IDENTICAL for every
        // episode of a slug (verified live: one-piece-odmau's episode list is
        // ~650KB and byte-identical across fetches). Caching them means the
        // language-chip batch downloads them ONCE and episodes 2..N reuse the
        // 30s ScraperEngine cache instead of re-downloading ~37MB per range
        // (the freeze). The per-episode server list below stays uncached —
        // that's the REAL sub/dub per episode.
        val watchHtml = ScraperEngine.fetchText("$BASE/watch/$slug", headers, useCache = true)
        val numericId = extractDataId(watchHtml)

        if (numericId.isNullOrBlank()) {
            if (BuildConfig.DEBUG) {
                Log.w(TAG, "FAILED: No numeric ID found on /watch/$slug")
            }
            return null
        }

        if (BuildConfig.DEBUG) {
            Log.d(TAG, "Numeric ID: $numericId")
        }

        val ajaxHeaders = headers + mapOf(
            "Referer" to "$BASE/watch/$slug",
            "Accept" to "application/json, text/javascript, */*; q=0.01"
        )
        // The episode list is parsed ONCE per show (cached in [episodeEntries]);
        // this episode just looks up its own entry. The watch page above and the
        // episode list below are downloaded once per show (30s ScraperEngine
        // cache), and the per-episode server list further down stays uncached —
        // that's the REAL sub/dub per episode.
        val entries = episodeEntries(numericId, ajaxHeaders) ?: return null

        // NEVER fall back to a different episode when the requested number is
        // not in this slug's list. Season slugs restart numbering at 1 (e.g.
        // Gintama S2/S4 both run 1..51), so falling back to episode 1 of the
        // resolved slug silently plays the WRONG (previous season) content.
        val entry = entries[episode] ?: run {
            if (BuildConfig.DEBUG) {
                Log.w(TAG, "FAILED: Episode $episode not found in slug $slug")
            }
            return null
        }
        val epDataIds = entry.ids
        val epDubAvail = entry.dub

        if (BuildConfig.DEBUG) {
            Log.d(TAG, "Episode $episode found (dub=$epDubAvail), data-ids length: ${epDataIds.length}")
        }

        val srvJsonStr = ScraperEngine.fetchText(
            "$BASE/ajax/server/list?servers=$epDataIds", headers
        ) ?: return null
        val srvHtml = runCatching { JSONObject(srvJsonStr) }.getOrNull()
            ?.optString("result", "")?.ifBlank { srvJsonStr } ?: return null

        val servers = mutableListOf<Triple<String, String, String>>()
        val blockRe = Regex(
            """<div class="type" data-type="([^"]+)">(.*?)(?=<div class="type"|</div>\s*</div>)""",
            RegexOption.DOT_MATCHES_ALL
        )
        // Row names may carry nested tags — the site's NEW "Vidstream-1" rows are
        // written as Vidstream-1 <span>beta</span>, so the old [^<]+ capture saw
        // no plain text and dropped the whole row. Capture across tags, strip them.
        for (b in blockRe.findAll(srvHtml)) {
            val stype = b.groupValues[1]
            val block = b.groupValues[2]
            for (m in Regex("""<li[^>]*data-link-id="([^"]+)"[^>]*>(.*?)</li>""", RegexOption.DOT_MATCHES_ALL).findAll(block)) {
                servers.add(Triple(stype, m.groupValues[2].replace(Regex("<[^>]+>"), "").trim(), m.groupValues[1]))
            }
        }
        if (servers.isEmpty()) {
            for (m in Regex("""<li[^>]*data-link-id="([^"]+)"[^>]*>(.*?)</li>""", RegexOption.DOT_MATCHES_ALL).findAll(srvHtml)) {
                servers.add(Triple("unknown", m.groupValues[2].replace(Regex("<[^>]+>"), "").trim(), m.groupValues[1]))
            }
        }
        if (servers.isEmpty()) {
            if (BuildConfig.DEBUG) {
                Log.w(TAG, "FAILED: No servers found")
            }
            return null
        }

        if (BuildConfig.DEBUG) {
            Log.d(TAG, "All servers: ${servers.map { "${it.first}:${it.second}" }}")
        }

        val seen = mutableSetOf<String>()
        val uniqueServers = servers.filter { seen.add("${it.first}:${it.second}") }
        return ServerCtx(numericId, uniqueServers, epDubAvail)
    }

    /**
     * The slug->m3u8 tail of the flow (server pick -> embed -> m3u8). Shared by
     * [resolve] and [resolveWithSlug]; [listServersFor] reuses [fetchServers].
     */
    private suspend fun resolveFromSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        headers: Map<String, String>
    ): ResolveResult? {
        val ctx = fetchServers(slug, episode, headers) ?: return null
        val uniqueServers = ctx.servers

        // The site marks per-episode dub availability (data-dub). When the user
        // asked for DUB but THIS episode has no dub, fall back to SUB of the
        // same episode instead of failing or playing different content.
        val wantType = if (type == "dub" && ctx.episodeHasDub == false) "sub"
            else if (type == "dub") "dub" else "sub"

        val chosen = if (!serverCode.isNullOrBlank()) {
            val match = uniqueServers.firstOrNull { "${it.first}:${it.second}" == serverCode }
            // Only honor the stored server if its type matches the requested
            // audio type. A stale "sub:..." id must NOT be reused when the user
            // switched to DUB — otherwise the player keeps playing SUB and the
            // user has to manually re-pick the DUB server. In that case fall
            // through to the type-based auto-selection below.
            if (match != null && match.first == wantType) match else null
        } else null

        // Ordered list of servers to TRY, best first. Every candidate of the
        // wanted type is attempted so a broken embed never silently switches
        // the audio type. When the wanted type is unavailable the list falls
        // back to hsub, then the remaining servers of the SAME episode.
        val typed = uniqueServers.filter { it.first == wantType }
        val vidplay = typed.firstOrNull { it.second.contains("VidPlay", true) || it.second.contains("Vidstream", true) }
        val orderedTyped = if (vidplay != null) listOf(vidplay) + typed.filter { it != vidplay } else typed
        val candidates = if (chosen != null) {
            listOf(chosen) + orderedTyped.filter { it != chosen }
        } else {
            orderedTyped.ifEmpty { uniqueServers.filter { it.first == "hsub" }.ifEmpty { uniqueServers } }
        }
        // Last resort: when EVERY row of the wanted audio type is dead (the site
        // lists a dub row but its stream is broken — verified live on
        // chainsmoker-cat ep9), append the remaining servers of the SAME episode
        // (other audio types) so the episode still plays instead of erroring.
        // Only reached after all wanted-type rows fail — audio is never switched
        // while a working wanted-type row exists.
        val fullCandidates = candidates + uniqueServers.filter { it !in candidates }

        for (finalServer in fullCandidates) {
            if (BuildConfig.DEBUG) {
                Log.d(TAG, "Trying server: ${finalServer.first}:${finalServer.second}")
            }

            val srvRespStr = ScraperEngine.fetchText(
                "$BASE/ajax/server?get=${finalServer.third}", headers
            ) ?: continue
            val embedUrl = runCatching { JSONObject(srvRespStr) }.getOrNull()
                ?.optJSONObject("result")?.optString("url")
                ?.takeIf { it.isNotBlank() } ?: continue

            val resolved = if (PLAYER_HOSTS.any { embedUrl.contains(it, true) }) {
                resolvePlayer(embedUrl, headers, finalServer.first)
            } else null
            val m3u8 = resolved?.first ?: embedUrl

            if (m3u8.isNullOrBlank() || !m3u8.contains(".m3u8")) {
                if (BuildConfig.DEBUG) {
                    Log.w(TAG, "FAILED: no m3u8 from ${finalServer.first}:${finalServer.second}")
                }
                continue
            }

            val referer = runCatching {
                val u = URL(embedUrl); "${u.protocol}://${u.host}/"
            }.getOrDefault("$BASE/")

            return ResolveResult(
                source = id,
                servers = fullCandidates.map { "${it.first}:${it.second}" to "${it.first.uppercase()} ${it.second}" },
                url = m3u8,
                rawUrl = m3u8,
                referer = referer,
                format = "hls",
                subtitles = resolved?.second ?: emptyList(),
                notFound = false
            )
        }

        if (BuildConfig.DEBUG) {
            Log.w(TAG, "FAILED: No playable server for ep $episode")
        }
        return null
    }

    /**
     * List the available servers (code to label) for an episode, without playing.
     * Used by the player's server preloading in Koto mode (the slug is already
     * known from the catalog).
     */
    suspend fun listServersFor(
        slug: String,
        episode: Int,
        type: String
    ): List<Pair<String, String>> {
        val headers = ScraperEngine.defaultHeaders(referer = "$BASE/") +
                mapOf("X-Requested-With" to "XMLHttpRequest")
        val ctx = fetchServers(slug, episode, headers) ?: return emptyList()
        val wanted = if (type.equals("dub", ignoreCase = true)) "dub" else "sub"
        val filtered = ctx.servers.filter { server ->
            when (wanted) {
                "dub" -> server.first.equals("dub", ignoreCase = true)
                else -> server.first.equals("sub", ignoreCase = true) ||
                    server.first.equals("hsub", ignoreCase = true) ||
                    server.first.equals("ssub", ignoreCase = true) ||
                    server.first.equals("raw", ignoreCase = true)
            }
        }
        return filtered.map { "${it.first}:${it.second}" to "${it.first.uppercase()} ${it.second}" }
    }

    /**
     * Raw server types for an episode — NO sub/dub filtering. Used by the
     * language-availability chips on the detail screen, which must reflect
     * every type the site lists for the episode (SUB/HSUB/SSUB/RAW/DUB),
     * independent of the audio type currently being watched. The type filter
     * stays in [listServersFor] for the player's server picker only.
     */
    suspend fun serverTypesFor(
        slug: String,
        episode: Int
    ): Set<String> {
        val headers = ScraperEngine.defaultHeaders(referer = "$BASE/") +
                mapOf("X-Requested-With" to "XMLHttpRequest")
        val ctx = fetchServers(slug, episode, headers) ?: return emptySet()
        return ctx.servers.map { it.first }.toSet()
    }

    /**
     * Resolve the site's slug for a MyAnimeList id. Used by KotoApi's bare-id
     * detail fallback: cold-start ids (My List / Continue Watching) carry no
     * slug, but the site's episode list exposes `data-mal`, which round-trips
     * to AniList (`Media(idMal:)`) and then through the normal title search.
     */
    suspend fun resolveByMalId(malId: Int): String? {
        if (malId <= 0) return null
        val anilistId = fetchAnilistIdForMal(malId) ?: return null
        return resolveSlug("", anilistId, 1)
    }

    /** AniList id for a MAL id via Media(idMal:) — null when unknown/offline. */
    private fun fetchAnilistIdForMal(malId: Int): Int? {
        if (malId <= 0) return null
        return runCatching {
            val body = JSONObject().apply {
                put("query", "query(\$mal:Int){Media(idMal:\$mal,type:ANIME){id}}")
                put("variables", JSONObject().put("mal", malId))
            }.toString()
            val conn = URL(Obf.s("Mi4uKilgdXU9KDsqMis2dDs0MzYzKS50OTU=")).openConnection() as java.net.HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            // AniList gated the GraphQL API to browser-origin requests during their
            // stability issues (403 "temporarily disabled" otherwise) — send the
            // same browser disguise the shared AniListApi client uses.
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36")
            conn.setRequestProperty("Origin", "https://anilist.co")
            conn.setRequestProperty("Referer", "https://anilist.co/")
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
            if (conn.responseCode != 200) return@runCatching null
            val txt = conn.inputStream.bufferedReader().use { it.readText() }
            JSONObject(txt).optJSONObject("data")
                ?.optJSONObject("Media")?.optInt("id", 0)?.takeIf { it > 0 }
        }.getOrNull()
    }

    // ── Season/title matcher constants ──────────────────────────────────────
    /** How many candidates get a network data-mal check (bounded latency). */
    private val MAL_CHECK_CAP = 6

    /** Season token seen in slug kebab-keys: "season-3", "3rd-season", "-iii", trailing "-N". */
    private val SEASON_TOKEN = Regex(
        """(?:season-(\d+)|(\d+)(?:st|nd|rd|th)-season|-(ii|iii|iv|v|vi|vii)$|-(\d{1,2})$)""",
        RegexOption.IGNORE_CASE
    )

    /** Season token stripped from the requested title to derive the family base key. */
    private val SEASON_STRIP = Regex(
        """(?:season[- ]*\d+|(\d+)(?:st|nd|rd|th)[- ]season|-ii|-iii|-iv|-v|-vi|-vii|-(\d{1,2})$)""",
        RegexOption.IGNORE_CASE
    )

    private val ROMAN = mapOf("ii" to 2, "iii" to 3, "iv" to 4, "v" to 5, "vi" to 6, "vii" to 7)

    /** Movies / OVAs / specials / recaps / side content — heavily penalized. */
    private val BAD_MARKER = Regex(
        "(movie|ova|special|ona|oad|recap|mugen-train|ordinal-scale|unanswered|butterfly|" +
            "music|live|stage|comic|chibi|sd-|hen|part-\\d|arc|episode-of|trailer|pv|preview|" +
            "the-movie|film|theater-2d|picture-drama|jump-festa)"
    )

    /**
     * Resolve a title to the site's exact slug, honoring the requested season.
     *
     * Pipeline (see class KDoc for rationale):
     *  1. AniList metadata (idMal / titles / SEQUEL chain) for the requested id.
     *  2. Authoritative season number = max(app seasonNumber, relation-chain depth).
     *  3. Deterministic candidate collection (exact + family prefix + Jaccard).
     *  4. MAL verification over the top-ranked candidates (authoritative).
     *  5. Scored fallback gated on the requested season; null when the site
     *     does not carry that season (never play the wrong season).
     *
     * @param title        anime title from the player
     * @param anilistId    AniList id (used for idMal + relation-chain season)
     * @param seasonNumber season number inferred by the app from the title
     */
    private fun resolveSlug(title: String, anilistId: Int, seasonNumber: Int): String? {
        val raw = normalize(title)
        val meta = fetchAniMeta(anilistId)

        // A blank title is only acceptable when authoritative AniList metadata is
        // available (the MAL-bridge path used by KotoApi's bare-id fallback);
        // otherwise there is nothing to match against.
        if (raw.isBlank() && !meta.hasInfo) return null

        var season = seasonNumber
        if (season <= 1) {
            val chain = relationsSeason(anilistId, meta)
            if (chain > 1) season = chain
        }

        val index = getSlugIndex()
        val base = baseKey(raw)
        val titleKeys = buildList {
            add(raw)
            if (base != raw) add(base)
            meta.titles.forEach { t -> normalize(t).takeIf { it.isNotBlank() }?.let { add(it) } }
            meta.synonyms.forEach { s -> normalize(s).takeIf { it.isNotBlank() }?.let { add(it) } }
        }.distinct()

        val candidates = collectCandidates(index, titleKeys)
        val ranked = candidates.sortedByDescending { scoreSlug(it, titleKeys, raw, season) }

        // 1) MAL verification (authoritative when data-mal is present).
        // 2) Scored fallback gated on the requested season.
        pickFromRanked(ranked, meta, titleKeys, raw, base, season, index)?.let { return it }

        // 3) Last resort: the site's own search. Its keyword search is loose
        //    (not relevance-ranked, returns the whole catalog on a failed AND),
        //    but distinctive English/romaji words do surface the right slug
        //    even when tokenization/transliteration defeat the sitemap match.
        val searchRanked = searchSlugs(titleKeys)
            .sortedByDescending { scoreSlug(it, titleKeys, raw, season) }
        if (searchRanked.isNotEmpty()) {
            pickFromRanked(searchRanked, meta, titleKeys, raw, base, season, index)?.let { return it }
        }

        if (BuildConfig.DEBUG) {
            Log.w(TAG, "No slug on site for requested season=$season ('$title')")
        }
        return null
    }

    /**
     * MAL-verifies the top candidates, then applies the season-gated scored
     * fallback. A bare season-1 request must land on the base slug itself (or a
     * -tv/-season-1 variant), never on a subtitled spin-off/sequel. Exception:
     * when the site keys the series under a different tokenization than the
     * request (e.g. romaji "…ojousama…" vs English "…Ojou-sama…") there is no
     * base slug on the site — then a near-identical token match (>= 0.8) to a
     * title variant is accepted.
     */
    private fun pickFromRanked(
        ranked: List<String>,
        meta: AniMeta,
        titleKeys: List<String>,
        raw: String,
        base: String,
        season: Int,
        index: Map<String, List<String>>
    ): String? {
        if (meta.idMal > 0) {
            for (slug in ranked.take(MAL_CHECK_CAP)) {
                if (slugStats(slug).mal == meta.idMal) {
                    if (BuildConfig.DEBUG) {
                        Log.d(TAG, "slug MAL-verified: $slug (mal=${meta.idMal})")
                    }
                    return slug
                }
            }
        }

        // Episode-count + Aired-year verification. Covers slugs whose data-mal
        // is absent while still honoring the site's shifted season labels:
        // e.g. Gintama° (51 eps, 2015) is the slug the site mislabels "Season 4"
        // — a count+year match pins it correctly, whereas the season-tag
        // fallback below would either miss it or pick the wrong season.
        if (meta.episodes != null && meta.episodes > 0) {
            for (slug in ranked.take(MAL_CHECK_CAP)) {
                val st = slugStats(slug)
                if (st.eps <= 0) continue
                val yearOk = st.startYear == null || meta.startYear == null ||
                    st.startYear == meta.startYear
                if (!yearOk) continue
                val countExact = kotlin.math.abs(st.eps - meta.episodes) <= 1
                // Bundled halves: the site sometimes merges parts into one entry
                // (e.g. Silver Soul Arc 12+14 episodes in a single 26-ep list).
                val bundledOk = st.startYear != null && meta.startYear != null &&
                    st.eps >= meta.episodes && st.eps - meta.episodes <= 16
                if (countExact || bundledOk) {
                    if (BuildConfig.DEBUG) {
                        Log.d(TAG, "slug count/year-verified: $slug (eps=${st.eps}, year=${st.startYear})")
                    }
                    return slug
                }
            }
        }

        for (slug in ranked) {
            val ck = slugKeypart(slug)
            if (season <= 1) {
                val baseOk = strictBaseOk(ck, raw, base)
                val strongRomaji = ck != raw && raw == base && !index.containsKey(base) &&
                    bestTokenSim(ck, titleKeys) >= 0.8
                if (!baseOk && !strongRomaji) continue
            }
            if (seasonOk(seasonOfKey(ck), season)) {
                if (BuildConfig.DEBUG) {
                    Log.d(TAG, "slug season-matched: $slug (requested season=$season)")
                }
                return slug
            }
        }
        return null
    }

    /**
     * Queries the site's keyword search with each title variant (full and the
     * leading/trailing word pairs, since the search matches distinctive short
     * phrases far better than a long AND query). Returns the slugs whose key
     * shares meaningful tokens with a title variant (noise filter: a failed
     * search returns the whole catalog, which token overlap drops out).
     */
    private fun searchSlugs(titleKeys: List<String>): List<String> {
        val queries = buildList {
            titleKeys.forEach { key ->
                val words = key.split("-").filter { it.isNotEmpty() }
                if (words.isNotEmpty()) {
                    add(words.joinToString(" ")) // the site search wants space-separated words
                    if (words.size > 2) {
                        add(words.take(2).joinToString(" "))
                        add(words.drop(words.size - 2).joinToString(" "))
                    }
                }
            }
        }.distinct().filter { it.length >= 4 }

        val headers = ScraperEngine.defaultHeaders(referer = "$BASE/")
        val seen = LinkedHashSet<String>()
        for (q in queries) {
            val page = ScraperEngine.fetchText(
                "$BASE/search?keyword=${URLEncoder.encode(q, "UTF-8")}", headers
            ) ?: continue
            val slugs = Regex(Obf.s("Mig/PGd4Mi4uKilgdXU7NDMxNS41BnQ5IHUtOy45MnVyATt3IGp3Y3cHcXNyZWB1Pyp3Bj5xc2V4"))
                .findAll(page).map { it.groupValues[1] }.distinct().toList()
            for (slug in slugs) {
                val ck = slugKeypart(slug)
                if (bestTokenSim(ck, titleKeys) >= 0.3) seen.add(slug)
            }
            if (seen.size >= 24) break
        }
        return seen.toList()
    }

    /**
     * Candidate slugs whose kebab-key matches any title variant: exact key,
     * family-prefix keys (key.startsWith(titleKey + "-")), and token-set
     * overlap (Jaccard >= 0.6) against ANY title variant. Iterating index keys
     * in sorted order keeps the result deterministic across devices/processes.
     *
     * The Jaccard pass must consider every title variant, not just the English
     * base: sites often kebab the romaji with different tokenization than
     * AniList (e.g. site "…gakuin-ichi-no-ojousama…" vs AniList romaji
     * "…Gakuin Ichi no Ojou-sama…"), so a variant that looks like an exact
     * match actually differs token-by-token and only surfaces via part-by-part
     * (token) similarity.
     */
    private fun collectCandidates(
        index: Map<String, List<String>>,
        titleKeys: List<String>
    ): List<String> {
        val sortedKeys = index.keys.sorted()
        val matched = LinkedHashSet<String>()
        for (k in titleKeys) if (index.containsKey(k)) matched.add(k)
        for (k in titleKeys) {
            val p = "$k-"
            for (ik in sortedKeys) if (ik.startsWith(p)) matched.add(ik)
        }
        for (ik in sortedKeys) {
            if (titleKeys.any { tokenJaccard(it, ik) >= 0.6 }) matched.add(ik)
        }
        // Token-subset candidates: the site often truncates very long titles
        // ("ROLL OVER AND DIE: …cursed sword!" -> "roll-over-and-die"). If every
        // token of one side appears in the other, the pair belongs to the same
        // family; identity is still pinned down later by MAL verification.
        for (ik in sortedKeys) {
            val a = ik.split("-").filter { it.isNotEmpty() }.toSet()
            if (a.isEmpty()) continue
            if (titleKeys.any { t ->
                    val b = t.split("-").filter { it.isNotEmpty() }.toSet()
                    b.isNotEmpty() && (a.all { it in b } || b.all { it in a })
                }) matched.add(ik)
        }
        if (matched.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        for (k in matched) index[k]?.let { out.addAll(it) }
        return out.toList()
    }

    /** Deterministic ranking used to order MAL checks + fallback selection. */
    private fun scoreSlug(slug: String, titleKeys: List<String>, raw: String, season: Int): Double {
        val ck = slugKeypart(slug)
        var s = 2.5 * bestTokenSim(ck, titleKeys)
        if (ck == raw) s += 1.5 else if (ck.startsWith("$raw-")) s += 0.6
        // The site's own kebab-key for the requested title must always outrank
        // its season-tagged / subtitled siblings so the MAL and count/year
        // verification windows actually see it. Without this, a +3 season bonus
        // and the movie/arc penalty can bury the exact-key slug past the
        // MAL_CHECK_CAP window (e.g. Silver Soul Arc vs the site's "Season 5").
        if (titleKeys.any { it == ck }) s += 8.0
        // Subtitled/verbose keys (movies, specials, arc recaps) usually run much
        // longer than the requested key; nudge them down when MAL is absent.
        s -= (ck.length - raw.length).coerceAtLeast(0) * 0.1
        val declared = seasonOfKey(ck)
        s += when {
            season <= 1 -> if (declared <= 1) 1.2 else -2.5
            declared == season -> 3.0
            declared == 1 -> -1.5
            else -> -2.0
        }
        if (BAD_MARKER.containsMatchIn(ck)) s -= 4.0
        return s
    }

    /**
     * A bare season-1 request ("Sword Art Online", "Gintama") must resolve to the
     * base slug itself (or an explicit -tv / -season-1 variant) — never to a
     * subtitled family slug that is actually a later season, a spin-off or a
     * movie. Subtitled requests (raw != base) are distinct titles and may match
     * their own family slugs.
     */
    private fun strictBaseOk(ck: String, raw: String, base: String): Boolean {
        if (ck == raw) return true
        if (raw == base) {
            return ck == "$base-tv" || ck == "$base-season-1"
        }
        return true
    }

    /** True when a slug's declared season satisfies the requested season. */
    private fun seasonOk(declared: Int, requested: Int): Boolean =
        if (requested <= 1) declared <= 1 else declared == requested

    /** Season number declared by a slug's kebab-key (1 when unmarked). */
    private fun seasonOfKey(key: String): Int {
        if (key.contains("-part-")) return 1
        val m = SEASON_TOKEN.find(key) ?: return 1
        m.groupValues[1].toIntOrNull()?.let { return it }
        m.groupValues[2].toIntOrNull()?.let { return it }
        m.groupValues[3].lowercase().let { if (it.isNotEmpty()) return ROMAN[it] ?: 1 }
        m.groupValues[4].toIntOrNull()?.let { return if (it in 2..9) it else 1 }
        return 1
    }

    /** Base family key: requested title with any trailing season token removed. */
    private fun baseKey(raw: String): String {
        val stripped = SEASON_STRIP.replace(raw, "").trim('-')
        return stripped.ifBlank { raw }
    }

    private fun tokenJaccard(a: String, b: String): Double {
        val A = a.split("-").filter { it.isNotEmpty() }.toSet()
        val B = b.split("-").filter { it.isNotEmpty() }.toSet()
        if (A.isEmpty() || B.isEmpty()) return 0.0
        val inter = A.intersect(B).size
        return inter.toDouble() / (A.size + B.size - inter)
    }

    private fun bestTokenSim(ck: String, keys: List<String>): Double {
        val A = ck.split("-").filter { it.isNotEmpty() }.toSet()
        if (A.isEmpty()) return 0.0
        var best = 0.0
        for (k in keys) {
            val B = k.split("-").filter { it.isNotEmpty() }.toSet()
            if (B.isEmpty()) continue
            val r = A.intersect(B).size.toDouble() / maxOf(A.size, B.size)
            if (r > best) best = r
        }
        return best
    }

    /** Strip the random 5-char id suffix, leaving the readable kebab-key. */
    private fun slugKeypart(slug: String): String {
        val m = Regex("^(.*)-([a-z0-9]{5})$").find(slug)
        return m?.groupValues?.get(1) ?: slug
    }

    /** Lazily build the sitemap slug index (kebab-key -> slugs). */
    private fun getSlugIndex(): Map<String, List<String>> {
        synchronized(indexLock) {
            slugIndex?.let { return it }
            val map = mutableMapOf<String, MutableList<String>>()
            runCatching {
                val idx = ScraperEngine.fetchText("$BASE/sitemap.xml") ?: return@runCatching
                val files = Regex(Obf.s("ZjY1OWRyMi4uKilgdXU7NDMxNS41BnQ5IHUpMy4/NzsqdTYzKS53Bj5xBnQiNzZzZnU2NTlk"))
                    .findAll(idx).map { it.groupValues[1] }
                for (f in files) {
                    val xml = ScraperEngine.fetchText(f) ?: continue
                    for (m in Regex(Obf.s("ZjY1OWRyMi4uKilgdXU7NDMxNS41BnQ5IHUtOy45MnUBBGYHcXNmdTY1OWQ=")).findAll(xml)) {
                        val slug = m.groupValues[1].substringAfter("/watch/")
                        val km = Regex("""^(.*)-([a-z0-9]{5})$""").find(slug)
                        val k = km?.groupValues?.get(1) ?: slug
                        map.getOrPut(k) { mutableListOf() }.add(slug)
                    }
                }
            }
            val built = map.toMap()
            slugIndex = built
            if (BuildConfig.DEBUG) {
                Log.d(TAG, "Built slug index: ${built.size} keys")
            }
            return built
        }
    }

    /**
     * Stats for a slug: episode count, data-mal, and the watch page's Aired
     * start year (all cached). Fetches the watch page + episode list once per
     * slug; the two requests are the same ones the old slugMal() made.
     */
    private fun slugStats(slug: String): SlugStats {
        synchronized(statsLock) {
            statsCache[slug]?.let { return it }
        }
        var stats = SlugStats()
        runCatching {
            val watchHtml = ScraperEngine.fetchText("$BASE/watch/$slug") ?: return@runCatching
            val nid = extractDataId(watchHtml) ?: return@runCatching
            val eps = ScraperEngine.fetchText(
                "$BASE/ajax/episode/list/$nid",
                ScraperEngine.defaultHeaders(referer = "$BASE/watch/$slug") +
                        mapOf("X-Requested-With" to "XMLHttpRequest")
            ) ?: return@runCatching
            val html = runCatching { JSONObject(eps) }.getOrNull()
                ?.optString("result", "")?.ifBlank { eps } ?: ""
            val mal = Regex("""data-mal="(\d+)""").find(html)
                ?.groupValues?.get(1)?.toIntOrNull() ?: 0
            val epsMax = Regex("""data-num="(\d+)""").findAll(html)
                .mapNotNull { it.groupValues[1].toIntOrNull() }.maxOrNull() ?: 0
            val aired = Regex("""Aired:\s*<span>\s*([^<]+)""").find(watchHtml)
                ?.groupValues?.get(1)
            val startYear = aired?.let { parseAiredStartYear(it) }
            stats = SlugStats(epsMax, mal, startYear)
        }
        synchronized(statsLock) { statsCache[slug] = stats }
        return stats
    }

    /** "Jan 3, 2015 to Mar 27, 2015" -> 2015. */
    private fun parseAiredStartYear(aired: String?): Int? {
        val m = Regex("""([A-Za-z]+)\s+\d{1,2},\s+(\d{4})""").find(aired?.trim().orEmpty())
            ?: return null
        return m.groupValues[2].toIntOrNull()
    }

    /**
     * Fetches AniList metadata for [anilistId]: idMal, episode count, all title
     * variants, synonyms and the SEQUEL relation chain (used to derive the
     * season number when the title carries none). Cached per process. Returns
     * an empty [AniMeta] on any failure — matching then relies on the score
     * fallback.
     */
    private fun fetchAniMeta(anilistId: Int): AniMeta {
        if (anilistId <= 0) return AniMeta()
        synchronized(metaLock) {
            metaCache[anilistId]?.let { return it }
        }
        val meta = runCatching {
            val body = JSONObject().apply {
                put(
                    "query",
                    "query(\$id:Int){Media(id:\$id,type:ANIME){" +
                        "idMal episodes seasonYear synonyms title{romaji english native}" +
                        "relations{edges{relationType node{id}}}}" +
                        "}"
                )
                put("variables", JSONObject().put("id", anilistId))
            }.toString()
            val url = URL(Obf.s("Mi4uKilgdXU9KDsqMis2dDs0MzYzKS50OTU="))
            val conn = url.openConnection() as java.net.HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            // AniList gated the GraphQL API to browser-origin requests during their
            // stability issues (403 "temporarily disabled" otherwise) — send the
            // same browser disguise the shared AniListApi client uses.
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36")
            conn.setRequestProperty("Origin", "https://anilist.co")
            conn.setRequestProperty("Referer", "https://anilist.co/")
            conn.connectTimeout = 15000
            conn.readTimeout = 15000
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
            if (conn.responseCode == 200) {
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val media = JSONObject(txt)
                    .optJSONObject("data")?.optJSONObject("Media") ?: return@runCatching null
                val t = media.optJSONObject("title")
                val syn = media.optJSONArray("synonyms")
                val rels = media.optJSONObject("relations")?.optJSONArray("edges")
                AniMeta(
                    idMal = media.optInt("idMal", 0),
                    episodes = media.optInt("episodes", 0).takeIf { it > 0 },
                    startYear = media.optInt("seasonYear", 0).takeIf { it > 0 },
                    titles = listOfNotNull(t?.optString("romaji"), t?.optString("english"), t?.optString("native")),
                    synonyms = syn?.let { (0 until it.length()).map { i -> it.optString(i) } } ?: emptyList(),
                    prequelIds = rels?.let { arr ->
                        (0 until arr.length()).mapNotNull { i ->
                            val e = arr.optJSONObject(i)
                            if (e?.optString("relationType") == "PREQUEL") e.optJSONObject("node")?.optInt("id", 0)?.takeIf { it > 0 }
                            else null
                        }
                    } ?: emptyList()
                )
            } else null
        }.getOrNull() ?: AniMeta()
        synchronized(metaLock) { metaCache[anilistId] = meta }
        return meta
    }

    /**
     * Authoritative season number from the AniList SEQUEL chain: count PREQUEL
     * hops back to the root of the franchise (capped). Only meaningful when the
     * title itself carries no season token (e.g. "HAIKYU!! TO THE TOP" -> 4).
     */
    private fun relationsSeason(anilistId: Int, seed: AniMeta): Int {
        if (anilistId <= 0) return 1
        var depth = 1
        var cur = anilistId
        var meta = seed
        val seen = mutableSetOf<Int>()
        repeat(6) {
            if (cur <= 0 || !seen.add(cur)) return depth
            if (!meta.hasInfo) {
                meta = fetchAniMeta(cur)
                if (!meta.hasInfo) return depth
            }
            val preq = meta.prequelIds.firstOrNull { it !in seen } ?: return depth
            cur = preq
            depth++
            meta = AniMeta()
        }
        return depth
    }

    /**
     * Lowercase kebab normalization shared by titles and site keys. Diacritics
     * are decomposed first (NFD + strip combining marks) so accented letters
     * map to their plain ASCII form ("Zürückspulen" -> "zuruckspulen", not
     * "zur-ckspulen").
     */
    private fun normalize(title: String): String {
        val flat = java.text.Normalizer.normalize(title, java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return flat.lowercase().trim()
            .replace("&", "and")
            .replace(Regex("[^a-z0-9]+"), "-")
            .replace(Regex("-+"), "-")
            .trim('-')
    }

    private fun extractDataId(html: String?): String? {
        if (html.isNullOrBlank()) return null
        return Regex("""data-id="(\d+)""").find(html)?.groupValues?.get(1)
    }

    // AES-256-CBC key/IV used by the megaplay/vidplay player to encrypt the
    // getSources `enc` blob. The live values ship in the host's newclient.min.js
    // (var E=key, C=iv); they can rotate, so we fetch + parse that file at
    // runtime and only fall back to these verified current values on failure.
    private val MEGAPLAY_KEY_FALLBACK = "i?LMTAx0Q6,:}50U"
    private val MEGAPLAY_IV_FALLBACK = "W0;27ToaUpl_P%'c"

    // host -> (key, iv), parsed once per process from newclient.min.js.
    private val megaplayCipherCache = mutableMapOf<String, Pair<String, String>>()
    private val megaplayCipherLock = Any()

    /**
     * Resolve the m3u8 from a megaplay-family embed. The site now (2025) returns
     * getSources as {tracks, t, intro, outro, server, enc} where `enc` is the
     * playlist URL encrypted with AES-256-CBC (key/IV from the host's
     * newclient.min.js), instead of the old plain {sources:{file}}. Both shapes
     * are handled so an old/plain host keeps working.
     */
    private fun resolvePlayer(embedUrl: String, headers: Map<String, String>, serverType: String): Pair<String, List<AniwavesApi.SubtitleTrack>>? {
        val host = runCatching {
            val u = URL(embedUrl); "${u.protocol}://${u.host}"
        }.getOrNull() ?: return null
        // The site's CDN selector rides on the embed URL's own ?s= (Vidstream
        // rows carry none, HD-1 -> tcdn, HD-2 -> bcdn) and is what getSources
        // keys on: tcdn -> megap.*, bcdn -> ncdn.imgnex.top (blocks apps),
        // none -> fetch.nexabloom.top (needs HMAC token). The rows the site
        // actually plays from (Vidstream-2/Vidstream-1 beta) are the NO-s ones,
        // so the no-s candidate MUST be tried — missing it means EP9 dub and
        // EP10 (whose tcdn rows are broken/absent) never resolve. Try the row's
        // own s first, then nexabloom, then the mirrors; keep the first
        // candidate whose master actually serves a playlist.
        val embedS = runCatching {
            URL(embedUrl).query?.split("&")?.mapNotNull { pair ->
                val kv = pair.split("=", limit = 2)
                if (kv.size == 2 && kv[0] == "s" && kv[1].isNotBlank()) kv[1] else null
            }?.firstOrNull()
        }.getOrNull()
        val sCandidates = buildList<String?> {
            add(embedS)
            add("tcdn")
            add("bcdn")
            if (embedS == null) add(null)
        }.distinct()
        val embedHtml = ScraperEngine.fetchText(
            embedUrl, headers + mapOf("Referer" to "$BASE/")
        ) ?: return null
        val pid = Regex("""data-id="([^"]+)""").find(embedHtml)?.groupValues?.get(1)
            ?: return null
        val settingsType = Regex("""type:\s*['"]([^'"]+)['"]""")
            .find(embedHtml)?.groupValues?.get(1)?.lowercase()
            ?.takeIf { it == "dub" || it == "sub" || it == "hsub" }
        val type = settingsType
            ?: serverType.takeIf { it == "dub" || it == "sub" || it == "hsub" }
        val base = buildString {
            if (!type.isNullOrBlank()) append("&type=$type")
        }
        val cdnHeaders = headers + mapOf("Referer" to "$host/")

        // Try each CDN selector until one yields a stream that is actually
        // playable (master + variant + first segment all serve and the segment
        // starts with an MPEG-TS sync byte). The no-s candidate resolves to the
        // token-gated nexabloom master — sign it narrowly (megap/imgnex play
        // unsigned). getSources 403s for s values an episode has no content for
        // (EP10 has no tcdn), and tcdn can resolve to megap.akirax which does
        // not stream on-device while the bcdn mirror (imgnex) blocks apps.
        for (s in sCandidates) {
            val srcJson = ScraperEngine.fetchText(
                "$host/stream/getSources?id=$pid$base" + if (s.isNullOrBlank()) "" else "&s=$s",
                cdnHeaders
            )?.let { runCatching { JSONObject(it) }.getOrNull() } ?: continue

            // Old (plain) shape: {sources:{file:"...m3u8"}}; new (encrypted)
            // shape: {enc:"base64url..."} -> {"file":".../master.m3u8"}.
            val m3u8 = srcJson.optJSONObject("sources")?.optString("file")
                ?.takeIf { it.isNotBlank() }
                ?: srcJson.optString("enc").takeIf { it.isNotBlank() }
                    ?.let { decryptEnc(it, host) }
            if (m3u8 == null) continue
            if (!m3u8.contains(".m3u8")) continue
            // Only nexabloom (the no-s route) gates its master behind the HMAC
            // token; megap/imgnex masters play unsigned on-device. Signing the
            // tcdn master is what broke playback earlier, so sign narrowly.
            val playableM3u8 = if ("nexabloom" in m3u8.lowercase()) {
                MegaplayCdnSigner.signed(m3u8)
            } else m3u8
            if (!megaplayStreamPlaysBack(playableM3u8, cdnHeaders)) continue

            // Subtitle tracks ride on the SAME getSources response (verified
            // live: {tracks:[{file:"...vtt",label:"English",kind:"captions"},...],
            // enc:...}).
            val seen = mutableSetOf<String>()
            val subs = srcJson.optJSONArray("tracks")?.let { arr ->
                (0 until arr.length()).mapNotNull { i ->
                    val t = arr.optJSONObject(i) ?: return@mapNotNull null
                    val kind = t.optString("kind")
                    if (kind == "thumbnails" || kind == "preview") return@mapNotNull null
                    val url = t.optString("file").ifBlank { t.optString("src") }
                    if (url.isBlank()) return@mapNotNull null
                    val label = t.optString("label").ifBlank { "Unknown" }
                    if (!seen.add("$url|$label")) return@mapNotNull null
                    AniwavesApi.SubtitleTrack(label.lowercase().replace(Regex("\\s+"), "-"), label, url)
                }
            } ?: emptyList()
            return playableM3u8 to subs
        }
        return null
    }

    /**
     * Cheap end-to-end check that [streamUrl] is served AND its first segment
     * is real MPEG-TS (0x47 sync at byte 0). tcdn streams on megap can resolve
     * to a host that 403s or serves a fake PNG-wrapped header the app's data
     * source cannot play; bcdn (imgnex) serves clean 0x47 throughout.
     */
    private fun megaplayStreamPlaysBack(streamUrl: String, headers: Map<String, String>): Boolean {
        val stream = ScraperEngine.fetchText(streamUrl, headers, timeoutMs = 12_000L, maxRetries = 1)
            ?: return false
        val line = stream.lineSequence()
            .map { it.trim() }
            .firstOrNull { it.isNotBlank() && !it.startsWith("#") }
            ?: return false
        val variantUrl = if (line.startsWith("http")) line else streamUrl.substringBeforeLast('/') + "/" + line
        val variant = ScraperEngine.fetchText(variantUrl, headers, timeoutMs = 12_000L, maxRetries = 1)
            ?: return false
        val seg = variant.lineSequence()
            .map { it.trim() }
            .firstOrNull { it.isNotBlank() && !it.startsWith("#") }
            ?: return false
        val segUrl = if (seg.startsWith("http")) seg else variantUrl.substringBeforeLast('/') + "/" + seg
        val head = ScraperEngine.fetchResponse(segUrl, headers) ?: return false
        try {
            if (!head.isSuccessful) return false
            val body = head.body ?: return false
            return body.use { b ->
                val source = b.source()
                try {
                    source.require(1)
                    source.buffer.readByte().toInt() == 0x47
                } catch (e: Exception) {
                    false
                }
            }
        } catch (e: Exception) {
            return false
        }
    }

    /** Parse the AES key/IV out of the host's newclient.min.js (cached). */
    private fun megaplayCipher(host: String): Pair<String, String> {
        synchronized(megaplayCipherLock) {
            megaplayCipherCache[host]?.let { return it }
        }
        var key = MEGAPLAY_KEY_FALLBACK
        var iv = MEGAPLAY_IV_FALLBACK
        runCatching {
            val js = ScraperEngine.fetchText(
                "$host/lib/newclient.min.js",
                ScraperEngine.defaultHeaders(referer = "$host/"),
                timeoutMs = 8000L, maxRetries = 1
            ) ?: return@runCatching
            Regex("""var\s+E="([^"]+)",C="([^"]+)""").find(js)?.let { m ->
                val k = m.groupValues[1].takeIf { it.isNotBlank() }
                val v = m.groupValues[2].takeIf { it.isNotBlank() }
                if (k != null && v != null) {
                    key = k
                    iv = v
                }
            }
        }
        val pair = key to iv
        synchronized(megaplayCipherLock) { megaplayCipherCache[host] = pair }
        return pair
    }

    /**
     * AES-256-CBC decrypt of the getSources `enc` blob (base64url). Key is the
     * player key zero-padded to 32 bytes; IV is the 16-byte player IV. Returns
     * the decrypted JSON's "file" (the m3u8) or null.
     */
    private fun decryptEnc(enc: String, host: String): String? {
        return runCatching {
            val (keyStr, ivStr) = megaplayCipher(host)
            // base64url -> standard base64 (the blob is unpadded).
            val std = enc.replace('-', '+').replace('_', '/')
            val pad = (4 - std.length % 4) % 4
            val ct = android.util.Base64.decode(std + "=".repeat(pad), android.util.Base64.DEFAULT)

            val keyBytes = ByteArray(32)
            keyStr.toByteArray(Charsets.UTF_8).copyInto(
                keyBytes, 0, 0, minOf(32, keyStr.toByteArray(Charsets.UTF_8).size)
            )
            val ivBytes = ivStr.toByteArray(Charsets.UTF_8).copyOf(16)

            val cipher = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(
                javax.crypto.Cipher.DECRYPT_MODE,
                javax.crypto.spec.SecretKeySpec(keyBytes, "AES"),
                javax.crypto.spec.IvParameterSpec(ivBytes)
            )
            val plain = String(cipher.doFinal(ct), Charsets.UTF_8).trim()
            JSONObject(plain).optString("file").takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    override suspend fun search(query: String): List<StreamProvider.SearchHit> {
        if (query.isBlank()) return emptyList()
        return KotoApi.search(query).map { anime ->
            StreamProvider.SearchHit(title = anime.title, slug = anime.kotoSlug ?: "", posterUrl = anime.posterUrl)
        }
    }

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        if (query.isBlank()) return PagedResult(emptyList(), 1)
        // Single /filter page + the site's own last-page number for manual paging.
        val res = KotoApi.searchPage(query, page)
        return PagedResult(
            items = res.items.map { anime ->
                StreamProvider.SearchHit(title = anime.title, slug = anime.kotoSlug ?: "", posterUrl = anime.posterUrl)
            },
            lastPage = res.lastPage
        )
    }
}
