package com.panime.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.SentimentDissatisfied
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.OrangeGlow
import com.panime.app.ui.theme.OrangePrimary
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary

/**
 * Rule 4 — Consumer-grade full-screen error state.
 * Expressive vector illustration + friendly copy + prominent accent Retry button.
 * Accepts either a raw [Throwable] or a legacy message string; both are mapped
 * through [toFriendlyError] so no raw code ever reaches the layout.
 */
@Composable
fun ErrorBox(message: String, onRetry: (() -> Unit)? = null) {
    FriendlyErrorScreen(message.toFriendlyError(), onRetry)
}

@Composable
fun ErrorBox(error: Throwable, onRetry: (() -> Unit)? = null) {
    FriendlyErrorScreen(error.toFriendlyError(), onRetry)
}

@Composable
fun FriendlyErrorScreen(error: FriendlyError, onRetry: (() -> Unit)?) {
    val icon: ImageVector = when (error.icon) {
        FriendlyErrorIcon.OFFLINE -> Icons.Default.CloudOff
        FriendlyErrorIcon.TIMEOUT -> Icons.Default.HourglassEmpty
        FriendlyErrorIcon.NOT_FOUND -> Icons.Default.SearchOff
        FriendlyErrorIcon.RATE_LIMIT -> Icons.Default.Speed
        FriendlyErrorIcon.GENERIC -> Icons.Default.SentimentDissatisfied
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Background)
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(OrangeGlow),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = OrangePrimary,
                modifier = Modifier.size(56.dp)
            )
        }
        Spacer(Modifier.height(24.dp))
        Text(
            error.title,
            style = MaterialTheme.typography.headlineSmall,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Text(
            error.message,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )
        if (onRetry != null) {
            Spacer(Modifier.height(28.dp))
            PrimaryPillButton(text = "Retry", onClick = onRetry, leadingIcon = Icons.Default.Refresh)
        }
    }
}
