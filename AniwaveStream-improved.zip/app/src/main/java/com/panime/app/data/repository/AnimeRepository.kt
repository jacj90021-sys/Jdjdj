package com.panime.app.data.repository

import com.panime.app.data.api.AniListApi
import com.panime.app.data.api.AniwavesCatalog
import com.panime.app.data.api.KotoApi
import com.panime.app.data.model.AlMedia
import com.panime.app.data.model.AiringSchedule
import com.panime.app.data.model.AlResponse
import com.panime.app.data.model.Anime
import com.panime.app.data.model.Character
import com.panime.app.data.model.BrowseGenres
import com.panime.app.data.model.DetailData
import com.panime.app.data.model.GenreChip
import com.panime.app.data.model.PagedResult
import com.panime.app.data.model.ScheduleDay
import com.panime.app.data.model.currentWeekScheduleDays
import com.panime.app.data.model.toAnime
import com.panime.app.data.model.toCharacter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

class AnimeRepository(
    private val json: Json = Json { ignoreUnknownKeys = true; isLenient = true; coerceInputValues = true }
) {
    /** Active discovery data source. Set from UserLibraryStore.apiProvider at launch. */
    @Volatile var provider: String = "anilist"

    private val cache = mutableMapOf<Int, Anime>()
    private val requestTimes = ArrayDeque<Long>()
    private val rateMutex = Mutex()
    /** Per-filter result cache for Browse (letter/year/genre) so re-selecting a
     *  filter reuses the prior network result instead of re-hitting AniList. */
    private val cacheResults = mutableMapOf<String, List<Anime>>()
    /**
     * Real last-page cache keyed by filter (e.g. "year:2025", "genre:Action").
     * AniList's pageInfo.lastPage is often a hard cap (100 / total 5000) and does
     * NOT reflect how many pages a filtered query actually has — so we discover
     * the true last page once and reuse it for the rest of the session.
     */
    private val realLastPageCache = mutableMapOf<String, Int>()

    // AniList unauthenticated limit is 90 req/min. Serialize ALL requests through one
    // mutex + a rolling 60s window so parallel calls can't burst past the limit and get
    // HTTP 429 (which previously dropped characters/recommendations on detail screens).
    private val MIN_GAP_MS = 750L
    private val WINDOW_MS = 60_000L
    private val MAX_PER_WINDOW = 85

    private suspend fun throttle() {
        rateMutex.withLock {
            val now = System.currentTimeMillis()
            while (requestTimes.isNotEmpty() && now - requestTimes.first() > WINDOW_MS) {
                requestTimes.removeFirst()
            }
            if (requestTimes.size >= MAX_PER_WINDOW) {
                val wait = (requestTimes.first() + WINDOW_MS - now).coerceAtLeast(0L) + 50L
                delay(wait)
            } else {
                val since = requestTimes.lastOrNull()?.let { now - it } ?: Long.MAX_VALUE
                val wait = (MIN_GAP_MS - since).coerceAtLeast(0L)
                if (wait > 0) delay(wait)
            }
            requestTimes.addLast(System.currentTimeMillis())
        }
    }

    private fun remember(list: List<Anime>): List<Anime> {
        list.forEach { cache[it.id] = it }
        return list
    }

    private fun parse(text: String): AlResponse {
        val resp = json.decodeFromString<AlResponse>(text)
        if (resp.errors?.isNotEmpty() == true) {
            throw RuntimeException(resp.errors.first().message)
        }
        return resp
    }

    private fun page(text: String): List<AlMedia> =
        parse(text).data?.Page?.media ?: emptyList()

    /**
     * AniList hard-caps [AlPageInfo.total] at 5000 and [AlPageInfo.lastPage] at 100
     * for many queries — even when a year/genre/season only has a few hundred titles
     * (e.g. 2025 ≈ 9 pages of 50). Treat that ceiling as untrusted.
     */
    private fun isCappedPageInfo(info: com.panime.app.data.model.AlPageInfo?): Boolean {
        if (info == null) return true
        val last = info.lastPage
        val total = info.total
        // Classic AniList lie: total=5000, lastPage=100 regardless of filter size.
        if (last >= ANILIST_LAST_PAGE_CAP && (total >= ANILIST_TOTAL_CAP || total <= 0)) return true
        if (total >= ANILIST_TOTAL_CAP) return true
        return false
    }

    /**
     * Derive a trustworthy last page from the current response when possible.
     * Returns null when AniList's pageInfo is the fake cap and we still have a
     * full page (need a binary probe to learn the real end).
     */
    private fun lastPageFromCurrent(
        info: com.panime.app.data.model.AlPageInfo?,
        itemCount: Int,
        currentPage: Int,
        perPage: Int
    ): Int? {
        if (itemCount == 0) return (currentPage - 1).coerceAtLeast(1)
        // Short page ⇒ this is the last page of real results.
        if (itemCount < perPage) return currentPage
        if (info?.hasNextPage == false) return currentPage
        val lp = info?.lastPage
        if (!isCappedPageInfo(info) && lp != null && lp > 0) {
            return maxOf(lp, currentPage)
        }
        return null
    }

    /**
     * Binary-search the highest page that still returns media for [fetchCount].
     * Used only when AniList reports the fake 100-page cap. Result is cached
     * under [cacheKey] so Browse/See All never re-probe the same filter.
     */
    private suspend fun probeRealLastPage(
        cacheKey: String,
        perPage: Int,
        upperBound: Int = ANILIST_LAST_PAGE_CAP,
        fetchCount: suspend (page: Int) -> Int
    ): Int {
        realLastPageCache[cacheKey]?.let { return it }
        var lo = 1
        var hi = upperBound.coerceAtLeast(1)
        var best = 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            throttle()
            val n = try {
                fetchCount(mid)
            } catch (_: Exception) {
                // On probe failure, fall back to a conservative lower bound so UI
                // still works; do not cache so a later attempt can succeed.
                return best.coerceAtLeast(1)
            }
            if (n > 0) {
                best = mid
                // A short final page is definitely the end — stop early.
                if (n < perPage) break
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        val resolved = best.coerceAtLeast(1)
        realLastPageCache[cacheKey] = resolved
        return resolved
    }

    /**
     * Resolve the real last page for a paged AniList list response.
     * Prefer current-page signals; otherwise probe + cache under [cacheKey].
     */
    private suspend fun resolveLastPage(
        cacheKey: String,
        info: com.panime.app.data.model.AlPageInfo?,
        itemCount: Int,
        currentPage: Int,
        perPage: Int,
        fetchCount: suspend (page: Int) -> Int
    ): Int {
        realLastPageCache[cacheKey]?.let { cached ->
            // If we landed past the cached end (data shrank), re-derive.
            if (itemCount > 0 || currentPage <= cached) {
                // Still allow shrinking when this page is clearly the end.
                lastPageFromCurrent(info, itemCount, currentPage, perPage)?.let { definite ->
                    if (definite < cached) {
                        realLastPageCache[cacheKey] = definite
                        return definite
                    }
                }
                return maxOf(cached, currentPage)
            }
        }
        lastPageFromCurrent(info, itemCount, currentPage, perPage)?.let { definite ->
            realLastPageCache[cacheKey] = definite
            return definite
        }
        // Full page + fake AniList cap → discover the real end once.
        val upper = (info?.lastPage?.takeIf { it > 0 } ?: ANILIST_LAST_PAGE_CAP)
            .coerceIn(currentPage, ANILIST_LAST_PAGE_CAP)
        return probeRealLastPage(cacheKey, perPage, upper, fetchCount)
            .coerceAtLeast(currentPage)
    }

    /** Count-only probe: same GraphQL as the list query, but we only read media size. */
    private fun mediaCount(text: String): Int =
        parse(text).data?.Page?.media?.size ?: 0

    // ---- Home / browse lists (AniList GraphQL; "koto" routes to KotoApi) ----

    suspend fun trending(perPage: Int = 20): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.trending(perPage))
            if (provider == "wave") return@runCatching remember(AniwavesCatalog.trending(perPage))
            // Hero shuffle pool: 50 trending titles (AniList provider only —
            // koto/wave keep their own pools). One page at AniList's max 50.
            throttle()
            remember(
                page(AniListApi.query(TRENDING_Q, { int("page", 1); int("perPage", 50) }))
                    .map { it.toAnime() }
            )
        }
    }

    suspend fun topRated(perPage: Int = 20): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.topRated(perPage))
            if (provider == "wave") return@runCatching remember(AniwavesCatalog.topRated(perPage))
            throttle()
            remember(page(AniListApi.query(POPULAR_Q, { int("page", 1); int("perPage", perPage) })).map { it.toAnime() })
        }
    }

    /** Top 100 by score — AniList caps perPage at 50, so fetch two pages. */
    suspend fun top100(): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.top100())
            if (provider == "wave") return@runCatching remember(AniwavesCatalog.topRated(100))
            val out = mutableListOf<Anime>()
            for (page in 1..2) {
                throttle()
                out += page(AniListApi.query(TOP100_Q, { int("page", page); int("perPage", 50) }))
                    .map { it.toAnime() }
            }
            remember(out.distinctBy { it.id })
        }
    }

    suspend fun seasonal(perPage: Int = 25): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.seasonal(perPage))
            if (provider == "wave") {
                val (season, year) = currentSeasonYear()
                return@runCatching remember(AniwavesCatalog.seasonal(season, year, perPage))
            }
            throttle()
            val (season, year) = currentSeasonYear()
            remember(
                page(
                    AniListApi.query(SEASONAL_Q) {
                        str("season", season)
                        int("year", year)
                        int("page", 1)
                        int("perPage", perPage)
                    }
                ).map { it.toAnime() }
            )
        }
    }

    /** Paged variant for the "See All" screen — fetches a server page of the current season
     *  without depending on HomeViewModel's shared state (so opening See All never triggers a
     *  home reload). */
    suspend fun seasonalPage(pageNum: Int, perPage: Int = 50): Result<PagedResult<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val (season, year) = currentSeasonYear()
                val res = KotoApi.filterPage(
                    "season%5B%5D=${season.lowercase()}&year%5B%5D=$year&sort=most-viewed",
                    pageNum
                )
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            if (provider == "wave") {
                val (season, year) = currentSeasonYear()
                val res = AniwavesCatalog.filterPage("status[]=1&season[]=${season.lowercase()}&year[]=$year&sort_by=m_view", pageNum)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            throttle()
            val (season, year) = currentSeasonYear()
            val cacheKey = "seasonal:$season:$year:$perPage"
            val text = AniListApi.query(SEASONAL_Q) {
                str("season", season)
                int("year", year)
                int("page", pageNum)
                int("perPage", perPage)
            }
            val resp = parse(text)
            val items = remember(resp.data?.Page?.media?.map { it.toAnime() } ?: emptyList())
            val lastPage = resolveLastPage(
                cacheKey = cacheKey,
                info = resp.data?.Page?.pageInfo,
                itemCount = items.size,
                currentPage = pageNum,
                perPage = perPage
            ) { p ->
                mediaCount(
                    AniListApi.query(SEASONAL_Q) {
                        str("season", season); int("year", year); int("page", p); int("perPage", perPage)
                    }
                )
            }
            PagedResult(items, lastPage)
        }
    }

    /** Same for Top 100 / Popular — let See All fetch its own page instead of relying on the
     *  home snapshot (which can be empty/transient right after a refresh). */
    suspend fun popularPage(pageNum: Int, perPage: Int = 50): Result<PagedResult<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val res = KotoApi.filterPage("sort=most-viewed", pageNum)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            if (provider == "wave") {
                val res = AniwavesCatalog.filterPage("sort_by=m_view", pageNum)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            throttle()
            val cacheKey = "popular:$perPage"
            val text = AniListApi.query(POPULAR_Q) {
                int("page", pageNum); int("perPage", perPage)
            }
            val resp = parse(text)
            val items = remember(resp.data?.Page?.media?.map { it.toAnime() } ?: emptyList())
            val lastPage = resolveLastPage(
                cacheKey = cacheKey,
                info = resp.data?.Page?.pageInfo,
                itemCount = items.size,
                currentPage = pageNum,
                perPage = perPage
            ) { p ->
                mediaCount(AniListApi.query(POPULAR_Q) { int("page", p); int("perPage", perPage) })
            }
            PagedResult(items, lastPage)
        }
    }

    /** Paged trending for See All. */
    suspend fun trendingPage(pageNum: Int, perPage: Int = 50): Result<PagedResult<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val res = KotoApi.filterPage("sort=most-viewed", pageNum)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            if (provider == "wave") {
                val res = AniwavesCatalog.filterPage("sort_by=m_view", pageNum)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            throttle()
            val cacheKey = "trending:$perPage"
            val text = AniListApi.query(TRENDING_Q) {
                int("page", pageNum); int("perPage", perPage)
            }
            val resp = parse(text)
            val items = remember(resp.data?.Page?.media?.map { it.toAnime() } ?: emptyList())
            val lastPage = resolveLastPage(
                cacheKey = cacheKey,
                info = resp.data?.Page?.pageInfo,
                itemCount = items.size,
                currentPage = pageNum,
                perPage = perPage
            ) { p ->
                mediaCount(AniListApi.query(TRENDING_Q) { int("page", p); int("perPage", perPage) })
            }
            PagedResult(items, lastPage)
        }
    }

    /** Paged upcoming for See All. */
    suspend fun upcomingPage(pageNum: Int, perPage: Int = 50): Result<PagedResult<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val res = KotoApi.statusPage("not-yet-aired", pageNum)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            if (provider == "wave") {
                val res = AniwavesCatalog.filterPage("status[]=not-yet-released", pageNum)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            throttle()
            val cacheKey = "upcoming:$perPage"
            val text = AniListApi.query(UPCOMING_Q) {
                int("page", pageNum); int("perPage", perPage)
            }
            val resp = parse(text)
            val items = remember(resp.data?.Page?.media?.map { it.toAnime() } ?: emptyList())
            val lastPage = resolveLastPage(
                cacheKey = cacheKey,
                info = resp.data?.Page?.pageInfo,
                itemCount = items.size,
                currentPage = pageNum,
                perPage = perPage
            ) { p ->
                mediaCount(AniListApi.query(UPCOMING_Q) { int("page", p); int("perPage", perPage) })
            }
            PagedResult(items, lastPage)
        }
    }

    /** AniList's Media.season arg requires an enum (WINTER/SPRING/SUMMER/FALL); CURRENT is
     *  invalid there (it only works on AiringSchedule). Derive the real current season. */
    private fun currentSeasonYear(): Pair<String, Int> {
        val now = java.util.Calendar.getInstance()
        val month = now.get(java.util.Calendar.MONTH) + 1
        val year = now.get(java.util.Calendar.YEAR)
        val season = when (month) {
            in 3..5 -> "SPRING"
            in 6..8 -> "SUMMER"
            in 9..11 -> "FALL"
            else -> "WINTER"
        }
        // Northern-hemisphere anime seasons: Winter = Jan–Mar (year), Spring = Apr–Jun, etc.
        return season to year
    }

    /** Recently Updated — as a flat Anime list (for the "See All" screen).
     *  Same faithful Dantotsu airingSchedules window as [recentlyUpdated]; returns
     *  the underlying Anime titles (newest-aired JP/non-adult) instead of tiles. */
    suspend fun recentlyUpdatedAnime(perPage: Int = 50): Result<List<Anime>> =
        recentlyUpdated(perPage).mapCatching { schedules ->
            schedules.mapNotNull { it.anime }
        }

    /**
     * Paged Recently Updated for the See All screen. Koto routes through the
     * site's real /latest-updated?page=N feed (40/page + real last page); AniList
     * keeps its flat airingSchedules window (page 1 only).
     */
    suspend fun recentlyUpdatedPaged(pageNum: Int, perPage: Int = 50): Result<PagedResult<Anime>> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (provider == "koto") {
                    val res = KotoApi.latestUpdatedPaged(pageNum)
                    return@runCatching PagedResult(remember(res.items), res.lastPage)
                }
                if (provider == "wave") {
                    val items = AniwavesCatalog.updated(50)
                    return@runCatching PagedResult(remember(items), 1)
                }
                PagedResult(recentlyUpdatedAnime(perPage).getOrThrow(), 1)
            }
        }

    suspend fun newReleases(perPage: Int = 20): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.newRelease(perPage))
            if (provider == "wave") return@runCatching remember(AniwavesCatalog.newest(perPage))
            throttle()
            remember(page(AniListApi.query(RELEASING_Q, { int("perPage", perPage) })).map { it.toAnime() })
        }
    }

    suspend fun upcoming(perPage: Int = 20): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.upcoming())
            if (provider == "wave") return@runCatching remember(AniwavesCatalog.ongoing(perPage))
            throttle()
            remember(page(AniListApi.query(UPCOMING_Q, { int("page", 1); int("perPage", perPage) })).map { it.toAnime() })
        }
    }

    suspend fun search(query: String): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (query.isBlank()) return@runCatching emptyList()
            if (provider == "koto") return@runCatching remember(KotoApi.search(query))
            if (provider == "wave") return@runCatching remember(AniwavesCatalog.search(query))
            val out = mutableListOf<Anime>()
            val seen = mutableSetOf<Int>()
            for (pg in 1..5) {
                throttle()
                val json = AniListApi.query(SEARCH_Q) {
                    str("q", query)
                    int("page", pg)
                    int("perPage", 50)
                }
                val resp = parse(json)
                val info = resp.data?.Page?.pageInfo
                resp.data?.Page?.media?.forEach { m ->
                    val anime = m.toAnime() ?: return@forEach
                    if (seen.add(anime.id)) out.add(anime)
                }
                if (info?.hasNextPage != true) break
            }
            remember(out)
        }
    }

    /**
     * One page of search results + the source's last-page number, for UIs with
     * manual pagination. WAVE maps to aniwaves /filter pages (site parity);
     * other providers already aggregate everything, so they report a single page.
     */
    suspend fun searchPaged(query: String, page: Int = 1): Result<PagedResult<Anime>> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (query.isBlank()) return@runCatching PagedResult(emptyList(), 1)
                if (provider == "wave") {
                    val pr = AniwavesCatalog.searchPage(query, page)
                    return@runCatching PagedResult(remember(pr.items), pr.lastPage)
                }
                if (provider == "koto") {
                    val pr = KotoApi.searchPage(query, page)
                    return@runCatching PagedResult(remember(pr.items), pr.lastPage)
                }
                PagedResult(search(query).getOrDefault(emptyList()), 1)
            }
        }

    suspend fun byGenre(genreId: Int): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.genrePage(genreId, 1).items)
            if (provider == "wave") return@runCatching remember(AniwavesCatalog.filterPage("genre[]=$genreId", 1).items)
            val genre = GENRE_NAMES[genreId] ?: return@runCatching emptyList()
            val out = retryQuery { page(AniListApi.query(GENRE_Q, { str("genre", genre); int("perPage", 24) })).map { it.toAnime() } }
            remember(out)
        }
    }

    /** Retry a query up to 3x with backoff. AniList's unauthenticated limit is 90
     *  req/min; rapid filter tapping on the year/letter grid can trip HTTP 429 or
     *  transient 5xx. We retry those here so the Browse screen surfaces data instead
     *  of a fatal "Something went sideways" error on the first hit. */
    private suspend inline fun <T> retryQuery(block: () -> T): T {
        var lastErr: Throwable? = null
        repeat(3) { attempt ->
            try {
                return block()
            } catch (e: RateLimitException) {
                lastErr = e
                val wait = (1500L * (attempt + 1)).coerceAtMost(9000L)
                delay(wait)
            } catch (e: RuntimeException) {
                // AniListApi throws RuntimeException for non-429 HTTP errors; retry once.
                lastErr = e
                if (attempt < 1) delay(1000L) else throw e
            }
        }
        throw lastErr ?: RuntimeException("Browse query failed")
    }

    /** A–Z browse.
     *
     * AniList has no "starts-with" filter, and the obvious approaches are broken:
     *  - Sorting by TITLE_ROMAJI + fetching page 1 returns only symbol/punctuation
     *    titles (the first real "A" sits ~index 220), so a 50-item fetch is empty.
     *  - `search: "A"`/`"O"` return nothing (AniList drops single-letter stopwords),
     *    and raw search matches substrings, not starts-with.
     *
     * Strategy: use `search` (sort SEARCH_MATCH) for every letter; it returns
     * starts-with titles for B–Z. For the two stopword letters A and O — where
     * search yields nothing — fall back to paging the TITLE_ROMAJI-sorted catalogue
     * and collecting titles that actually start with the letter.
     * "All"/"ALL"/blank returns the popular list. */
    suspend fun byLetter(letter: String): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.letterPage(letter, 1).items)
            if (provider == "wave") {
                return@runCatching remember(AniwavesCatalog.letterPage(letter, 1).items)
            }
            val key = ("letter:" + letter.lowercase())
            cacheResults[key]?.let { return@runCatching it }
            val out = retryQuery {
                loadByLetterUncached(letter)
            }
            cacheResults[key] = out
            remember(out)
        }
    }

    /** Core letter load (no caching/retry wrapper). */
    private suspend fun loadByLetterUncached(letter: String): List<Anime> {
        throttle()
        if (letter.isBlank() || letter.equals("All", ignoreCase = true)) {
            return page(AniListApi.query(POPULAR_Q, { int("page", 1); int("perPage", 50) })).map { it.toAnime() }
        }
        val target = letter.first().uppercaseChar()
        // Search works for B–Z. A and O are stopwords → paging fallback.
        if (target !in setOf('A', 'O')) {
            val all = page(
                AniListApi.query(SEARCH_Q, { str("q", letter); int("perPage", 50) })
            ).map { it.toAnime() }
            val filtered = all.filter { a ->
                a.title.firstOrNull()?.equals(letter.first(), ignoreCase = true) == true
            }
            if (filtered.isNotEmpty()) return filtered
            // fall through to paging if search returned nothing unexpected
        }
        // Paging fallback (covers A, O, and any search miss).
        val out = mutableListOf<Anime>()
        val maxPages = 80
        for (pageNum in 1..maxPages) {
            val media = page(
                AniListApi.query(BY_LETTER_Q, { int("page", pageNum); int("perPage", 50) })
            )
            if (media.isEmpty()) break
            var passed = false
            for (m in media) {
                val anime = m.toAnime()
                val first = anime.title.firstOrNull() ?: continue
                if (!first.isLetterOrDigit()) continue
                val fu = first.uppercaseChar()
                if (fu < target) continue
                if (fu > target) { passed = true; break }
                if (fu == target) out += anime
            }
            if (passed || out.size >= 60) break
        }
        return out
    }

    /** Release year browse: AniList media filtered by seasonYear.
     *
     *  Root cause of "Something went sideways" on every year tap: [BY_YEAR_Q]
     *  was written as a Kotlin raw string starting with """\ — that injects a
     *  literal backslash into the GraphQL body, so AniList rejects the query
     *  with a syntax error before any media is returned.
     *
     *  Fetches at most 2 pages (AniList caps perPage at 50). Cached per year so
     *  re-selecting never re-hits the network. Partial success on mid-walk 429. */
    suspend fun byYear(year: Int): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching remember(KotoApi.yearPage(year, 1).items)
            if (provider == "wave") return@runCatching remember(AniwavesCatalog.filterPage("year[]=$year", 1).items)
            val key = "year:$year"
            cacheResults[key]?.let { return@runCatching it }
            val out = retryQuery { loadByYearUncached(year) }
            cacheResults[key] = out
            remember(out)
        }
    }

    /** Core year load. First page is required; later pages are best-effort so a
     *  mid-walk 429 still returns the titles already loaded. */
    private suspend fun loadByYearUncached(year: Int): List<Anime> {
        val out = mutableListOf<Anime>()
        for (p in 1..MAX_YEAR_PAGES) {
            try {
                throttle()
                val pageItems = page(
                    AniListApi.query(BY_YEAR_Q, { int("year", year); int("page", p); int("perPage", 50) })
                ).map { it.toAnime() }
                if (pageItems.isEmpty()) break
                out += pageItems
                // Enough for a polished grid; more pages only burn rate limit.
                if (out.size >= 50) break
            } catch (e: Exception) {
                if (out.isNotEmpty()) break // return partial success
                throw e
            }
        }
        return out.distinctBy { it.id }
    }

    // ---- Paged browse methods (server-side pagination) ----

    /** All anime sorted by popularity — server-side paginated. */
    suspend fun allAnimePaged(page: Int, perPage: Int = 50): Result<PagedResult<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val res = KotoApi.filterPage("sort=most-viewed", page)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            if (provider == "wave") {
                val res = AniwavesCatalog.filterPage("sort_by=m_view", page)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            throttle()
            val cacheKey = "all:$perPage"
            val text = AniListApi.query(POPULAR_Q) { int("page", page); int("perPage", perPage) }
            val resp = parse(text)
            val items = remember(resp.data?.Page?.media?.map { it.toAnime() } ?: emptyList())
            val lastPage = resolveLastPage(
                cacheKey = cacheKey,
                info = resp.data?.Page?.pageInfo,
                itemCount = items.size,
                currentPage = page,
                perPage = perPage
            ) { p ->
                mediaCount(AniListApi.query(POPULAR_Q) { int("page", p); int("perPage", perPage) })
            }
            PagedResult(items, lastPage)
        }
    }

    /** Genre browse — server-side paginated. */
    suspend fun byGenrePaged(genreId: Int, page: Int, perPage: Int = 50): Result<PagedResult<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val res = KotoApi.genrePage(genreId, page)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            if (provider == "wave") {
                // Real /genre/<slug> pages (path pager) — the chip ids come from
                // AniwavesCatalog.genres()' site-order scrape, mapped to slugs.
                val res = AniwavesCatalog.genrePage(genreId, page)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            val genre = GENRE_NAMES[genreId] ?: return@runCatching PagedResult(emptyList(), 1)
            throttle()
            val cacheKey = "genre:$genre:$perPage"
            val text = AniListApi.query(GENRE_Q) { str("genre", genre); int("page", page); int("perPage", perPage) }
            val resp = parse(text)
            val items = remember(resp.data?.Page?.media?.map { it.toAnime() } ?: emptyList())
            val lastPage = resolveLastPage(
                cacheKey = cacheKey,
                info = resp.data?.Page?.pageInfo,
                itemCount = items.size,
                currentPage = page,
                perPage = perPage
            ) { p ->
                mediaCount(
                    AniListApi.query(GENRE_Q) { str("genre", genre); int("page", p); int("perPage", perPage) }
                )
            }
            PagedResult(items, lastPage)
        }
    }

    /** A–Z browse — uses the proven approach from the original codebase.
     *
     *  AniList has no starts‑with filter. TITLE_ROMAJI sort puts A-titles
     *  ~220 pages in (after symbol titles), so per‑page client filtering is broken.
     *
     *  Strategy (matches original loadByLetterUncached):
     *  • "All" → return popular list (same as allAnimePaged).
     *  • Every other letter: page TITLE_ROMAJI catalogue sequentially,
     *    collect titles whose first letter matches. Stop at 60 titles.
     *  Returns up to 60 titles (one full grid page).
     */
    suspend fun byLetterPaged(letter: String, page: Int, perPage: Int = 50): Result<PagedResult<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val res = KotoApi.letterPage(letter, page)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            if (provider == "wave") {
                val res = AniwavesCatalog.letterPage(letter, page)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            val target = letter.first().uppercaseChar()
            // "All" returns the popular list via allAnimePaged.
            if (letter.equals("All", ignoreCase = true)) {
                return@runCatching allAnimePaged(page, perPage).getOrThrow()
            }
            // Paging fallback for every letter (A–Z). TITLE_ROMAJI sort puts A-titles
            // ~220 pages in (after symbol titles), so we scan pages until we collect 60 matches.
            val out = mutableListOf<Anime>()
            val seen = mutableSetOf<Int>()
            for (pageNum in 1..80) {
                val media = page(
                    AniListApi.query(LETTER_Q) { int("page", pageNum); int("perPage", 50) }
                )
                if (media.isEmpty()) break
                for (m in media) {
                    val anime = m.toAnime()
                    if (!seen.add(anime.id)) continue
                    val first = anime.title.firstOrNull() ?: continue
                    if (!first.isLetterOrDigit()) continue
                    val fu = first.uppercaseChar()
                    if (fu < target) continue
                    if (fu > target) break
                    if (fu == target) out += anime
                }
                if (out.size >= 60) break
            }
            // Client-side letter scan returns one grid of matches (not AniList pages).
            PagedResult(out, 1)
        }
    }

    /** Year browse — server-side paginated with real last-page detection. */
    suspend fun byYearPaged(year: Int, page: Int, perPage: Int = 50): Result<PagedResult<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val res = KotoApi.yearPage(year, page)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            if (provider == "wave") {
                val res = AniwavesCatalog.filterPage("year[]=$year", page)
                return@runCatching PagedResult(remember(res.items), res.lastPage)
            }
            throttle()
            val cacheKey = "year:$year:$perPage"
            val text = AniListApi.query(BY_YEAR_Q) { int("year", year); int("page", page); int("perPage", perPage) }
            val resp = parse(text)
            val items = remember(resp.data?.Page?.media?.map { it.toAnime() } ?: emptyList())
            val lastPage = resolveLastPage(
                cacheKey = cacheKey,
                info = resp.data?.Page?.pageInfo,
                itemCount = items.size,
                currentPage = page,
                perPage = perPage
            ) { p ->
                mediaCount(
                    AniListApi.query(BY_YEAR_Q) { int("year", year); int("page", p); int("perPage", perPage) }
                )
            }
            PagedResult(items, lastPage)
        }
    }

    /** The provider's real genre list for the Browse tab. Koto scrapes its own
     *  /genre/<slug> header nav (48 real genres — Action, Boys Love, Demons,
     *  Isekai, Josei, Magic, Samurai, Shounen, Vampire, …); other providers fall
     *  back to the shared chip list. */
    suspend fun genres(): Result<List<GenreChip>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val site = KotoApi.genres()
                if (site.isNotEmpty()) return@runCatching site
            }
            if (provider == "wave") {
                val site = AniwavesCatalog.genres()
                if (site.isNotEmpty()) return@runCatching site
            }
            BrowseGenres
        }
    }

    /**
     * Release years offered by the Browse "Release Year" filter. Koto uses the
     * site's OWN year list (scraped from the /filter sidebar); AniList falls back
     * to a dynamic current-year range (no AniList "list years" endpoint exists).
     */
    suspend fun browseYears(): Result<List<Int>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val site = KotoApi.siteYears()
                if (site.isNotEmpty()) return@runCatching site
            }
            if (provider == "wave") {
                val site = AniwavesCatalog.siteYears()
                if (site.isNotEmpty()) return@runCatching site
            }
            val now = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
            (now downTo 1940).toList()
        }
    }

    // ---- Detail + extras ----

    /**
     * Single GraphQL round-trip for detail + characters + recommendations.
     * Avoids the old 3-request chain where characters/recs often hit 429 after
     * home+detail had already spent the rate budget, leaving Key Characters empty.
     */
    suspend fun detailBundle(id: Int): Result<DetailData> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                val d = KotoApi.detail(id)
                cache[d.anime.id] = d.anime
                return@runCatching d
            }
            if (provider == "wave") {
                val d = AniwavesCatalog.detail(id) ?: error("Anime not found on AniWaves")
                cache[d.anime.id] = d.anime
                return@runCatching d
            }
            throttle()
            val media = fetchMediaByAppId(id, DETAIL_BUNDLE_Q, DETAIL_BUNDLE_BY_MAL_Q)
            val anime = media.toAnime().also { cache[it.id] = it }
            val characters = media.characters?.edges
                ?.mapNotNull { it.toCharacter() }
                ?.take(12)
                ?: emptyList()
            val recommendations = media.recommendations?.nodes
                ?.mapNotNull { it.recommended }
                ?.distinctBy { it.id }
                ?.take(12)
                ?.map { it.toAnime().also { a -> cache[a.id] = a } }
                ?: emptyList()
            DetailData(anime = anime, characters = characters, recommendations = recommendations)
        }
    }

    /**
     * The provider whose id-space an anime id belongs to. The three sources use
     * DISJOINT id ranges — AniList (< 80M), wave ([80M, 90M), koto (≥ 90M) — so
     * each provider's Continue Watching / My List entries are exactly its own.
     * Used to isolate those sections per provider: switching the API provider
     * switch hides the other providers' history and list entries.
     */
    fun providerForId(id: Int): String = when {
        KotoApi.rawId(id) > 0 -> "koto"
        AniwavesCatalog.rawId(id) > 0 -> "wave"
        else -> "anilist"
    }

    suspend fun detail(id: Int): Result<Anime> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") {
                cache[id]?.let { return@runCatching it }
                return@runCatching KotoApi.detail(id).anime.also { cache[it.id] = it }
            }
            if (provider == "wave") {
                cache[id]?.let { return@runCatching it }
                return@runCatching AniwavesCatalog.detail(id)?.anime ?: error("Not found")
            }
            // Prefer AniList Media.id (what list screens now store). Cache hit is fine
            // for title/poster; Key Characters always go through detailBundle / characters().
            cache[id]?.let { return@runCatching it }
            throttle()
            val media = fetchMediaByAppId(id, DETAIL_Q, DETAIL_BY_MAL_Q)
            media.toAnime().also { cache[it.id] = it }
        }
    }

    suspend fun characters(id: Int): Result<List<Character>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching emptyList()
            if (provider == "wave") return@runCatching emptyList()
            throttle()
            val media = fetchMediaByAppId(id, CHAR_Q, CHAR_BY_MAL_Q)
            media.characters?.edges
                ?.mapNotNull { it.toCharacter() }
                ?.take(12)
                ?: emptyList()
        }
    }

    suspend fun recommendations(id: Int): Result<List<Anime>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching emptyList()
            if (provider == "wave") return@runCatching emptyList()
            throttle()
            val media = fetchMediaByAppId(id, REC_Q, REC_BY_MAL_Q)
            media.recommendations?.nodes
                ?.mapNotNull { it.recommended }
                ?.distinctBy { it.id }
                ?.take(12)
                ?.map { it.toAnime() }
                ?: emptyList()
        }
    }

    /**
     * Resolve media by app id. Primary: AniList Media.id (current app convention).
     * Fallback: idMal — covers legacy My List / progress entries that still store MAL ids
     * from when [AlMedia.toAnime] incorrectly preferred idMal.
     */
    private fun fetchMediaByAppId(id: Int, byAniListIdQ: String, byMalIdQ: String): AlMedia {
        val byId = runCatching {
            parse(AniListApi.query(byAniListIdQ, { int("id", id) })).data?.Media
        }.getOrNull()
        if (byId != null) return byId
        val byMal = runCatching {
            parse(AniListApi.query(byMalIdQ, { int("id", id) })).data?.Media
        }.getOrNull()
        if (byMal != null) {
            // Re-key cache under AniList id so later character/detail calls stay consistent.
            byMal.toAnime().also { cache[it.id] = it }
            return byMal
        }
        throw RuntimeException("AniList: no media for id $id")
    }

    /**
     * REAL weekly schedule from AniList AiringSchedule. We fetch the next 7 days of
     * airing episodes (time-windowed) and hand the flat list back; the ViewModel
     * groups it by weekday + derives "EP x" + status. No mock data.
     * Retries on transient 429/5xx so the home schedule doesn't flash empty.
     */
    suspend fun schedule(perPage: Int = 50): Result<List<AiringSchedule>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching KotoApi.schedule().entries
            // Wave: the site's own Estimated Schedule widget (/ajax/schedule +
            // per-day /ajax/schedule/date) — real entries, never empty.
            if (provider == "wave") return@runCatching AniwavesCatalog.schedule().entries
            val tz = java.util.TimeZone.getDefault()
            val cal = java.util.Calendar.getInstance(tz)
            cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
            cal.set(java.util.Calendar.MINUTE, 0)
            cal.set(java.util.Calendar.SECOND, 0)
            cal.set(java.util.Calendar.MILLISECOND, 0)
            // Fetch a wider window than the 7 local days so shows that air just
            // after local midnight are included; buildSiteSchedule drops the rest.
            val from = cal.timeInMillis / 1000L - (24L * 3600)
            val to = from + (9L * 24 * 3600)
            val all = mutableListOf<AiringSchedule>()
            val seen = mutableSetOf<String>()
            retryQuery {
                for (pg in 1..SCHEDULE_MAX_PAGES) {
                    throttle()
                    val text = AniListApi.query(AIRING_Q) {
                        int("per", perPage)
                        int("page", pg)
                        int("from", from.toInt())
                        int("to", to.toInt())
                    }
                    val resp = parse(text)
                    val batch = (resp.data?.Page?.airingSchedules ?: emptyList())
                        .mapNotNull { it.toAiring() }
                    if (batch.isEmpty()) break
                    batch.forEach { s -> if (seen.add("${s.anime?.id}:${s.episode}")) all.add(s) }
                    if (batch.size < perPage) break
                }
            }
            all
        }
    }

    /** Day window for the weekly schedule card. Koto uses the site's own widget
     *  labels (reused from the [schedule] scrape); other providers compute the
     *  current week's UTC days. */
    suspend fun scheduleDays(): Result<List<ScheduleDay>> = withContext(Dispatchers.IO) {
        runCatching {
            if (provider == "koto") return@runCatching KotoApi.scheduleDays()
            if (provider == "wave") return@runCatching AniwavesCatalog.scheduleDays()
            currentWeekScheduleDays()
        }
    }

    /** Recently Updated — faithful to Dantotsu's recentAnimeUpdates() call.
     *  Window: everything that has aired up to ~now (airingAt_greater:0,
     *  airingAt_lesser: now-10s), sorted TIME_DESC => newest broadcasts first.
     *  Dantotsu paginates pages 1+2 and filters to JP, non-adult. We keep the
     *  TIME_DESC order (no .reversed()) so the freshest episodes appear first. */
    suspend fun recentlyUpdated(perPage: Int = 50): Result<List<AiringSchedule>> =
        withContext(Dispatchers.IO) {
            runCatching {
                if (provider == "koto") return@runCatching KotoApi.latestUpdated(perPage)
                if (provider == "wave") {
                    val items = AniwavesCatalog.updated(perPage)
                    return@runCatching items.map { a ->
                        AiringSchedule(
                            id = a.id,
                            title = a.title,
                            cover = a.posterUrl,
                            episode = a.episodes ?: 0,
                            anime = a
                        )
                    }
                }
                val now = (System.currentTimeMillis() / 1000L).toInt()
                val lesser = now - 10 // Dantotsu: currentTime - 10000ms
                val all = mutableListOf<AiringSchedule>()
                val seen = mutableSetOf<Int>()
                retryQuery {
                    for (page in 1..RECENTLY_UPDATED_PAGES) {
                        throttle()
                        val text = AniListApi.query(RECENTLY_UPDATED_Q) {
                            int("per", perPage)
                            int("page", page)
                            int("lesser", lesser)
                        }
                        val resp = parse(text)
                        (resp.data?.Page?.airingSchedules ?: emptyList())
                            .mapNotNull { it.toAiring() }
                            .filter { s ->
                                s.anime != null &&
                                s.anime.countryOfOrigin == "JP" &&
                                s.anime.isAdult != true
                            }
                            .forEach { s ->
                                if (seen.add(s.id)) all.add(s)
                            }
                    }
                }
                all.also { remember(it.mapNotNull { a -> a.anime }) }
            }
        }

    fun cached(id: Int): Anime? = cache[id]
}

/* ===================== GraphQL queries ===================== */

/** AniList pageInfo ceiling — not a real count for filtered lists. */
private const val ANILIST_TOTAL_CAP = 5000
private const val ANILIST_LAST_PAGE_CAP = 100

private const val MEDIA_FIELDS = """
    id idMal title { romaji english native } synonyms
    coverImage { extraLarge large medium color }
    bannerImage averageScore episodes nextAiringEpisode { episode airingAt }
    season seasonYear startDate { year month day } format status description
    genres studios(isMain: true) { nodes { name } }
"""

/** pageInfo fields used to detect real vs capped pagination. */
private const val PAGE_INFO_FIELDS = "total lastPage currentPage hasNextPage perPage"

private const val TRENDING_Q = """
query(${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(sort: TRENDING_DESC, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}"""

private const val POPULAR_Q = """
query(${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(sort: POPULARITY_DESC, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}"""

private const val TOP100_Q = """
query(${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(sort: SCORE_DESC, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}"""

private const val SEASONAL_Q = """
query(${'$'}season: MediaSeason, ${'$'}year: Int, ${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(season: ${'$'}season, seasonYear: ${'$'}year, sort: POPULARITY_DESC, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}"""

private const val RELEASING_Q = """
query(${'$'}perPage: Int) {
  Page(page: 1, perPage: ${'$'}perPage) {
    media(status: RELEASING, sort: POPULARITY_DESC, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}"""

private const val UPCOMING_Q = """
query(${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(status: NOT_YET_RELEASED, sort: POPULARITY_DESC, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}"""

private const val SEARCH_Q = """
query(${'$'}q: String, ${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(search: ${'$'}q, sort: SEARCH_MATCH, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}"""

/** Letter browse — TITLE_ROMAJI sort with server‑side paging.
 *  byLetterPaged filters results by first letter client‑side. */
private const val LETTER_Q = """
query(${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(sort: TITLE_ROMAJI, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}
"""

private const val GENRE_Q = """
query(${'$'}genre: String, ${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(genre: ${'$'}genre, sort: POPULARITY_DESC, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}"""

// NOTE: Kotlin raw strings do NOT treat \ as escape. Never use """\ — that
// injects a literal backslash and AniList returns a GraphQL syntax error
// ("Something went sideways" on Browse Release Year / letter paging).
private const val BY_LETTER_Q = """
query(${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(sort: TITLE_ROMAJI, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}
"""

/** One page (50) fills the Browse grid; a second page only if page 1 is full. */
private const val MAX_YEAR_PAGES = 2

private const val BY_YEAR_Q = """
query(${'$'}year: Int, ${'$'}page: Int, ${'$'}perPage: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}perPage) {
    pageInfo { ${PAGE_INFO_FIELDS} }
    media(seasonYear: ${'$'}year, sort: POPULARITY_DESC, type: ANIME, isAdult: false) { ${MEDIA_FIELDS} }
  }
}
"""

private const val DETAIL_Q = """
query(${'$'}id: Int) {
  Media(id: ${'$'}id, type: ANIME) { ${MEDIA_FIELDS} }
}"""

/** Shared character + recommendation selection (AniList Media.id or idMal). */
private const val CHAR_REC_FIELDS = """
    characters(sort: ROLE, perPage: 12) {
      edges { role node { id name { full } image { large medium } } }
    }
    recommendations(sort: RATING_DESC, perPage: 12) {
      nodes { mediaRecommendation { ${MEDIA_FIELDS} } }
    }
"""

/** Detail + characters + recommendations in ONE request (rate-limit friendly). */
private const val DETAIL_BUNDLE_Q = """
query(${'$'}id: Int) {
  Media(id: ${'$'}id, type: ANIME) {
    ${MEDIA_FIELDS}
    ${CHAR_REC_FIELDS}
  }
}"""

/** Same as [DETAIL_BUNDLE_Q] but resolves by MyAnimeList id (legacy app ids). */
private const val DETAIL_BUNDLE_BY_MAL_Q = """
query(${'$'}id: Int) {
  Media(idMal: ${'$'}id, type: ANIME) {
    ${MEDIA_FIELDS}
    ${CHAR_REC_FIELDS}
  }
}"""

private const val DETAIL_BY_MAL_Q = """
query(${'$'}id: Int) {
  Media(idMal: ${'$'}id, type: ANIME) { ${MEDIA_FIELDS} }
}"""

private const val CHAR_Q = """
query(${'$'}id: Int) {
  Media(id: ${'$'}id, type: ANIME) {
    characters(sort: ROLE, perPage: 12) {
      edges { role node { id name { full } image { large medium } } }
    }
  }
}"""

private const val CHAR_BY_MAL_Q = """
query(${'$'}id: Int) {
  Media(idMal: ${'$'}id, type: ANIME) {
    characters(sort: ROLE, perPage: 12) {
      edges { role node { id name { full } image { large medium } } }
    }
  }
}"""

private const val REC_Q = """
query(${'$'}id: Int) {
  Media(id: ${'$'}id, type: ANIME) {
    recommendations(sort: RATING_DESC, perPage: 12) {
      nodes { mediaRecommendation { ${MEDIA_FIELDS} } }
    }
  }
}"""

private const val REC_BY_MAL_Q = """
query(${'$'}id: Int) {
  Media(idMal: ${'$'}id, type: ANIME) {
    recommendations(sort: RATING_DESC, perPage: 12) {
      nodes { mediaRecommendation { ${MEDIA_FIELDS} } }
    }
  }
}"""

private const val SCHEDULE_MAX_PAGES = 10

private const val AIRING_Q = """
query(${'$'}per: Int, ${'$'}page: Int, ${'$'}from: Int, ${'$'}to: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}per) {
    airingSchedules(sort: TIME, airingAt_greater: ${'$'}from, airingAt_lesser: ${'$'}to) {
      episode
      airingAt
      media {
        ${MEDIA_FIELDS}
        duration
        countryOfOrigin
        isAdult
      }
    }
  }
}
"""

/** Recently Updated — EXACT Dantotsu request (recentAnimeUpdates, AnilistQueries.kt:1203).
 *  Key: airingAt_greater:0 (epoch) and airingAt_lesser: now-10s, so the window
 *  is "everything that has ever aired, up to ~now" sorted TIME_DESC => newest
 *  episode broadcasts first. (My earlier version used a 7-day window + a FUTURE
 *  upper bound, which surfaced stale/old anime — this mirrors Dantotsu's real call.) */
private const val RECENTLY_UPDATED_Q = """
query(${'$'}per: Int, ${'$'}page: Int, ${'$'}lesser: Int) {
  Page(page: ${'$'}page, perPage: ${'$'}per) {
    airingSchedules(airingAt_greater: 0, airingAt_lesser: ${'$'}lesser, sort: TIME_DESC) {
      episode
      airingAt
      media {
        ${MEDIA_FIELDS}
        duration
        countryOfOrigin
        isAdult
      }
    }
  }
}
"""

/** Dantotsu paginates the home "Recently Updated" row over 2 pages (pages 1+2). */
private const val RECENTLY_UPDATED_PAGES = 2

private fun com.panime.app.data.model.AlAiring.toAiring(): AiringSchedule? {
    val m = media ?: return null
    val t = m.title
    val name = (t?.english ?: t?.romaji).orEmpty().ifBlank { return null }
    return AiringSchedule(
        id = m.id,
        title = name,
        cover = m.coverImage?.extraLarge ?: m.coverImage?.large ?: m.coverImage?.medium,
        episode = episode ?: 0,
        totalEpisodes = m.episodes,
        airingAt = airingAt ?: 0L,
        status = m.status,
        durationMin = m.duration,
        anime = m.toAnime()
    )
}

/** Maps the numeric BrowseGenres ids used by the UI to AniList genre names. */
private val GENRE_NAMES = mapOf(
    1 to "Action", 2 to "Adventure", 3 to "Comedy", 4 to "Drama",
    5 to "Ecchi", 6 to "Fantasy", 7 to "Horror", 8 to "Mecha",
    9 to "Music", 10 to "Mystery", 11 to "Psychological", 12 to "Romance",
    13 to "Sci-Fi", 14 to "Mahou Shoujo", 15 to "Slice of Life", 16 to "Space",
    17 to "Sports", 18 to "Supernatural", 19 to "Thriller"
)