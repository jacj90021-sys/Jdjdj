package com.panime.app.ui.player

import android.app.Activity
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.util.Rational
import androidx.annotation.RequiresApi

internal const val PIP_ACTION_PLAY_PAUSE = "panime.PIP_PLAY_PAUSE"
internal const val PIP_ACTION_REWIND = "panime.PIP_REWIND"
internal const val PIP_ACTION_FORWARD = "panime.PIP_FORWARD"

internal fun pipPendingIntent(context: Context, action: String, requestCode: Int): PendingIntent {
    val intent = Intent(action).setPackage(context.packageName)
    return PendingIntent.getBroadcast(
        context, requestCode, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

@RequiresApi(Build.VERSION_CODES.O)
internal fun buildPipActions(context: Context, isPlaying: Boolean): List<RemoteAction> {
    val playPauseIcon = Icon.createWithResource(
        context,
        if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
    )
    val playPauseAction = RemoteAction(
        playPauseIcon,
        if (isPlaying) "Pause" else "Play",
        if (isPlaying) "Pause playback" else "Play playback",
        pipPendingIntent(context, PIP_ACTION_PLAY_PAUSE, 0)
    )

    val rewindAction = RemoteAction(
        Icon.createWithResource(context, android.R.drawable.ic_media_rew),
        "Rewind", "Rewind 10 seconds",
        pipPendingIntent(context, PIP_ACTION_REWIND, 1)
    )

    val forwardAction = RemoteAction(
        Icon.createWithResource(context, android.R.drawable.ic_media_ff),
        "Forward", "Forward 10 seconds",
        pipPendingIntent(context, PIP_ACTION_FORWARD, 2)
    )

    return listOf(rewindAction, playPauseAction, forwardAction)
}

internal fun pipEnter(activity: Activity?, isPlaying: Boolean, position: Long, duration: Long) {
    activity ?: return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .setActions(buildPipActions(activity, isPlaying))
            .build()
        activity.enterPictureInPictureMode(params)
    } else {
        @Suppress("DEPRECATION")
        activity.enterPictureInPictureMode()
    }
}
