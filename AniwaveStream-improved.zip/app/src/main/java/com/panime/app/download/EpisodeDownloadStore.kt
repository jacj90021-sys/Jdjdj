package com.panime.app.download

import android.content.Context
import org.json.JSONObject

/**
 * Small app-side extras that Media3's DownloadIndex does not hold
 * (completion timestamp, last human-readable error). Prefs-backed; keyed by
 * download id. Everything download-progression-related itself lives in
 * Media3's persistent index — this store never duplicates progress bytes.
 */
object EpisodeDownloadStore {

    private const val PREFS = "dl_extras"

    fun setCompletedAt(context: Context, id: String) = edit(context) {
        putLong("completed_$id", System.currentTimeMillis())
    }

    fun completedAt(context: Context, id: String): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("completed_$id", 0L)

    fun setLastError(context: Context, id: String, message: String?) = edit(context) {
        if (message == null) remove("error_$id") else putString("error_$id", message)
    }

    fun lastError(context: Context, id: String): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("error_$id", null)

    fun clearAllFor(context: Context, id: String) = edit(context) {
        remove("completed_$id"); remove("error_$id")
    }

    private inline fun edit(context: Context, block: android.content.SharedPreferences.Editor.() -> Unit) {
        runCatching {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().apply(block).apply()
        }
    }
}
