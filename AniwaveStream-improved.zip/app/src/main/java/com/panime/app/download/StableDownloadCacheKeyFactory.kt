package com.panime.app.download

import android.content.Context
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.cache.CacheKeyFactory

/**
 * Media3 [CacheKeyFactory] that gives every HLS/DASH segment of a download a
 * cache key rooted in the download's STABLE id, rather than the CDN URL path.
 *
 * ## Why this fixes the 10% -> 0% resume bug
 *
 * Media3's `SegmentDownloader` decides to re-fetch purely from the cache key:
 * if `buildCacheKey(segment)` matches a key that already has cached bytes, the
 * segment is skipped (resumed); if not, it is fetched from 0. The default key
 * is the query-stripped segment URL, which changes whenever the CDN rotates the
 * *path* — so a refresh from URL-A (`…/v1/enc/AAAA/…`) to URL-B (`…/v1/enc/BBBB/…`)
 * produces different keys and the old 10% is missed.
 *
 * This factory maps every segment of a registered download to:
 *
 *     "dl:<downloadId>:<segment-relative-path>"
 *
 * where `<segment-relative-path>` is the part after the registered manifest base
 * (the segments' stable content identifiers) and `<downloadId>` is our
 * per-episode id. Because the same [DownloadCacheRegistry] entry is re-asserted
 * after a URL refresh with the NEW base pointing at the SAME downloadId, segments
 * under the new path compute the SAME key as before -> Media3 finds the cached
 * bytes -> resume, not restart.
 *
 * ## Safety properties
 *
 *  - **No arbitrary path truncation**: we only map URIs that fall under a base
 *    we explicitly registered at enqueue/refresh. Anything unregistered uses the
 *    current query-stripped key (streaming playback is byte-for-byte unchanged).
 *  - **No cross-episode collision**: the key is rooted in `downloadId`, so two
 *    shows never share cache entries even if segment names coincide.
 *  - **Process-death safe**: the registry is SharedPreferences-backed and read
 *    here, so a fresh process finds prior registrations and the 10% is reused
 *    after an app kill/restart.
 *  - **MP4 untouched**: progressive downloads keep their `customCacheKey`
 *    (`dataSpec.key`), as today.
 *  - **No Media3 fork**: both the downloader and offline playback already funnel
 *    through the single factory in [com.panime.app.player.PlayerModule]; we only
 *    swap the factory object.
 */
@UnstableApi
object StableDownloadCacheKeyFactory : CacheKeyFactory {

    @Volatile
    private var appContext: Context? = null

    /** Call once at app start before any downloads run. */
    fun init(context: Context) {
        appContext = context.applicationContext
    }

    override fun buildCacheKey(dataSpec: DataSpec): String {
        // Progressive (MP4) downloads set a customCacheKey; honor it as before.
        dataSpec.key?.let { return it }

        val uriStr = dataSpec.uri?.toString() ?: return ""
        val ctx = appContext ?: return queryStrippedKey(uriStr)

        // Stable, per-download key when the segment belongs to a registered
        // download; otherwise fall back to the historical query-stripped key.
        return StableCacheKeyCore.stableKey(uriStr, DownloadCacheRegistry.currentBases(ctx))
            ?: queryStrippedKey(uriStr)
    }

    /** Historical behaviour (identical to the old query-stripped key). */
    private fun queryStrippedKey(url: String): String = runCatching {
        Uri.parse(url).buildUpon().clearQuery().fragment(null).build().toString()
    }.getOrDefault(url)
}