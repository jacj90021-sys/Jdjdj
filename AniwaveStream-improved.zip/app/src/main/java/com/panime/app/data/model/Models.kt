package com.panime.app.data.model

import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.Transient

@Serializable
data class AnimeListResponse(
    val data: List<AnimeDto> = emptyList(),
    val pagination: Pagination? = null
)

@Serializable
data class AnimeDetailResponse(
    val data: AnimeDto
)

@Serializable
data class CharacterListResponse(
    val data: List<CharacterEdgeDto> = emptyList()
)

@Serializable
data class CharacterEdgeDto(
    val character: CharacterDto? = null,
    val role: String? = null
)

@Serializable
data class CharacterDto(
    @SerialName("mal_id") val malId: Int = 0,
    val name: String = "",
    val images: Images? = null,
    val url: String? = null
)

@Serializable
data class Pagination(
    @SerialName("last_visible_page") val lastVisiblePage: Int = 1,
    @SerialName("has_next_page") val hasNextPage: Boolean = false
)

@Serializable
data class AnimeDto(
    @SerialName("mal_id") val malId: Int,
    val title: String = "",
    @SerialName("title_english") val titleEnglish: String? = null,
    val synopsis: String? = null,
    val type: String? = null,
    val episodes: Int? = null,
    val status: String? = null,
    val score: Double? = null,
    val rank: Int? = null,
    val popularity: Int? = null,
    val year: Int? = null,
    val season: String? = null,
    val rating: String? = null,
    val duration: String? = null,
    val images: Images? = null,
    val trailer: Trailer? = null,
    val genres: List<NamedEntity> = emptyList(),
    val studios: List<NamedEntity> = emptyList(),
    @SerialName("aired") val aired: Aired? = null
) {
    val displayTitle: String get() = titleEnglish?.takeIf { it.isNotBlank() } ?: title
    val posterUrl: String? get() =
        images?.jpg?.largeImageUrl ?: images?.jpg?.imageUrl ?: images?.webp?.largeImageUrl ?: images?.webp?.imageUrl
    val bannerUrl: String? get() = posterUrl
}

@Serializable
data class Images(val jpg: ImageUrls? = null, val webp: ImageUrls? = null)

@Serializable
data class ImageUrls(
    @SerialName("image_url") val imageUrl: String? = null,
    @SerialName("small_image_url") val smallImageUrl: String? = null,
    @SerialName("large_image_url") val largeImageUrl: String? = null
)

@Serializable
data class Trailer(
    @SerialName("youtube_id") val youtubeId: String? = null,
    val url: String? = null,
    @SerialName("embed_url") val embedUrl: String? = null
)

@Serializable
data class NamedEntity(
    @SerialName("mal_id") val malId: Int = 0,
    val name: String = ""
)

@Serializable
data class Aired(val string: String? = null)

/**
 * Wrapper for paginated list responses.
 * [lastPage] is the *real* total page count derived from actual anime results
 * (AniList's pageInfo.lastPage is often a hard cap of 100 and must not be used raw).
 */
data class PagedResult<T>(
    val items: List<T>,
    val lastPage: Int
)

/* ===================== AniList GraphQL models ===================== */

@Serializable
data class AlResponse(
    val data: AlData? = null,
    val errors: List<AlError>? = null
)

@Serializable
data class AlError(val message: String = "")

@Serializable
data class AlData(
    val Page: AlPage? = null,
    val Media: AlMedia? = null
)

@Serializable
data class AlPageInfo(
    val total: Int = 0,
    val lastPage: Int = 0,
    val hasNextPage: Boolean? = null,
    val currentPage: Int = 0,
    val perPage: Int = 0
)

@Serializable
data class AlPage(
    val media: List<AlMedia> = emptyList(),
    val airingSchedules: List<AlAiring> = emptyList(),
    val pageInfo: AlPageInfo? = null
)

@Serializable
data class AlAiring(
    val episode: Int? = null,
    val airingAt: Long? = null,
    val media: AlMedia? = null
)

@Serializable
data class AlFuzzyDate(
    val year: Int? = null,
    val month: Int? = null,
    val day: Int? = null
)

@Serializable
data class AlMedia(
    val id: Int = 0,
    @SerialName("idMal") val idMal: Int? = null,
    val title: AlTitle? = null,
    val coverImage: AlCoverImage? = null,
    val bannerImage: String? = null,
    val averageScore: Int? = null,
    val episodes: Int? = null,
    val nextAiringEpisode: AlAiringEpisode? = null,
    val season: String? = null,
    val seasonYear: Int? = null,
    val startDate: AlFuzzyDate? = null,
    val format: String? = null,
    val status: String? = null,
    val description: String? = null,
    val genres: List<String> = emptyList(),
    val studios: AlStudioConnection? = null,
    val characters: AlCharacterConnection? = null,
    val recommendations: AlRecommendationConnection? = null,
    val synonyms: List<String> = emptyList(),
    val duration: Int? = null,
    val countryOfOrigin: String? = null,
    val isAdult: Boolean? = null
)

@Serializable
data class AlTitle(
    val romaji: String = "",
    val english: String? = null,
    val native: String? = null
)

@Serializable
data class AlCoverImage(
    val extraLarge: String? = null,
    val large: String? = null,
    val medium: String? = null,
    val color: String? = null
)

@Serializable
data class AlAiringEpisode(
    val episode: Int? = null,
    val airingAt: Long? = null
)

@Serializable
data class AlStudioConnection(val nodes: List<AlStudio> = emptyList())

@Serializable
data class AlStudio(val name: String = "")

@Serializable
data class AlCharacterConnection(val edges: List<AlCharacterEdge> = emptyList())

@Serializable
data class AlCharacterEdge(
    val role: String? = null,
    val node: AlCharacterNode? = null
)

@Serializable
data class AlCharacterNode(
    val id: Int = 0,
    val name: AlName? = null,
    val image: AlImage? = null
)

@Serializable
data class AlName(val full: String = "")

@Serializable
data class AlImage(
    val large: String? = null,
    val medium: String? = null
)

@Serializable
data class AlRecommendationConnection(val nodes: List<AlRecommendationNode> = emptyList())

/** AniList Recommendation: [mediaRecommendation] is the suggested title (not [media], the source). */
@Serializable
data class AlRecommendationNode(
    val mediaRecommendation: AlMedia? = null,
    /** Legacy alias some payloads still use; prefer mediaRecommendation. */
    val media: AlMedia? = null
) {
    val recommended: AlMedia? get() = mediaRecommendation ?: media
}


/** Extract the season NUMBER from an AniList title set.
 *  Handles "Season 3", "3rd Season", "2nd Season", and roman numerals
 *  ("II"/"III"). Returns 1 when no season token is found (base series). */
fun parseSeasonNumber(titles: List<String>): Int {
    val wordToNum = mapOf(
        "second" to 2, "third" to 3, "fourth" to 4, "fifth" to 5,
        "sixth" to 6, "seventh" to 7, "eighth" to 8, "ninth" to 9
    )
    val romanToNum = mapOf("ii" to 2, "iii" to 3, "iv" to 4, "v" to 5, "vi" to 6)
    for (t in titles) {
        val low = t.lowercase()
        Regex("""season\s*(\d+)""").find(low)?.let { return it.groupValues[1].toIntOrNull() ?: 1 }
        Regex("""(\d+)(st|nd|rd|th)\s+season""").find(low)?.let { return it.groupValues[1].toIntOrNull() ?: 1 }
        for ((w, n) in wordToNum) {
            if (Regex("""\b$w\s+season\b""").containsMatchIn(low)) return n
        }
        Regex("""\b(ii|iii|iv|v|vi)\b""").find(low)?.let { return romanToNum[it.groupValues[1]] ?: 1 }
    }
    return 1
}

/** Strip HTML tags from AniList descriptions and fall back to romaji title. */
fun AlMedia.toAnime(): Anime {
    val poster = coverImage?.extraLarge ?: coverImage?.large ?: coverImage?.medium
    val title = this.title?.english ?: this.title?.romaji ?: this.title?.native ?: ""
    val seasonNumber = parseSeasonNumber(
        listOfNotNull(this.title?.romaji, this.title?.english, this.title?.native)
    )
    val synopsis = description
        ?.replace(Regex("<br\\s*/?>"), "\n")
        ?.replace(Regex("<[^>]*>"), "")
        ?.trim()
        .orEmpty()
    // Always use AniList Media.id as the app id. Detail/characters/recommendations
    // query AniList with Media(id: …); using idMal here silently broke Key Characters
    // (wrong media or null) while list screens still looked fine via the in-memory cache.
    return Anime(
        id = id,
        title = title,
        synopsis = synopsis,
        posterUrl = poster,
        bannerUrl = bannerImage ?: poster,
        score = averageScore?.toDouble()?.div(10.0),
        // Total planned eps only — never fall back to nextAiringEpisode.episode
        // (that is the *next* ep number, not the series length; it broke Upcoming meta).
        episodes = episodes,
        nextEpisode = nextAiringEpisode?.episode,
        nextAiringAt = nextAiringEpisode?.airingAt,
        year = seasonYear,
        season = season,
        seasonNumber = seasonNumber,
        startYear = startDate?.year,
        startMonth = startDate?.month,
        startDay = startDate?.day,
        type = format,
        status = status,
        rating = null,
        genres = genres,
        studios = studios?.nodes?.map { it.name } ?: emptyList(),
        countryOfOrigin = countryOfOrigin,
        isAdult = isAdult
    )
}

fun AlCharacterEdge.toCharacter(): Character? {
    val n = node ?: return null
    val name = n.name?.full?.trim().orEmpty()
    if (n.id == 0 && name.isEmpty()) return null
    return Character(
        id = n.id,
        name = name.ifEmpty { "Unknown" },
        imageUrl = n.image?.large ?: n.image?.medium,
        role = role
    )
}

/** In-app domain models */
@Immutable
data class Anime(
    val id: Int = 0,
    val title: String = "",
    val synopsis: String = "",
    val posterUrl: String? = null,
    val bannerUrl: String? = null,
    val score: Double? = null,
    val episodes: Int? = null,
    /** AniList nextAiringEpisode.episode (only set while the anime is currently airing). */
    val nextEpisode: Int? = null,
    /** AniList nextAiringEpisode.airingAt — epoch SECONDS of the next episode drop (0 = none). */
    val nextAiringAt: Long? = null,
    /** AniList seasonYear (e.g. 2026). */
    val year: Int? = null,
    /** AniList Media.season enum: WINTER / SPRING / SUMMER / FALL. */
    val season: String? = null,
    /** AniList season NUMBER (1 = base, 2 = Season 2 / "2nd Season", ...). */
    val seasonNumber: Int = 1,
    /** AniList startDate fuzzy components (any may be null). */
    val startYear: Int? = null,
    val startMonth: Int? = null,
    val startDay: Int? = null,
    val type: String? = null,
    val status: String? = null,
    val rating: String? = null,
    val genres: List<String> = emptyList(),
    val studios: List<String> = emptyList(),
    val countryOfOrigin: String? = null,
    val isAdult: Boolean? = null,
    /** anikoto.cz watch-page slug for this title (Koto provider mode only). */
    val kotoSlug: String? = null
)

/**
 * Badge + meta line for Upcoming cards, driven by AniList startDate / season /
 * nextAiringEpisode / episodes / format / status. Covers the 11 real-world cases:
 * live countdown, exact date, month, season, year-only, OVA, TBA/postponed, etc.
 */
data class UpcomingDisplay(
    /** Top badge, e.g. "EP 1: 92D 10H 42M", "OCT 4, 2026", "FALL 2026", "TBA". */
    val badge: String,
    /** Meta under the title, e.g. "TV · 12 EPS · FALL 2026". */
    val meta: String,
    /** True when [badge] embeds a live countdown that should tick every second. */
    val liveCountdown: Boolean = false
)

private val MONTH_ABBR = arrayOf(
    "", "JAN", "FEB", "MAR", "APR", "MAY", "JUN",
    "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"
)

/** AniList format enum → short label (TV, MOVIE, OVA…). */
fun formatLabel(type: String?): String {
    val raw = type?.trim().orEmpty()
    if (raw.isEmpty()) return "TV"
    return raw.replace('_', ' ').uppercase()
}

/** "92D 10H 42M" / "11H 4M" style countdown from remaining seconds. */
fun formatCountdownUpper(seconds: Long): String {
    val s = seconds.coerceAtLeast(0L)
    val d = s / 86400L
    val h = (s % 86400L) / 3600L
    val m = (s % 3600L) / 60L
    return when {
        d > 0 -> "${d}D ${h}H ${m}M"
        h > 0 -> "${h}H ${m}M"
        else -> "${m}M"
    }
}

/** Full date when year+month+day are all known: "OCT 4, 2026". */
fun formatFullStartDate(year: Int?, month: Int?, day: Int?): String? {
    if (year == null || month == null || day == null) return null
    if (month !in 1..12 || day !in 1..31) return null
    return "${MONTH_ABBR[month]} $day, $year"
}

/** Month + year when day is unknown: "OCT 2026". */
fun formatMonthYear(year: Int?, month: Int?): String? {
    if (year == null || month == null || month !in 1..12) return null
    return "${MONTH_ABBR[month]} $year"
}

/** "FALL 2026" from AniList season + seasonYear. */
fun formatSeasonYear(season: String?, year: Int?): String? {
    val s = season?.trim()?.uppercase().orEmpty()
    if (s.isEmpty() || year == null) return null
    return "$s $year"
}

/**
 * Pick badge + meta from available AniList fields (11 scenarios).
 * Pass [nowSec] / recompute when the live countdown ticks.
 */
fun Anime.toUpcomingDisplay(nowSec: Long = System.currentTimeMillis() / 1000L): UpcomingDisplay {
    val format = formatLabel(type)
    val fullDate = formatFullStartDate(startYear, startMonth, startDay)
    val monthYear = formatMonthYear(startYear ?: year, startMonth)
    val seasonYearLabel = formatSeasonYear(season, year ?: startYear)
    val yearOnly = startYear ?: year
    val eps = episodes
    val airingAt = nextAiringAt ?: 0L
    val left = if (airingAt > 0L) (airingAt - nowSec) else Long.MIN_VALUE
    val hasCountdown = left >= 0L && airingAt > 0L
    val epNum = (nextEpisode ?: 1).coerceAtLeast(1)
    val statusUp = status?.uppercase().orEmpty()
    val isSpecialFormat = type.equals("OVA", true) ||
        type.equals("SPECIAL", true) ||
        type.equals("MOVIE", true) ||
        type.equals("TV_SHORT", true)
    val isSingle = eps == 1 || type.equals("MOVIE", true)

    // --- Live countdown branch (scenarios 1–3) ---
    if (hasCountdown) {
        val badge = "EP $epNum: ${formatCountdownUpper(left)}"
        val meta = when {
            // 3) Single ep / Movie / OVA + release date
            isSingle && fullDate != null ->
                "$format · 1 EP · $fullDate"
            // 1) Countdown + total EPS + start date
            eps != null && eps > 0 && fullDate != null ->
                "$format · $eps EPS · $fullDate"
            // 2) Countdown + start date + season
            fullDate != null && seasonYearLabel != null ->
                "$format · $fullDate · $seasonYearLabel"
            fullDate != null ->
                listOfNotNull(format, fullDate).joinToString(" · ")
            eps != null && eps > 0 ->
                "$format · $eps EPS"
            seasonYearLabel != null ->
                "$format · $seasonYearLabel"
            else -> format
        }
        return UpcomingDisplay(badge, meta, liveCountdown = true)
    }

    // --- Exact start date, no live countdown (4, 8, 10) ---
    if (fullDate != null) {
        // 10) Special format / OVA direct date
        if (isSpecialFormat) {
            val epPart = when {
                isSingle -> "1 EP"
                eps != null && eps > 0 -> "$eps EPS"
                else -> null
            }
            return UpcomingDisplay(fullDate, listOfNotNull(format, epPart).joinToString(" · "))
        }
        // 8) Exact start date + episode count
        if (eps != null && eps > 0) {
            val tail = seasonYearLabel ?: yearOnly?.toString()
            return UpcomingDisplay(
                fullDate,
                listOfNotNull(format, "$eps EPS", tail).joinToString(" · ")
            )
        }
        // 4) Exact start date only
        return UpcomingDisplay(
            fullDate,
            listOfNotNull(format, seasonYearLabel).joinToString(" · ")
        )
    }

    // 5) Month & year confirmed
    if (monthYear != null) {
        return UpcomingDisplay(
            monthYear,
            listOfNotNull(format, seasonYearLabel).joinToString(" · ")
        )
    }

    // 6–7) Season & year (± episode count)
    if (seasonYearLabel != null) {
        val meta = if (eps != null && eps > 0) {
            "$format · $eps EPS · ${yearOnly ?: year}"
        } else {
            "$format · ${yearOnly ?: year}"
        }
        return UpcomingDisplay(seasonYearLabel, meta)
    }

    // 9) Year only
    if (yearOnly != null) {
        return UpcomingDisplay(yearOnly.toString(), "$format · $yearOnly")
    }

    // 11) Postponed / TBA fallback
    val statusMeta = when {
        statusUp.contains("CANCEL") || statusUp.contains("HIATUS") ||
            statusUp.contains("POSTPON") -> "POSTPONED"
        else -> "UPCOMING"
    }
    return UpcomingDisplay("TBA", "$format · $statusMeta")
}

fun AnimeDto.toAnime() = Anime(
    id = malId,
    title = displayTitle,
    synopsis = synopsis.orEmpty(),
    posterUrl = posterUrl,
    bannerUrl = bannerUrl,
    score = score,
    episodes = episodes,
    year = year,
    type = type,
    status = status,
    rating = rating,
    genres = genres.map { it.name },
    studios = studios.map { it.name }
)

@Immutable
data class Episode(
    val number: Int,
    val title: String,
    val durationLabel: String,
    /** Public demo stream (not licensed anime content). */
    val streamUrl: String
)

@Immutable
data class ContinueItem(
    val anime: Anime,
    val episode: Int,
    val progressFraction: Float,
    val completedCount: Int = 0,
    val totalEpisodes: Int = 0
)

@Immutable
data class GenreChip(val id: Int, val name: String)

val BrowseGenres = listOf(
    GenreChip(1, "Action"),
    GenreChip(2, "Adventure"),
    GenreChip(3, "Comedy"),
    GenreChip(4, "Drama"),
    GenreChip(5, "Ecchi"),
    GenreChip(6, "Fantasy"),
    GenreChip(7, "Horror"),
    GenreChip(8, "Mecha"),
    GenreChip(9, "Music"),
    GenreChip(10, "Mystery"),
    GenreChip(11, "Psychological"),
    GenreChip(12, "Romance"),
    GenreChip(13, "Sci-Fi"),
    GenreChip(14, "Mahou Shoujo"),
    GenreChip(15, "Slice of Life"),
    GenreChip(16, "Space"),
    GenreChip(17, "Sports"),
    GenreChip(18, "Supernatural"),
    GenreChip(19, "Thriller")
)

@Immutable
data class Character(
    val id: Int,
    val name: String,
    val imageUrl: String?,
    val role: String?
)

/** Combined detail payload fetched from AniList in a SINGLE GraphQL call (media + characters + recommendations). */
data class DetailData(
    val anime: Anime,
    val characters: List<Character>,
    val recommendations: List<Anime>
)

fun CharacterEdgeDto.toCharacter(): Character? {
    val c = character ?: return null
    return Character(
        id = c.malId,
        name = c.name,
        imageUrl = c.images?.jpg?.largeImageUrl ?: c.images?.jpg?.imageUrl,
        role = role
    )
}

/** One real airing entry from AniList AiringSchedule, grouped by weekday in-app. */
@Serializable
data class AiringSchedule(
    val id: Int = 0,
    val title: String = "",
    val cover: String? = null,
    val episode: Int = 0,
    val totalEpisodes: Int? = null,
    val airingAt: Long = 0L,
    val status: String? = null,
    /** AniList episode duration in MINUTES (may be null). */
    val durationMin: Int? = null,
    /** Full AniList media (for the Recently Updated tiles); null in the weekly-schedule path.
     *  In-memory only — excluded from kotlinx serialization (Anime is not @Serializable). */
    @Transient val anime: Anime? = null
)

/** Human "x mins/hours/days ago" from an AniList UTC `airingAt` (epoch SECONDS). */
fun AiringSchedule.timeAgo(nowMs: Long = System.currentTimeMillis()): String {
    if (airingAt <= 0L) return ""
    val diffSec = (nowMs / 1000L - airingAt).coerceAtLeast(0L)
    val min = diffSec / 60
    return when {
        min < 1 -> "just now"
        min < 60 -> "$min min ago"
        min < 1440 -> "${min / 60} hr${if (min / 60 > 1) "s" else ""} ago"
        else -> "${min / 1440} day${if (min / 1440 > 1) "s" else ""} ago"
    }
}

/** "24m" style duration label from AniList `durationMin` minutes. */
fun AiringSchedule.durationLabel(): String = durationMin?.let { "${it}m" }.orEmpty()

/** Sort airing entries by their broadcast time, earliest first. */
fun List<AiringSchedule>.sortedByAiring(): List<AiringSchedule> =
    sortedBy { it.airingAt }

/** Default crop bias for the slanted schedule art: vertically centred on the
 *  upper-third of the poster (object-position ~center 22%), so faces in tall
 *  portrait sources aren't cut. Built via the public Alignment lambda ctor. */
val PosterFocalDefault: Alignment = Alignment { size, space, _ ->
    IntOffset(
        x = (space.width - size.width) / 2,
        y = ((space.height - size.height) * 0.22f).roundToInt()
    )
}

/** A single timed broadcast for the weekly schedule card. */
data class DayAiring(
    val time: String,      // "23:00"
    val title: String,
    val status: String,    // "Hype Airing", "New", "Final"
    val episode: Int = 0,  // released episode number (0 = unknown)
    val cover: String? = null,
    val posterFocal: Alignment = PosterFocalDefault, // crop bias: top-third (object-position ~center 22%), overridable per title
    val airingAt: Long = 0L,  // epoch SECONDS of the next airing (0 = unknown)
    val animeId: Int = 0      // AniList Media.id for detail navigation
)

/** One day in the site's own schedule window (epoch = UTC midnight). */
data class ScheduleDay(
    val epoch: Long,   // UTC midnight epoch SECONDS
    val date: String,  // site label, e.g. "Aug 14"
    val wday: String   // site label, e.g. "Fri"
)

/** The week the site's schedule widget currently shows: day window + broadcasts. */
data class WeekSchedule(
    val days: List<ScheduleDay>,
    val entries: List<AiringSchedule>
)

/** Fallback day window for providers without a site schedule (today..+6, local time). */
fun currentWeekScheduleDays(): List<ScheduleDay> {
    val tz = java.util.TimeZone.getDefault()
    val cal = java.util.Calendar.getInstance(tz)
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)
    val startEpoch = cal.timeInMillis / 1000L
    val dateFmt = java.text.SimpleDateFormat("MMM d", java.util.Locale.US).apply { timeZone = tz }
    val wdayFmt = java.text.SimpleDateFormat("EEE", java.util.Locale.US).apply { timeZone = tz }
    return (0 until 7).map { i ->
        val epoch = startEpoch + i * 86400L
        ScheduleDay(epoch, dateFmt.format(java.util.Date(epoch * 1000L)), wdayFmt.format(java.util.Date(epoch * 1000L)))
    }
}

/**
 * Group timed broadcasts into the site's day window. Each row keeps the release
 * time EXACTLY as the site publishes it (UTC tz=0) — no countdowns, no invented
 * timestamps. Rows that fall outside the window are dropped.
 */
fun buildSiteSchedule(days: List<ScheduleDay>, shows: List<AiringSchedule>): Map<Long, List<DayAiring>> {
    val byDay = mutableMapOf<Long, MutableList<DayAiring>>()
    val tz = java.util.TimeZone.getDefault()
    val cal = java.util.Calendar.getInstance(tz)
    // Site-schedule windows (koto) are UTC midnights; the fallback week (anilist
    // etc.) is local midnights. Group each broadcast into the matching window:
    // a UTC-aligned window matches the broadcast's UTC day, a local window its
    // local day. Without this, koto's all-UTC entries never land in a non-UTC
    // user's local-day window and the schedule card stays empty.
    val utcAlignedWindow = days.isNotEmpty() && days.all { it.epoch % 86400L == 0L }
    for (s in shows.sortedByAiring()) {
        val dayEpoch =
            if (utcAlignedWindow) s.airingAt - (s.airingAt % 86400L)
            else localDayEpoch(s.airingAt, tz)
        if (days.none { it.epoch == dayEpoch }) continue
        cal.timeInMillis = s.airingAt * 1000L
        val time = "%02d:%02d".format(cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE))
        val status = when {
            s.status.equals("FINISHED", true) -> "Final"
            s.status.equals("RELEASING", true) && (s.totalEpisodes == null || s.episode < (s.totalEpisodes ?: Int.MAX_VALUE)) -> "Hype Airing"
            else -> "New"
        }
        byDay.getOrPut(dayEpoch) { mutableListOf() }.add(
            DayAiring(time, s.title, status, s.episode, s.cover, PosterFocalDefault, s.airingAt, s.id)
        )
    }
    return byDay
}

/** Epoch of the LOCAL midnight that [airingAtEpoch] falls into, in [tz]. */
private fun localDayEpoch(airingAtEpoch: Long, tz: java.util.TimeZone): Long {
    val cal = java.util.Calendar.getInstance(tz)
    cal.timeInMillis = airingAtEpoch * 1000L
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)
    return cal.timeInMillis / 1000L
}

/** A new-release episode tile (landscape) for the Home "Recently Updated" row. */
data class NewReleaseEpisode(
    val anime: Anime,
    val epNum: String,     // "Ep 3"
    val epTitle: String,   // "Across the Pass"
    val timeAgo: String,   // "2 hrs ago" / "3 days ago"
    val duration: String,  // "24m"
    val progress: Float    // 0..1 watched fraction
) {
    companion object {
        /** Build a real tile from a live AiringSchedule (Dantotsu-style window). */
        fun from(s: AiringSchedule): NewReleaseEpisode {
            val ep = s.episode
            val epLabel = if (ep > 0) "Ep $ep" else "New"
            return NewReleaseEpisode(
                anime = checkNotNull(s.anime) { "RecentlyUpdated tile needs a resolved Anime" },
                epNum = epLabel,
                epTitle = s.anime.title,
                timeAgo = s.timeAgo(),
                duration = s.durationLabel(),
                progress = 0f
            )
        }
    }
}

/** Build the home "Recently Updated" tiles from the provider's own airings.
 *  Only real entries are ever shown — the demo fallback list was deleted. */
fun buildRecentlyUpdated(result: Result<List<AiringSchedule>>): List<NewReleaseEpisode> {
    return result.getOrDefault(emptyList()).mapNotNull { s -> runCatching { NewReleaseEpisode.from(s) }.getOrNull() }
}

