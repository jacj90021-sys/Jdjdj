package com.panime.app.data.api

import com.panime.app.data.model.AiringSchedule
import com.panime.app.data.model.Anime
import com.panime.app.data.model.DetailData
import com.panime.app.data.model.GenreChip
import com.panime.app.data.model.PagedResult
import com.panime.app.data.model.ScheduleDay
import com.panime.app.data.model.WeekSchedule
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.util.Obf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.concurrent.ConcurrentHashMap

/**
 * Catalog provider that scrapes aniwaves.ru for browse/search/detail/episodes.
 *
 * Mirrors the KotoApi pattern: aniwaves numeric IDs are shifted by [ID_OFFSET]
 * so they never collide with AniList IDs in the shared cache/progress/My List.
 *
 * Endpoints used:
 *   /trending               -> popular anime list
 *   /updated                -> recently updated
 *   /newest                 -> newest additions
 *   /ajax/anime/search      -> typeahead (5 results)
 *   /filter?keyword=X&page=N -> paginated search
 *   /watch/{slug}           -> detail page (title, year, genres, synopsis)
 *   /ajax/episode/list/{id} -> episode list (data-num values)
 */
object AniwavesCatalog {

    private val BASE = Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoLw==")
    const val ID_OFFSET = 80_000_000

    /** In-memory slug registry: aniwaves numeric id -> slug. */
    private val slugById = ConcurrentHashMap<Int, String>()

    /** Genre chip id (site order) -> /genre/<slug>, filled by [genres]. */
    private val genreIdToSlug = mutableMapOf<Int, String>()

    /** Last-scraped week (day window + entries), reused by [scheduleDays] so the
     *  card never triggers a second batch of site fetches. In-memory only. */
    private var cachedWeek: WeekSchedule? = null

    private fun headers() = ScraperEngine.defaultHeaders(referer = "$BASE/")

    // ── ID helpers ────────────────────────────────────────────────────────

    /** App-level ID from aniwaves numeric id. */
    fun appId(rawId: Int): Int = rawId + ID_OFFSET

    /** Aniwaves raw numeric id from app-level id. */
    fun rawId(appId: Int): Int = appId - ID_OFFSET

    private fun numIdFromSlug(slug: String): Int =
        Regex("""-(\d+)$""").find(slug)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    // ── Catalog lists ─────────────────────────────────────────────────────

    fun trending(limit: Int = 30): List<Anime> = parseListPage("$BASE/trending", limit)

    fun updated(limit: Int = 30): List<Anime> = parseListPage("$BASE/updated", limit)

    fun newest(limit: Int = 30): List<Anime> = parseListPage("$BASE/newest", limit)

    fun ongoing(limit: Int = 30): List<Anime> = parseListPage("$BASE/ongoing", limit)

    fun added(limit: Int = 30): List<Anime> = parseListPage("$BASE/added", limit)

    fun seasonal(season: String, year: Int, limit: Int = 30): List<Anime> =
        parseFilterPage("$BASE/filter?status[]=1&season[]=${season.lowercase()}&year[]=$year&sort_by=m_view", limit)

    fun topRated(limit: Int = 30): List<Anime> =
        parseFilterPage("$BASE/filter?sort_by=score", limit)

    /** Safety cap on /filter pagination during search (each page ≈ 24 items). */
    private const val MAX_SEARCH_PAGES = 30

    /** Concurrent /filter page fetches during search (site + network friendly). */
    private const val SEARCH_PARALLELISM = 4

    /**
     * Full search: typeahead first (best-ranked), then EVERY /filter page so we
     * return everything the site has for [query] — not just page 1. The site's
     * catalog paginates (~24 items/page); page 1 reveals the true last page via
     * the site's own pager links, then the remaining pages are fetched
     * concurrently. A failed page fetch is retried and never silently truncates
     * the result set ([MAX_SEARCH_PAGES] caps pathological queries).
     */
    fun search(query: String, limit: Int = 500): List<Anime> {
        if (query.isBlank()) return emptyList()
        // 1. Typeahead (fast, top 5) — ranks the best matches first.
        val typeahead = typeahead(query)
        if (typeahead.isNotEmpty() && typeahead.size >= limit) return typeahead.take(limit)

        val seen = mutableSetOf<Int>()
        val out = mutableListOf<Anime>()
        for (a in typeahead) { if (seen.add(a.id)) out.add(a) }

        val params = "keyword=${enc(query)}"
        // 2. Page 1 first: its items AND the site's own last-page number.
        val first = searchFilterPage(params, 1) ?: return out.take(limit)
        for (a in first.items) { if (seen.add(a.id)) out.add(a) }

        // 3. Fetch every remaining page (2..lastPage) concurrently, bounded, so a
        //    broad query doesn't crawl sequentially for half a minute. Pages that
        //    keep failing are skipped rather than mistaken for "no more results".
        val lastPage = minOf(first.lastPage, MAX_SEARCH_PAGES)
        if (lastPage > 1 && out.size < limit) {
            val byPage = ConcurrentHashMap<Int, List<Anime>>()
            runBlocking {
                val sem = Semaphore(SEARCH_PARALLELISM)
                (2..lastPage).map { pg ->
                    launch(Dispatchers.IO) {
                        sem.withPermit {
                            searchFilterPage(params, pg)?.let { byPage[pg] = it.items }
                        }
                    }
                }.joinAll()
            }
            for (pg in 2..lastPage) {
                if (out.size >= limit) break
                for (a in byPage[pg].orEmpty()) { if (seen.add(a.id)) out.add(a) }
            }
        }
        return out.take(limit)
    }

    /**
     * One page of search results (site parity with the /filter pager).
     * Page 1 merges the typeahead hits (best-ranked) with filter page 1;
     * [PagedResult.lastPage] comes from the site's own pager so the UI can
     * offer manual next/prev navigation instead of crawling everything.
     */
    fun searchPage(query: String, page: Int = 1): PagedResult<Anime> {
        if (query.isBlank()) return PagedResult(emptyList(), 1)
        val params = "keyword=${enc(query)}"
        val res = searchFilterPage(params, page.coerceAtLeast(1))
            ?: return PagedResult(emptyList(), 1)
        if (page > 1) return res
        // Page 1: typeahead first, then filter items, deduped.
        val typeahead = typeahead(query)
        if (typeahead.isEmpty()) return res
        val seen = mutableSetOf<Int>()
        val out = mutableListOf<Anime>()
        for (a in typeahead) { if (seen.add(a.id)) out.add(a) }
        for (a in res.items) { if (seen.add(a.id)) out.add(a) }
        return PagedResult(out, maxOf(res.lastPage, 1))
    }

    fun filterPage(params: String, page: Int = 1, limit: Int = 30): PagedResult<Anime> {
        val doc = fetchFilterDoc(params, page) ?: return PagedResult(emptyList(), 1)
        return parseFilterDoc(doc, limit)
    }

    /** GET one /filter page as a parsed document; null after repeated failures. */
    private fun fetchFilterDoc(params: String, page: Int): Document? {
        repeat(3) { attempt ->
            val html = ScraperEngine.fetchText(
                "$BASE/filter?$params&page=$page", headers(),
                timeoutMs = 10_000L, maxRetries = 2
            )
            if (!html.isNullOrBlank()) {
                val doc = runCatching { Jsoup.parse(html) }.getOrNull()
                if (doc != null) return doc
            }
            runCatching { Thread.sleep(500L * (attempt + 1)) }
        }
        return null
    }

    /** Fetch + parse one /filter page with retries. Null ONLY on persistent
     *  failure — an empty [PagedResult.items] means the site truly has no more. */
    private fun searchFilterPage(params: String, page: Int): PagedResult<Anime>? {
        val doc = fetchFilterDoc(params, page) ?: return null
        return parseFilterDoc(doc, Int.MAX_VALUE)
    }

    /** Items + last-page number (from the site's own pager links). */
    private fun parseFilterDoc(doc: Document, limit: Int): PagedResult<Anime> {
        val scope = doc.getElementById("list-items") ?: doc
        val items = parseItems(scope.html()).take(limit)
        val lastPage = doc.select("a[href*='page=']").mapNotNull {
            Regex("""page=(\d+)""").find(it.attr("href"))?.groupValues?.get(1)?.toIntOrNull()
        }.maxOrNull() ?: 1
        return PagedResult(items, lastPage)
    }

    // ── Browse: genres / years / A-Z (wave parity with koto) ────────────────

    /**
     * The site's REAL genre list from the /filter header nav (48 genres with
     * clean labels — Action, Adult Cast, Avant Garde, CGDCT, Gore, Isekai,
     * Vampire, …). Ids are assigned in site order so the chips resolve to a
     * slug immediately; the scrape also fills [genreIdToSlug] so [genrePage]
     * needs no hardcoded id->slug table.
     */
    fun genres(): List<GenreChip> {
        val html = ScraperEngine.fetchText(
            "$BASE/filter", headers(), timeoutMs = 10_000L, maxRetries = 2
        ) ?: return emptyList()
        val matches = Regex("""href="/genre/([a-z0-9-]+)" title="([^"]+)""")
            .findAll(html).toList()
        return matches.mapIndexed { i, m ->
            val slug = m.groupValues[1]
            genreIdToSlug[i + 1] = slug
            GenreChip(i + 1, m.groupValues[2].trim())
        }
    }

    /** One page of a real /genre/<slug> grid. Wave's pager is PATH-based:
     *  /genre/<slug>/page/N (verified: action has 155 pages). */
    fun genrePage(genreId: Int, page: Int, limit: Int = 30): PagedResult<Anime> {
        val slug = genreIdToSlug[genreId] ?: return PagedResult(emptyList(), 1)
        return gridPagePaged("$BASE/genre/$slug/page/$page", limit)
    }

    /** One page of a real /az-list/<LETTER> grid (server-side filtered, same
     *  structure as koto — A = A-titles only). "All" = the full A-Z catalogue
     *  (/az-list/all/page/N). Path-based pager: /az-list/<LETTER>/page/N. */
    fun letterPage(letter: String, page: Int, limit: Int = 30): PagedResult<Anime> {
        if (letter.isBlank() || letter.equals("All", ignoreCase = true)) {
            return gridPagePaged("$BASE/az-list/all/page/$page", limit)
        }
        val target = letter.trim().first().uppercaseChar()
        return gridPagePaged("$BASE/az-list/$target/page/$page", limit)
    }

    /** The site's OWN release-year list from the /filter sidebar year filter
     *  (verified: 23 real years, 2026 down to 2004). Never a hardcoded range. */
    fun siteYears(): List<Int> {
        val html = ScraperEngine.fetchText(
            "$BASE/filter", headers(), timeoutMs = 10_000L, maxRetries = 2
        ) ?: return emptyList()
        return Regex("""name="year\[\]"[^>]*value="(\d{4})""")
            .findAll(html).mapNotNull { it.groupValues[1].toIntOrNull() }
            .distinct().sortedDescending().toList()
    }

    /** One page of a path-paginated grid (#list-items cards, /page/N pager). */
    private fun gridPagePaged(url: String, limit: Int): PagedResult<Anime> {
        val html = ScraperEngine.fetchText(
            url, headers(), timeoutMs = 10_000L, maxRetries = 2
        ) ?: return PagedResult(emptyList(), 1)
        val doc = runCatching { Jsoup.parse(html) }.getOrNull()
            ?: return PagedResult(emptyList(), 1)
        val scope = doc.getElementById("list-items") ?: doc
        val items = parseItems(scope.html()).take(limit)
        val lastPage = doc.select("a[href*='/page/']").mapNotNull {
            Regex("""/page/(\d+)""").find(it.attr("href"))?.groupValues?.get(1)?.toIntOrNull()
        }.maxOrNull() ?: 1
        return PagedResult(items, lastPage)
    }

    // ── Schedule ─────────────────────────────────────────────────────────

    /**
     * REAL estimated weekly schedule straight from the site's own widget
     * (aniwaves.ru/home — "Estimated Schedule"). Mirrors the koto approach:
     * /ajax/schedule returns the day tabs (each carrying a UTC date string like
     * "2026-08-24" + the site's own date/weekday labels); each tab is then
     * fetched via /ajax/schedule/date?tz=0&time=<date-string>, whose items carry
     * the anime's broadcast time (12-hour, UTC), episode number and title.
     * No synthetic data — every entry is scraped live and the day window is the
     * site's own. The result is cached so the day tabs don't trigger a second
     * batch of site fetches.
     */
    fun schedule(): WeekSchedule {
        val html = ScraperEngine.fetchText(
            "$BASE/ajax/schedule?tz=0",
            headers() + mapOf("X-Requested-With" to "XMLHttpRequest"),
            timeoutMs = 10_000L, maxRetries = 1
        ) ?: return WeekSchedule(emptyList(), emptyList())
        val json = runCatching { org.json.JSONObject(html) }.getOrNull()
            ?: return WeekSchedule(emptyList(), emptyList())
        val resultHtml = json.optString("result", "")
        if (resultHtml.isBlank()) return WeekSchedule(emptyList(), emptyList())
        val doc = Jsoup.parse(resultHtml)

        // Day tabs: keep the raw date string (the per-day route wants it) plus
        // the UTC-midnight epoch for the ScheduleDay window.
        val dayTabs = doc.select(".day .inner[data-time]").mapNotNull { el ->
            val dateStr = el.attr("data-time")
            val wday = el.selectFirst(".wday")?.text()?.trim() ?: ""
            val dateLabel = el.selectFirst(".date")?.text()?.trim() ?: dateStr
            val epoch = runCatching {
                java.time.LocalDate.parse(dateStr)
                    .atStartOfDay(java.time.ZoneOffset.UTC)
                    .toEpochSecond()
            }.getOrNull() ?: return@mapNotNull null
            Triple(dateStr, epoch, ScheduleDay(epoch = epoch, date = dateLabel, wday = wday))
        }.distinctBy { it.second }.take(7)
        if (dayTabs.isEmpty()) return WeekSchedule(emptyList(), emptyList())

        // Entries per day from the site's per-day route. hrefs are
        // "/watch/{slug}/ep-N" — strip the episode suffix to get the slug.
        val entries = mutableListOf<AiringSchedule>()
        for ((dateStr, dayEpoch, _) in dayTabs) {
            val dayHtml = ScraperEngine.fetchText(
                "$BASE/ajax/schedule/date?tz=0&time=$dateStr",
                headers() + mapOf("X-Requested-With" to "XMLHttpRequest"),
                timeoutMs = 10_000L, maxRetries = 1
            ) ?: continue
            val dayJson = runCatching { org.json.JSONObject(dayHtml) }.getOrNull() ?: continue
            val dayDoc = Jsoup.parse(dayJson.optString("result", ""))
            for (item in dayDoc.select(".items .item")) {
                val timeEl = item.selectFirst(".time") ?: continue
                val rawId = timeEl.attr("data-tip").toIntOrNull() ?: continue
                val title = item.selectFirst(".title.d-title")?.text()?.trim() ?: continue
                if (title.isBlank()) continue
                val slug = item.attr("href")
                    .removePrefix("/watch/").substringBefore("/ep-").trimEnd('/')
                if (slug.isBlank()) continue
                val epNum = item.selectFirst(".ep span")?.text()?.trim()
                    ?.replace(Regex("""(?i)episode\s*"""), "")?.toIntOrNull() ?: 0
                slugById[rawId] = slug
                val appIdVal = appId(rawId)
                entries += AiringSchedule(
                    id = appIdVal,
                    title = title,
                    episode = epNum,
                    airingAt = dayEpoch + parse12hSeconds(timeEl.text().trim()),
                    status = "RELEASING",
                    anime = if (appIdVal > 0) Anime(id = appIdVal, title = title, kotoSlug = slug) else null
                )
            }
        }
        val week = WeekSchedule(days = dayTabs.map { it.third }, entries = entries.distinctBy { it.id })
        cachedWeek = week
        return week
    }

    /** "04:00 AM" / "12:30 PM" -> seconds past UTC midnight. */
    private fun parse12hSeconds(time: String): Long {
        val (timePart, meridian) = time.split("\\s+".toRegex(), limit = 2).let {
            it.getOrElse(0) { "" } to it.getOrElse(1) { "" }
        }
        val parts = timePart.split(":")
        var hour = parts.getOrElse(0) { "0" }.toIntOrNull() ?: 0
        val minute = parts.getOrElse(1) { "0" }.toIntOrNull() ?: 0
        if (meridian.equals("PM", ignoreCase = true) && hour != 12) hour += 12
        if (meridian.equals("AM", ignoreCase = true) && hour == 12) hour = 0
        return hour * 3600L + minute * 60L
    }

    /** The site's schedule day window — served from the last [schedule] scrape. */
    fun scheduleDays(): List<ScheduleDay> = cachedWeek?.days ?: schedule().days

    // ── Detail ────────────────────────────────────────────────────────────

    fun detail(appIdValue: Int): DetailData? {
        val rawId = rawId(appIdValue)
        val slug = slugById[rawId] ?: return null
        return detailBySlug(slug)
    }

    fun detailBySlug(slug: String): DetailData? {
        val html = ScraperEngine.fetchText(
            "$BASE/watch/$slug", headers(),
            useCache = true, timeoutMs = 10_000L, maxRetries = 1
        ) ?: return null
        val doc = runCatching { Jsoup.parse(html) }.getOrNull() ?: return null

        val ogTitle = doc.selectFirst("meta[property='og:title']")?.attr("content") ?: ""
        val title = ogTitle
            .substringBefore(" – ").substringBefore(" –")
            .replace(Regex("""\s*\(\d{4}\)\s*$"""), "").trim()
            .ifBlank { slug.replace(Regex("""-\d+$"""), "").replace('-', ' ') }
        val year = Regex("""\((\d{4})\)""").find(ogTitle)?.groupValues?.get(1)?.toIntOrNull()
        val synopsis = doc.selectFirst("meta[property='og:description']")?.attr("content")
            ?: doc.selectFirst("meta[name='description']")?.attr("content")
            ?: ""
        val poster = doc.selectFirst("meta[property='og:image']")?.attr("content")

        // Genre: scope to body content AFTER </header> to avoid 48+ nav genre links
        val fullHtml = html
        val headerEnd = fullHtml.indexOf("</header>").coerceAtLeast(0)
        val bodyHtml = fullHtml.substring(headerEnd)
        val genres = Regex("""href="/genre/([^"]+)"[^>]*>([^<]+)<""").findAll(bodyHtml)
            .map { it.groupValues[2].trim() }.filter { it.isNotBlank() }.distinct().toList()

        val rawId = numIdFromSlug(slug)
        if (rawId > 0) slugById[rawId] = slug

        val epCount = fetchEpisodeCount(rawId)

        val anime = Anime(
            id = appId(rawId),
            title = title,
            synopsis = synopsis.trim(),
            posterUrl = poster,
            year = year,
            genres = genres,
            type = "TV",
            status = null,
            episodes = epCount,
            kotoSlug = slug
        )
        return DetailData(anime = anime, characters = emptyList(), recommendations = emptyList())
    }

    // ── Episode count ─────────────────────────────────────────────────────

    fun episodeCount(appIdValue: Int): Int {
        val rawId = rawId(appIdValue)
        return fetchEpisodeCount(rawId)
    }

    private fun fetchEpisodeCount(rawId: Int): Int {
        if (rawId <= 0) return 0
        val slug = slugById[rawId]
        val watchRef = if (slug != null) "$BASE/watch/$slug" else BASE
        val html = ScraperEngine.fetchText(
            "$BASE/ajax/episode/list/$rawId",
            headers() + mapOf("Referer" to watchRef, "X-Requested-With" to "XMLHttpRequest"),
            useCache = true, timeoutMs = 10_000L, maxRetries = 1
        ) ?: return 0
        val result = runCatching {
            val j = org.json.JSONObject(html)
            j.optString("result", html)
        }.getOrNull() ?: html
        return Jsoup.parse(result).select("a[data-ids][data-num]")
            .mapNotNull { it.attr("data-num").toDoubleOrNull()?.toInt() }
            .maxOrNull() ?: 0
    }

    // ── Internal parsers ──────────────────────────────────────────────────

    /**
     * Parse typeahead results (different structure from catalog items).
     * Typeahead HTML: <a class="item" href="/watch/{slug}-{id}">
     *   <div class="poster"><img src="..."></div>
     *   <div class="info">
     *     <div class="name d-title" data-jp="JP">EN</div>
     *     <div class="meta">..rating..star score..type..date..</div>
     *   </div>
     * </a>
     */
    private fun parseTypeahead(html: String): List<Anime> {
        val doc = Jsoup.parse("<div>$html</div>")
        val out = mutableListOf<Anime>()
        for (el in doc.select("a.item[href*='/watch/']")) {
            val href = el.attr("href").removePrefix("/watch/")
            val rawId = Regex("""-(\d+)$""").find(href)?.groupValues?.get(1)?.toIntOrNull() ?: continue
            val slug = href
            slugById[rawId] = slug

            val title = el.selectFirst(".name.d-title")?.text()?.trim() ?: ""
            if (title.isBlank()) continue
            val poster = el.selectFirst("img")?.attr("src")

            // Rating score from meta
            val score = el.selectFirst(".fa-star")?.parent()?.text()?.trim()?.toDoubleOrNull()
            val type = el.selectFirst(".dot")?.text()?.trim()?.ifBlank { null } ?: "TV"

            out.add(Anime(
                id = appId(rawId),
                title = title,
                posterUrl = poster,
                type = type,
                score = score,
                kotoSlug = slug
            ))
        }
        return out
    }

    private fun typeahead(query: String): List<Anime> {
        val body = ScraperEngine.postForm(
            "$BASE/ajax/anime/search",
            mapOf("keyword" to query),
            headers() + mapOf(
                "X-Requested-With" to "XMLHttpRequest"
            ),
            timeoutMs = 10_000L
        ) ?: return emptyList()
        val html = runCatching {
            org.json.JSONObject(body).optJSONObject("result")?.optString("html")
                ?: org.json.JSONObject(body).optString("result")
        }.getOrNull() ?: body
        return parseTypeahead(html)
    }

    private fun parseListPage(url: String, limit: Int): List<Anime> {
        val html = ScraperEngine.fetchText(url, headers(), timeoutMs = 10_000L, maxRetries = 1)
            ?: return emptyList()
        val doc = runCatching { Jsoup.parse(html) }.getOrNull() ?: return emptyList()
        val scope = doc.getElementById("list-items") ?: doc
        return parseItems(scope.html()).take(limit)
    }

    private fun parseFilterPage(url: String, limit: Int): List<Anime> {
        val html = ScraperEngine.fetchText(url, headers(), timeoutMs = 10_000L, maxRetries = 1)
            ?: return emptyList()
        val doc = runCatching { Jsoup.parse(html) }.getOrNull() ?: return emptyList()
        val scope = doc.getElementById("list-items") ?: doc
        return parseItems(scope.html()).take(limit)
    }

    /**
     * Parse anime items from aniwaves HTML.
     *
     * Real item structure (each item is a <div class="item">):
     *
     *   <div class="item">
     *     <div class="inner">
     *       <div class="ani poster tip tooltipstered" data-tip="RAW_ID">
     *         <a href="/watch/{slug}-{id}">
     *           <img src="POSTER_URL">
     *           <div class="meta"><div class="inner"><div class="left">
     *             <span class="ep-status sub"><span> N </span></span>
     *             <span class="ep-status dub"><span> N </span></span>
     *             <span class="ep-status total"><span> N </span></span>
     *           </div><div class="right">TV</div></div></div>
     *         </a>
     *       </div>
     *       <div class="info">
     *         <div class="b1">
     *           <a class="name d-title" href="..." data-jp="JP_TITLE">EN_TITLE</a>
     *           <div class="genre"><a href="/genre/x">X</a>, ...</div>
     *         </div>
     *         <div class="meta">
     *           <div class="m-item"><span>N</span><label>Sub</label></div>
     *           <div class="m-item"><span>N</span><label>Dub</label></div>
     *           <div class="m-item"><span>N</span><label>TV</label></div>
     *           <div class="m-item rated"><span> 9</span><label>★</label></div>
     *         </div>
     *       </div>
     *     </div>
     *   </div>
     *
     * KEY: title/genres/rating are in .info (SIBLING of [data-tip]), not children.
     * Must select <div class="item"> blocks, then find poster + info within each.
     */
    private fun parseItems(html: String): List<Anime> {
        val doc = Jsoup.parse("<div>$html</div>")
        val out = mutableListOf<Anime>()
        for (item in doc.select("div.item")) {
            // Poster section: [data-tip] has the ID, img, and ep-status
            val poster = item.selectFirst("[data-tip]") ?: continue
            val rawId = poster.attr("data-tip").toIntOrNull() ?: continue
            val slug = poster.selectFirst("a[href*='/watch/']")?.attr("href")
                ?.replace("/watch/", "")?.trimEnd('/') ?: continue
            slugById[rawId] = slug

            // Poster image
            val posterUrl = poster.selectFirst("img")?.attr("src")

            // Episode counts from ep-status spans (inside poster)
            val subEp = poster.selectFirst(".ep-status.sub span")?.text()?.trim()?.toIntOrNull()
            val dubEp = poster.selectFirst(".ep-status.dub span")?.text()?.trim()?.toIntOrNull()
            val epCount = maxOf(subEp ?: 0, dubEp ?: 0).takeIf { it > 0 }

            // Type from poster meta .right
            val typeText = poster.selectFirst(".meta .right")?.text()?.trim()?.ifBlank { null }
                ?: "TV"

            // Info section: title, genres, rating (SIBLING of poster)
            val info = item.selectFirst("div.info")
            val titleEl = info?.selectFirst("a.name.d-title")
            val title = titleEl?.text()?.trim() ?: ""
            if (title.isBlank()) continue  // skip items with no title

            val genres = info?.select("a[href*='/genre/']")?.map { it.text().trim() }
                ?.filter { it.isNotBlank() } ?: emptyList()

            // Rating from .rated span in info meta
            val rating = info?.selectFirst(".rated span")?.text()?.trim()

            // Score as double
            val score = rating?.toDoubleOrNull()

            val anime = Anime(
                id = appId(rawId),
                title = title,
                posterUrl = posterUrl,
                type = typeText,
                genres = genres,
                episodes = epCount,
                score = score,
                kotoSlug = slug
            )
            out.add(anime)
        }
        return out
    }

    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
}
