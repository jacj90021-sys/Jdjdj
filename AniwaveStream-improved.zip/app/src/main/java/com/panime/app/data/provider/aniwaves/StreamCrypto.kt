package com.panime.app.data.provider.aniwaves

import android.util.Base64
import android.util.Log
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Crypto primitives ported from the Aniwavesapi backend (vidplay.ts /
 * megacloud.ts), which rely on CryptoJS.
 *
 * - RC4 is used by vidplay's vrfEncrypt (CryptoJS.RC4.encrypt, key = decimal
 *   string of the futoken k value).
 * - CryptoJS.AES.decrypt(ciphertext, passphrase) decrypts an OpenSSL-format
 *   blob ("Salted__" + 8-byte salt) with AES-256-CBC, where the key + IV come
 *   from EVP_BytesToKey (MD5) over (passphrase, salt). This implementation was
 *   validated against real `openssl enc` salted output locally.
 */
object StreamCrypto {

    private const val TAG = "StreamCrypto"

    /** RC4-encrypt [data] with a numeric key (CryptoJS RC4.encrypt equivalent). */
    fun rc4Encrypt(data: String, key: Int): String? {
        val keyBytes = key.toString().toByteArray(Charsets.UTF_8)
        for (algo in listOf("RC4", "ARCFOUR")) {
            try {
                val cipher = Cipher.getInstance(algo)
                cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keyBytes, algo))
                return Base64.encodeToString(
                    cipher.doFinal(data.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP
                )
            } catch (e: Exception) {
                Log.w(TAG, "RC4 via $algo failed: ${e.message}")
            }
        }
        return null
    }

    /** EVP_BytesToKey (MD5) — the CryptoJS passphrase KDF. */
    private fun evpBytesToKey(
        password: ByteArray,
        salt: ByteArray,
        keyLen: Int,
        ivLen: Int
    ): Pair<ByteArray, ByteArray> {
        val md = MessageDigest.getInstance("MD5")
        var prev = ByteArray(0)
        val derived = ByteArray(keyLen + ivLen)
        var pos = 0
        while (pos < derived.size) {
            md.reset()
            md.update(prev)
            md.update(password)
            md.update(salt)
            val block = md.digest()
            System.arraycopy(block, 0, derived, pos, minOf(block.size, derived.size - pos))
            pos += block.size
            prev = block
        }
        return derived.copyOfRange(0, keyLen) to derived.copyOfRange(keyLen, derived.size)
    }

    /**
     * CryptoJS.AES.decrypt(base64Cipher, passphrase) equivalent. Handles the
     * OpenSSL "Salted__" header (base64 may be wrapped with newlines — strip
     * whitespace before decoding). Returns the decrypted UTF-8 text or null.
     */
    fun opensslAesDecrypt(base64Cipher: String, passphrase: String): String? {
        val raw = runCatching {
            Base64.decode(base64Cipher.replace(Regex("\\s"), ""), Base64.NO_WRAP)
        }.getOrNull() ?: return null
        val salted = raw.size >= 16 &&
            raw[0].toInt() == 'S'.code && raw[1].toInt() == 'a'.code &&
            raw[2].toInt() == 'l'.code && raw[3].toInt() == 't'.code &&
            raw[4].toInt() == 'e'.code && raw[5].toInt() == 'd'.code &&
            raw[6].toInt() == '_'.code && raw[7].toInt() == '_'.code
        val salt = if (salted) raw.copyOfRange(8, 16) else ByteArray(8)
        val ct = if (salted) raw.copyOfRange(16, raw.size) else raw
        if (ct.isEmpty()) return null
        val (key, iv) = evpBytesToKey(passphrase.toByteArray(Charsets.UTF_8), salt, 32, 16)
        return runCatching {
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
            String(cipher.doFinal(ct), Charsets.UTF_8)
        }.getOrNull()
    }

    /** AES-128/192/256 in ECB with raw key bytes — fallback for some megacloud keys. */
    fun aesEcbDecrypt(base64Cipher: String, keyStr: String): String? {
        val keyBytes = keyStr.toByteArray(Charsets.UTF_8)
        if (keyBytes.size != 16 && keyBytes.size != 24 && keyBytes.size != 32) return null
        val raw = runCatching {
            Base64.decode(base64Cipher.replace(Regex("\\s"), ""), Base64.NO_WRAP)
        }.getOrNull() ?: return null
        return runCatching {
            val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"))
            String(cipher.doFinal(raw), Charsets.UTF_8)
        }.getOrNull()
    }

    /** AES-128/192/256 in CBC with a zero IV and raw key bytes — fallback key mode. */
    fun aesCbcZeroIvDecrypt(base64Cipher: String, keyStr: String): String? {
        val keyBytes = keyStr.toByteArray(Charsets.UTF_8)
        if (keyBytes.size != 16 && keyBytes.size != 24 && keyBytes.size != 32) return null
        val raw = runCatching {
            Base64.decode(base64Cipher.replace(Regex("\\s"), ""), Base64.NO_WRAP)
        }.getOrNull() ?: return null
        return runCatching {
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(ByteArray(16)))
            String(cipher.doFinal(raw), Charsets.UTF_8)
        }.getOrNull()
    }

    /** MD5 hex digest — used as a CryptoJS passphrase key: MD5(rawId). */
    fun md5Hex(input: String): String {
        val md = MessageDigest.getInstance("MD5")
        return md.digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xFF) }
    }

    /**
     * AES-256-GCM decrypt with a raw key (BYFMS playback). [key] is the
     * concatenated key_parts; returns the plaintext bytes or null.
     */
    fun aesGcmDecrypt(key: ByteArray, iv: ByteArray, ciphertext: ByteArray): ByteArray? {
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                SecretKeySpec(key, "AES"),
                GCMParameterSpec(128, iv)
            )
            cipher.doFinal(ciphertext)
        } catch (e: Exception) {
            Log.w(TAG, "aesGcmDecrypt failed: ${e.message}")
            null
        }
    }
}
