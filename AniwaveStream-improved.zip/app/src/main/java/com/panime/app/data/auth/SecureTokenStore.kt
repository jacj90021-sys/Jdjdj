package com.panime.app.data.auth

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Encrypted storage for OAuth access/refresh tokens.
 *
 * Uses AndroidX Security EncryptedSharedPreferences (AES-256 via a
 * Keystore-backed MasterKey). Non-token profile data stays in DataStore.
 */
class SecureTokenStore(context: Context) {
    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "aniwave_oauth_tokens",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    suspend fun save(service: String, access: String, refresh: String?, expiresIn: Long?) =
        withContext(Dispatchers.IO) {
            val expiresAt = if (expiresIn != null && expiresIn > 0) {
                System.currentTimeMillis() + expiresIn * 1000L
            } else 0L
            prefs.edit().apply {
                putString("${service}_access", access)
                if (refresh != null) putString("${service}_refresh", refresh)
                else remove("${service}_refresh")
                putLong("${service}_expires_at", expiresAt)
            }.apply()
        }

    fun getAccessToken(service: String): String? = prefs.getString("${service}_access", null)
    fun getRefreshToken(service: String): String? = prefs.getString("${service}_refresh", null)
    fun getExpiresAt(service: String): Long = prefs.getLong("${service}_expires_at", 0L)

    fun isExpired(service: String, skewMs: Long = 60_000L): Boolean {
        val at = getExpiresAt(service)
        if (at <= 0L) return false // unknown expiry — try use until API rejects
        return System.currentTimeMillis() >= at - skewMs
    }

    fun hasToken(service: String): Boolean = !getAccessToken(service).isNullOrBlank()

    /**
     * Return a usable access token, refreshing if expired.
     * Returns null if not connected or refresh fails.
     */
    suspend fun validAccessToken(service: String): String? = withContext(Dispatchers.IO) {
        val access = getAccessToken(service) ?: return@withContext null
        if (!isExpired(service)) return@withContext access
        // AniList has no refresh grant — an expired token means the user must
        // re-authorize (implicit flow), not attempt a refresh that AniList rejects.
        if (service == "anilist") return@withContext null
        val refresh = getRefreshToken(service) ?: return@withContext access
        val pair = refreshAccessToken(service, refresh) ?: return@withContext null
        save(service, pair.accessToken, pair.refreshToken ?: refresh, pair.expiresInSeconds)
        pair.accessToken
    }

    suspend fun clear(service: String) = withContext(Dispatchers.IO) {
        prefs.edit().apply {
            remove("${service}_access")
            remove("${service}_refresh")
            remove("${service}_expires_at")
            remove("${service}_expires_in") // legacy key from earlier builds
        }.apply()
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        clear("anilist")
        clear("mal")
    }
}
