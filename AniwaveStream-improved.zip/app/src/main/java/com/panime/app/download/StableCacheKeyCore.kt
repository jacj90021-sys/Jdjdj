package com.panime.app.download

/**
 * Pure, JVM-friendly core of the stable cache-identity logic. Deliberately free
 * of Android types ([android.net.Uri], [android.content.Context]) so the exact
 * matching/key rules used in production can be unit-tested on a plain JVM — and
 * so the app-side wrappers ([DownloadCacheRegistry],
 * [StableDownloadCacheKeyFactory]) are thin plumbing over one source of truth.
 *
 * ## Cache key
 *
 * For a segment of a registered download the key is:
 *
 *     "dl:<downloadId>:<segment-relative-path>"
 *
 * where `<segment-relative-path>` is the segment URI minus the registered
 * manifest base (the segments' stable content identifier). Because the same
 * base->downloadId mapping is re-asserted with a NEW base after a URL refresh,
 * segments under a rotated path compute the SAME key and Media3 reuses the old
 * partial data (resume, not 0%).
 *
 * ## Normalization
 *
 * URLs are canonicalized by stripping query + fragment only. This is what both
 * sides share; it keeps token-only rotation hitting the same key while never
 * guessing/truncating arbitrary CDN path structure.
 */
object StableCacheKeyCore {

    /** Canonical segment URL: drop query & fragment, keep path/host/etc intact. */
    fun normalizeUrl(url: String): String {
        val f = url.indexOf('#')
        val q = url.indexOf('?')
        val cut = when {
            f >= 0 && q >= 0 -> minOf(f, q)
            f >= 0 -> f
            q >= 0 -> q
            else -> url.length
        }
        return url.substring(0, cut)
    }

    /**
     * Directory (base) form of a manifest URL — the playlist filename removed.
     * Media3 resolves HLS segment URIs against this directory. Returns the URL
     * unchanged when there is no directory structure to strip.
     */
    fun baseOf(url: String): String {
        val norm = normalizeUrl(url)
        val slash = norm.lastIndexOf('/')
        if (slash <= 0) return norm
        // If it already points at a directory (trailing slash), keep it as-is.
        return if (norm.endsWith("/")) norm else norm.substring(0, slash)
    }

    /**
     * Longest registered base that is a strict path-prefix of [segment], plus
     * its downloadId — or null when no registered base covers the segment.
     */
    fun match(segment: String, bases: Map<String, String>): Pair<String, String>? {
        val seg = normalizeUrl(segment)
        var bestBase: String? = null
        var bestId: String? = null
        var bestLen = -1
        for ((base, id) in bases) {
            val b = normalizeUrl(base)
            if (seg.length > b.length && seg.startsWith(b) && b.length > bestLen) {
                bestBase = b
                bestId = id
                bestLen = b.length
            }
        }
        return if (bestBase != null && bestId != null) bestBase to bestId else null
    }

    /**
     * Final stable cache key for a registered, NON-manifest segment, or null when
     * the segment is not covered by [bases] OR it is a playlist/manifest resource.
     *
     * Manifests (m3u8/mpd/…) are deliberately left on their true (token-rotated)
     * URI key so a refreshed URL always fetches a FRESH playlist — shadowing the
     * cached playlists under the stable id would cause an expired-path playlist to
     * keep being reused. Only media segments (ts/m4s/… backing the content) join
     * the stable per-download namespace.
     */
    fun stableKey(segment: String, bases: Map<String, String>): String? {
        val norm = normalizeUrl(segment)
        if (isManifest(norm)) return null
        val (base, id) = match(segment, bases) ?: return null
        val relative = norm.removePrefix(base)
        return "dl:$id:$relative"
    }

    private fun isManifest(path: String): Boolean {
        val lower = path.lowercase()
        return lower.endsWith(".m3u8") ||
            lower.endsWith(".mpd") ||
            lower.endsWith(".m3u") ||
            lower.contains(".m3u8?") ||
            lower.contains(".mpd?") ||
            lower.endsWith("master") // some providers use extension-less master URLs
    }
}