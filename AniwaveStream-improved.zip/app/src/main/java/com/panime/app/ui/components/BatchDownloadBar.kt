package com.panime.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.SharpCorner
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.theme.TextOnDark
import com.panime.app.ui.theme.TextPrimary

private val qualities = listOf("1080p", "720p", "480p")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatchDownloadBar(
    visible: Boolean,
    selectedQuality: String,
    onQualityChange: (String) -> Unit,
    selectedCount: Int,
    totalCount: Int,
    onStartDownload: () -> Unit,
    onCancel: () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(initialOffsetY = { it }),
        exit = slideOutVertically(targetOffsetY = { it })
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(SurfaceRaised)
                .border(1.dp, Hairline, SharpCorner)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Quality dropdown selector
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = it }
            ) {
                Text(
                    "QUALITY: $selectedQuality",
                    color = TextPrimary,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .menuAnchor()
                        .clip(SharpCorner)
                        .border(1.dp, Hairline, SharpCorner)
                        .clickable { expanded = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    qualities.forEach { q ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    q,
                                    color = if (q == selectedQuality) Flame else TextPrimary,
                                    fontFamily = PlexMono,
                                    fontWeight = if (q == selectedQuality) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            },
                            onClick = {
                                onQualityChange(q)
                                expanded = false
                            }
                        )
                    }
                }
            }

            // Download button — compact
            val enabled = selectedCount > 0
            Text(
                "DOWNLOAD ($selectedCount)",
                color = if (enabled) TextOnDark else TextMuted,
                fontFamily = PlexMono,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                modifier = Modifier
                    .clip(SharpCorner)
                    .background(if (enabled) Flame else Surface)
                    .border(1.dp, if (enabled) Flame else Hairline, SharpCorner)
                    .clickable(enabled) { onStartDownload() }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

/**
 * Selection controls bar shown above the episode list when in selection mode.
 * "SELECT ALL (N)" on the left, "CANCEL" on the right.
 */
@Composable
fun SelectionControlsBar(
    selectedCount: Int,
    totalVisible: Int,
    onSelectAll: () -> Unit,
    onDeselectAll: () -> Unit,
    onCancel: () -> Unit
) {
    val allSelected = selectedCount == totalVisible && totalVisible > 0
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(SharpCorner)
            .background(SurfaceRaised)
            .border(1.dp, Hairline, SharpCorner)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            Modifier.clickable {
                if (allSelected) onDeselectAll() else onSelectAll()
            },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "SELECT ALL ($selectedCount)",
                color = TextPrimary,
                fontFamily = PlexMono,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 0.5.sp
            )
        }

        Text(
            "CANCEL",
            color = Flame,
            fontFamily = PlexMono,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            letterSpacing = 0.5.sp,
            modifier = Modifier.clickable { onCancel() }
        )
    }
}
