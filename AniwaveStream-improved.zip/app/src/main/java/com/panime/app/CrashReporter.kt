package com.panime.app

import android.content.Context
import java.io.File

/**
 * Writes any uncaught exception to filesDir/last_crash.txt, then delegates to
 * the previous default handler (normal crash behavior is preserved). On the
 * next launch MainActivity reads and deletes the file so the user can copy the
 * stack trace and share it — no adb/logcat required.
 */
object CrashReporter {

    private const val FILE_NAME = "last_crash.txt"

    fun install(context: Context) {
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                File(appContext.filesDir, FILE_NAME).writeText(
                    buildString {
                        appendLine("Thread: ${thread.name}")
                        appendLine(android.util.Log.getStackTraceString(throwable))
                        var cause = throwable.cause
                        while (cause != null) {
                            appendLine()
                            appendLine("Caused by:")
                            appendLine(android.util.Log.getStackTraceString(cause))
                            cause = cause.cause
                        }
                    }
                )
            } catch (_: Exception) {
                // Never let crash reporting itself crash.
            }
            previous?.uncaughtException(thread, throwable)
        }
    }

    /** Returns the saved crash report (or null) and deletes the file. */
    fun popLastCrash(context: Context): String? {
        return try {
            val file = File(context.applicationContext.filesDir, FILE_NAME)
            val text = if (file.exists()) file.readText() else null
            file.delete()
            text?.takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }
}
