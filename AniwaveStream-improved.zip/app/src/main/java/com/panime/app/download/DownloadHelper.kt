package com.panime.app.download

import android.content.Context
import android.util.Log
import com.panime.app.data.provider.ProviderManager
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.data.provider.anikoto.AnikotoProvider
import com.panime.app.data.provider.animenosub.AnimenosubApi
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.data.repository.UserLibraryStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * Season number explicitly picked in the wrong-title picker, encoded in the
 * slug as "|se=N" (moviebox only — other providers ignore/never encode it).
 * Per-season rows like "BoJack Horseman S2" encode season 2; combined rows
 * like "Hunter x Hunter S1-S6" stay un-encoded (all-seasons entry).
 */
fun parsePickedSeason(slug: String): Int? =
    slug.split("|").getOrNull(2)
        ?.takeIf { it.startsWith("se=") }
        ?.substring(3)?.toIntOrNull()?.takeIf { it > 0 }

/**
 * (se, maxEp) map for a wrong-title pick — moviebox only (its detail API
 * exposes the exact per-season episode counts of combined entries). Empty for
 * every other source. DetailScreen uses it to render season chips + per-season
 * episode blocks; PlayerScreen uses it to compute the real per-season count.
 */
suspend fun sourceSeasonMap(sourceId: String, slug: String): List<Pair<Int, Int>> =
    if (sourceId == "moviebox") {
        runCatching { com.panime.app.data.provider.moviebox.MovieboxProvider().seasonMapForSlug(slug) }
            .getOrDefault(emptyList())
    } else emptyList()

/**
 * Real episode count for a wrong-title pick, straight from the picked source.
 * Returns 0 for sources we can't query — caller keeps AniList originals then.
 * [title] is the picked entry's title — just4anime needs it (its search ranks
 * by title; a numeric id query matches titles, not ids, so it must not be
 * used to look the picked series up). [seasonNumber] scopes moviebox combined
 * entries to ONE season's count (e.g. "HxH S1-S6" + se=2 -> 12, not 208).
 * Shared by DetailScreen (episode list replacement) and PlayerScreen (episode
 * sheet range) so both always show the picked source's real count — never
 * AniList's.
 */
suspend fun sourceEpisodeCount(
    sourceId: String,
    slug: String,
    title: String = "",
    seasonNumber: Int = 0
): Int = runCatching {
    when (sourceId) {
        "aniwaves" -> com.panime.app.data.api.AniwavesCatalog.detailBySlug(slug)?.anime?.episodes ?: 0
        "anikoto" -> AnikotoProvider().episodeCountForSlug(slug)
        "anikage" -> com.panime.app.data.provider.anikage.AnikageProvider().episodeCountForPick(slug)
        "just4anime" -> com.panime.app.data.provider.just4anime.Just4AnimeProvider().episodeCountForPick(slug, title)
        "anidap" -> com.panime.app.data.api.AnidapApi.episodeCountByPick(slug) ?: 0
        "anizone" -> com.panime.app.data.api.AnizoneApi.episodeCountBySlug(slug)
        "anidb" -> com.panime.app.data.provider.anidb.AnidbProvider().episodeCountForPick(slug)
        "animenosub" -> AnimenosubApi.listEpisodes(slug).size
        "moviebox" -> com.panime.app.data.provider.moviebox.MovieboxProvider().episodeCountForSlug(
            if (seasonNumber > 0) "$slug|se=$seasonNumber" else slug
        )
        else -> 0
    }
}.getOrDefault(0)

/**
 * Resolves an episode exactly like the player does (same source selection,
 * same wrong-title override rules) and hands the m3u8 to the download service.
 */
object DownloadHelper {

    private const val TAG = "DownloadHelper"

    /** Source selection shared with the batch server sheet. */
    data class SourceCtx(
        val sourceMode: String,
        val slugHint: String?,
        val kotoLocked: Boolean,
        val audioType: String
    )

    suspend fun sourceContext(
        repository: AnimeRepository,
        library: UserLibraryStore,
        animeId: Int
    ): SourceCtx {
        val apiProv = library.apiProvider.first()
        val kotoLocked = apiProv == "koto" || apiProv == "wave"
        val ov = library.getWrongTitleOverride(animeId)
        // Player parity (PlayerScreen entry): a fresh wrong-title pick plays on
        // ITS OWN source — never falls back to the last-used source.
        val sourceMode = when {
            apiProv == "koto" -> "anikoto"
            apiProv == "wave" -> "aniwaves"
            ov != null && ov.slug.isNotBlank() -> ov.sourceId
            else -> library.lastSourceMode.first().ifBlank { "aniwaves" }
        }
        val slugHint = when {
            ov != null && ov.slug.isNotBlank() && ov.sourceId == sourceMode -> ov.slug
            kotoLocked -> repository.detail(animeId).getOrNull()?.kotoSlug
            else -> null
        }
        return SourceCtx(sourceMode, slugHint, kotoLocked, library.lastAudioType.first().ifBlank { "sub" })
    }

    data class Result(
        val error: String? = null,
        val usedServer: String? = null,
        val fellBack: Boolean = false
    )

    /** Provider headers for a resolved stream (UA + Referer the CDN expects). */
    fun headersFor(result: com.panime.app.data.provider.ResolveResult?): Map<String, String> = buildMap {
        if (result == null) return@buildMap
        ScraperEngine.defaultHeaders()["User-Agent"]?.let { put("User-Agent", it) }
        result.referer?.let { put("Referer", it) }
    }

    /**
     * Resolve + enqueue one episode. Tries servers in order:
     * user pick -> provider default -> every other server. Returns the first
     * stream found; [Result.fellBack] is true when the pick had no stream.
     */
    suspend fun downloadEpisode(
        context: Context,
        repository: AnimeRepository,
        library: UserLibraryStore,
        animeId: Int,
        title: String,
        episode: Int,
        seasonNumber: Int,
        totalEps: Int,
        posterUrl: String?,
        preferredServer: String? = null,
        serverChain: List<Pair<String, String>> = emptyList(),
        audioTypeOverride: String? = null
    ): Result = withContext(Dispatchers.IO) {
        try {
            val sc = sourceContext(repository, library, animeId)
            val audioType = if (audioTypeOverride == "dub") "dub" else "sub"

            // Duplicate guard: one download per anime+season+episode.
            val existingId = EpisodeDownloadMeta.idFor(animeId, seasonNumber, episode)
            if (DownloadCenter.readRequest(context, existingId) != null) {
                return@withContext Result("Already downloaded or downloading")
            }

            // Order to try: explicit pick first, then default, then the rest.
            val picks = ArrayList<String?>()
            if (preferredServer != null) {
                picks.add(preferredServer)
                picks.add(null)
                serverChain.map { it.first }.filter { it != preferredServer }.forEach { picks.add(it) }
            } else {
                picks.add(null)
                serverChain.forEach { picks.add(it.first) }
            }

            var lastError = ""
            var attempt = 0
            for (code in picks.distinct()) {
                attempt++
                val result = ProviderManager.resolveOn(
                    sc.sourceMode, title, animeId, episode,
                    type = audioType,
                    serverCode = code,
                    seasonNumber = seasonNumber,
                    slugHint = sc.slugHint,
                    totalEpisodes = totalEps
                )
                if (result == null || result.url.isNullOrBlank()) {
                    lastError = ProviderManager.lastError.ifBlank { lastError }
                    continue
                }
                val headers = headersFor(result)
                val usedName = when {
                    code == null && preferredServer == null ->
                        serverChain.firstOrNull()?.second ?: "default"
                    code == null -> "default"
                    else -> serverChain.firstOrNull { it.first == code }?.second
                        // Never render a raw embed URL as the server label
                        // (Animenosub's preload codes are embed URLs).
                        ?: friendlyServerName(code)
                }
                val meta = EpisodeDownloadMeta(
                    id = existingId,
                    animeId = animeId,
                    episode = episode,
                    seasonNumber = seasonNumber,
                    title = title,
                    episodeLabel = "Episode $episode",
                    posterUrl = posterUrl,
                    quality = result.quality,
                    serverLabel = usedName + if (attempt > 1 && code != preferredServer && preferredServer != null) " (fallback)" else "",
                    sourceMode = sc.sourceMode,
                    audioType = audioType,
                    slugHint = sc.slugHint,
                    totalEps = totalEps,
                    streamUrl = result.url,
                    format = result.format ?: "hls",
                    headers = headers,
                    subtitles = result.subtitles.map { Triple(it.lang, it.label, it.url) },
                    decryptKeyB64 = result.decryptKey?.let {
                        android.util.Base64.encodeToString(it, android.util.Base64.NO_WRAP)
                    }
                )
                DownloadCenter.enqueue(context, meta)
                return@withContext Result(
                    usedServer = usedName,
                    fellBack = preferredServer != null && code != preferredServer
                )
            }
            Result(lastError.ifBlank { "No stream found for ep $episode" })
        } catch (e: Exception) {
            Log.w(TAG, "downloadEpisode failed: ${e.message}")
            Result(e.message ?: "Download failed")
        }
    }

    /**
     * Expired-URL recovery: re-run the SAME provider resolution path the
     * original download used and return a fresh stream. Keeps everything the
     * resolver needs (source/slug/audio type) inside [meta], so a stale CDN
     * link never requires the user to restart the episode manually.
     */
    suspend fun resolveFreshStream(meta: EpisodeDownloadMeta): com.panime.app.data.provider.ResolveResult? =
        withContext(Dispatchers.IO) {
            ProviderManager.resolveOn(
                meta.sourceMode, meta.title, meta.animeId, meta.episode,
                type = meta.audioType,
                serverCode = null,
                seasonNumber = meta.seasonNumber,
                slugHint = meta.slugHint,
                totalEpisodes = meta.totalEps
            )
        }
}

/**
 * Fallback display name for a server code that isn't in the chain. Server
 * codes are normally labels ("Moon", "AniZone"), but Animenosub's preload
 * pair uses the embed URL as the code — never render that raw.
 */
private fun friendlyServerName(code: String): String {
    val clean = code.trim()
    if (clean.startsWith("http://") || clean.startsWith("https://")) {
        val host = clean.substringAfter("://").substringBefore("/").substringBefore(":")
        val known = host.lowercase()
        return when {
            "moon" in known || "sayeveum" in known -> "Moon"
            "omega" in known || "vidmoly" in known -> "Omega"
            "nova" in known || "upn.one" in known -> "Nova"
            else -> host.ifBlank { "Server" }
        }
    }
    return clean.ifBlank { "Server" }
}
