package com.panime.app.download

import androidx.media3.datasource.HttpDataSource
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Classifies download failures and computes the next action:
 *  - RETRY_SAME_URL: transient network/CDN problem — back off, then re-add the
 *    SAME request (Media3 resumes from already-cached segments).
 *  - REFRESH_URL: the resolved stream URL/token most likely expired (403/404/410)
 *    — run the provider resolver again for a fresh URL, keep id + cache key.
 *  - GIVE_UP: permanent failure — surface the error, never auto-retry.
 */
object DownloadRetryPolicy {

    enum class Kind { RETRY_SAME_URL, REFRESH_URL, GIVE_UP }

    data class Decision(val kind: Kind, val delayMs: Long)

    /** Backoff schedule for transient failures (attempt = 1-based count of failures so far). */
    val TRANSIENT_DELAYS_MS = longArrayOf(15_000L, 60_000L, 180_000L, 600_000L)

    /** Max attempts per category before a download is declared FAILED for good. */
    const val MAX_TRANSIENT_ATTEMPTS = 4
    const val MAX_REFRESH_ATTEMPTS = 3

    fun classify(error: Throwable?): Kind {
        // No exception surfaced (e.g. engine-level abort) — treat as transient
        // so the capped backoff still applies instead of killing the task.
        if (error == null) return Kind.RETRY_SAME_URL
        var cur: Throwable? = error
        var depth = 0
        while (cur != null && depth < 6) {
            when (cur) {
                is HttpDataSource.InvalidResponseCodeException ->
                    return classifyCode(cur.responseCode)
                is UnknownHostException,
                is SocketTimeoutException,
                is ConnectException,
                is HttpDataSource.HttpDataSourceException,
                is IOException -> return Kind.RETRY_SAME_URL
            }
            cur = cur.cause
            depth++
        }
        return Kind.GIVE_UP
    }

    /**
     * Pure HTTP-status mapping (kept separate so JVM unit tests can exercise
     * it without constructing framework exception types).
     */
    fun classifyCode(code: Int): Kind = when (code) {
        // Expired token / removed CDN object / auth rejected.
        401, 403, 404, 410 -> Kind.REFRESH_URL
        // Rate limiting & server errors: worth retrying as-is.
        408, 425, 429, 500, 502, 503, 504 -> Kind.RETRY_SAME_URL
        else -> Kind.GIVE_UP
    }

    /**
     * Full decision pipeline. [transientFailures]/[refreshAttempts] are the
     * persisted per-download counters.
     */
    fun decide(error: Throwable?, transientFailures: Int, refreshAttempts: Int): Decision =
        decide(classify(error), transientFailures, refreshAttempts)

    /** Cap/backoff logic on a pre-classified kind (unit-testable without Android types). */
    fun decide(kind: Kind, transientFailures: Int, refreshAttempts: Int): Decision {
        return when (kind) {
            Kind.RETRY_SAME_URL ->
                if (transientFailures < MAX_TRANSIENT_ATTEMPTS) {
                    Decision(Kind.RETRY_SAME_URL, TRANSIENT_DELAYS_MS[transientFailures.coerceAtMost(TRANSIENT_DELAYS_MS.size - 1)])
                } else Decision(Kind.GIVE_UP, 0L)
            Kind.REFRESH_URL ->
                if (refreshAttempts < MAX_REFRESH_ATTEMPTS) {
                    Decision(Kind.REFRESH_URL, 0L)
                } else Decision(Kind.GIVE_UP, 0L)
            Kind.GIVE_UP -> Decision(Kind.GIVE_UP, 0L)
        }
    }
}
