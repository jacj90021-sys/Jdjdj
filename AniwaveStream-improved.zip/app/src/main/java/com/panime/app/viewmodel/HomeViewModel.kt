package com.panime.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.panime.app.data.model.Anime
import com.panime.app.data.model.ContinueItem
import com.panime.app.data.model.AiringSchedule
import com.panime.app.data.model.ScheduleDay
import com.panime.app.data.model.DayAiring
import com.panime.app.data.model.buildSiteSchedule
import com.panime.app.data.model.buildRecentlyUpdated
import com.panime.app.data.model.NewReleaseEpisode
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.data.repository.UserLibraryStore
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class HomeUiState(
    val loading: Boolean = true,
    val error: String? = null,
    val hero: Anime? = null,
    val trending: List<Anime> = emptyList(),
    val topRated: List<Anime> = emptyList(),
    val seasonal: List<Anime> = emptyList(),
    val top100: List<Anime> = emptyList(),
    val newReleases: List<Anime> = emptyList(),
    val newReleaseEpisodes: List<NewReleaseEpisode> = emptyList(),
    val upcoming: List<Anime> = emptyList(),
    val scheduleDayIndex: Int = 0,
    val scheduleDays: List<ScheduleDay> = emptyList(),
    val schedule: List<DayAiring> = emptyList(),
    /** True while the weekly airing API is in flight (independent of home catalog load). */
    val scheduleLoading: Boolean = false,
    val scheduleError: String? = null,
    val continueWatching: List<ContinueItem> = emptyList()
)

class HomeViewModel(
    private val repository: AnimeRepository,
    private val library: UserLibraryStore
) : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    /** Full week map cached after one successful schedule fetch — day pills only re-slice.
     *  Keyed by the day's UTC-midnight epoch (the site's own day window). */
    private var scheduleByDay: Map<Long, List<DayAiring>> = emptyMap()
    private var scheduleFetched = false

    /** Serializes Continue Watching rebuilds (progress flow + home refresh can overlap). */
    private val continueRebuildMutex = Mutex()

    init {
        // Schedule day window comes from the provider (site's widget / current week);
        // pill index 0 is the site's active first day, so no today-index math here.
        refresh()
        // AniwaveApp sets repository.provider asynchronously at launch; if the home
        // ViewModel boots before that lands, the first refresh would pull from the
        // default (anilist). Sync the persisted provider and re-pull once so KOTO
        // never shows another provider's data on cold start. Continue Watching is
        // per-provider (each provider sees only its own id-space), so a provider
        // switch also rebuilds it.
        viewModelScope.launch {
            library.apiProvider.collect { p ->
                if (p != repository.provider) {
                    repository.provider = p
                    refresh()
                }
                rebuildContinueWatching(library.progressMap.first())
            }
        }
        // Progress is persisted, but anime objects live only in the in-memory repo cache.
        // On cold start the cache is empty, so we must re-resolve titles (same pattern as
        // My List) — otherwise Continue Watching stays blank until the user opens a show.
        viewModelScope.launch {
            library.progressMap.collect { progress ->
                rebuildContinueWatching(progress)
            }
        }
    }

    /**
     * Build Continue Watching from saved progress.
     * 1) Instant pass from whatever is already cached (catalog / recently opened).
     * 2) Network-fetch any missing IDs via [AnimeRepository.detail] (throttled).
     * 3) Prefer most-recently-watched order from history when available.
     */
    private suspend fun rebuildContinueWatching(progress: Map<Int, Pair<Int, Float>>) {
        continueRebuildMutex.withLock {
            // Per-provider isolation: each provider only sees its own id-space
            // (AniList < 80M, wave 80–90M, koto ≥ 90M), so switching the API
            // provider hides the other providers' history.
            val provider = repository.provider
            val own = progress.filterKeys { repository.providerForId(it) == provider }
            if (own.isEmpty()) {
                _state.update { it.copy(continueWatching = emptyList()) }
                return
            }

            val lastWatchedAt: Map<Int, Long> = runCatching {
                library.currentHistory()
                    .groupBy { it.animeId }
                    .filterKeys { repository.providerForId(it) == provider }
                    .mapValues { (_, entries) -> entries.maxOf { it.watchedAtMs } }
            }.getOrDefault(emptyMap())

            fun toItem(id: Int, pair: Pair<Int, Float>, anime: Anime): ContinueItem {
                // Same logic as DetailScreen: prefer planned total, fall back to
                // nextAiringEpisode - 1 (released so far while airing), then 999.
                val total = (anime.episodes ?: anime.nextEpisode?.minus(1) ?: 999)
                    .coerceAtLeast(1)
                return ContinueItem(
                    anime = anime,
                    episode = pair.first,
                    progressFraction = pair.second,
                    completedCount = pair.first.coerceAtLeast(0),
                    totalEpisodes = total
                )
            }

            fun sortItems(items: List<ContinueItem>): List<ContinueItem> =
                items.sortedByDescending { lastWatchedAt[it.anime.id] ?: 0L }

            // Fast path: show anything already in memory immediately.
            val cachedItems = own.mapNotNull { (id, pair) ->
                val anime = repository.cached(id) ?: return@mapNotNull null
                toItem(id, pair, anime)
            }
            _state.update { it.copy(continueWatching = sortItems(cachedItems)) }

            // Resolve titles that were not in the session cache (cold start / obscure shows).
            val missingIds = own.keys.filter { repository.cached(it) == null }
            if (missingIds.isEmpty()) return

            for (id in missingIds) {
                repository.detail(id).getOrNull()
            }
            val fullItems = own.mapNotNull { (id, pair) ->
                val anime = repository.cached(id) ?: return@mapNotNull null
                toItem(id, pair, anime)
            }
            _state.update { it.copy(continueWatching = sortItems(fullItems)) }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            // Kick schedule in parallel so the card can shimmer while the catalog loads.
            loadSchedule(force = true)
            val trending = async { repository.trending() }
            val top = async { repository.topRated() }
            val newRel = async { repository.newReleases() }
            // Larger pool so the home Upcoming row can shuffle through more titles.
            val upc = async { repository.upcoming(perPage = 50) }
            val top100res = async { repository.top100() }
            val recUpd = async { repository.recentlyUpdated() }
            // sequential-ish via throttle inside repo; still fire after first batch
            val t = trending.await()
            val r = top.await()
            val nr = newRel.await()
            val up = upc.await()
            val t100 = top100res.await()
            val ru = recUpd.await()
            val s = repository.seasonal()

            val errors = listOf(t, r, s, nr, up).mapNotNull { it.exceptionOrNull()?.message }
            if (t.isFailure && r.isFailure && s.isFailure) {
                _state.update {
                    it.copy(loading = false, error = errors.firstOrNull() ?: "Failed to load catalog")
                }
                // Catalog failed, but progress may still resolve via detail() fetches.
                rebuildContinueWatching(library.progressMap.first())
                return@launch
            }

            val trendingList = t.getOrDefault(emptyList())
            val topList = r.getOrDefault(emptyList())
            val seasonalList = s.getOrDefault(emptyList())
            val top100List = t100.getOrDefault(emptyList())
            _state.update {
                it.copy(
                    loading = false,
                    error = null,
                    hero = seasonalList.firstOrNull() ?: trendingList.firstOrNull() ?: topList.firstOrNull(),
                    trending = trendingList,
                    topRated = topList,
                    seasonal = seasonalList,
                    top100 = top100List,
                    newReleases = nr.getOrDefault(emptyList()),
                    newReleaseEpisodes = buildRecentlyUpdated(ru),
                    upcoming = up.getOrDefault(emptyList())
                )
            }
            // Home lists just warmed the in-memory cache — re-emit Continue Watching
            // so titles that appear in trending/seasonal/etc. show without extra network.
            rebuildContinueWatching(library.progressMap.first())
        }
    }

    fun setScheduleDayIndex(index: Int) {
        val epoch = _state.value.scheduleDays.getOrNull(index)?.epoch
        _state.update {
            it.copy(
                scheduleDayIndex = index,
                schedule = emptyList(),
                scheduleLoading = true
            )
        }
        viewModelScope.launch {
            if (!scheduleFetched) {
                loadSchedule(force = false)
            } else {
                delay(150)
                _state.update {
                    it.copy(
                        schedule = epoch?.let { e -> scheduleByDay[e] } ?: emptyList(),
                        scheduleLoading = false
                    )
                }
            }
        }
    }

    fun retrySchedule() {
        loadSchedule(force = true)
    }

    /** Wipe every Continue Watching entry (See All → Clear All). */
    fun clearAllContinueWatching() {
        viewModelScope.launch { library.clearAllProgress() }
    }

    /** Remove one Continue Watching entry (See All long-press → Delete). */
    fun clearContinueWatching(animeId: Int) {
        viewModelScope.launch { library.clearProgress(animeId) }
    }

    private fun loadSchedule(force: Boolean) {
        if (!force && scheduleFetched) {
            val epoch = _state.value.scheduleDays.getOrNull(_state.value.scheduleDayIndex)?.epoch
            _state.update {
                it.copy(
                    scheduleLoading = false,
                    scheduleError = null,
                    schedule = epoch?.let { e -> scheduleByDay[e] } ?: emptyList()
                )
            }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(scheduleLoading = true, scheduleError = null) }
            repository.schedule()
                .onSuccess { list: List<AiringSchedule> ->
                    val days = repository.scheduleDays().getOrDefault(emptyList())
                    scheduleByDay = if (list.isEmpty() || days.isEmpty()) emptyMap() else buildSiteSchedule(days, list)
                    scheduleFetched = true
                    val index = _state.value.scheduleDayIndex.coerceAtMost((days.size - 1).coerceAtLeast(0))
                    val epoch = days.getOrNull(index)?.epoch
                    _state.update {
                        it.copy(
                            scheduleLoading = false,
                            scheduleError = null,
                            scheduleDayIndex = index,
                            scheduleDays = days,
                            schedule = epoch?.let { e -> scheduleByDay[e] } ?: emptyList()
                        )
                    }
                }
                .onFailure { e ->
                    _state.update {
                        it.copy(
                            scheduleLoading = false,
                            scheduleError = e.message ?: "Failed to load schedule",
                            // Keep previous schedule rows if any so the card doesn't go blank on a blip.
                            schedule = if (scheduleFetched) it.schedule else emptyList()
                        )
                    }
                }
        }
    }

    companion object {
        fun factory(repo: AnimeRepository, library: UserLibraryStore) =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    HomeViewModel(repo, library) as T
            }
    }
}

class LibraryViewModel(
    private val repository: AnimeRepository,
    private val library: UserLibraryStore,
    private val tokenStore: com.panime.app.data.auth.SecureTokenStore
) : ViewModel() {
    private val _items = MutableStateFlow<List<Anime>>(emptyList())
    val items: StateFlow<List<Anime>> = _items.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _syncing = MutableStateFlow(false)
    val syncing: StateFlow<Boolean> = _syncing.asStateFlow()
    // Which service the in-flight sync is for, so the UI label reads "AniList" /
    // "MyAnimeList" instead of always hardcoding AniList (Bug 1). Empty while idle.
    private val _syncLabel = MutableStateFlow("")
    val syncLabel: StateFlow<String> = _syncLabel.asStateFlow()

    private val _listProgress = MutableStateFlow<Map<Int, Int>>(emptyMap())
    val listProgress: StateFlow<Map<Int, Int>> = _listProgress.asStateFlow()

    private val _listStatus = MutableStateFlow<Map<Int, String>>(emptyMap())
    val listStatus: StateFlow<Map<Int, String>> = _listStatus.asStateFlow()

    /** Rebuild the visible My List from the store, showing ONLY the current
     *  provider's entries. The three providers use disjoint id-spaces (AniList
     *  < 80M, wave 80–90M, koto ≥ 90M), so filtering by id-space isolates each
     *  provider's list — switching the API provider hides the others'. */
    private suspend fun rebuildItems() {
        _loading.value = true
        val provider = repository.provider
        val ids = library.myListIds.first().filter { repository.providerForId(it) == provider }
        val meta = library.listMeta.first()
        val resolved = ids.mapNotNull { id ->
            val cached = repository.cached(id) ?: repository.detail(id).getOrNull()
            val localStatus = meta.firstOrNull { m -> m.id == id }?.status
            cached?.let {
                if (!localStatus.isNullOrBlank()) it.copy(status = localStatus) else it
            }
        }
        _items.value = resolved
        _loading.value = false
    }

    init {
        // Rebuild when the API provider switch changes — each provider sees only
        // its own My List entries.
        viewModelScope.launch {
            library.apiProvider.collect { p ->
                if (p != repository.provider) repository.provider = p
                rebuildItems()
            }
        }
        // Collector 1: membership. Re-resolves the catalog ONLY when the set of
        // list IDs actually changes (add/remove). distinctUntilChanged() drops the
        // re-emit that DataStore fires on every status/progress/score edit, so a
        // save never triggers a network call.
        viewModelScope.launch {
            library.myListIds
                .distinctUntilChanged()
                .collect { rebuildItems() }
        }
        // Collector 2: meta. Feeds the editor's initial values only. It must NOT
        // rebuild _items — that previously raced with the in-memory save and made
        // the first save appear to do nothing (needed a second save to stick).
        viewModelScope.launch {
            library.listMeta.collect { meta ->
                _listProgress.value = meta.associate { it.id to it.progress }
                _listStatus.value = meta.associate { it.id to it.status }
            }
        }
    }

    suspend fun updateListStatus(id: Int, status: String) {
        library.setListStatus(id, status)
        _items.update { list -> list.map { if (it.id == id) it.copy(status = status) else it } }
        // keep the All-tab status badge in sync immediately (don't wait on the
        // listMeta flow, which can lag and leave the badge showing the old status)
        _listStatus.value = _listStatus.value + (id to status)
    }

    suspend fun updateListProgress(id: Int, progress: Int) {
        library.setListProgress(id, progress)
        library.saveProgress(id, progress, 0f)
        _listProgress.value = _listProgress.value + (id to progress)
        _items.update { list -> list.map { if (it.id == id) it.copy(episodes = maxOf(it.episodes ?: 0, progress)) else it } }
    }

    suspend fun updateListScore(id: Int, score: Double?) {
        library.setListScore(id, score)
        _items.update { list -> list.map { if (it.id == id) it.copy(score = score) else it } }
    }

    suspend fun deleteAnime(id: Int) {
        library.removeFromList(id)
        _items.value = _items.value.filterNot { it.id == id }
        _listProgress.value = _listProgress.value - id
    }

    /**
     * Auto-sync the connected AniList account's list into My List. Triggered when the
     * My List tab loads. Shows the loading animation via `loading`. Only runs while
     * connected; safe to call repeatedly (idempotent — merges, never duplicates).
     */
    suspend fun syncAniList() {
        if (!library.isAniListConnected()) return
        _syncing.value = true
        _syncLabel.value = "AniList"
        _loading.value = true
        try {
            library.syncAniListOnLoad()
        } finally {
            // Collectors (membership + listMeta) re-fire on the DataStore write and
            // repopulate _items/_listStatus, then set _loading = false themselves.
            // These flags just guarantee the spinner clears even if no ids changed.
            _loading.value = false
            _syncing.value = false
            _syncLabel.value = ""
        }
    }

    /**
     * Auto-sync the connected MyAnimeList account's list into My List. Mirrors
     * [syncAniList]. Only runs while connected; idempotent merge.
     */
    suspend fun syncMal() {
        if (!library.isMalConnected()) return
        _syncing.value = true
        _syncLabel.value = "MyAnimeList"
        _loading.value = true
        try {
            library.syncMalOnLoad()
        } finally {
            _loading.value = false
            _syncing.value = false
            _syncLabel.value = ""
        }
    }

    /**
     * Push a single anime's status/progress/score to the connected AniList account.
     * No-op (returns true) when not connected. Delegates to the store, which does
     * the actual network write and never throws. Returns true on success.
     */
    suspend fun pushToAniList(id: Int, status: String, progress: Int, score: Double?): Boolean {
        return library.pushToAniList(id, status, progress, score)
    }

    /**
     * Push a single anime's status/progress/score to the connected MAL account.
     * No-op (returns true) when not connected. Delegates to the store, which does
     * the actual network write and never throws. Returns true on success.
     */
    suspend fun pushToMal(id: Int, status: String, progress: Int, score: Double?): Boolean {
        return library.pushToMal(id, status, progress, score)
    }

    companion object {
        fun factory(
            repo: AnimeRepository,
            library: UserLibraryStore,
            tokenStore: com.panime.app.data.auth.SecureTokenStore
        ) =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    LibraryViewModel(repo, library, tokenStore) as T
            }
    }
}
