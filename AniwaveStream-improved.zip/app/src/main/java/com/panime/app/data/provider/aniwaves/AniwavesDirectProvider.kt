package com.panime.app.data.provider.aniwaves

import android.util.Log
import com.panime.app.BuildConfig
import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.api.AniwavesCatalog
import com.panime.app.data.api.SubtitleHealth
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider

/**
 * On-device AniWaves provider — the WAVE source chip now drives aniwaves.ru
 * directly instead of going through the deployed backend:
 *   slug (/filter) -> /ajax/episode/list -> /ajax/server/list -> /ajax/sources
 *   -> on-device extractor (echovideo primary; vidplay/megacloud fallbacks)
 * The resulting m3u8 (+ .srt subtitles) is played directly by ExoPlayer with the
 * echovideo referer — no backend proxy, no Cloudflare worker.
 *
 * BYFMS runs fully on-device (device attestation + PoW). DGHG is excluded (its
 * TLS-impersonation flow can't run on-device). No server fallback: the player
 * plays exactly the server it picks — a broken server fails visibly.
 */
class AniwavesDirectProvider : StreamProvider, SearchableProvider {

    override val id = "aniwaves"
    override val label = "WAVE"
    override val backendRequired = false

    /** Upper bound on distinct site search queries per resolve (rate-limit safety). */
    private val MAX_QUERIES = 10

    override suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int,
        totalEpisodes: Int,
        year: Int?
    ): ResolveResult? {
        val slug = resolveVerifiedSlug(title, anilistId, episode, seasonNumber) ?: return null
        return resolveFromSlug(slug, episode, type, serverCode)
    }

    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? = resolveFromSlug(slug, episode, type, serverCode)

    private suspend fun resolveFromSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?
    ): ResolveResult? {
        val rows = AniwavesScraper.listServers(slug, episode, type)
        if (rows.isEmpty()) return null

        // Play exactly the server the user picked. No silent fallback: if that
        // server fails, it fails visibly (snag) so the user knows it's broken.
        // If nothing was picked, use the first available row as the default.
        val target = serverCode?.takeIf { c -> rows.any { it.id == c } }
            ?: rows.firstOrNull()?.id ?: return null
        val embed = AniwavesScraper.resolveEmbed(target, slug) ?: return null
        val serverName = rows.firstOrNull { it.id == target }?.name.orEmpty()
        val stream = AniwavesExtractor.extract(embed.url, serverName, embed.intro, embed.outro) ?: return null
        // MyCloud is the only wave server whose getSources carries subtitle
        // tracks (verified live: Vidplay/BYFMS/DGHG return tracks:[]). If the
        // playing server returned none, borrow MyCloud's tracks so subtitles
        // work on every server — the playing stream itself is untouched.
        //
        // The borrow is CROSS-HOST (subtitles live on a different echovideo
        // edge than the playing m3u8). Before attaching we health-probe the
        // subtitle host — if the phone can't reach it, an attached (unreachable)
        // track used to make the merged stream die (Media3 treated the subtitle
        // load error as fatal), while the DUB fallback (which never borrows)
        // played fine. Unreachable borrowed subs are therefore DROPPED and this
        // SUB stream degrades to exactly the no-subtitle path DUB uses.
        val playingSubs = stream.subtitles
        var borrowedSubs: List<AniwavesApi.SubtitleTrack> = emptyList()
        if (playingSubs.isEmpty()) {
            val myCloud = rows.firstOrNull { it.id != target && it.name.contains("mycloud", true) }
            if (myCloud != null) {
                borrowedSubs = runCatching {
                    AniwavesScraper.resolveEmbed(myCloud.id, slug)?.let { mcEmbed ->
                        AniwavesExtractor.extract(mcEmbed.url, myCloud.name)
                    }?.subtitles.orEmpty()
                }.getOrDefault(emptyList())
            }
        }
        val attach = SubtitleHealth.urlsToAttach(
            native = playingSubs.map { it.url },
            borrowed = borrowedSubs.map { it.url },
            healthy = { url -> AniwavesApi.probeSubtitleTrack(url, stream.referer) }
        )
        val subs = (playingSubs + borrowedSubs).filter { it.url in attach }
        if (BuildConfig.DEBUG) {
            Log.i(
                "AniwavesDirectProvider",
                "subtitles for '$slug' ep $episode via $serverName: " +
                    "native=${playingSubs.size} borrowed=${borrowedSubs.size} attach=${subs.size}"
            )
        }
        val byfms = serverName.equals("BYFMS", true) || serverName.equals("bymas", true) ||
            serverName.lowercase().let { n ->
                n.contains("weneverbeenfree") || n.contains("owphbf") || n.contains("animefever")
            }
        if (BuildConfig.DEBUG) {
            Log.i("AniwavesDirectProvider", "resolved '$slug' ep $episode via $serverName (${stream.m3u8.take(60)}) fmt=${stream.format} quality=${stream.quality}")
        }
        return ResolveResult(
            source = id,
            servers = rows.map { it.id to it.name },
            url = stream.m3u8,
            rawUrl = stream.m3u8.takeIf { byfms },
            isByfms = byfms,
            referer = stream.referer.takeIf { it.isNotBlank() },
            format = stream.format,
            quality = stream.quality,
            subtitles = subs,
            intro = stream.intro,
            outro = stream.outro,
            notFound = false
        )
    }

    /** Direct in-app server list for the player's server sheet (no backend). */
    suspend fun listServersFor(
        title: String,
        episode: Int,
        type: String,
        seasonNumber: Int = 0,
        anilistId: Int = 0,
        slugHint: String? = null
    ): List<Pair<String, String>> {
        val slug = if (!slugHint.isNullOrBlank()) slugHint
        else resolveVerifiedSlug(title, anilistId, episode, seasonNumber) ?: return emptyList()
        return AniwavesScraper.listServers(slug, episode, type).map { it.id to it.name }
    }

    /**
     * Every server across ALL audio tracks (koto-style: type-tagged ids like
     * "dub:<linkId>", labels like "DUB <name>"). Download server picker only —
     * the player keeps its per-track listing.
     */
    suspend fun listServersAllFor(
        title: String,
        episode: Int,
        seasonNumber: Int = 0,
        slugHint: String? = null
    ): List<Pair<String, String>> {
        val slug = if (!slugHint.isNullOrBlank()) slugHint
        else resolveVerifiedSlug(title, 0, episode, seasonNumber) ?: return emptyList()
        return AniwavesScraper.listServersAllTypes(slug, episode).map { it.id to it.name }
    }

    /**
     * Verified slug, metadata-first, availability fallback:
     *   1) Fetch the AniList detail (romaji/english/native titles, synonyms,
     *      year, total episodes, synopsis) — the app's ground truth.
     *   2) For each candidate slug, fetch its on-site metadata (jp/en titles,
     *      year, episode count, synopsis) and score how well it matches the
     *      AniList detail:
     *        + episode count equal  (strongest)
     *        + aired year equal
     *        + any AniList title key (romaji/english/native/synonym) appears in
     *          the slug's jp or en title
     *        + synopsis similarity (Jaccard) when titles differ
     *   3) Play the highest-scoring candidate that exposes the requested
     *      episode. Inconclusive (no positive match) -> best-ranked candidate so
     *      no anime becomes unplayable. Only refuses to play when every candidate
     *      lacks the requested episode.
     */
    private fun resolveVerifiedSlug(title: String, anilistId: Int, episode: Int, seasonNumber: Int): String? {
        val expectedEps = AniwavesScraper.anilistEpisodes(anilistId)
        val detail = AniwavesScraper.anilistDetail(anilistId)
        val candidates = AniwavesScraper.resolveSlugCandidates(searchQueries(title, detail, seasonNumber), seasonNumber)
        if (candidates.isEmpty()) return null

        var networkFailed = true
        var sawUnknown = false
        var bestSlug: String? = null
        var bestScore = -1
        for (slug in candidates) {
            val meta = AniwavesScraper.slugMeta(slug)
            val maxEp = meta?.maxEpisode ?: AniwavesScraper.slugMaxEpisode(slug)
            if (maxEp <= 0) continue
            networkFailed = false
            if (!AniwavesScraper.slugHasEpisode(slug, episode)) {
                sawUnknown = true
                continue
            }
            val candSeason = seasonOf(meta, slug)
            val score = scoreAgainstAniList(meta, maxEp, expectedEps, detail, candSeason, seasonNumber)
            if (BuildConfig.DEBUG) {
                Log.i("AniwavesDirectProvider", "candidate '$slug' ep=$episode maxEp=$maxEp expectedEps=$expectedEps score=$score")
            }
            if (score > bestScore) {
                bestScore = score
                bestSlug = slug
            }
        }
        if (bestSlug != null) {
            if (BuildConfig.DEBUG) {
                Log.i("AniwavesDirectProvider", "verified slug '$bestSlug' ep=$episode expectedEps=$expectedEps score=$bestScore")
            }
            return bestSlug
        }
        // Network failed, or verdict inconclusive -> best-ranked guess.
        if (networkFailed || sawUnknown) return candidates.first()
        // Every candidate was probed and none contains the requested episode.
        return null
    }

    /** Jaccard similarity of two normalized keyword sets (0..1). */
    private fun synopsisSimilarity(a: String?, b: String?): Double {
        if (a.isNullOrBlank() || b.isNullOrBlank()) return 0.0
        val sa = a.lowercase().split(Regex("""[^a-z0-9]+""")).filter { it.length > 2 }.toSet()
        val sb = b.lowercase().split(Regex("""[^a-z0-9]+""")).filter { it.length > 2 }.toSet()
        if (sa.isEmpty() || sb.isEmpty()) return 0.0
        val inter = sa.intersect(sb).size.toDouble()
        return inter / (sa.size + sb.size - inter).coerceAtLeast(1.0)
    }

    /**
     * Rank a candidate slug against the AniList detail. Higher = better match.
     *
     * Season intent is the strongest signal — the app already knows which cour
     * the user asked for ([seasonNumber]). Without it, a base series whose
     * episode count is >= the expected count (via the count slack) out-scores
     * the ACTUAL requested cour while it is still airing (site count < AniList
     * count), e.g. Re:ZERO S4 (AniList 19, site 12 so far) lost to S1 (25).
     */
    private fun scoreAgainstAniList(
        meta: AniwavesScraper.SlugMeta?,
        maxEp: Int,
        expectedEps: Int?,
        detail: AniwavesScraper.AniDetail?,
        candSeason: Int,
        seasonNumber: Int
    ): Int {
        if (meta == null) return 0
        var score = 0

        // Season intent — dominates. A candidate whose on-site title encodes the
        // requested cour wins outright; mismatched cour is heavily discounted.
        if (seasonNumber > 0) {
            if (candSeason == seasonNumber) score += 6
            else if (candSeason > 0) score -= 3
        }

        // Episode count — the strongest signal for cours/sequels (BLEACH S1 vs
        // Separation vs Conflict all share the base title but differ in count).
        // An EXACT count beats a mere over-count ("slack"): a base S1 (11 eps)
        // must outrank its own Part 2 (12 eps) when both cover the requested ep.
        val epExact = expectedEps != null && expectedEps > 0 && maxEp > 0 && maxEp == expectedEps
        val epSlack = !epExact && expectedEps != null && expectedEps > 0 && maxEp > 0 &&
            maxEp >= expectedEps && maxEp - expectedEps <= 16
        if (epExact) score += 2
        else if (epSlack) score += 1

        // Aired year.
        if (detail?.year != null && meta.year == detail.year) score += 1

        // Title overlap: any AniList title key (romaji/english/native/synonym)
        // contained in the slug's on-site jp or en title (or vice versa). This
        // catches "Sennen Kessen-hen" -> "Thousand-Year Blood War" while keeping
        // the right cour. Also matches PART-BY-PART: an AniList title like
        // "Mushoku Tensei: Jobless Reincarnation Cour 2 - Eris the Goblin Slayer"
        // never full-contains the site's "... - Eris the Goblin Slayer", but they
        // SHARE the significant word-group "eris the goblin slayer".
        //
        // Weight +3 (not +1) because title identity is the PRIMARY signal for
        // distinguishing the right anime. Without this, ep-count matching alone
        // lets an unrelated anime win: e.g. "Iruma-kun S4" (19 eps, epExact)
        // beats Re:Zero S4 (12/19 eps, still airing) because +2 epExact > +1
        // titleOverlap, even though the titles don't match at all.
        if (detail != null) {
            val siteTexts = listOfNotNull(meta.jpTitle, meta.enTitle)
            val siteKeys = siteTexts.mapTo(mutableSetOf()) { AniwavesScraper.normalize(it) }
            val fullOverlap = siteKeys.isNotEmpty() && detail.titleKeys.any { k ->
                siteKeys.any { s -> s.contains(k) || k.contains(s) }
            }
            val partOverlap = siteTexts.any { s ->
                detail.titleTexts.any { t -> sharesSignificantPart(s, t) }
            }
            if (fullOverlap || partOverlap) score += 3
        }

        // Synopsis similarity — the tiebreaker when titles alone are ambiguous.
        if (detail?.synopsis != null && meta.synopsis != null &&
            synopsisSimilarity(detail.synopsis, meta.synopsis) >= 0.4
        ) score += 1

        return score
    }

    /**
     * Season encoded in a candidate slug's on-site title ("Re:Zero ... 4th
     * Season" -> 4). Falls back to the slug text ("...-4th-season-..."). 0 when
     * it's the base/unsuffixed entry.
     */
    private fun seasonOf(meta: AniwavesScraper.SlugMeta?, slug: String): Int {
        val t = listOfNotNull(meta?.jpTitle, meta?.enTitle).joinToString(" ").lowercase()
        Regex("""(\d+)(?:st|nd|rd|th)\s+season""").find(t)?.let {
            it.groupValues[1].toIntOrNull()?.let { s -> return s }
        }
        Regex("""season\s+(\d+)""").find(t)?.let {
            it.groupValues[1].toIntOrNull()?.let { s -> return s }
        }
        val roman = mapOf(
            "ii" to 2, "iii" to 3, "iv" to 4, "v" to 5,
            "second" to 2, "third" to 3, "fourth" to 4, "fifth" to 5
        )
        Regex("""\b(ii|iii|iv|v|second|third|fourth|fifth)\b""").find(t)?.let {
            roman[it.groupValues[1]]?.let { s -> return s }
        }
        val s = slug.lowercase()
        Regex("""-(\d+)(?:st|nd|rd|th)?-season""").find(s)?.let {
            it.groupValues[1].toIntOrNull()?.let { n -> return n }
        }
        Regex("""-season-(\d+)""").find(s)?.let {
            it.groupValues[1].toIntOrNull()?.let { n -> return n }
        }
        return 0
    }

    /**
     * True when two raw titles share a significant contiguous word-group (>= 3
     * words). Enables part-by-part matching: the AniList title "Mushoku Tensei:
     * Jobless Reincarnation Cour 2 - Eris the Goblin Slayer" and the site's
     * "Mushoku Tensei: Jobless Reincarnation - Eris the Goblin Slayer" both
     * contain "eris the goblin slayer", so they match even though no full string
     * contains the other ("cour 2" appears on one side only). 3-word minimum
     * keeps "goblin slayer"-style 2-word coincidences from firing.
     */
    private fun sharesSignificantPart(a: String, b: String): Boolean {
        val wa = a.lowercase().split(Regex("""[^a-z0-9]+""")).filter { it.length >= 2 }
        val wb = b.lowercase().split(Regex("""[^a-z0-9]+""")).filter { it.length >= 2 }
        if (wa.size < 3 || wb.size < 3) return false
        val min = minOf(wa.size, wb.size)
        for (size in min downTo 3) {
            val groupsB = buildSet {
                for (i in 0..wb.size - size) add(wb.subList(i, i + size).joinToString(" "))
            }
            for (i in 0..wa.size - size) {
                if (wa.subList(i, i + size).joinToString(" ") in groupsB) return true
            }
        }
        return false
    }

    /**
     * Search queries for slug resolution. Tries the full AniList metadata
     * (romaji / english / native / synonyms) IN ADDITION to the app's title, so
     * the site's romaji-stored names are searched too, and splits each into its
     * significant parts (part-by-part). A long title like "Mushoku Tensei:
     * Jobless Reincarnation Cour 2 - Eris the Goblin Slayer" therefore also
     * searches "Eris the Goblin Slayer" on its own — otherwise the typeahead's
     * 5-hit cap never surfaces that slug.
     *
     * Season intent is appended ONLY to base titles that don't already encode a
     * season/part marker (the app's english title usually already says "Season
     * 2"); re-suffixing it would emit garbage like "…Season 2 Season 2" that the
     * site's fuzzy search mangles into unrelated anime. Queries are capped so a
     * title with many synonyms can't explode into dozens of site searches.
     */
    private fun searchQueries(
        title: String,
        detail: AniwavesScraper.AniDetail?,
        seasonNumber: Int
    ): List<String> {
        val out = LinkedHashSet<String>()
        fun addQ(q: String) {
            val s = q.trim()
            if (s.isNotBlank()) out.add(s)
        }

        // 1. Primary title: full + core. Only suffix a season marker onto titles
        //    that don't carry one already (the full english title usually does).
        for (c in candidateTitles(title)) {
            addQ(c)
            if (seasonNumber > 1 && AniwavesApi.extractSeason(c) == 0) {
                addQ("$c Season $seasonNumber")
                addQ("$c Part $seasonNumber")
            }
        }

        // 2. Alternative spellings (romaji / native / synonyms) as-is — they
        //    already encode the cour ("Mushoku Tensei II: …", "Part 2").
        //    Skip titles that clean to almost nothing (e.g. a Thai synonym whose
        //    only ASCII residue is the "2" of "season 2") — those would blast the
        //    site's fuzzy search with noise like every "Season 2" anime.
        detail?.let {
            for (v in listOfNotNull(it.romaji, it.english, it.native) + it.synonyms) {
                if (v.isNullOrBlank()) continue
                if (Regex("""[a-z]{2,}""").findAll(AniwavesApi.cleanTitle(v)).none()) continue
                addQ(v)
                for (p in titleParts(v)) addQ(p)
            }
        }

        // 3. Significant parts of the primary title (part-by-part matching).
        for (p in titleParts(title)) addQ(p)

        return out.toList().take(MAX_QUERIES)
    }

    /** Significant sub-parts of a title (split on separators), deduped. */
    private fun titleParts(t: String): List<String> {
        val out = LinkedHashSet<String>()
        for (token in t.split(Regex("""\s*[:\-–—,|]\s*"""))) {
            val p = token.trim()
            // Skip pure season/part markers ("Season 4") that clean to nothing —
            // they'd only add noise like every "Season 4" anime on the site.
            if (p.length >= 6 && AniwavesApi.cleanTitle(p).isNotBlank()) out.add(p)
        }
        return out.toList()
    }

    /** Title candidates, tried season-first so /filter ranks the right season. */
    private fun candidateTitles(t: String): List<String> {
        val base = t.trim()
        if (base.isBlank()) return emptyList()
        val core = base.split(Regex("""\s*[:：-]\s*""")).first().trim()
        // Guard against garbage cores from a prefix-split (e.g. "Re:ZERO" -> "Re").
        // Only emit the core when it is substantial enough to be a real search term.
        val substantial = core.length >= 6 ||
            (core.contains(' ') && core.length >= 4) ||
            core.equals(base, ignoreCase = true)
        return if (core.equals(base, ignoreCase = true)) listOf(base)
        else listOf(base) + if (substantial) listOf(core) else emptyList()
    }

    override suspend fun search(query: String): List<StreamProvider.SearchHit> {
        if (query.isBlank()) return emptyList()
        // Full paginated site search (all /filter pages) — not just the first 20.
        return AniwavesCatalog.search(query).map { anime ->
            StreamProvider.SearchHit(title = anime.title, slug = anime.kotoSlug ?: "", posterUrl = anime.posterUrl)
        }
    }

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        if (query.isBlank()) return PagedResult(emptyList(), 1)
        // Single /filter page + the site's own last-page number for manual paging.
        val res = AniwavesCatalog.searchPage(query, page)
        return PagedResult(
            items = res.items.map { anime ->
                StreamProvider.SearchHit(title = anime.title, slug = anime.kotoSlug ?: "", posterUrl = anime.posterUrl)
            },
            lastPage = res.lastPage
        )
    }
}
