@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.panime.app.player

import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.TransferListener
import java.io.IOException

/**
 * ExoPlayer [DataSource] that mirrors megaplay's own player (`newclient.min.js`)
 * so the `tcdn` mirror plays too.
 *
 * megaplay hides the real video inside fake TikTok-ad image files:
 *   - `s=tcdn` segments are served from `*.tiktokcdn.com` as an image with a
 *     **252-byte fake header** glued on the front. Stripping those 252 bytes
 *     reveals a normal MPEG-TS stream (verified: byte 252 == 0x47 and a
 *     2385-packet TS run follows).
 *   - When `tiktokcdn.com` is unreachable, their player rewrites the host to
 *     the proxy `yoot.akirax.buzz` and appends `?domain=<original host>`
 *     (`TikTokCdnProxy` / `TikTokCdnFailover`).
 *   - Segments from `yoot.akirax.buzz` also carry the 252-byte header because
 *     the proxy relays the raw file, so they need the same strip.
 *
 * Mirrors the site's constants:
 *   stripUrlRe  = ibyteimg.com | tiktokcdn.com | ipstatp.com | yoot.akirax.buzz
 *   stripBytes  = 252
 *   proxyHost   = yoot.akirax.buzz
 *   cdnHostRe   = tiktokcdn.com
 *
 * Clean mirrors (e.g. `bb.akirax.buzz`, which serves plain TS) match none of
 * these and pass through untouched.
 */
@UnstableApi
class MegaplaySegmentDataSource(
    private val upstream: DataSource,
    private val stripBytes: Int = 252,
    private val proxyHost: String = "yoot.akirax.buzz",
) : DataSource {

    private var skipRemaining = 0
    private val discard = ByteArray(8192)

    override fun addTransferListener(transferListener: TransferListener) {
        upstream.addTransferListener(transferListener)
    }

    override fun getUri() = upstream.uri

    override fun open(dataSpec: DataSpec): Long {
        val host = dataSpec.uri.host?.lowercase().orEmpty()
        val isProxyHost = host == proxyHost || host.endsWith(".$proxyHost")
        val needsProxy = !isProxyHost && BLOCK_HOST_RE.containsMatchIn(host)

        val resultLen: Long = try {
            upstream.open(dataSpec)
        } catch (e: IOException) {
            // tiktokcdn blocked here -> retry through the megaplay proxy.
            if (needsProxy) upstream.open(withProxy(dataSpec)) else throw e
        }

        skipRemaining = if (STRIP_HOST_RE.containsMatchIn(host)) stripBytes else 0
        return if (skipRemaining == 0 || resultLen == C.LENGTH_UNSET.toLong()) resultLen
        else (resultLen - skipRemaining).coerceAtLeast(0L)
    }

    override fun read(target: ByteArray, offset: Int, length: Int): Int {
        if (skipRemaining > 0) {
            while (skipRemaining > 0) {
                val toSkip = minOf(skipRemaining, discard.size)
                val n = upstream.read(discard, 0, toSkip)
                if (n == C.RESULT_END_OF_INPUT) return C.RESULT_END_OF_INPUT
                if (n <= 0) return n
                skipRemaining -= n
            }
        }
        return upstream.read(target, offset, length)
    }

    override fun close() {
        skipRemaining = 0
        upstream.close()
    }

    /** Rewrite a tiktokcdn URL to the megaplay proxy, passing the host as `domain`. */
    private fun withProxy(dataSpec: DataSpec): DataSpec {
        val uri = dataSpec.uri
        val host = uri.host ?: return dataSpec
        val proxied = uri.buildUpon()
            .scheme("https")
            .authority(proxyHost)
            .appendQueryParameter("domain", host)
            .build()
        return dataSpec.withUri(proxied)
    }

    class Factory(
        private val userAgent: String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        private val connectTimeoutMs: Int = 30_000,
        private val readTimeoutMs: Int = 30_000,
        private val defaultRequestProperties: Map<String, String> = emptyMap(),
        private val stripBytes: Int = 252,
        private val proxyHost: String = "yoot.akirax.buzz",
    ) : DataSource.Factory {

        override fun createDataSource(): DataSource {
            val httpFactory = DefaultHttpDataSource.Factory()
                .setUserAgent(userAgent)
                .setConnectTimeoutMs(connectTimeoutMs)
                .setReadTimeoutMs(readTimeoutMs)
                .setAllowCrossProtocolRedirects(true)
                .apply {
                    if (defaultRequestProperties.isNotEmpty()) {
                        setDefaultRequestProperties(defaultRequestProperties)
                    }
                }
            return MegaplaySegmentDataSource(httpFactory.createDataSource(), stripBytes, proxyHost)
        }
    }

    companion object {
        /** Hosts whose chunks carry the fake 252-byte header. */
        val STRIP_HOST_RE = Regex(
            "ibyteimg\\.com|tiktokcdn\\.com|ipstatp\\.com|yoot\\.akirax\\.buzz",
            RegexOption.IGNORE_CASE
        )

        /** Hosts that get proxied through [proxyHost] when unreachable. */
        val BLOCK_HOST_RE = Regex(
            "(ibyteimg\\.com|tiktokcdn\\.com|ipstatp\\.com)$",
            RegexOption.IGNORE_CASE
        )
    }
}
