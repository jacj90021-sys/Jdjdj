package com.panime.app.ui.detail

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.SharpCorner
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.theme.TextPrimary

/**
 * Per-episode server picker for batch downloads. Every selected episode gets a
 * row; tap its chip to cycle AUTO -> server 1 -> server 2 -> ... AUTO means the
 * provider default, with automatic fallback to other servers when empty.
 */
@Composable
fun BatchServerSheet(
    episodes: List<Int>,
    initialAudioType: String = "sub",
    loadServers: suspend (audioType: String) -> List<Pair<String, String>>,
    onDismiss: () -> Unit,
    onConfirm: (audioType: String, choices: Map<Int, String?>, servers: List<Pair<String, String>>) -> Unit
) {
    var audioType by remember { mutableStateOf(if (initialAudioType == "dub") "dub" else "sub") }
    var servers by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val picks = remember { mutableStateMapOf<Int, String?>() }

    LaunchedEffect(audioType) {
        loading = true
        picks.clear()
        // Clear the list immediately: otherwise a quick tap between the start
        // of the reload and its result would pick a code from the OLD list,
        // which then won't match the new one and would show a raw URL.
        servers = emptyList()
        servers = runCatching { loadServers(audioType) }.getOrDefault(emptyList())
        loading = false
    }

    fun cycle(ep: Int) {
        if (servers.isEmpty()) return
        // order: null (AUTO), then each server code
        val options: List<String?> = listOf(null) + servers.map { it.first }
        val cur = picks[ep]
        val next = when {
            cur == null -> servers.firstOrNull()?.first
            else -> {
                val i = options.indexOf(cur)
                options.getOrElse(i + 1) { null }
            }
        }
        picks[ep] = next
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Background.copy(alpha = 0.65f))
            .clickable(onClick = onDismiss)
    ) {
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                .border(2.dp, Hairline, RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                .background(SurfaceRaised)
                .clickable { }
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .width(44.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Hairline)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "CHOOSE SERVERS",
                color = TextMuted,
                fontFamily = PlexMono,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 1.sp
            )
            Spacer(Modifier.height(2.dp))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (loading) "Loading servers…"
                    else if (servers.isEmpty()) "No servers found — default will be used"
                    else "${episodes.size} episode${if (episodes.size == 1) "" else "s"} · tap a chip to change",
                    modifier = Modifier.weight(1f),
                    color = TextPrimary,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier
                        .clip(SharpCorner)
                        .border(2.dp, Hairline, SharpCorner)
                ) {
                    listOf("sub" to "SUB", "dub" to "DUB").forEach { (value, label) ->
                        Box(
                            Modifier
                                .background(if (audioType == value) Flame else Surface)
                                .clickable { audioType = value }
                                .padding(horizontal = 9.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                label,
                                color = if (audioType == value) Background else TextMuted,
                                fontFamily = PlexMono,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))

            LazyColumn(
                Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.45f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(episodes, key = { it }) { ep ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, Hairline.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .background(Surface)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            "Episode $ep",
                            color = TextPrimary,
                            fontFamily = Bricolage,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        val label = picks[ep]
                            ?.let { code -> servers.firstOrNull { it.first == code }?.second ?: friendlyServerName(code) }
                            ?: "AUTO"
                        Row(
                            Modifier
                                .clip(SharpCorner)
                                .border(2.dp, Hairline, SharpCorner)
                                .background(if (picks[ep] == null) SurfaceRaised else Flame.copy(alpha = 0.12f))
                                .clickable { cycle(ep) }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                label.uppercase(),
                                color = if (picks[ep] == null) TextMuted else Flame,
                                fontFamily = PlexMono,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(SharpCorner)
                        .border(2.dp, Hairline, SharpCorner)
                        .background(Surface)
                        .clickable(onClick = onDismiss)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "CANCEL",
                        color = TextMuted,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                }
                Box(
                    Modifier
                        .weight(2f)
                        .clip(SharpCorner)
                        .background(Flame)
                        .clickable { onConfirm(audioType, picks.toMap(), servers) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "OK — DOWNLOAD",
                        color = Background,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

/**
 * Fallback display name for a server code that isn't in the current list.
 * Server codes are normally labels ("Moon", "AniZone"), but Animenosub's
 * preload pair uses the embed URL as the code — never render that raw.
 */
private fun friendlyServerName(code: String): String {
    val clean = code.trim()
    if (clean.startsWith("http://") || clean.startsWith("https://")) {
        // Extract a recognizable name from the URL when possible, else generic.
        val host = clean.substringAfter("://").substringBefore("/").substringBefore(":")
        val known = host.lowercase()
        return when {
            "moon" in known || "sayeveum" in known -> "Moon"
            "omega" in known || "vidmoly" in known -> "Omega"
            "nova" in known || "upn.one" in known -> "Nova"
            else -> host.ifBlank { "Server" }
        }
    }
    return clean.ifBlank { "Server" }
}
