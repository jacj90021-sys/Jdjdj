package com.panime.app.ui.mylist

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panime.app.data.model.Anime
import com.panime.app.ui.mylist.ListEditorSheet
import com.panime.app.ui.components.AnimePosterCard
import com.panime.app.ui.components.LoadingBox
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.PaperWhite
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary
import com.panime.app.viewmodel.LibraryViewModel

private val FILTERS = listOf(
    "All",
    "Watching",
    "Completed",
    "Paused",
    "Plan to Watch",
    "Rewatching",
    "Dropped",
    "Downloads"
)

private val BASE_STATUSES = setOf(
    "Watching",
    "Completed",
    "Paused",
    "Plan to Watch",
    "Rewatching",
    "Dropped"
)

private fun baseStatus(raw: String?): String? {
    val v = raw?.trim() ?: return null
    for (b in BASE_STATUSES) if (v.equals(b, true)) return b
    return null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyListScreen(
    viewModel: LibraryViewModel,
    onAnimeClick: (Anime) -> Unit,
    onPlayOffline: (anilistId: Int, episode: Int, uri: String, title: String) -> Unit = { _, _, _, _ -> },
    onPlayDownloaded: (anilistId: Int, episode: Int, downloadId: String, title: String) -> Unit = { _, _, _, _ -> }
) {
    val list by viewModel.items.collectAsStateWithLifecycle()
    val loading by viewModel.loading.collectAsStateWithLifecycle()
    val syncing by viewModel.syncing.collectAsStateWithLifecycle()
    val syncLabel by viewModel.syncLabel.collectAsStateWithLifecycle()
    val progressMap by viewModel.listProgress.collectAsStateWithLifecycle()
    val statusMap by viewModel.listStatus.collectAsStateWithLifecycle()
    var selectedFilter by remember { mutableStateOf("All") }
    // Local, synchronous status override so the All-tab badge flips immediately on
    // Save — does not depend on the ViewModel StateFlow/collect timing.
    val statusOverride = remember { mutableStateMapOf<Int, String>() }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    var editingAnime by remember { mutableStateOf<Anime?>(null) }
    var snack by remember { mutableStateOf<String?>(null) }

    // Auto-sync the connected AniList account's list into My List on tab load.
    // Shows the loading animation while it runs (no manual button — like other
    // professional list apps). Only fires once per tab entry.
    LaunchedEffect(Unit) {
        viewModel.syncAniList()
        viewModel.syncMal()
    }
    // Auto-dismiss the push/sync feedback banner after a few seconds.
    LaunchedEffect(snack) {
        if (snack != null) {
            kotlinx.coroutines.delay(3000)
            snack = null
        }
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        Text(
            "My List",
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
            modifier = Modifier.padding(16.dp)
        )
        // Same viewport as Browse: full-width LazyRow + contentPadding so chips
        // start inset, then clip at the screen edges while scrolling — not under
        // a padded beige gutter.
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(FILTERS, key = { it }) { filter ->
                val selected = selectedFilter == filter
                Box(
                    Modifier
                        .border(2.dp, if (selected) Flame else Hairline)
                        .background(if (selected) Flame else Surface)
                        .clickable { selectedFilter = filter }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = filter.uppercase(),
                        color = if (selected) PaperWhite else TextPrimary,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp
                    )
                }
            }
        }

        // Sync / push feedback banner
        snack?.let { s ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .background(
                        if (s.startsWith("Saved")) Surface else Color(0x33E8465A),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(s, color = TextSecondary)
            }
        }

        // Sync indicator — shows the loading animation while AniList auto-syncs on tab load.
        if (syncing) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CircularProgressIndicator(
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(16.dp),
                    color = Flame
                )
                Text("Syncing your ${syncLabel.ifBlank { "list" }}…", color = TextSecondary)
            }
        }

        when {
            selectedFilter == "Downloads" -> DownloadsScreen(
                onPlayOffline = onPlayOffline,
                onPlayDownloaded = onPlayDownloaded
            )
            loading && list.isEmpty() -> LoadingBox()
            list.isEmpty() -> Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Your list is empty", color = TextPrimary)
                Text("Add titles from the detail screen", color = TextSecondary)
            }
            else -> {
                val filtered = remember(list, selectedFilter) {
                    if (selectedFilter == "All") {
                        list
                    } else {
                        list.filter { anime ->
                            val raw = anime.status
                            val mapped = baseStatus(raw)
                            when (selectedFilter) {
                                "Watching" -> raw.equals("Watching", true) || mapped == "Watching"
                                "Completed" -> raw.equals("Completed", true) || mapped == "Completed"
                                "Paused" -> raw.equals("Paused", true) || mapped == "Paused"
                                "Plan to Watch" -> raw.equals("Plan to Watch", true) || raw.equals(
                                    "Plan To Watch", true
                                ) || mapped == "Plan to Watch"
                                "Rewatching" -> raw.equals("Rewatching", true) || mapped == "Rewatching"
                                "Dropped" -> raw.equals("Dropped", true) || mapped == "Dropped"
                                else -> false
                            }
                        }
                    }
                }
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(120.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filtered, key = { it.id }) { anime ->
                        AnimePosterCard(
                            anime = anime,
                            onClick = { onAnimeClick(anime) },
                            onLongPress = { editingAnime = anime },
                            watchedProgress = progressMap[anime.id] ?: 0,
                            status = statusOverride[anime.id] ?: statusMap[anime.id] ?: anime.status,
                            showStatusBadge = selectedFilter == "All"
                        )
                    }
                }
            }
        }
        editingAnime?.let { anime ->
            ModalBottomSheet(
                onDismissRequest = { editingAnime = null },
                sheetState = sheetState
            ) {
                ListEditorSheet(
                    anime = anime,
                    initialStatus = statusMap[anime.id] ?: anime.status ?: "Plan to Watch",
                    initialProgress = progressMap[anime.id] ?: 0,
                    initialScore = anime.score,
                    onDismiss = { editingAnime = null },
                    onSave = { status, progress, score ->
                        scope.launch {
                            viewModel.updateListStatus(anime.id, status)
                            viewModel.updateListProgress(anime.id, progress)
                            viewModel.updateListScore(anime.id, score)
                            // Push the change to whichever remote accounts are connected
                            // (AniList + MAL), like professional list-tracking apps.
                            val okAni = viewModel.pushToAniList(anime.id, status, progress, score)
                            val okMal = viewModel.pushToMal(anime.id, status, progress, score)
                            val msg = buildList {
                                if (okAni) add("AniList")
                                if (okMal) add("MAL")
                            }.let { synced ->
                                if (synced.isEmpty()) "Saved locally only" else "Saved to ${synced.joinToString(" + ")}"
                            }
                            snack = msg
                            statusOverride[anime.id] = status
                            editingAnime = null
                        }
                    },
                    onDelete = {
                        scope.launch {
                            viewModel.deleteAnime(anime.id)
                            editingAnime = null
                        }
                    }
                )
            }
        }
    }
}
