package com.panime.app.download

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Live download progress shared between the service and the UI. */
object DownloadState {

    data class Entry(
        val name: String,
        val percent: Int,
        val error: String? = null,
        val done: Boolean = false,
        val posterUrl: String? = null,
        val quality: String? = null,
        val server: String? = null,
        val bytes: Long = 0
    )

    private val _entries = MutableStateFlow<Map<String, Entry>>(emptyMap())
    val entries: StateFlow<Map<String, Entry>> = _entries

    /** Episodes the user individually paused — keyed by task name.
     *  No queue-wide flag: a stale pause must never block NEW downloads. */
    private val _pausedTasks = MutableStateFlow<Set<String>>(emptySet())
    val pausedTasks: StateFlow<Set<String>> = _pausedTasks

    fun toggleTaskPause(name: String) {
        _pausedTasks.value = if (name in _pausedTasks.value) _pausedTasks.value - name
        else _pausedTasks.value + name
    }

    /** Merges so poster/quality/server given once at enqueue are kept across updates. */
    fun update(
        name: String,
        percent: Int,
        posterUrl: String? = null,
        quality: String? = null,
        server: String? = null,
        bytes: Long = 0
    ) {
        val old = _entries.value[name]
        _entries.value = _entries.value + (name to Entry(
            name = name,
            percent = percent.coerceIn(0, 99),
            posterUrl = posterUrl ?: old?.posterUrl,
            quality = quality ?: old?.quality,
            server = server ?: old?.server,
            bytes = if (bytes > 0) bytes else old?.bytes ?: 0
        ))
    }

    fun complete(name: String) {
        val old = _entries.value[name]
        _entries.value = _entries.value + (name to Entry(
            name, 100, done = true,
            posterUrl = old?.posterUrl, quality = old?.quality,
            server = old?.server, bytes = old?.bytes ?: 0
        ))
    }

    fun fail(name: String, message: String) {
        val old = _entries.value[name]
        _entries.value = _entries.value + (name to Entry(
            name, 0, error = message,
            posterUrl = old?.posterUrl, quality = old?.quality,
            server = old?.server, bytes = old?.bytes ?: 0
        ))
    }

    fun clear(name: String) {
        _entries.value = _entries.value - name
        _pausedTasks.value = _pausedTasks.value - name
    }
}
