package com.panime.app.data.api

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import com.panime.app.data.network.HttpClient
import com.panime.app.util.Obf
import com.panime.app.util.jsonArrayOrNull
import okhttp3.Request
import java.net.URLEncoder

/**
 * Client for anidap (anidap.lol).
 *
 * anidap serves DIRECT HLS m3u8 urls hosted on playeng.animeapps.top (or similar
 * CDN). No Cloudflare Worker, no proxy needed — the device fetches the m3u8 +
 * segments directly with the Referer.
 *
 * IMPORTANT: anidap's metadata API (chad.anidap.lol/rest/api endpoints) BLOCKS datacenter
 * IPs (e.g. Render returns 403). It only answers requests from a normal/residential
 * IP — which the device has. So unlike the other scrapers, this client resolves
 * everything directly from the device (slug + servers + sources), not via the
 * anidap-scraper backend (which would be IP-blocked by chad.anidap.lol).
 *
 * Flow (all keyed by the AniList id, which the app already has):
 *   1) GET anidap.lol/api/anime/<anilistId>  -> data.id (slug, e.g. "dogul-wang-rbdrw")
 *   2) GET chad.anidap.lol/rest/api/servers?id=<slug>&epNum=<ep>
 *        -> { subProviders:[{id,tip}], dubProviders:[...] }
 *   3) GET chad.anidap.lol/rest/api/sources?id=<slug>&epNum=<ep>&type=<sub|dub>&providerId=<id>
 *        -> { sources:[{url,quality,type}], headers:{Referer} }
 *
 * Each episode exposes multiple "servers" (anidap provider ids: beep, mimi, yuki,
 * uwu, kiwi, sora, ...). The player's server sheet lets the user pick.
 *
 * Any failure returns null — the caller shows a real error, never a demo video.
 */
object AnidapApi {

    private val ANIDAP = Obf.s("Mi4uKilgdXU7NDM+Oyp0NjU2")
    private val CHAD = Obf.s("Mi4uKilgdXU5Mjs+dDs0Mz47KnQ2NTY=")

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    // chad.anidap.lol returns real server ids (beep, mimi, yuki, ...) with a `tip`
    // describing quality ("Soft sub, Fastest, High quality"). The `tip` is a blurb,
    // NOT the server name — the player should show the actual server name instead.
    private val SERVER_NAMES = mapOf(
        "adp" to "ADP",
        "zuna" to "Zuna",
        "beep" to "Beep",
        "mimi" to "Mimi",
        "yuki" to "Yuki",
        "neko" to "Neko",
        "kiwi" to "Kiwi",
        "sora" to "Sora",
        "loli" to "Loli",
        "uwu" to "UwU",
        "minky" to "Minky",
        "miku" to "Miku",
        "kuro" to "Kuro",
        "sax" to "Sax",
        "yume" to "Yume"
    )

    /** Friendly display name for an anidap provider/server id. */
    fun serverDisplayName(id: String): String =
        SERVER_NAMES[id] ?: id.replaceFirstChar { it.uppercase() }

    // anidap's OWN site injects a first-party "adp" provider into every anime's
    // sub and dub list in client-side JS (`subProviders.unshift({id:"adp"})`);
    // its public chad API never returns it, so it cannot be discovered — the id
    // has to be named here. Listing it is what makes the app show the same
    // servers the site does. Resolves via /rest/api/sources?providerId=adp.
    const val ADP_ID = "adp"

    /** Prepend the site's built-in adp server unless the API already lists it. */
    fun withAdp(servers: List<Pair<String, String>>): List<Pair<String, String>> =
        if (servers.any { it.first == ADP_ID }) servers
        else listOf(ADP_ID to serverDisplayName(ADP_ID)) + servers

    private val client = HttpClient.shared

    fun warmUp() { /* direct fetches need no warmup */ }

    private fun get(url: String): String {
        val req = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
            .header("Referer", "$ANIDAP/home")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw RuntimeException("AnidapApi HTTP ${resp.code}: ${resp.body?.string()?.take(120)}")
            return resp.body?.string().orEmpty()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Resolve AniList id -> anidap slug via the public anime API (works from device). */
    fun resolveSlug(anilistId: Int): String? {
        val root: JsonObject = json.parseToJsonElement(get("$ANIDAP/api/anime/$anilistId")).jsonObject
        val ok = root["success"]?.jsonPrimitive?.content == "true"
        if (ok) {
            return root["data"]?.jsonObject?.get("id")?.jsonPrimitive?.content
        }
        return null
    }

    /** Server entries (provider ids + tips) for an episode, as (id, name) pairs. */
    fun servers(anilistId: Int, episode: Int, type: String = "sub"): List<Pair<String, String>> {
        val slug = resolveSlug(anilistId) ?: return emptyList()
        val root: JsonObject = json.parseToJsonElement(
            get("$CHAD/rest/api/servers?id=$slug&epNum=$episode")
        ).jsonObject
        val pool = if (type == "dub") {
            root["dubProviders"].jsonArrayOrNull ?: root["subProviders"].jsonArrayOrNull ?: return emptyList()
        } else {
            root["subProviders"].jsonArrayOrNull ?: return emptyList()
        }
        val listed = pool.mapNotNull { s ->
            val o = s.jsonObject
            val code = o["id"]?.jsonPrimitive?.content ?: return@mapNotNull null
            code to serverDisplayName(code)
        }
        return withAdp(listed)
    }

    /**
     * Per-episode audio availability — the TRUTH, never inferred. anidap's API
     * reports `subProviders[]` and `dubProviders[]` arrays (provider ids like
     * beep/mimi/yuki/neko/kiwi/sora). Returns (hasSub, hasDub) from ONE servers
     * call. An episode with an empty dubProviders array genuinely has no dub
     * (e.g. Liar Game eps 20-21).
     */
    fun audioAvailability(anilistId: Int, episode: Int): Pair<Boolean, Boolean> {
        val slug = resolveSlug(anilistId) ?: return false to false
        val root = try {
            json.parseToJsonElement(
                get("$CHAD/rest/api/servers?id=$slug&epNum=$episode")
            ).jsonObject
        } catch (e: Exception) {
            return false to false
        }
        val hasSub = root["subProviders"].jsonArrayOrNull?.isNotEmpty() == true
        val hasDub = root["dubProviders"].jsonArrayOrNull?.isNotEmpty() == true
        return hasSub to hasDub
    }

    /**
     * A resolved stream result. anidap returns a DIRECT m3u8 + Referer (no proxy),
     * so proxiedM3u8 == rawM3u8 == the CDN url. `serverCode` is the provider id.
     */
    data class StreamResult(
        val proxiedM3u8: String?,
        val rawM3u8: String?,
        val isByfms: Boolean,
        val referer: String?,
        val subtitles: List<AniwavesApi.SubtitleTrack>,
        val serverCode: String?
    )

    /** Resolve the full sources payload for an episode (first/default server). */
    fun resolveFull(anilistId: Int, episode: Int, type: String = "sub"): StreamResult? {
        val slug = resolveSlug(anilistId) ?: return null
        val pool = serverPool(slug, episode, type) ?: return null
        val pid = pool.firstOrNull { it["default"]?.jsonPrimitive?.content == "true" }?.get("id")?.jsonPrimitive?.content
            ?: pool.firstOrNull()?.get("id")?.jsonPrimitive?.content ?: return null
        return resolveProvider(slug, episode, type, pid)
    }

    /** Resolve a specific provider id to a StreamResult, or null. */
    fun resolveOne(anilistId: Int, episode: Int, serverCode: String, type: String = "sub"): StreamResult? {
        val slug = resolveSlug(anilistId) ?: return null
        return resolveProvider(slug, episode, type, serverCode)
    }

    private fun serverPool(slug: String, episode: Int, type: String): List<JsonObject>? {
        val root: JsonObject = json.parseToJsonElement(
            get("$CHAD/rest/api/servers?id=$slug&epNum=$episode")
        ).jsonObject
        val arr = if (type == "dub") root["dubProviders"].jsonArrayOrNull ?: root["subProviders"].jsonArrayOrNull
                   else root["subProviders"].jsonArrayOrNull
        val listed = arr?.map { it.jsonObject } ?: return null
        return withAdpPool(listed)
    }

    private fun withAdpPool(pool: List<JsonObject>): List<JsonObject> =
        if (pool.any { it["id"]?.jsonPrimitive?.content == ADP_ID }) pool
        else listOf(JsonObject(mapOf("id" to JsonPrimitive(ADP_ID)))) + pool

    private fun resolveProvider(slug: String, episode: Int, type: String, pid: String): StreamResult? {
        val root: JsonObject = json.parseToJsonElement(
            get("$CHAD/rest/api/sources?id=$slug&epNum=$episode&type=$type&providerId=$pid")
        ).jsonObject
        val srcList = root["sources"].jsonArrayOrNull ?: return null
        val first = srcList.firstOrNull()?.jsonObject ?: return null
        val m3u8 = first["url"]?.jsonPrimitive?.content ?: return null
        val referer = root["headers"]?.jsonObject?.get("Referer")?.jsonPrimitive?.content
            ?: run {
                val u = java.net.URI(m3u8)
                "${u.scheme}://${u.host}/"
            }
        return StreamResult(m3u8, m3u8, false, referer, emptyList(), pid)
    }

    /** Legacy single-url resolve (first available server). */
    fun streamUrl(anilistId: Int, episode: Int, type: String = "sub"): String? =
        resolveFull(anilistId, episode, type)?.proxiedM3u8

    // ===================== Wrong-title support (additive) =====================
    // The search endpoint (/api/anime/search) returns its own ids ("21"), but
    // the chad.anidap.lol endpoints need the site slug ("one-piece-p8k27").
    // These helpers bridge a wrong-title pick to the real identifiers. The
    // default anilistId-keyed flow above never calls them.

    private fun pickDetail(pickId: String): Pair<String, Int>? {
        val txt = try {
            get("$ANIDAP/api/anime/${enc(pickId)}")
        } catch (e: Exception) {
            return null
        }
        val root = runCatching { json.parseToJsonElement(txt).jsonObject }.getOrNull() ?: return null
        if (root["success"]?.jsonPrimitive?.content != "true") return null
        val data = root["data"]?.jsonObject ?: return null
        val slug = data["id"]?.jsonPrimitive?.content ?: return null
        val eps = data["episodeCount"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
        return slug to eps
    }

    /** Search-pick id -> episode count (replaces the detail episode list). */
    fun episodeCountByPick(pickId: String): Int? = pickDetail(pickId)?.second

    /** Search-pick id -> the chad slug ("one-piece-p8k27") for servers/sources. */
    fun chadSlugByPick(pickId: String): String? = pickDetail(pickId)?.first

    /** Servers for an already-known chad slug — skips the anilist-id auto-match. */
    fun serversBySlug(chadSlug: String, episode: Int, type: String = "sub"): List<Pair<String, String>> {
        val root = try {
            json.parseToJsonElement(get("$CHAD/rest/api/servers?id=$chadSlug&epNum=$episode")).jsonObject
        } catch (e: Exception) {
            return emptyList()
        }
        val pool = if (type == "dub") {
            root["dubProviders"].jsonArrayOrNull ?: root["subProviders"].jsonArrayOrNull
        } else {
            root["subProviders"].jsonArrayOrNull
        } ?: return emptyList()
        val listed = pool.mapNotNull { s ->
            val o = s.jsonObject
            val code = o["id"]?.jsonPrimitive?.content ?: return@mapNotNull null
            code to serverDisplayName(code)
        }
        return withAdp(listed)
    }
}
