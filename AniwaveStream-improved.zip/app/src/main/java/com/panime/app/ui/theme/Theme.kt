package com.panime.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.panime.app.R

/**
 * AnimeX type system:
 *   Anton          → display / section headers
 *   Work Sans      → body
 *   JetBrains Mono → labels, chips, meta, data
 */

val Anton = FontFamily(
    Font(R.font.anton, FontWeight.W400),
    Font(R.font.anton, FontWeight.W700),
    Font(R.font.anton, FontWeight.W800)
)

val Inter = FontFamily(
    Font(R.font.inter, FontWeight.W400),
    Font(R.font.inter, FontWeight.W500),
    Font(R.font.inter, FontWeight.W600),
    Font(R.font.inter, FontWeight.W700)
)

val WorkSans = FontFamily(
    Font(R.font.work_sans, FontWeight.W400),
    Font(R.font.work_sans, FontWeight.W500),
    Font(R.font.work_sans, FontWeight.W600),
    Font(R.font.work_sans, FontWeight.W700)
)

val JetBrainsMono = FontFamily(
    Font(R.font.jetbrains_mono, FontWeight.W500),
    Font(R.font.jetbrains_mono, FontWeight.W600),
    Font(R.font.jetbrains_mono, FontWeight.W700)
)

// Back-compat aliases so existing call sites keep compiling.
val Bricolage = Anton
val PlexMono = JetBrainsMono

/** Sharp / minimal corners for buttons, chips, toggles (prototype: no soft pills). */
val SharpCorner = RoundedCornerShape(0.dp)
val SharpCornerSm = RoundedCornerShape(2.dp)

/** Rounded corner for buttons and chips (matches 12dp cards). */
val UiCorner = RoundedCornerShape(12.dp)

/** Standard ink stroke width from the prototype (2px). */
val InkBorder = 2.dp

private fun colorSchemeFor(palette: AniwavePalette) = if (palette.isDark) {
    darkColorScheme(
        primary = palette.flame,
        onPrimary = Color(0xFFFAF7EE),
        secondary = palette.cool,
        onSecondary = palette.ink,
        background = palette.void,
        surface = palette.surface,
        onBackground = palette.textPrimary,
        onSurface = palette.textPrimary,
        surfaceVariant = palette.surfaceRaised,
        onSurfaceVariant = palette.textSecondary,
        outline = palette.hairline,
        outlineVariant = palette.hairlineBright,
        error = palette.danger,
        onError = Color(0xFFFAF7EE)
    )
} else {
    lightColorScheme(
        primary = palette.flame,
        onPrimary = Color(0xFFFAF7EE),
        secondary = palette.cool,
        onSecondary = palette.ink,
        background = palette.void,
        surface = palette.surface,
        onBackground = palette.textPrimary,
        onSurface = palette.textPrimary,
        surfaceVariant = palette.surfaceRaised,
        onSurfaceVariant = palette.textSecondary,
        outline = palette.hairline,
        outlineVariant = palette.hairlineBright,
        error = palette.danger,
        onError = Color(0xFFFAF7EE)
    )
}

// Typography omits baked-in colors so it follows LocalContentColor / explicit color args.
private val AniwaveTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = Anton,
        fontWeight = FontWeight.W400,
        fontSize = 34.sp,
        lineHeight = 40.sp,
        letterSpacing = 0.2.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = Anton,
        fontWeight = FontWeight.W400,
        fontSize = 22.sp,
        letterSpacing = 0.2.sp
    ),
    headlineSmall = TextStyle(
        fontFamily = Anton,
        fontWeight = FontWeight.W400,
        fontSize = 20.sp,
        letterSpacing = 0.2.sp
    ),
    titleLarge = TextStyle(
        fontFamily = Anton,
        fontWeight = FontWeight.W400,
        fontSize = 19.sp,
        letterSpacing = 0.2.sp
    ),
    titleMedium = TextStyle(
        fontFamily = Anton,
        fontWeight = FontWeight.W400,
        fontSize = 16.sp
    ),
    labelLarge = TextStyle(
        fontFamily = JetBrainsMono,
        fontWeight = FontWeight.W700,
        fontSize = 13.sp,
        letterSpacing = 0.2.sp
    ),
    labelMedium = TextStyle(
        fontFamily = JetBrainsMono,
        fontWeight = FontWeight.W600,
        fontSize = 11.sp,
        letterSpacing = 0.4.sp
    ),
    labelSmall = TextStyle(
        fontFamily = JetBrainsMono,
        fontWeight = FontWeight.W600,
        fontSize = 10.sp,
        letterSpacing = 0.3.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = WorkSans,
        fontWeight = FontWeight.W400,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = WorkSans,
        fontWeight = FontWeight.W400,
        fontSize = 13.sp,
        lineHeight = 18.sp
    ),
    bodySmall = TextStyle(
        fontFamily = WorkSans,
        fontWeight = FontWeight.W400,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun AniwaveTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val palette = if (darkTheme) DarkAniwavePalette else LightAniwavePalette
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
            @Suppress("DEPRECATION")
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            @Suppress("DEPRECATION")
            window.navigationBarColor =
                if (darkTheme) 0xFF1A1A1A.toInt() else 0xFFFAF7EE.toInt()
        }
    }

    CompositionLocalProvider(LocalAniwavePalette provides palette) {
        MaterialTheme(
            colorScheme = colorSchemeFor(palette),
            typography = AniwaveTypography,
            content = content
        )
    }
}
