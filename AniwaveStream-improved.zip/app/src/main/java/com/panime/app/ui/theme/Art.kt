package com.panime.app.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.panime.app.data.model.Anime

/**
 * Premium art-wash: a single subtle dark gradient that never clashes with
 * the poster. The background fades from surface-dark at the top to void
 * at the bottom — clean, consistent, and lets the artwork speak.
 */
private val PremiumWashStops = listOf(
    Color(0xFF1A1A1A),
    Color(0xFF121212),
    Color(0xFF0E0E0E),
    Color(0xFF0A0A0A)
)

@Composable
fun AnivaveArt(
    anime: Anime,
    modifier: Modifier = Modifier,
    showImage: Boolean = true
) {
    BoxWithConstraints(modifier) {
        val w = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val h = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val brush = Brush.verticalGradient(
            colorStops = PremiumWashStops.mapIndexed { i, c -> i.toFloat() / (PremiumWashStops.size - 1) to c }.toTypedArray(),
            startY = 0f,
            endY = h
        )
        Box(Modifier.fillMaxSize().background(brush)) {
            if (showImage && anime.posterUrl != null) {
                AsyncImage(
                    model = anime.posterUrl,
                    contentDescription = anime.title,
                    contentScale = ContentScale.Crop,
                    placeholder = ColorPainter(Color.Transparent),
                    error = ColorPainter(Color.Transparent),
                    onError = { result ->
                        android.util.Log.e(
                            "AnivaveArt",
                            "POSTER FAIL: '${anime.title}' id=${anime.id} url=${anime.posterUrl}",
                            result.result.throwable
                        )
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
            // Bottom scrim for legibility — kept light so the poster shows clear
            // (badges already carry their own backgrounds). Only the very bottom
            // darkens, so the image is never lost in a black wash.
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.45f)),
                        startY = h * 0.72f,
                        endY = h
                    )
                )
            )
        }
    }
}

/** Compact poster-tile variant used inside rows. */
@Composable
fun AnivavePosterArt(anime: Anime, modifier: Modifier = Modifier) {
    AnivaveArt(anime = anime, modifier = modifier.fillMaxWidth().height(160.dp))
}
