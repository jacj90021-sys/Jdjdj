package com.panime.app.data.provider.anikage

import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider
import com.panime.app.util.Obf
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URLEncoder

/** (a, b, c, d) — like Triple but 4 fields; used for (url, quality, referer, isM3u8). */
internal data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

/**
 * On-device AniKage provider.
 *
 * Ports the anikage.cc resolver directly — NO backend, NO Cloudflare, NO Node.
 * The site exposes a clean JSON API; each source `url` is an opaque server-side
 * token that the browser routes through the public proxy. We reproduce
 * that proxy call from the device (the old client-side XOR cipher is rotated).
 *
 * === 2026-09 site update (reverse-engineered from live site JS) ===
 *  - PUBLIC_PROXY_URL moved: gg.akage.lol is DEAD (TLS handshake fails) and
 *    was never in the site config anyway (that's the 2025 value). The site
 *    now ships PUBLIC_PROXY_URL = og.bakayaro.live (fallback prox.anikage.cc).
 *  - Token routing rule (site fn r(e, t=`stream`)): tokens not starting with
 *    /stream/|/m3u8/|/hls/ go to `${PROXY}/stream/<token>` — both /m3u8/<tok>
 *    and /stream/<tok> are served (verified live, both return playlists).
 *  - servers[] changed: {koto, kiwi, megg, dib, wave, zen}; koto returns
 *    EMPTY sources now (2026-09), kiwi is the default. DISPLAY gains Kiwi/Zen.
 *  - embeds[] mapping ($t in site JS): {0:kiss, 1:kiss, softsub:neko,
 *    hardsub:neko, koto:koto, wish:koto, zen:zen}. kiss sources are empty
 *    for non-logged-in sessions; zen = flixcloud embed (handled by the
 *    player's FlixcloudDecryptingDataSource).
 *
 * Server vs Embed rows (verified against the live site JS):
 *   servers[]: kiwi, megg, dib, wave, koto, zen -> queried directly as `provider=`
 *   embeds[] : koto(E-Koto), wish(E-Wish), zen(E-Zen), softsub(E-Neko),
 *              hardsub(E-Ken), kiss(E-Kiss/E-Aki) mapped via the $t table above.
 *
 * Source of truth: anikage-scraper/anikage_scraper.py + site JS.
 */
class AnikageProvider : StreamProvider, SearchableProvider {

    override val id = "anikage"
    override val label = "KAGE"
    override val backendRequired = false

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val BASE = Obf.s("Mi4uKilgdXU7NDMxOz0/dDk5")

    // Server id -> display name. NOTE: anikage's /servers API stores the ANIME
    // TITLE in `label` (not the server name), so we map by id instead of using label.
    private val DISPLAY = mapOf(
        "neko" to "Neko", "megg" to "Megg", "dib" to "Dib",
        "wave" to "Wave", "koto" to "Koto", "ken" to "Ken",
        "kiwi" to "Kiwi", "zen" to "Zen", "kiss" to "Kiss"
    )

    // Embed id -> (backing backend, optional subTrack type, optional CDN host filter)
    // Mirrors the site's $t map (2026-09: {0:kiss, 1:kiss, softsub:neko,
    // hardsub:neko, koto:koto, wish:koto, zen:zen}). null host = no narrowing.
    private val EMBED_MAP: Map<String, Triple<String, String?, String?>> = mapOf(
        "softsub" to Triple("neko", "softsub", null),
        "hardsub" to Triple("neko", "hardsub", null),
        "koto" to Triple("koto", null, "megaplay"),
        "wish" to Triple("koto", null, "vidtube"),
        "zen" to Triple("zen", null, null),
        "kiss" to Triple("kiss", null, null)
    )

    private fun headers(referer: String) = ScraperEngine.defaultHeaders(referer = referer) +
        ("Origin" to BASE)

    override suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int,
        totalEpisodes: Int,
        year: Int?
    ): ResolveResult? {
        val slug = resolveSlug(anilistId, title) ?: return null
        val servers = listServers(slug, episode, type)
        if (servers.isEmpty()) return null
        val (provider, quality) = splitServer(serverCode, servers)
        val result = resolveStream(slug, episode, type, provider, quality) ?: return null
        return ResolveResult(
            source = id,
            servers = servers,
            url = result.url,
            rawUrl = result.url,
            referer = result.referer,
            format = result.format,
            subtitles = result.subtitles,
            intro = result.intro,
            outro = result.outro,
            notFound = false
        )
    }

    /** Direct in-app server list for the player's server sheet (no backend). */
    suspend fun listServersFor(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String
    ): List<Pair<String, String>> {
        val slug = resolveSlug(anilistId, title) ?: return emptyList()
        return listServers(slug, episode, type)
    }

    private fun resolveSlug(anilistId: Int, title: String): String? {
        // anikage's /api/media/anime/<id> expects a SLUG, not an AniList ID, and
        // rejects numeric ids with {"error":"invalid slug"}. So we resolve by a
        // title search against the browse endpoint, which returns slug + anilistId
        // and lets [score] pin the exact match.
        if (title.isNotBlank()) {
            val q = URLEncoder.encode(title, "UTF-8")
            val browse = getJson(
                "/api/media/anime/browse?q=$q&sort=popularity&page=1&limit=10",
                referer = "$BASE/"
            )
            val tn = title.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
            val best = browse?.get("data")?.jsonArray
                ?.mapNotNull { it.jsonObject }
                ?.maxByOrNull { score(it, tn, anilistId) }
            return best?.get("slug")?.jsonPrimitive?.content
        }
        return null
    }

    private fun score(o: JsonObject, tn: String, anilistId: Int): Int {
        var s = 0
        val aid = o["anilistId"]?.jsonPrimitive?.content
        if (aid == anilistId.toString()) s += 1000
        val t = o["title"]?.jsonObject
        for (k in listOf("english", "romaji", "native", "name")) {
            val v = t?.get(k)?.jsonPrimitive?.content?.lowercase()
                ?.replace(Regex("[^a-z0-9]+"), " ")?.trim()
            if (v != null && tn.isNotEmpty() && v == tn) s += 100
        }
        return s
    }

    /** Maps a (possibly embed) id to a backing backend + type + host filter. */
    private fun mapBackend(code: String): Triple<String, String?, String?> {
        val e = EMBED_MAP[code.lowercase()]
        if (e != null) return e
        // Regular server id (neko/megg/dib/wave/koto) -> itself, no filter.
        val backend = code.lowercase()
        return Triple(backend, null, null)
    }

    private fun listServers(slug: String, episode: Int, type: String): List<Pair<String, String>> {
        val want = if (type == "dub") "dub" else "sub"
        val root = getJson(
            "/api/media/anime/$slug/episodes/$episode/servers",
            referer = "$BASE/anime/watch/$slug"
        ) ?: return emptyList()
        val out = mutableListOf<Pair<String, String>>()
        // servers[] -> listed by their real id (kiwi/megg/dib/wave/koto/zen)
        for (el in root["servers"]?.jsonArray ?: emptyList()) {
            val o = el.jsonObject
            val id = o["id"]?.jsonPrimitive?.content ?: continue
            val name = DISPLAY[id.lowercase()] ?: id  // API `label` here is the anime title, not server
            val quals = providerSources(slug, episode, mapBackend(id), want)
                .streams.mapNotNull { it.second }
            if (quals.isEmpty()) out.add(id to name)
            else for (q in quals.distinct()) out.add("$id|$q" to "$name · $q")
        }
        // embeds[] -> mapped to backing backend via the site's $t table
        // (softsub->neko, koto->koto, wish->koto, zen->zen, kiss->kiss)
        for (el in root["embeds"]?.jsonArray ?: emptyList()) {
            val o = el.jsonObject
            val id = o["id"]?.jsonPrimitive?.content ?: continue
            val name = o["label"]?.jsonPrimitive?.content ?: o["name"]?.jsonPrimitive?.content ?: id
            val (backend, subTrack, host) = mapBackend(id)
            val quals = providerSources(slug, episode, Triple(backend, subTrack, host), want)
                .streams.mapNotNull { it.second }
            if (quals.isEmpty()) out.add(id to name)
            else for (q in quals.distinct()) out.add("$id|$q" to "$name · $q")
        }
        return out
    }

    /** Returns streams/intro-outro/subtitles for a backing backend. Each
     *  stream is (url, quality, referer, isM3u8); intro/outro are root-level on
     *  anikage's /sources response, in SECONDS: {start,end}. */
    private data class ProviderSourcesResult(
        val streams: List<Quadruple<String, String?, String, Boolean>>,
        val introOutro: Pair<Pair<Int, Int>?, Pair<Int, Int>?>,
        val subtitles: List<AniwavesApi.SubtitleTrack>
    )

    private fun providerSources(
        slug: String,
        episode: Int,
        backend: Triple<String, String?, String?>,
        lang: String
    ): ProviderSourcesResult {
        val (b, subTrack, hostFilter) = backend
        val root = getJson(
            "/api/media/anime/$slug/episodes/$episode/sources?provider=$b&lang=$lang",
            referer = "$BASE/anime/watch/$slug"
        ) ?: return ProviderSourcesResult(emptyList(), null to null, emptyList())
        // Collect the FULL source list first, then apply the embed filters. If the
        // strict filter (subTrack / CDN host) matches nothing, fall back to the
        // whole list — mirrors the site (node 13): `source = pick(subTrack) ?? defaultSource`.
        // This keeps E-Ken/E-Wish playable even when the backend only serves a
        // softsub (neko) or a single megaplay (koto) source for the episode.
        val raw = mutableListOf<Quadruple<String, String?, String, Boolean>>()
        val meta = mutableListOf<Pair<String, String>>()  // (type, embedUrl)
        for (s in root["sources"]?.jsonArray
            ?: return ProviderSourcesResult(emptyList(), null to null, emptyList())) {
            val o = s.jsonObject
            val tok = o["url"]?.jsonPrimitive?.content ?: continue
            val isM3u8 = o["isM3U8"]?.jsonPrimitive?.content == "true"
            // The source `url` is a server-side token, NOT a client-decodable
            // URL (anikage rotated the base64 XOR key). Route it through anikage's
            // public proxy, which returns the real playlist/file. Try a DIRECT
            // embed m3u8 first for hosts that expose one (e.g. vivibebe).
            val real = extractFromEmbed(o["embedUrl"]?.jsonPrimitive?.content)
                ?: buildProxyUrl(tok, isM3u8)
                ?: continue
            val q = o["quality"]?.jsonPrimitive?.content
            val embed = o["embedUrl"]?.jsonPrimitive?.content ?: ""
            val t = o["type"]?.jsonPrimitive?.content ?: ""
            raw.add(Quadruple(real, q, refererFor(real, embed), isM3u8))
            meta.add(t to embed)
        }
        val out = raw.filterIndexed { i, _ ->
            val (t, embed) = meta[i]
            (subTrack == null || t.equals(subTrack, ignoreCase = true)) &&
                (hostFilter == null || embed.contains(hostFilter, true))
        }.ifEmpty { raw }
        val intro = runCatching {
            val i = root["intro"]?.jsonObject ?: return@runCatching null
            ((i["start"]?.jsonPrimitive?.content?.toIntOrNull()) ?: 0) to
                ((i["end"]?.jsonPrimitive?.content?.toIntOrNull()) ?: 0)
        }.getOrNull()?.takeIf { it.first > 0 || it.second > 0 }
        val outro = runCatching {
            val o = root["outro"]?.jsonObject ?: return@runCatching null
            ((o["start"]?.jsonPrimitive?.content?.toIntOrNull()) ?: 0) to
                ((o["end"]?.jsonPrimitive?.content?.toIntOrNull()) ?: 0)
        }.getOrNull()?.takeIf { it.first > 0 || it.second > 0 }
        return ProviderSourcesResult(out, intro to outro, parseSubtitles(root))
    }

    /**
     * anikage returns subtitle `file` tokens; route them through the same
     * public proxy (which serves WebVTT). Append a `#` fragment so the
     * player's extension-based MIME sniff picks TEXT_VTT (the token has no
     * file extension). The fragment is never sent over the wire.
     */
    private fun parseSubtitles(root: JsonObject): List<AniwavesApi.SubtitleTrack> {
        val arr = root["subtitles"]?.jsonArray ?: return emptyList()
        return arr.mapNotNull { el ->
            val o = el.jsonObject
            val file = o["file"]?.jsonPrimitive?.content ?: return@mapNotNull null
            val label = o["label"]?.jsonPrimitive?.content ?: "English"
            val lang = when {
                "english" in label.lowercase() -> "en"
                "portug" in label.lowercase() -> "pt"
                "spanish" in label.lowercase() -> "es"
                "arabic" in label.lowercase() -> "ar"
                "french" in label.lowercase() -> "fr"
                "german" in label.lowercase() -> "de"
                "italian" in label.lowercase() -> "it"
                "russian" in label.lowercase() -> "ru"
                else -> "en"
            }
            AniwavesApi.SubtitleTrack(lang, label, Obf.s("Mi4uKilgdXU9PXQ7MTs9P3Q2NTZ1N2kvYnU=") + "$file#.vtt")
        }
    }

    /**
     * Best-effort DIRECT m3u8 for hosts that expose one without the proxy. Used as
     * a fast path before falling back to [buildProxyUrl]:
     *   1) Known hosts with a predictable path: build the m3u8 URL directly
     *      (vivibebe.site -> /public/stream/<id>/master.m3u8).
     *   2) Otherwise scrape the embed page HTML for the .m3u8 (covers bibiemb.xyz,
     *      playeng.animeapps.top, and any future host).
     * Returns null if no m3u8 is found (most hosts), so the proxy is the
     * reliable general path.
     */
    private fun extractFromEmbed(embedUrl: String?): String? {
        if (embedUrl.isNullOrBlank()) return null
        val u = runCatching { java.net.URI(embedUrl) }.getOrNull() ?: return null
        val host = u.host.lowercase()
        val id = Regex("""/([A-Za-z0-9]{10,})""").find(embedUrl)?.groupValues?.get(1)
        // 1) Direct transform for hosts we know.
        if (host == Obf.s("LDMsMzg/OD90KTMuPw==") && id != null) {
            val direct = Obf.s("Mi4uKilgdXUsMywzOD84P3QpMy4/dSovODYzOXUpLig/Ozd1") + "$id/master.m3u8"
            if (ScraperEngine.fetchText(direct, headers(Obf.s("Mi4uKilgdXUsMywzOD84P3QpMy4/dQ=="))) != null) return direct
        }
        // 2) Fallback: scrape the embed page for the .m3u8.
        val html = ScraperEngine.fetchText(embedUrl, headers(embedUrl)) ?: return null
        val m = Regex("""https?://[^\s"'<>]+\.m3u8[^\s"'<>]*""").find(html) ?: return null
        return m.value
    }

    /** Full resolved stream for one server: playable url + referer + format,
     *  plus the episode's intro/outro windows (seconds) from anikage. */
    private data class AnikageStream(
        val url: String,
        val referer: String,
        val format: String,
        val intro: Pair<Int, Int>?,
        val outro: Pair<Int, Int>?,
        val subtitles: List<AniwavesApi.SubtitleTrack> = emptyList()
    )

    private fun resolveStream(
        slug: String, episode: Int, type: String,
        serverCode: String?, quality: String?
    ): AnikageStream? {
        val want = if (type == "dub") "dub" else "sub"
        val known = listServers(slug, episode, type)
            .mapNotNull { it.first.split("|").first().takeIf { p -> p.isNotBlank() } }
            .toSet()
        // A valid code is a real server id OR an embed id (mapped to a backend).
        val validCode = serverCode?.takeIf { it in known || it.lowercase() in EMBED_MAP }
        // Try the chosen (or first) backend, then walk the rest — one dead
        // server must never leave the episode unplayable.
        val effCodes = if (validCode != null) listOf(validCode) + known.filter { it != validCode }
        else known.toList()
        if (effCodes.isEmpty()) return null
        for (code in effCodes) {
            val backend = mapBackend(code)
            val result = providerSources(slug, episode, backend, want)
            val srcs = result.streams
            val introOutro = result.introOutro
            val subs = result.subtitles
            if (srcs.isEmpty()) continue
            val pick = if (!quality.isNullOrBlank()) {
                srcs.firstOrNull { it.second == quality }
                    ?: srcs.firstOrNull { it.second?.contains(quality, true) == true }
            } else srcs.firstOrNull()
            val chosen = pick ?: continue
            // 2026-09: the proxy serves HLS playlists at /stream/<token> too, and the
            // API's isM3U8 flag is UNRELIABLE (koto returns isM3U8=false but serves
            // application/vnd.apple.mpegurl; megg genuinely serves mp4). URL shape
            // can't tell them apart either — both go through /stream/<token>. The
            // proxy's response Content-Type is the only authority, so sniff it.
            val fmt = when {
                chosen.first.substringBefore('?').endsWith(".m3u8", ignoreCase = true) -> "hls"
                chosen.first.contains("/m3u8/", ignoreCase = true) -> "hls"
                chosen.fourth -> "hls"
                isHlsContentType(chosen.first, chosen.third) -> "hls"
                else -> "mp4"
            }
            return AnikageStream(chosen.first, chosen.third, fmt, introOutro.first, introOutro.second, subs)
        }
        return null
    }

    /**
     * anikage's source `url` is an opaque server-side token. The browser sends it
     * to the site's public proxy (PUBLIC_PROXY_URL = og.bakayaro.live as of
     * 2026-09; the old gg.akage.lol is dead — TLS handshake fails). The site's
     * routing fn puts bare tokens at `${PROXY}/stream/<token>`; both /m3u8/ and
     * /stream/ are served (verified live 2026-09). Fallback: prox.anikage.cc,
     * the site's own hardcoded default when PUBLIC_PROXY_URL is absent.
     */
    private fun buildProxyUrl(tok: String, isM3u8: Boolean): String {
        val base = Obf.s("Mi4uKilgdXU1PXQ4OzE7IzsoNXQ2Myw/")
        return "$base/stream/$tok"
    }

    /**
     * 2026-09: koto's /stream/<token> sources return HLS (Content-Type
     * application/vnd.apple.mpegurl) even though the API flags isM3U8=false and
     * the URL has no /m3u8/ segment. Ask the proxy itself: check the response
     * Content-Type (headers only — the body is never read/downloaded).
     */
    private fun isHlsContentType(url: String, referer: String): Boolean {
        val resp = ScraperEngine.fetchResponse(url, headers(referer)) ?: return false
        return resp.use { r ->
            val ct = r.header("Content-Type")?.lowercase() ?: return@use false
            ct.contains("mpegurl")
        }
    }

    private fun refererFor(url: String, embedUrl: String?): String {
        val u = runCatching { java.net.URI(url) }.getOrNull()
        val host = u?.host?.lowercase() ?: ""
        // The og.bakayaro.live proxy requires a Referer of anikage.cc
        // (or its own origin) or it returns 403. Never use the embed host here.
        if (host.endsWith("bakayaro.live") || host.endsWith("akage.lol") ||
            host == "prox.anikage.cc"
        ) return Obf.s("Mi4uKilgdXU7NDMxOz0/dDk5dQ==")
        if ("vidcache" in host) return Obf.s("Mi4uKilgdXUsMz45OzkyP3Q0Py51")
        if (host.startsWith("megap.")) return Obf.s("Mi4uKilgdXU3Pz07KjY7I3Q4LyAgdQ==")
        if (host.startsWith("vidtub")) return Obf.s("Mi4uKilgdXUsMz4uLzg/dCkzLj91")
        if ("echovideo" in host) return Obf.s("Mi4uKilgdXUqNjsjdD85MjUsMz4/NXQoL3U=")
        if (!embedUrl.isNullOrBlank()) {
            runCatching { java.net.URI(embedUrl) }.getOrNull()?.let {
                if (it.host.isNotBlank()) return "${it.scheme}://${it.host}/"
            }
        }
        return "${u?.scheme ?: "https"}://${u?.host ?: Obf.s("OzQzMTs9P3Q5OQ==")}/"
    }

    private fun splitServer(code: String?, servers: List<Pair<String, String>>): Pair<String?, String?> {
        if (code.isNullOrBlank()) return null to null
        val parts = code.split("|")
        return parts[0] to parts.getOrNull(1)?.takeIf { it.isNotBlank() }
    }

    private fun getJson(path: String, referer: String): JsonObject? {
        val txt = ScraperEngine.fetchText("$BASE$path", headers(referer), useCache = true) ?: return null
        return runCatching { json.parseToJsonElement(txt).jsonObject }.getOrNull()
    }

    // ===================== Wrong-title support (additive) =====================
    // The picker searches anikage's browse JSON API (the same call the site's
    // /browse?search= page makes) and stores the picked slug directly. The
    // default resolve() flow (title search + score) is never consulted here.

    override suspend fun search(query: String): List<StreamProvider.SearchHit> =
        searchPage(query, 1).items

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        if (query.isBlank()) return PagedResult(emptyList(), 1)
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        val root = getJson(
            "/api/media/anime/browse?q=$q&sort=popularity&page=1&limit=20",
            referer = "$BASE/browse?search=$q"
        ) ?: return PagedResult(emptyList(), 1)
        val items = root["data"]?.jsonArray ?: return PagedResult(emptyList(), 1)
        val hits = items.mapNotNull { el ->
            val o = el.jsonObject
            val slug = o["slug"]?.jsonPrimitive?.content ?: return@mapNotNull null
            val t = o["title"]?.jsonObject
            val title = t?.get("romaji")?.jsonPrimitive?.content
                ?: t?.get("english")?.jsonPrimitive?.content
                ?: return@mapNotNull null
            // coverImage is an OBJECT {large, medium, extraLarge} — calling
            // jsonPrimitive on it throws and kills the whole search. Use .large.
            val coverObj = o["coverImage"]?.jsonObject
            val cover = coverObj?.get("large")?.jsonPrimitive?.content
                ?: coverObj?.get("medium")?.jsonPrimitive?.content
                ?: coverObj?.get("extraLarge")?.jsonPrimitive?.content
            StreamProvider.SearchHit(title = title, slug = slug, posterUrl = cover)
        }
        // Single page — anikage's browse returns one batch per query.
        return PagedResult(items = hits, lastPage = 1)
    }

    /** Wrong-title resolution: [slug] is the user's picked anikage slug, used
     *  DIRECTLY — resolveSlug's title scoring is never consulted. */
    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? {
        val servers = listServers(slug, episode, type)
        if (servers.isEmpty()) return null
        val (provider, quality) = splitServer(serverCode, servers)
        val result = resolveStream(slug, episode, type, provider, quality) ?: return null
        return ResolveResult(
            source = id,
            servers = servers,
            url = result.url,
            rawUrl = result.url,
            referer = result.referer,
            format = result.format,
            subtitles = result.subtitles,
            intro = result.intro,
            outro = result.outro,
            notFound = false
        )
    }

    /** Episode count for a picked slug, from the anime detail API. */
    fun episodeCountForPick(slug: String): Int {
        val root = getJson("/api/media/anime/$slug", referer = "$BASE/anime/$slug")
            ?: return 0
        return root["anime"]?.jsonObject?.get("episodeCount")?.jsonPrimitive?.content
            ?.toIntOrNull() ?: 0
    }

    /**
     * Real per-episode audio blocks — the truth, never inferred. anikage's
     * servers API carries `subTypes` per server (e.g. koto: [sub, dub]); the
     * union across all servers is what this episode genuinely offers. Returns
     * the real block types (subset of sub/dub) from ONE servers call.
     */
    fun audioBlocksFor(slug: String, episode: Int): List<String> {
        val root = getJson(
            "/api/media/anime/$slug/episodes/$episode/servers",
            referer = "$BASE/anime/watch/$slug"
        ) ?: return emptyList()
        val out = LinkedHashSet<String>()
        for (el in root["servers"]?.jsonArray ?: emptyList()) {
            val o = el.jsonObject
            for (t in o["subTypes"]?.jsonArray ?: emptyList()) {
                t.jsonPrimitive.content.takeIf { it == "sub" || it == "dub" }
                    ?.let { out.add(it) }
            }
        }
        return out.toList()
    }
}
