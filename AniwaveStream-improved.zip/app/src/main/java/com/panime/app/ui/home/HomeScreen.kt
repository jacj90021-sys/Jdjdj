package com.panime.app.ui.home

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import com.panime.app.BuildConfig
import com.panime.app.data.model.Anime
import com.panime.app.data.repository.UserLibraryStore
import com.panime.app.ui.components.AnimeRow
import com.panime.app.ui.components.AnimeRankedRow
import com.panime.app.ui.components.AnivaveSectionCard
import com.panime.app.ui.components.AnivaveSectionCardNoHeader
import com.panime.app.ui.components.AnivaveScheduleCard
import com.panime.app.ui.components.AnivaveUpcomingRow
import com.panime.app.ui.components.AnivaveNewReleasesGrid
import com.panime.app.ui.components.ContinueCard
import com.panime.app.ui.components.ErrorBox
import com.panime.app.ui.components.HomeShimmer
import com.panime.app.ui.components.SectionHeader
import com.panime.app.ui.components.PosterRowShimmer
import com.panime.app.ui.components.AnivaveHeroSlider
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextSecondary
import com.panime.app.ui.theme.Void
import com.panime.app.ui.update.AppUpdateInfo
import com.panime.app.ui.update.AppUpdateOverlay
import com.panime.app.ui.update.checkForAppUpdate
import com.panime.app.ui.update.rememberUpdateFlow
import com.panime.app.update.GitHubUpdater
import com.panime.app.viewmodel.HomeViewModel
import com.panime.app.ui.home.SeeAllKind
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onAnimeClick: (Anime) -> Unit,
    onPlay: (Anime) -> Unit,
    onContinue: (Anime, Int) -> Unit,
    onViewAll: (SeeAllKind) -> Unit = { _: SeeAllKind -> },
    onViewSchedule: () -> Unit = {},
    library: UserLibraryStore
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val myListIds by library.myListIds.collectAsStateWithLifecycle(emptySet())
    val scope = rememberCoroutineScope()

    // HOME TAB LAUNCH — auto-check for an update shortly after open. If a new
    // version exists the prompt modal appears (Later / Update Now); if we
    // already downloaded it without installing, jump straight to Install.
    // The check result is persisted so the app never forgets a pending update
    // or claims "up to date" while one is waiting to be installed.
    val updateFlow = rememberUpdateFlow(library)
    val appCtx = LocalContext.current.applicationContext
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(500)
        // Forget state once the installed version has actually caught up.
        val pending = library.updatePendingTag.first()
        if (pending.isNotBlank() && !GitHubUpdater.isNewer(
                GitHubUpdater.stripTag(pending),
                GitHubUpdater.stripTag(BuildConfig.VERSION_NAME)
            )
        ) {
            library.clearUpdateState()
        }
        val upd = checkForAppUpdate()
        if (upd != null) {
            val apk = GitHubUpdater.destFile(appCtx)
            if (library.updateDownloadedTag.first() == upd.version && apk.exists()) {
                library.rememberUpdateDownloaded(upd.version)
                updateFlow.showReady(upd, apk)
            } else {
                val count = library.rememberUpdatePrompt(upd.version)
                updateFlow.showPrompt(upd, count)
            }
        } else {
            // Live check found nothing — but a download we started earlier may
            // still be waiting to be installed. Surface Install instead of
            // silently dropping the reminder.
            val downloaded = library.updateDownloadedTag.first()
            val apk = GitHubUpdater.destFile(appCtx)
            if (downloaded.isNotBlank() && apk.exists() &&
                GitHubUpdater.isNewer(downloaded, GitHubUpdater.stripTag(BuildConfig.VERSION_NAME))
            ) {
                updateFlow.showReady(
                    AppUpdateInfo(
                        version = downloaded,
                        displayTag = downloaded,
                        sizeLabel = "",
                        changelog = listOf("Update downloaded — tap Install to finish."),
                        apkUrl = ""
                    ),
                    apk
                )
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Background)) {
    PullToRefreshBox(
        isRefreshing = state.loading && state.hero != null,
        onRefresh = { viewModel.refresh() },
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        Crossfade(
            targetState = when {
                state.loading && state.hero == null -> HomeContentState.LOADING
                state.error != null && state.hero == null -> HomeContentState.ERROR
                else -> HomeContentState.CONTENT
            },
            animationSpec = tween(350),
            label = "home-content"
        ) { contentState ->
            when (contentState) {
                HomeContentState.LOADING -> HomeShimmer(Modifier.fillMaxSize().background(Background))
                HomeContentState.ERROR -> ErrorBox(state.error ?: "") { viewModel.refresh() }
                HomeContentState.CONTENT -> LazyColumn(Modifier.fillMaxSize()) {
                    // Anivave auto-rotating hero slider
                    item {
                        AnivaveHeroSlider(
                            items = state.trending,
                            onPlay = onPlay,
                            onDetails = onAnimeClick,
                            myListIds = myListIds,
                            onWatchlist = { anime ->
                                scope.launch { library.toggleMyList(anime.id) }
                            }
                        )
                        Spacer(Modifier.height(18.dp))
                    }

                    if (state.continueWatching.isNotEmpty()) {
                        item { SectionHeader("Continue Watching", onSeeAll = { onViewAll(SeeAllKind.CONTINUE) }) }
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(state.continueWatching, key = { it.anime.id }) { item ->
                                    ContinueCard(
                                        anime = item.anime,
                                        episode = item.episode,
                                        progress = item.progressFraction,
                                        onClick = { onContinue(item.anime, item.episode) },
                                        completedCount = item.completedCount,
                                        totalEpisodes = item.totalEpisodes
                                    )
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }

                    item { SectionHeader("Trending Now", onSeeAll = { onViewAll(SeeAllKind.TRENDING) }) }
                    item {
                        if (state.trending.isNotEmpty()) AnimeRow(state.trending, onAnimeClick)
                        else PosterRowShimmer()
                        Spacer(Modifier.height(8.dp))
                    }

                    item { SectionHeader("POPULAR THIS SEASON", onSeeAll = { onViewAll(SeeAllKind.SEASONAL) }) }
                    item {
                        if (state.seasonal.isNotEmpty()) AnimeRow(state.seasonal, onAnimeClick)
                        else PosterRowShimmer()
                        Spacer(Modifier.height(8.dp))
                    }

                    item { SectionHeader("ALL TIME POPULAR", onSeeAll = { onViewAll(SeeAllKind.TOP_RATED) }) }
                    item {
                        if (state.topRated.isNotEmpty()) AnimeRow(state.topRated, onAnimeClick)
                        else PosterRowShimmer()
                        Spacer(Modifier.height(8.dp))
                    }

                    // TOP 100 ANIME — ranked cards (number 1-100 on the card, name on the card)
                    item { SectionHeader("TOP 100 ANIME", onSeeAll = { onViewAll(SeeAllKind.TOP_100) }) }
                    item {
                        if (state.top100.isNotEmpty()) {
                            AnimeRankedRow(items = state.top100.take(20), onAnimeClick = onAnimeClick)
                        } else {
                            PosterRowShimmer()
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    // New Releases (bottom, top untouched) — anivave landscape tiles
                    item {
                        Column(Modifier.fillMaxWidth()) {
                            SectionHeader("Recently Updated", onSeeAll = { onViewAll(SeeAllKind.NEW_RELEASES) })
                            Spacer(Modifier.height(4.dp))
                            AnivaveNewReleasesGrid(state.newReleaseEpisodes, onItem = { onAnimeClick(it.anime) })
                            Spacer(Modifier.height(8.dp))
                        }
                    }

                    // Upcoming Anime — rotating random window from the full pool so
                    // every title gets a turn (reshuffles on a timer; See All still shows all).
                    item {
                        Column(Modifier.fillMaxWidth()) {
                            SectionHeader("Upcoming Anime", onSeeAll = { onViewAll(SeeAllKind.UPCOMING) })
                            Spacer(Modifier.height(4.dp))
                            if (state.upcoming.isEmpty()) {
                                Text("Nothing upcoming.", color = TextSecondary, fontFamily = PlexMono, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
                            } else {
                                AnivaveUpcomingRow(
                                    pool = state.upcoming,
                                    onItem = onAnimeClick
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                    }

                    // Weekly Schedule (bottom) — anivave timed card w/ calendar pills
                    item {
                        Column(Modifier.fillMaxWidth()) {
                            SectionHeader("Weekly Schedule", onSeeAll = onViewSchedule)
                            Spacer(Modifier.height(6.dp))
                            AnivaveScheduleCard(
                                activeDayIndex = state.scheduleDayIndex,
                                onDay = { viewModel.setScheduleDayIndex(it) },
                                shows = state.schedule,
                                days = state.scheduleDays,
                                maxRows = 4,
                                loading = state.scheduleLoading,
                                error = state.scheduleError,
                                onRetry = { viewModel.retrySchedule() },
                                onItem = { day ->
                                    if (day.animeId != 0) {
                                        onAnimeClick(
                                            Anime(
                                                id = day.animeId,
                                                title = day.title,
                                                posterUrl = day.cover
                                            )
                                        )
                                    }
                                },
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }
            }
        }
    }

    // ── Ad banner (Home) ───────────────────────────────────────────────────
    val ctx = LocalContext.current
    val adBanner = remember { com.panime.app.ad.AdManager.createBannerView(ctx) }
    if (adBanner != null) {
        androidx.compose.ui.viewinterop.AndroidView(
            factory = { adBanner },
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
        )
    }
    } // Box

    AppUpdateOverlay(updateFlow)
}

private enum class HomeContentState { LOADING, ERROR, CONTENT }
