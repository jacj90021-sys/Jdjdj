package com.panime.app.data.api

import android.util.Log
import com.panime.app.BuildConfig
import com.panime.app.util.Obf
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Shared aniwaves helpers used by the on-device direct scrapers.
 *
 * The legacy render.com backend client (aniwavesapi-2.onrender.com) was removed —
 * playback now runs entirely on-device through AniwavesScraper /
 * AniwavesDirectProvider. What remains here is the shared data type and pure
 * helpers those direct providers depend on.
 */
object AniwavesApi {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Normalize a title for reliable search matching.
     * - Lowercases
     * - Strips audio tags: (Sub), (Dub), (Uncensored), (Raw)
     * - Removes season/part markers: "Season 2", "Part 3", "2nd Season"
     * - Removes special characters except alphanumerics and spaces
     * - Trims trailing colons/dashes
     * - Collapses whitespace
     */
    fun cleanTitle(title: String): String {
        if (title.isBlank()) return ""
        return title
            .replace(Regex("""\(sub\)|\(dub\)|\(uncensored\)|\(raw\)""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\bseason\s*\d+(st|nd|rd|th)?\b""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\bpart\s*\d+\b""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\s+(ii|iii|iv|v)\s*$""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""[:\-–—]\s*$"""), "")
            .replace(Regex("[^a-zA-Z0-9\\s']"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .lowercase()
    }

    /**
     * Extract the requested season/part number from a title query.
     * "Season 2" -> 2, "II" -> 2, "Part 3" -> 3, "3rd Season" -> 3.
     * Returns 0 when no season is specified (base series).
     */
    fun extractSeason(title: String): Int {
        val t = title.lowercase()
        val num = Regex("""(season|part)\s*(\d+)""").find(t)?.groupValues?.get(2)
        if (num != null) return num.toIntOrNull() ?: 0
        val nth = Regex("""(\d+)(?:st|nd|rd|th)\s+(?:season|part)""").find(t)?.groupValues?.get(1)
        if (nth != null) return nth.toIntOrNull() ?: 0
        val rn = Regex("""\b(second|third|fourth|fifth|ii|iii|iv|v)\b""").find(t)?.groupValues?.get(1)
        if (rn != null) {
            return mapOf(
                "second" to 2, "ii" to 2,
                "third" to 3, "iii" to 3,
                "fourth" to 4, "iv" to 4,
                "fifth" to 5, "v" to 5
            )[rn] ?: 0
        }
        return 0
    }

    /** A resolved stream's (external) subtitle track. */
    data class SubtitleTrack(
        val lang: String,   // "eng"
        val label: String,  // "ENG"
        val url: String     // absolute subtitle url
    )

    /**
     * Probe whether the device can fetch a BYFMS raw CDN m3u8 directly (bypassing
     * any proxy). owphbf24 blocks datacenter IPs but should accept a residential
     * mobile IP. We do a cheap ranged GET with the exact headers the old proxy
     * sent, log the status code, and return true only on HTTP 200/206.
     *
     * On any non-200 (403/404/timeout) the caller falls back to the proxied url,
     * so playback never breaks — we just lose the bandwidth saving.
     */
    fun probeByfmsDirect(rawCdnUrl: String): Boolean {
        return try {
            val req = Request.Builder()
                .url(rawCdnUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                .header("Referer", Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoL3U="))
                .header("Origin", Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoLw=="))
                .header("Accept", "*/*")
                .header("Range", "bytes=0-1")
                .build()
            client.newCall(req).execute().use { resp ->
                if (BuildConfig.DEBUG) {
                    Log.i("AniwavesApi", "BYFMS direct probe -> HTTP ${resp.code} for $rawCdnUrl")
                }
                resp.code == 200 || resp.code == 206
            }
        } catch (e: Exception) {
            Log.w("AniwavesApi", "BYFMS direct probe failed: ${e.message}")
            false
        }
    }

    /**
     * Cheap ranged probe of a subtitle url BEFORE we attach it to a stream
     * (WAVE cross-host borrow). True only when the host actually returns
     * subtitle bytes (2xx, non-empty, not an HTML/JSON error page). On any
     * failure the SUB/HLS path drops the borrowed tracks and plays without
     * subtitles instead of letting a subtitle load error kill the stream.
     */
    fun probeSubtitleTrack(url: String, referer: String?): Boolean {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                .header("Referer", referer ?: Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoLw=="))
                .header("Accept", "*/*")
                .header("Range", "bytes=0-4095")
                .build()
            client.newCall(req).execute().use { resp ->
                val body = runCatching { resp.body?.string().orEmpty() }.getOrElse { "" }
                val ok = (resp.code == 200 || resp.code == 206) &&
                    body.isNotBlank() && !looksLikeHtmlError(body)
                if (BuildConfig.DEBUG) {
                    Log.i("AniwavesApi", "subtitle probe -> HTTP ${resp.code} len=${body.length} ok=$ok for $url")
                }
                ok
            }
        } catch (e: Exception) {
            Log.w("AniwavesApi", "subtitle probe failed: ${e.message}")
            false
        }
    }

    private fun looksLikeHtmlError(body: String): Boolean {
        val t = body.trimStart()
        val first = t.firstOrNull() ?: return true
        return first == '<' || first == '{' ||
            t.startsWith("<!doctype", ignoreCase = true)
    }
}
