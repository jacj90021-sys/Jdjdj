package com.panime.app.data.auth

import android.util.Base64
import android.util.Log
import com.panime.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import com.panime.app.data.network.HttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.security.SecureRandom

/**
 * Production OAuth for AniList + MyAnimeList.
 *
 * Public-client flows — no client_secret.
 *  - AniList: implicit flow (response_type=token). Token comes back in the URL fragment
 *    (panime://oauth/callback#access_token=...) and is parsed in AniwaveAuthActivity.
 *    No token exchange.
 *  - MyAnimeList: auth-code + PKCE plain. Exchange code server-side for access + refresh tokens.
 *
 * Client IDs are hardcoded below, same as Dantotsu. End users do NOT need to set up
 * local.properties or GitHub Actions secrets. Just tap Connect.
 */

// ---- Hardcoded public client IDs (register once, use everywhere) ----
// Dantotsu-style: client IDs live in the app so end users never configure anything.
const val ANILIST_CLIENT_ID = "49536" // user-owned client "panime", redirect panime://oauth/callback
const val MAL_CLIENT_ID = "03d5cf4eec5e29e3c6ecb1ce8f5e31c5" // MAL public app (no secret) — PKCE plain

fun isConfigured(service: String): Boolean = when (service) {
    "anilist" -> ANILIST_CLIENT_ID.isNotBlank()
    "mal" -> MAL_CLIENT_ID.isNotBlank()
    else -> false
}

fun authUrl(service: String, state: String, challenge: String): String {
    require(isConfigured(service)) { "OAuth not configured for $service" }
    return when (service) {
        // Dantotsu-style: NO redirect_uri param. AniList redirects to the
        // client's REGISTERED redirect URL (panime://oauth/callback for our
        // client) — passing it explicitly is what triggered AniList's token
        // endpoint quirks with custom schemes.
        "anilist" -> "https://anilist.co/api/v2/oauth/authorize" +
            "?client_id=$ANILIST_CLIENT_ID" +
            "&response_type=token"

        // MAL public (confidential=false) app: auth-code + PKCE plain. The verifier is
        // sent back at token exchange; MAL has NO client_secret (it can't be safely
        // shipped in an Android app anyway). challenge == verifier for method=plain.
        "mal" -> "https://myanimelist.net/v1/oauth2/authorize" +
            "?response_type=code" +
            "&client_id=$MAL_CLIENT_ID" +
            "&redirect_uri=panime://oauth/callback" +
            "&code_challenge=$challenge" +
            "&code_challenge_method=plain" +
            "&state=$state"

        else -> throw IllegalArgumentException("Unknown service: $service")
    }.also { if (BuildConfig.DEBUG) { Log.d("OAuth", "[$service] authUrl: $it") } }
}

object OAuthPkce {
    fun randomState(): String = randomUrlSafe(16)
    fun randomVerifier(): String = randomUrlSafe(64)
    fun challenge(verifier: String): String = verifier // plain = verifier itself

    private fun randomUrlSafe(n: Int): String {
        val bytes = ByteArray(n)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    }
}

private val client = HttpClient.shared

/**
 * Exchange authorization code for tokens. Used for MAL.
 * AniList tokens are parsed from the redirect fragment in AniwaveAuthActivity.
 */
suspend fun exchangeCodeForToken(service: String, code: String, verifier: String): TokenPair =
    withContext(Dispatchers.IO) {
        require(service == "mal") { "exchangeCodeForToken is only wired for MAL currently" }
        val body = FormBody.Builder()
            .add("grant_type", "authorization_code")
            .add("client_id", MAL_CLIENT_ID)
            .add("code", code)
            .add("code_verifier", verifier)
            .add("redirect_uri", "panime://oauth/callback")
            .build()
        val req = Request.Builder()
            .url("https://myanimelist.net/v1/oauth2/token")
            .post(body)
            .header("Accept", "application/json")
            .build()
        if (BuildConfig.DEBUG) Log.d("OAuth", "[mal] token exchange POST")
        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                Log.e("OAuth", "[mal] token HTTP ${resp.code}: $text")
                throw IllegalStateException("MAL token HTTP ${resp.code}: ${text.take(400)}")
            }
            val json = JSONObject(text)
            TokenPair(
                accessToken = json.getString("access_token"),
                refreshToken = json.optString("refresh_token").ifBlank { null },
                expiresInSeconds = json.optLong("expires_in").takeIf { it > 0 }
            )
        }
    }

/** Refresh an expired token. Returns null if refresh fails / unavailable. */
suspend fun refreshAccessToken(service: String, refreshToken: String): TokenPair? =
    withContext(Dispatchers.IO) {
        try {
            // AniList's implicit flow has NO refresh grant — access tokens last
            // ~1 year, then the user re-authorizes. Its token endpoint rejects
            // grant_type=refresh_token with "unsupported_grant_type".
            if (service == "anilist") return@withContext null
            val body = FormBody.Builder()
                .add("grant_type", "refresh_token")
                .add("client_id", if (service == "mal") MAL_CLIENT_ID else ANILIST_CLIENT_ID)
                .add("refresh_token", refreshToken)
                .build()
            val url = if (service == "mal")
                "https://myanimelist.net/v1/oauth2/token"
            else
                "https://anilist.co/api/v2/oauth/token"
            val req = Request.Builder().url(url).post(body)
                .header("Accept", "application/json")
                .build()
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    Log.e("OAuth", "[$service] refresh HTTP ${resp.code}: $text")
                    return@withContext null
                }
                val json = JSONObject(text)
                TokenPair(
                    accessToken = json.getString("access_token"),
                    refreshToken = json.optString("refresh_token").ifBlank { refreshToken },
                    expiresInSeconds = json.optLong("expires_in").takeIf { it > 0 }
                )
            }
        } catch (e: Throwable) {
            Log.e("OAuth", "[$service] refresh failed: ${e.message}")
            null
        }
    }

/** Resolve the real account name from a provider token. */
suspend fun fetchAccountName(service: String, accessToken: String): String =
    withContext(Dispatchers.IO) {
        when (service) {
            "anilist" -> {
                val query = "query { Viewer { name id } }"
                val body = "{\"query\":${JSONObject.quote(query)}}"
                val req = Request.Builder()
                    .url("https://graphql.anilist.co")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .header("Authorization", "Bearer $accessToken")
                    .header("Accept", "application/json")
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36")
                    .header("Origin", "https://anilist.co")
                    .header("Referer", "https://anilist.co/")
                    .build()
                client.newCall(req).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) throw IllegalStateException(
                        "AniList viewer HTTP ${resp.code}: ${text.take(400)}"
                    )
                    JSONObject(text).getJSONObject("data").getJSONObject("Viewer").getString("name")
                }
            }
            "mal" -> {
                val req = Request.Builder()
                    .url("https://api.myanimelist.net/v2/users/@me")
                    .get()
                    .header("Authorization", "Bearer $accessToken")
                    .header("Accept", "application/json")
                    .build()
                client.newCall(req).execute().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) throw IllegalStateException(
                        "MAL me HTTP ${resp.code}: ${text.take(400)}"
                    )
                    JSONObject(text).getString("name")
                }
            }
            else -> throw IllegalArgumentException("Unknown service: $service")
        }
    }

data class TokenPair(
    val accessToken: String,
    val refreshToken: String?,
    val expiresInSeconds: Long?
)
