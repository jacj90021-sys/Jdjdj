package com.panime.app.ad

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.View
import com.panime.app.BuildConfig
import com.panime.app.data.provider.RemoteAdConfig
import com.panime.app.data.provider.RemoteProviderConfig

/**
 * Central ad manager — init once at app startup, then call [showInterstitial],
 * [showRewarded], or add [createBannerView] to the view tree.
 *
 * Two-level control:
 *
 *  1. [BuildConfig.ADS_ENABLED] — compile-time safety gate. `false` → zero ad
 *     code runs, the SDK is never initialized. This is a build-level switch,
 *     NOT the production control.
 *
 *  2. Remote config — production runtime control. [applyRemoteConfig] is called
 *     once the remote provider_config.json has been fetched (see
 *     ProviderInitializer). Its `ads` section decides:
 *
 *        ads.enabled == false            → no ads at all
 *        ads.enabled == true             → per-format flags apply:
 *              bannerEnabled / interstitialEnabled / rewardedEnabled
 *
 *  Fallback: if the remote config is missing the `ads` section, is malformed,
 *  can't be downloaded, or the app is offline, [adConfig] stays at
 *  [RemoteAdConfig.DEFAULT] (`enabled = false`) → ads are OFF. A temporary
 *  network failure can never accidentally turn ads on; the safe deterministic
 *  default is no ads.
 *
 * The ad SDK is swappable: [AdMobNetwork] (default) or [UnityAdsNetwork]
 * (built with `-PadsNetwork=unity`). All policy here (remote config, cooldowns)
 * is network-agnostic; the actual SDK work is delegated.
 */
object AdManager {
    private const val TAG = "AdManager"

    /**
     * The compiled-in ad SDK. Selected by the Gradle flag `-PadsNetwork`
     * (`admob` default, or `unity`). Each APK ships exactly one implementation
     * (see the NetworkModule in the corresponding source set), so the unused
     * SDK is never bundled.
     */
    private val network: AdNetwork = provideAdNetwork()

    /** True after [init] has been called. */
    @Volatile private var initialized = false

    /** Last interstitial show timestamp (rate-limit: 1 per [AD_COOLDOWN_MS]). */
    @Volatile private var lastInterstitialShown = 0L

    /** Last rewarded show timestamp (rate-limit: 1 per [AD_COOLDOWN_MS]). */
    @Volatile private var lastRewardedShown = 0L

    /** 1 ad per 2 hours across interstitial + rewarded. */
    private const val AD_COOLDOWN_MS = 2 * 60 * 60 * 1000L

    /**
     * Effective remote ad settings. Defaults to [RemoteAdConfig.DEFAULT]
     * (`enabled = false`) so the app NEVER shows ads until the remote config
     * explicitly enables them.
     */
    @Volatile private var adConfig: RemoteAdConfig = RemoteAdConfig.DEFAULT

    // ── Remote control ──────────────────────────────────────────────────────

    /**
     * Push the fetched remote config's `ads` section into the manager.
     * Called by ProviderInitializer after a (successful or fallback) load.
     * A missing `ads` section (`null`) = ads OFF — same safe fallback.
     */
    fun applyRemoteConfig(cfg: RemoteProviderConfig) {
        adConfig = cfg.ads ?: RemoteAdConfig.DEFAULT
        Log.d(
            TAG,
            "Remote ad config: enabled=${adConfig.enabled} banner=${adConfig.bannerEnabled} " +
                "interstitial=${adConfig.interstitialEnabled} rewarded=${adConfig.rewardedEnabled} " +
                "network=${network.tag}"
        )
    }

    // ── Gates ───────────────────────────────────────────────────────────────

    /** Master runtime gate: active network AND compile-time flag AND remote master switch. */
    private fun adsEnabled(context: Context): Boolean =
        network.isSupported(context) && BuildConfig.ADS_ENABLED && adConfig.enabled

    private fun bannerEnabled(context: Context): Boolean = adsEnabled(context) && adConfig.bannerEnabled

    private fun interstitialEnabled(context: Context): Boolean = adsEnabled(context) && adConfig.interstitialEnabled

    private fun rewardedEnabled(context: Context): Boolean = adsEnabled(context) && adConfig.rewardedEnabled

    // ── Public API ──────────────────────────────────────────────────────────

    /** Call once from Application.onCreate(). No-op when ads are disabled. */
    fun init(context: Context) {
        if (initialized) return
        initialized = true

        if (!adsEnabled(context)) {
            Log.d(TAG, "${network.tag} not available/disabled — ads off")
            return
        }
        network.initialize(context)
    }

    /**
     * Show a full-screen interstitial. Returns true if shown.
     *
     * Contract: [onDismissed] fires ONLY after an ad was actually shown and
     * dismissed. When the ad is skipped (disabled, rate-limited, not ready)
     * this returns false and NO callback fires — the caller handles the
     * fallback (e.g. popBackStack) itself.
     */
    fun showInterstitial(activity: Activity, onDismissed: (() -> Unit)? = null): Boolean {
        if (!interstitialEnabled(activity.applicationContext)) return false

        // Rate-limit: 1 per 2 hours
        val now = System.currentTimeMillis()
        if (now - lastInterstitialShown < AD_COOLDOWN_MS) {
            Log.d(TAG, "Interstitial rate-limited, skipping")
            return false
        }

        if (!network.showInterstitial(activity) {
                lastInterstitialShown = System.currentTimeMillis()
                onDismissed?.invoke()
            }
        ) {
            Log.d(TAG, "Interstitial not ready, skipping")
            return false
        }
        return true
    }

    /**
     * Show a rewarded ad. [onReward] fires ONLY when the user earns the reward.
     *
     * Contract: when the ad is skipped (disabled, rate-limited, not ready) this
     * returns false and neither [onReward] nor [onDismissed] fires — the caller
     * proceeds with its fallback (e.g. starting the download directly).
     */
    fun showRewarded(
        activity: Activity,
        onReward: () -> Unit,
        onDismissed: (() -> Unit)? = null
    ): Boolean {
        if (!rewardedEnabled(activity.applicationContext)) return false

        // Rate-limit: 1 per 2 hours (same budget as the interstitial)
        val now = System.currentTimeMillis()
        if (now - lastRewardedShown < AD_COOLDOWN_MS) {
            Log.d(TAG, "Rewarded rate-limited, skipping")
            return false
        }

        if (!network.showRewarded(activity, onReward) {
                lastRewardedShown = System.currentTimeMillis()
                onDismissed?.invoke()
            }
        ) {
            Log.d(TAG, "Rewarded not ready, skipping")
            return false
        }
        return true
    }

    /**
     * Creates a ready-to-use banner view for embedding in Compose via AndroidView.
     * Returns null if ads are disabled (compile-time OR remote) or the active
     * network can't render banners.
     */
    fun createBannerView(context: Context): View? {
        if (!bannerEnabled(context)) return null
        return network.createBanner(context)
    }
}