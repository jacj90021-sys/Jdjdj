package com.panime.app.ui.theme

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * AnimeX halftone texture — radial ink dots fading from the top-right corner.
 * Matches `.halftone` in animex_prototype.html (9px grid, ~13% opacity, corner mask).
 */
@Composable
fun HalftoneTexture(
    modifier: Modifier = Modifier,
    size: Dp = 260.dp,
    opacity: Float = 0.13f,
    spacingPx: Float = 9f,
    dotRadiusPx: Float = 1.4f
) {
    val ink = Ink
    Canvas(modifier = modifier.size(size)) {
        val cols = (this.size.width / spacingPx).toInt() + 2
        val rows = (this.size.height / spacingPx).toInt() + 2
        val origin = Offset(this.size.width, 0f)
        val maxDist = this.size.minDimension * 0.95f
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val x = c * spacingPx
                val y = r * spacingPx
                val dist = (Offset(x, y) - origin).getDistance()
                val t = (1f - (dist / maxDist).coerceIn(0f, 1f))
                if (t <= 0.02f) continue
                drawCircle(
                    color = ink.copy(alpha = opacity * t),
                    radius = dotRadiusPx,
                    center = Offset(x, y)
                )
            }
        }
    }
}

/**
 * Full-screen paper canvas with a top-right halftone wash behind [content].
 * Use on chrome screens (home, browse, search, list, profile) — not the player.
 */
@Composable
fun PaperScreen(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier
            .fillMaxSize()
            .background(Background)
    ) {
        HalftoneTexture(
            modifier = Modifier.align(Alignment.TopEnd),
            size = 260.dp,
            // Softer wash on dark so the corner texture doesn't dominate.
            opacity = if (AniwaveColors.isDark) 0.08f else 0.13f
        )
        content()
    }
}
