package com.panime.app

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.panime.app.ui.navigation.AniwaveNavHost
import com.panime.app.ui.theme.AniwaveTheme
import com.panime.app.ui.theme.Background

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as AniwaveApp
        val lastCrash = CrashReporter.popLastCrash(this)
        setContent {
            val darkTheme by app.library.darkTheme.collectAsStateWithLifecycle(false)
            AniwaveTheme(darkTheme = darkTheme) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Background
                ) {
                    AniwaveNavHost(
                        repository = app.repository,
                        library = app.library
                    )

                    var showCrash by remember { mutableStateOf(lastCrash != null) }
                    if (showCrash && lastCrash != null) {
                        LastCrashDialog(report = lastCrash, onDismiss = { showCrash = false })
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun LastCrashDialog(report: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("The app crashed last time") },
        text = {
            Text(
                text = report.take(4000),
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.verticalScroll(rememberScrollState())
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val cm = context.getSystemService(ClipboardManager::class.java)
                cm?.setPrimaryClip(ClipData.newPlainText("crash", report))
                Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
            }) { Text("COPY") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("CLOSE") }
        },
        modifier = Modifier.padding(8.dp)
    )
}
