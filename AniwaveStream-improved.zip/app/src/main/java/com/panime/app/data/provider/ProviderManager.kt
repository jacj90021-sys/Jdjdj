package com.panime.app.data.provider

import android.util.Log
import com.panime.app.BuildConfig
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Central registry + resolution orchestrator.
 *
 * - Holds all registered [StreamProvider]s (on-device + the AniWaves backend).
 * - Applies remote config: enabled flags (kill-switch), priority, per-provider timeout.
 * - Resolves by priority, falling through to the next eligible provider on failure.
 * - Tracks lightweight health so a degraded/broken provider is deprioritized
 *   instead of being hammered on every play.
 * - Reuses the player's existing retry semantics conceptually: transient failures
 *   (502/503/timeout) are retried with backoff; then fallback to next provider.
 */
object ProviderManager {

    private const val TAG = "ProviderManager"

    private val providers = ConcurrentHashMap<String, StreamProvider>()
    private val cfg = ConcurrentHashMap<String, ProviderCfg>()
    private val health = ConcurrentHashMap<String, HealthState>()
    private val mutex = Mutex()

    private var remoteConfig: RemoteProviderConfig = RemoteProviderConfig.DEFAULT
    private val lastConfigFetch = AtomicLong(0L)

    /** Last provider error message — displayed on screen so users don't need logcat. */
    @Volatile var lastError: String = ""; private set

    data class HealthState(
        var healthy: Boolean = true,
        var lastChecked: Long = 0L,
        var failures: Int = 0
    )

    fun register(provider: StreamProvider) {
        providers[provider.id] = provider
        if (!cfg.containsKey(provider.id)) {
            cfg[provider.id] = ProviderCfg(
                id = provider.id,
                enabled = true,
                priority = if (provider.backendRequired) 10 else 50,
                backendRequired = provider.backendRequired
            )
        }
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "registered provider: ${provider.id} (backend=${provider.backendRequired})")
        }
    }

    /** Apply a (validated) remote config. Safe to call with the bundled default. */
    fun applyConfig(config: RemoteProviderConfig) {
        remoteConfig = RemoteConfigParser.safeMerge(config)
        for (pc in remoteConfig.providers) {
            // Preserve provider existence; only override declarative fields.
            if (providers.containsKey(pc.id)) cfg[pc.id] = pc
        }
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "config applied: ${remoteConfig.providers.size} providers, version=${remoteConfig.version}")
        }
    }

    fun getConfig(): RemoteProviderConfig = remoteConfig

    fun isEnabled(id: String): Boolean = cfg[id]?.enabled != false
    fun priorityOf(id: String): Int = cfg[id]?.priority ?: 50
    fun timeoutSecOf(id: String): Long = (cfg[id]?.timeoutSec ?: 60).toLong()

    /** Short display name for a source id — the chip/error label, e.g. "WAVE". */
    fun shortName(id: String): String = when (id) {
        "aniwaves" -> "WAVE"
        "anikoto" -> "KOTO"
        "anidap" -> "DAP"
        "animenosub" -> "NOSUB"
        "anizone" -> "ZONE"
        "just4anime" -> "JUST"
        "anidb" -> "DB"
        "anikage" -> "KAGE"
        "moviebox" -> "MOVIE"
        else -> id
    }
    fun isBackendRequired(id: String): Boolean = cfg[id]?.backendRequired ?: false

    /** Kill-switch: instantly disable a provider without an APK update. */
    fun setEnabled(id: String, enabled: Boolean) {
        val existing = cfg[id] ?: ProviderCfg(id)
        cfg[id] = existing.copy(enabled = enabled)
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "provider $id enabled=$enabled")
        }
    }

    private fun eligible(): List<StreamProvider> =
        providers.values
            .filter { isEnabled(it.id) }
            .sortedByDescending { priorityOf(it.id) }

    fun listProviders(): List<Pair<String, String>> =
        eligible().map { it.id to it.label }

    /** Providers supporting user-facing search — the wrong-title picker chips. */
    fun listSearchableProviders(): List<Pair<String, String>> =
        eligible().filter { it is SearchableProvider }.map { it.id to it.label }

    /** Search a specific provider. Returns empty list if provider not found/disabled. */
    suspend fun search(sourceId: String, query: String): List<StreamProvider.SearchHit> {
        val p = providers[sourceId] ?: return emptyList()
        if (!isEnabled(sourceId)) return emptyList()
        return try {
            withTimeout(timeoutSecOf(sourceId) * 1000L) {
                p.search(query)
            }
        } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
            Log.w(TAG, "search on ${sourceId} timed out")
            emptyList()
        } catch (e: kotlinx.coroutines.CancellationException) {
            // Job/composition cancellation must propagate — swallowing it here
            // corrupts structured concurrency and reports nonsense errors.
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "search on ${sourceId} failed: ${e.message}")
            emptyList()
        }
    }

    /**
     * One page of results from a specific provider (+ its last-page number).
     * Returns an empty single page if provider not found/disabled/failed.
     */
    suspend fun searchPage(
        sourceId: String,
        query: String,
        page: Int
    ): com.panime.app.data.model.PagedResult<StreamProvider.SearchHit> {
        val p = providers[sourceId] ?: return com.panime.app.data.model.PagedResult(emptyList(), 1)
        if (!isEnabled(sourceId)) return com.panime.app.data.model.PagedResult(emptyList(), 1)
        return try {
            withTimeout(timeoutSecOf(sourceId) * 1000L) {
                p.searchPage(query, page)
            }
        } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
            Log.w(TAG, "searchPage on ${sourceId} timed out")
            com.panime.app.data.model.PagedResult(emptyList(), 1)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "searchPage on ${sourceId} failed: ${e.message}")
            com.panime.app.data.model.PagedResult(emptyList(), 1)
        }
    }

    fun healthOf(id: String): HealthState =
        health.getOrPut(id) { HealthState() }

    /** Mark a provider degraded so future auto-selects skip it sooner. */
    private fun recordFailure(id: String) {
        val h = healthOf(id)
        h.failures++
        h.healthy = h.failures < 3
        h.lastChecked = System.currentTimeMillis()
    }

    private fun recordSuccess(id: String) {
        val h = healthOf(id)
        h.failures = 0
        h.healthy = true
        h.lastChecked = System.currentTimeMillis()
    }

    /**
     * Resolve an episode, trying providers in priority order with fallback.
     * Returns the first non-null [ResolveResult], or null if all failed.
     */
    suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String? = null,
        preferredSource: String? = null,
        seasonNumber: Int = 1,
        totalEpisodes: Int = 0,
        year: Int? = null
    ): ResolveResult? {
        // If the user explicitly picked a source, try it first (if enabled).
        val ordered = if (preferredSource != null && isEnabled(preferredSource)) {
            listOfNotNull(providers[preferredSource]) + eligible().filter { it.id != preferredSource }
        } else {
            eligible()
        }
        for (p in ordered) {
            val result = try {
                withTimeout(timeoutSecOf(p.id) * 1000L) {
                    p.resolve(title, anilistId, episode, type, serverCode, seasonNumber, totalEpisodes, year)
                }
            } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                Log.w(TAG, "provider ${p.id} timed out")
                recordFailure(p.id)
                null
            } catch (e: kotlinx.coroutines.CancellationException) {
                // Never convert cancellation into "provider failed" — the caller
                // (compose effect / scope) is being torn down on purpose.
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "provider ${p.id} threw: ${e.message}")
                recordFailure(p.id)
                null
            }
            if (result != null && !result.url.isNullOrBlank()) {
                recordSuccess(p.id)
                return result
            }
            if (result != null) recordFailure(p.id)
        }
        return null
    }

    /**
     * Resolve a specific server/quality selection on a specific provider.
     *
     * Error-text contract: [lastError] ALWAYS reflects the most recent attempt
     * on this source — stale text from an earlier cancelled/failed attempt must
     * never survive into a later failure message (this used to surface compose
     * LeftCompositionCancellationException as a playback error).
     */
    suspend fun resolveOn(
        sourceId: String,
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int = 1,
        slugHint: String? = null,
        totalEpisodes: Int = 0,
        year: Int? = null
    ): ResolveResult? {
        val p = providers[sourceId] ?: return null
        if (!isEnabled(sourceId)) return null

        suspend fun run(block: suspend () -> ResolveResult?): ResolveResult? =
            try {
                withTimeout(timeoutSecOf(sourceId) * 1000L) { block() }
            } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                lastError = "${shortName(sourceId)}: timeout after ${timeoutSecOf(sourceId)}s"
                null
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = "${shortName(sourceId)}: ${e.javaClass.simpleName}: ${e.message}"
                null
            }

        val r = if (!slugHint.isNullOrBlank()) {
            run { p.resolveWithSlug(slugHint, episode, type, serverCode, seasonNumber) }
        } else {
            run { p.resolve(title, anilistId, episode, type, serverCode, seasonNumber, totalEpisodes, year) }
        }
        return if (r != null && !r.url.isNullOrBlank()) {
            lastError = ""
            r
        } else {
            // Overwrite unconditionally: only this attempt's outcome belongs here.
            if (lastError.isEmpty() || lastError.startsWith("${shortName(sourceId)}: resolve returned")) {
                lastError = "${shortName(sourceId)}: no stream for ep $episode"
            }
            null
        }
    }
}
