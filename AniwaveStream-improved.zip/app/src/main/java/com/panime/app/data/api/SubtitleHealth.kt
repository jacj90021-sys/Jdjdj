package com.panime.app.data.api

/**
 * Decides which subtitle urls may be glued onto a playing stream.
 *
 * The decision exists because of the WAVE subtitle-borrow (see
 * [com.panime.app.data.provider.aniwaves.AniwavesDirectProvider]): SUB rows
 * include MyCloud (whose getSources carries .srt tracks), DUB rows don't. When
 * the default SUB server (Vidplay) returned no tracks, the resolver borrowed
 * MyCloud's tracks and attached them to the playing stream via a Media3
 * MergingMediaSource. If the phone could not reach the subtitle edge
 * (hlsxsb4.echovideo.to) those load errors were FATAL in older Media3 and the
 * whole stream died — every SUB server "wouldn't play", while the DUB fallback
 * (which never borrows subs) always played.
 *
 * Rule here: native tracks (served from the same host as the video) are
 * trusted as-is. Borrowed tracks (cross-host) are attached ONLY if the first
 * one survives a live health probe — the same fetch ExoPlayer would otherwise
 * perform. When the subtitle host is unreachable we attach NONE, so the stream
 * degrades to exactly the same no-subtitle play path the DUB fallback uses:
 * subtitles are lost, playback is preserved.
 */
object SubtitleHealth {

    /**
     * @return the ordered list of subtitle urls safe to attach. Native tracks
     *   win (all of them); otherwise borrowed tracks iff [healthy] accepts the
     *   first one; otherwise empty (plain no-subtitle playback).
     */
    fun urlsToAttach(
        native: List<String>,
        borrowed: List<String>,
        healthy: (String) -> Boolean
    ): List<String> = when {
        native.isNotEmpty() -> native
        borrowed.isNotEmpty() && healthy(borrowed.first()) -> borrowed
        else -> emptyList()
    }
}