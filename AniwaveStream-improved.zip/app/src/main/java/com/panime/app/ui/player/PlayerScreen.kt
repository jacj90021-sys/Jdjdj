package com.panime.app.ui.player

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.outlined.ClosedCaption
import androidx.compose.material.icons.outlined.HighQuality
import androidx.compose.material.icons.outlined.ViewAgenda
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.PlaybackException
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.panime.app.BuildConfig
import com.panime.app.R
import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.data.repository.UserLibraryStore
import com.panime.app.player.PlayerModule
import com.panime.app.data.provider.ProviderManager
import com.panime.app.player.PlayerViewModel
import com.panime.app.player.clearVideoOverrides
import com.panime.app.player.disableSubtitles
import com.panime.app.player.enableSubtitles
import com.panime.app.player.selectTrack
import com.panime.app.player.toTrackSelectionUiState
import com.panime.app.ui.theme.Flame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import com.panime.app.data.provider.moviebox.MovieboxProvider
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * Strip internal coroutine-cancellation noise from provider error text before
 * it reaches the UI. Compose tears down the resolve effect's coroutine scope
 * whenever the screen leaves composition (or an effect restarts), and a
 * swallowed cancellation used to surface as a pseudo error
 * ("LeftCompositionCancellationException: The coroutine scope left the
 * composition"). Cancellation is never a real stream failure — show nothing.
 */
private fun sanitizeErrorText(msg: String?): String? {
    if (msg.isNullOrBlank()) return null
    if ("CancellationException" in msg || "left the composition" in msg) return null
    return msg
}

/**
 * Mutable watch-time accumulator shared by the periodic tracker, episode
 * restarts and screen exit, so no played seconds are ever lost. Lives on the
 * composition's main thread alongside the tracker coroutine.
 */
private class WatchSessionAccumulator {
    var animeId = 0
    var episode = 0
    var pendingPlayedMs = 0L
    var lastObservedPosition = 0L
    var lastSessionSaveAt = 0L
    var lastFrac = 0f
    var completionRecorded = false
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun PlayerScreen(
    animeId: Int,
    episode: Int,
    repository: AnimeRepository,
    library: UserLibraryStore,
    onBack: () -> Unit,
    onEpisodeChange: (Int) -> Unit,
    offlineUri: String? = null,
    offlineTitle: String? = null,
    downloadId: String? = null
) {
    val context = LocalContext.current
    // Local playback = SAF legacy file OR internal Media3 download.
    val isLocal = offlineUri != null || downloadId != null
    var downloadMeta by remember(downloadId) {
        mutableStateOf<com.panime.app.download.EpisodeDownloadMeta?>(null)
    }
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val audioManager = remember {
        context.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager
    }

    val vm: PlayerViewModel = viewModel()
    val exoPlayer = vm.player
    val playbackError by vm.error.collectAsStateWithLifecycle()
    val currentTracks by vm.tracks.collectAsStateWithLifecycle()

    var title by remember { mutableStateOf("") }
    var seasonNumber by remember { mutableStateOf(1) }
    var totalEps by remember { mutableIntStateOf(12) }
    var animeYear by remember { mutableStateOf<Int?>(null) }
    var orientationForced by rememberSaveable { mutableStateOf(true) }
    var forceLandscape by rememberSaveable { mutableStateOf(true) }
    var locked by rememberSaveable { mutableStateOf(false) }
    var currentType by remember { mutableStateOf("sub") }

    var streamUrl by remember(animeId, episode) { mutableStateOf<String?>(null) }
    var subtitleTracks by remember(animeId, episode) { mutableStateOf<List<AniwavesApi.SubtitleTrack>>(emptyList()) }
    var byfmsRawUrl by remember(animeId, episode) { mutableStateOf<String?>(null) }
    var anikageReferer by remember(animeId, episode) { mutableStateOf<String?>(null) }
    var streamFormat by remember(animeId, episode) { mutableStateOf("hls") }
    var isByfmsServer by remember(animeId, episode) { mutableStateOf(false) }
    var resolveError by remember(animeId, episode) { mutableStateOf(false) }
    var errorDetail by remember(animeId, episode) { mutableStateOf<String?>(null) }
    var loadKey by remember { mutableIntStateOf(0) }
    var reloadKey by remember { mutableIntStateOf(0) }
    var staleRetries by remember(animeId, episode) { mutableIntStateOf(0) }
    var resolveRetries by remember(animeId, episode) { mutableIntStateOf(0) }
    var isBuffering by remember { mutableStateOf(true) }
    var resolveGeneration by remember { mutableIntStateOf(0) }
    var decryptKey by remember(animeId, episode) { mutableStateOf<ByteArray?>(null) }
    var decryptIv by remember(animeId, episode) { mutableStateOf<ByteArray?>(null) }

    var controlsVisible by remember { mutableStateOf(true) }
    var lastInteraction by remember { mutableLongStateOf(System.currentTimeMillis()) }
    // Starts false (nothing is playing before the stream loads); the 250ms poll
    // keeps it in sync with the player. Avoids showing the Pause icon while the
    // first stream is still buffering.
    var isPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var bufferedMs by remember { mutableLongStateOf(0L) }
    var introMs by remember { mutableStateOf<Pair<Long, Long>?>(null) }
    var outroMs by remember { mutableStateOf<Pair<Long, Long>?>(null) }
    var hadPlayed by remember { mutableStateOf(false) }
    var resumeAtMs by remember { mutableLongStateOf(0L) }
    var resumeReady by remember { mutableStateOf(false) }

    var showMoreMenu by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showTrackSheet by remember { mutableStateOf(false) }
    var showAudioSheet by remember { mutableStateOf(false) }
    var showQualitySheet by remember { mutableStateOf(false) }
    var showEpisodeSheet by remember { mutableStateOf(false) }
    var showSpeedSheet by remember { mutableStateOf(false) }
    var showServerSheet by remember { mutableStateOf(false) }
    var resizeMode by rememberSaveable { mutableIntStateOf(0) }

    var lockIconVisible by remember { mutableStateOf(false) }
    var lastLockInteraction by remember { mutableLongStateOf(0L) }

    val speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
    var speed by remember { mutableFloatStateOf(1f) }

    var serverOptions by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var serverQualities by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var selectedServerId by remember(animeId, episode) { mutableStateOf<String?>(null) }
    // Manual server/source pick disables the auto-fallback permanently for this
    // episode: once the user chooses a server themselves, a failed stream shows
    // the error instead of silently switching to another server. Auto-switch
    // only ever fires for the automatic first-pick (user just pressed play).
    var manualServerPick by remember(animeId, episode) { mutableStateOf(false) }
    var rememberedServerId by remember(animeId) { mutableStateOf<String?>(null) }
    var selectedServerName by remember(animeId, episode) { mutableStateOf<String?>(null) }
    var castHint by remember { mutableStateOf(false) }

    var sourceMode by remember(animeId) { mutableStateOf("aniwaves") }
    var anidbId by remember(animeId) { mutableStateOf<String?>(null) }
    var serversLoading by remember { mutableStateOf(false) }

    var kotoLocked by remember(animeId) { mutableStateOf(false) }
    var kotoSlug by remember(animeId) { mutableStateOf<String?>(null) }
    // Audio language the user explicitly picked in the audio menu (e.g. "eng"),
    // persisted in DataStore so it survives episode navigation (the player screen is
    // recreated per episode). Without this, the audio TrackSelectionOverride from the
    // menu is pinned to the current episode's track groups and the next episode falls
    // back to the stream's default (usually Japanese).
    var preferredAudioLang by remember(animeId) { mutableStateOf<String?>(null) }
    var lockedApiProvider by remember(animeId) { mutableStateOf("anilist") }
    // Wrong-title override (user explicitly picked a different show) — wins over
    // the catalog slug whenever playback runs on the source it was picked for.
    var wtSlug by remember(animeId) { mutableStateOf<String?>(null) }
    var wtSource by remember(animeId) { mutableStateOf<String?>(null) }
    // Moviebox DEFAULT mode (no wrong-title pick): resolveHybrid stores the
    // matched entry's "subjectId|detailPath" in ResolvePack.slug — surfaced
    // here as mbDefaultSlug so the Audio sheet can show language variants.
    var mbDefaultSlug by remember(animeId) { mutableStateOf<String?>(null) }

    val autoplay by library.autoplay.collectAsStateWithLifecycle(true)
    var hasAutoAdvanced by remember(animeId, episode) { mutableStateOf(false) }

    var seekFlash by remember { mutableStateOf<SeekFlash?>(null) }
    var gestureHud by remember { mutableStateOf<GestureHud?>(null) }

    val playerViewRef = remember { mutableStateOf<PlayerView?>(null) }

    var brightness by remember {
        mutableFloatStateOf(
            runCatching {
                val raw = Settings.System.getInt(
                    context.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS
                )
                (raw / 255f).coerceIn(0.05f, 1f)
            }.getOrDefault(0.5f)
        )
    }

    fun setWindowBrightness(value: Float) {
        brightness = value.coerceIn(0.05f, 1f)
        activity?.window?.let { w ->
            val lp = w.attributes
            lp.screenBrightness = brightness
            w.attributes = lp
        }
    }

    fun volumeFraction(): Float {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    fun setVolumeFraction(f: Float) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val v = (f.coerceIn(0f, 1f) * max).roundToInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
    }

    LaunchedEffect(animeId) {
        val savedAudio = library.lastAudioType.first()
        currentType = savedAudio.ifBlank { "sub" }
        // Restore the persisted audio-language pick (e.g. "eng" from the audio
        // menu) so this episode — and every next one — keeps the user's choice.
        preferredAudioLang = library.lastAudioLang.first()
        rememberedServerId = library.lastSelectedServerId.first().takeIf { it.isNotBlank() }
        selectedServerId = null
        val apiProv = library.apiProvider.first()
        kotoLocked = apiProv == "koto" || apiProv == "wave"
        lockedApiProvider = apiProv
        sourceMode = when {
            apiProv == "koto" -> "anikoto"
            apiProv == "wave" -> "aniwaves"
            else -> library.lastSourceMode.first().ifBlank { "aniwaves" }
        }
        if (offlineUri != null || downloadId != null) {
            // Offline playback: no network lookups — identity comes from the
            // nav route (legacy SAF file) or the download index (internal).
            val dm = downloadId?.let {
                com.panime.app.download.DownloadCenter.readMeta(context.applicationContext, it)
            }
            downloadMeta = dm
            title = offlineTitle.orEmpty().ifBlank {
                dm?.let { "${it.title} — ${it.episodeLabel}" } ?: "Offline"
            }
            seasonNumber = 1
            totalEps = 1
            animeYear = null
            kotoSlug = null
            return@LaunchedEffect
        }
        repository.detail(animeId)
            .onSuccess {
                title = it.title
                seasonNumber = it.seasonNumber
                kotoSlug = it.kotoSlug
                totalEps = (it.episodes ?: (it.nextEpisode?.minus(1)) ?: 0).coerceAtLeast(1)
                animeYear = it.year
                // Record the episode total for the profile stats even when this
                // anime was never opened in the Detail screen (e.g. resumed from
                // Continue Watching) — otherwise Card 3 can never auto-detect it.
                if (totalEps > 0) {
                    scope.launch { library.setListTotalEpisodes(animeId, totalEps) }
                }
            }
            .onFailure { resolveError = true }
        // Wrong-title override (checked once per entry — never mid-session):
        // a fresh pick wins over the catalog slug when playing on its source.
        library.getWrongTitleOverride(animeId)?.let { ov ->
            if (ov.slug.isNotBlank()) {
                wtSlug = ov.slug
                wtSource = ov.sourceId
                // Start on the source the pick came from — otherwise a pick
                // made under e.g. the KOTO chip would be ignored because
                // lastSourceMode still points at aniwaves (default).
                if (!kotoLocked) sourceMode = ov.sourceId
                // Animenosub splits some DUB series onto their own "-dub" page
                // (e.g. one-piece-dub). If the user picked such a series and has
                // no explicit audio preference, default to DUB — otherwise the
                // sub default resolves the SUB series page and a dub-only series
                // won't play. Episode changes then resolve through the same dub
                // slug instead of dropping back to the wrong (sub) title.
                if (savedAudio.isBlank() && ov.sourceId == "animenosub" &&
                    ov.slug.endsWith("-dub", ignoreCase = true)
                ) {
                    currentType = "dub"
                }
                // Point the episode sheet at the picked series' REAL episode
                // count — not AniList's. Without this a wrongly-titled pick is
                // stuck on AniList's range (e.g. 12 when the picked series
                // actually has 1175), so the sheet shows the wrong episode set
                // and "next episode" auto-advance stops too early. Uses the
                // count stored WITH the pick (zero re-search); older picks fall
                // back to a live lookup per source — same helper as DetailScreen.
                val n = ov.totalEpisodes?.takeIf { it > 0 } ?: withContext(Dispatchers.IO) {
                    com.panime.app.download.sourceEpisodeCount(
                        ov.sourceId, ov.slug, ov.selectedTitle,
                        // Per-season picks ("|se=N"): count THAT season only.
                        // Combined entries: full sum — the player sheet uses
                        // global numbering and resolveWithSlug maps global ep
                        // -> (se, ep) via the source's own season ranges.
                        com.panime.app.download.parsePickedSeason(ov.slug) ?: 0
                    )
                }
                // Replace AniList's count whenever we have the picked source's
                // real number (n > 0) — not only when it's larger. A pick whose
                // series is SHORTER than the AniList entry must also drive the
                // sheet range, or the sheet shows episodes the source can't serve.
                if (n > 0) totalEps = n
            }
        }
    }

    LaunchedEffect(animeId, episode) {
        resumeAtMs = 0L
        resumeReady = false
    }

    LaunchedEffect(animeId, episode, title, reloadKey, currentType, selectedServerId, sourceMode, downloadId) {
        if (title.isBlank()) return@LaunchedEffect
        if (downloadId != null) {
            // Internal (Media3) download: stream straight from the persistent
            // download cache. Subtitles are local sidecars fetched at completion.
            val meta = com.panime.app.download.DownloadCenter.readMeta(
                context.applicationContext, downloadId
            )
            downloadMeta = meta
            if (meta == null) {
                resolveError = true
                errorDetail = "Download not found"
                return@LaunchedEffect
            }
            isBuffering = true
            streamFormat = meta.format ?: "hls"
            subtitleTracks = com.panime.app.download.EpisodeDownloadService.localSubtitleTracks(
                context.applicationContext, downloadId
            )
            serverOptions = emptyList()
            isByfmsServer = false
            byfmsRawUrl = null
            anikageReferer = null
            decryptKey = null
            decryptIv = null
            introMs = null
            outroMs = null
            streamUrl = meta.streamUrl
            resolveError = false
            return@LaunchedEffect
        }
        if (offlineUri != null) {
            // Offline file: skip the whole provider pipeline — the local
            // document IS the stream. Capabilities stay off (no servers,
            // no audio/subtitle menus, no intro data).
            isBuffering = true
            streamFormat = "local"
            subtitleTracks = emptyList()
            serverOptions = emptyList()
            isByfmsServer = false
            byfmsRawUrl = null
            anikageReferer = null
            decryptKey = null
            decryptIv = null
            introMs = null
            outroMs = null
            streamUrl = offlineUri
            resolveError = false
            return@LaunchedEffect
        }
        val gen = ++resolveGeneration
        resolveError = false
        errorDetail = null
        isBuffering = true
        val preferredId = selectedServerId

        val pack: ResolvePack? = withContext(Dispatchers.IO) {
            resolveHybrid(
                context = context.applicationContext,
                sourceMode = sourceMode,
                title = title,
                animeId = animeId,
                episode = episode,
                currentType = currentType,
                selectedServerId = selectedServerId,
                selectedServerName = selectedServerName,
                seasonNumber = seasonNumber,
                // Wrong-title pick wins on its own source; otherwise the
                // locked koto/wave catalog slug (previous behavior).
                slugHint = when {
                    wtSource == sourceMode && !wtSlug.isNullOrBlank() -> wtSlug
                    kotoLocked -> kotoSlug
                    else -> null
                },
                totalEpisodes = totalEps,
                year = animeYear
            )
        }

        if (pack == null) {
            // Cold-start protection: the first resolve can fail transiently
            // (Render sleep / warm-up, cold caches in slug verification). Retry
            // a couple times before surfacing "no stream".
            if (resolveRetries < 2) {
                resolveRetries++
                reloadKey++
                return@LaunchedEffect
            }
            streamUrl = null
            resolveError = true
            isBuffering = false
            if (errorDetail.isNullOrBlank()) {
                val srvHint = selectedServerName?.let { " on '$it'" } ?: ""
                errorDetail = sanitizeErrorText(ProviderManager.lastError)
                    ?: "No stream found$srvHint for '${title}' ep $episode \u2014 try another server or source"
            }
            return@LaunchedEffect
        }
        if (gen != resolveGeneration) return@LaunchedEffect
        resolveRetries = 0
        anidbId = pack.anidbId
        // Default-mode moviebox: remember the matched entry's slug for the
        // Audio sheet's language list (cleared on other sources).
        mbDefaultSlug = if (sourceMode == "moviebox" && wtSlug.isNullOrBlank()) pack.slug else null
        serverOptions = filterServersForAudio(pack.servers, sourceMode, currentType)
        if (sourceMode == "anidb" && selectedServerId == null) {
            serverOptions.firstOrNull()?.let { selectedServerName = it.second }
        }
        if (!pack.serverName.isNullOrBlank()) {
            selectedServerName = pack.serverName
        } else if (!selectedServerId.isNullOrBlank()) {
            selectedServerName = serverOptions.firstOrNull { it.first == selectedServerId }?.second
                ?: selectedServerName
        }
        subtitleTracks = pack.subtitles
        isByfmsServer = pack.isByfms && !pack.rawUrl.isNullOrBlank()
        byfmsRawUrl = if (isByfmsServer) pack.rawUrl else null
        // moviebox CDN (hakunaymatata) returns HTTP 429 without Referer —
        // verified: no Referer -> 429, Referer mzfi.me -> 206 video bytes.
        anikageReferer = if (sourceMode == "aniwaves" || sourceMode == "anikage" || sourceMode == "just4anime" || sourceMode == "anidap" || sourceMode == "anikoto" || sourceMode == "animenosub" || sourceMode == "moviebox") pack.referer else null
        decryptKey = pack.decryptKey
        decryptIv = pack.decryptIv
        if (BuildConfig.DEBUG) {
            android.util.Log.d("SubtitleDebug",
                "source=$sourceMode provider=${pack.serverName} subtitleTracks=${subtitleTracks.size} " +
                "firstUrl=${subtitleTracks.firstOrNull()?.url} byfmsRawUrlSet=${byfmsRawUrl != null} referer=$anikageReferer")
        }
        streamFormat = pack.format ?: "hls"
        if (!selectedServerId.isNullOrBlank() && !pack.quality.isNullOrBlank()) {
            val sid = selectedServerId ?: return@LaunchedEffect
            val qual = pack.quality ?: return@LaunchedEffect
            serverQualities = serverQualities + (sid to qual)
        }
        introMs = pack.intro?.let { (a, b) -> (a * 1000L) to (b * 1000L) }
        outroMs = pack.outro?.let { (a, b) -> (a * 1000L) to (b * 1000L) }
        if (!pack.url.isNullOrBlank()) {
            val resolvedUrl = pack.url ?: return@LaunchedEffect
            streamUrl = resolvedUrl.replaceFirst(Regex("^http://"), "https://")
            resolveError = false
        } else {
            streamUrl = null
            resolveError = true
            isBuffering = false
            if (errorDetail.isNullOrBlank()) {
                errorDetail = sanitizeErrorText(ProviderManager.lastError)
                    ?: "Backend returned no stream for '${title}' ep $episode"
            }
        }
    }

    fun safePlayer(block: ExoPlayer.() -> Unit) {
        runCatching { (exoPlayer as? ExoPlayer)?.block() }
    }

    LaunchedEffect(streamUrl, loadKey) {
        val url = streamUrl ?: return@LaunchedEffect
        vm.clearError()
        errorDetail = null
        isBuffering = true
        resumeReady = false
        var attempt = 0
        val maxAttempts = 3
        var ok = false
        while (attempt < maxAttempts && !ok) {
            attempt++
            runCatching {
                safePlayer { stop() }
                val rawUrlForProbe = if (isByfmsServer && !byfmsRawUrl.isNullOrBlank()) byfmsRawUrl else null
                val byfmsDirectOk = if (rawUrlForProbe != null) {
                    if (sourceMode == "anikage") true
                    else withContext(Dispatchers.IO) { runCatching { AniwavesApi.probeByfmsDirect(rawUrlForProbe) }.getOrDefault(false) }
                } else false
                safePlayer {
                    if (!url.startsWith("http")) {
                        // Offline document (content://…): plain progressive item,
                        // mime inferred by ExoPlayer (mkv/mp4 both fine).
                        setMediaItem(androidx.media3.common.MediaItem.fromUri(url))
                    } else if (downloadId != null && downloadMeta != null) {
                        // Internal download: read through the persistent cache;
                        // falls back to network+headers only for missing spans.
                        val m = downloadMeta!!
                        setMediaSource(
                            PlayerModule.buildOfflineMediaSource(
                                context.applicationContext,
                                url,
                                m.mimeType,
                                m.id,
                                subtitleTracks,
                                m.decryptKeyB64
                            )
                        )
                    } else if (isByfmsServer && !byfmsRawUrl.isNullOrBlank() && byfmsDirectOk) {
                        val rawUrl = rawUrlForProbe!!
                        setMediaSource(
                            PlayerModule.buildAnikageMediaSource(
                                context.applicationContext, rawUrl, streamFormat,
                                subtitleTracks, referer = "https://aniwaves.ru/"
                            )
                        )
                    } else if (isByfmsServer && !byfmsRawUrl.isNullOrBlank()) {
                        setMediaSource(
                            PlayerModule.buildAnikageMediaSource(
                                context.applicationContext, url, streamFormat,
                                subtitleTracks, referer = anikageReferer
                            )
                        )
                    } else if (!anikageReferer.isNullOrBlank()) {
                        setMediaSource(
                            PlayerModule.buildAnikageMediaSource(
                                context.applicationContext, url, streamFormat,
                                subtitleTracks, referer = anikageReferer,
                                xorKey = decryptKey
                            )
                        )
                    } else {
                        setMediaItem(PlayerModule.buildMediaItem(url, subtitles = subtitleTracks))
                    }
                    if (BuildConfig.DEBUG) {
                        android.util.Log.d("SubtitleDebug",
                            "prepared player: subtitleTracks=${subtitleTracks.size} sourceUsed=${if (isByfmsServer && !byfmsRawUrl.isNullOrBlank()) "anikageMS" else "mediaItem"}")
                    }
                    setPlaybackSpeed(speed)
                    // Apply the persisted audio-language preference BEFORE prepare so
                    // the very first track selection honors it (no JP->EN flip).
                    preferredAudioLang?.let { lang ->
                        trackSelectionParameters = trackSelectionParameters.buildUpon()
                            .setPreferredAudioLanguage(lang)
                            .build()
                    }
                    prepare()
                    if (resumeAtMs > 0L) {
                        runCatching { exoPlayer.seekTo(resumeAtMs) }
                    }
                    play()
                }
            }
            val deadline = System.currentTimeMillis() + 60_000L
            while (System.currentTimeMillis() < deadline) {
                val ready = runCatching { exoPlayer.playbackState == Player.STATE_READY }.getOrElse { false }
                if (ready) { ok = true; break }
                if (vm.error.value != null && !hadPlayed) break
                delay(400)
            }
            if (!ok && vm.error.value == null) delay(1500L * attempt)
        }
        if (ok && resumeAtMs <= 0L) {
            runCatching {
                val dur = exoPlayer.duration
                if (dur > 0L) {
                    val saved = library.progressMap.first()[animeId]
                    if (saved != null && saved.first == episode &&
                        saved.second > 0.02f && saved.second < 0.95f
                    ) {
                        val target = (saved.second * dur).toLong()
                        resumeAtMs = target
                        exoPlayer.seekTo(target)
                    }
                }
            }
        }
        if (!ok) {
            if (staleRetries < 2) {
                staleRetries++
                reloadKey++
            } else {
                resolveError = true
                errorDetail = sanitizeErrorText(vm.error.value?.message)
                    ?: "Couldn't load the stream for '$selectedServerName' (tried $maxAttempts times). " +
                       "Try switching servers or source."
            }
        } else {
            staleRetries = 0
            hadPlayed = true
            resumeReady = true
            // Re-apply the user's persisted audio language on every new episode.
            // The per-episode TrackSelectionOverride dies with the old media item;
            // preferredAudioLang (language-tag based) survives episode changes.
            preferredAudioLang?.let { lang ->
                safePlayer {
                    trackSelectionParameters = trackSelectionParameters.buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                        .setPreferredAudioLanguage(lang)
                        .build()
                }
            }
        }
    }

    fun applyResize() {
        val mode = when (resizeMode) {
            0 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            else -> AspectRatioFrameLayout.RESIZE_MODE_FILL
        }
        runCatching { playerViewRef.value?.resizeMode = mode }
    }

    LaunchedEffect(resizeMode) { applyResize() }

    fun exitPlayerImmersive() {
        val window = activity?.window ?: return
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, true)
        val controller = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
        controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
    }

    DisposableEffect(Unit) {
        val window = activity?.window
        if (window != null) {
            androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
            controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            @Suppress("DEPRECATION")
            window.navigationBarColor = android.graphics.Color.BLACK
            @Suppress("DEPRECATION")
            window.statusBarColor = android.graphics.Color.BLACK
            controller.isAppearanceLightNavigationBars = false
            controller.isAppearanceLightStatusBars = false
        }
        onDispose { }
    }

    var inPipMode by remember { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> runCatching { exoPlayer.pause() }
                Lifecycle.Event.ON_RESUME, Lifecycle.Event.ON_START -> {
                    inPipMode = activity?.isInPictureInPictureMode == true
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val pipReceiver = remember {
        object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    PIP_ACTION_PLAY_PAUSE -> runCatching {
                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    }
                    PIP_ACTION_REWIND -> runCatching { exoPlayer.seekTo((exoPlayer.currentPosition - 10_000).coerceAtLeast(0)) }
                    PIP_ACTION_FORWARD -> runCatching { exoPlayer.seekTo((exoPlayer.currentPosition + 10_000).coerceAtMost(exoPlayer.duration)) }
                }
            }
        }
    }
    DisposableEffect(activity) {
        val filter = IntentFilter().apply {
            addAction(PIP_ACTION_PLAY_PAUSE)
            addAction(PIP_ACTION_REWIND)
            addAction(PIP_ACTION_FORWARD)
        }
        // Android 13+ requires RECEIVER_EXPORTED / RECEIVER_NOT_EXPORTED when
        // registering a receiver for non-system broadcasts, else the system
        // throws SecurityException and kills the app. These are our own PiP
        // control broadcasts, so NOT_EXPORTED (private to this app) is correct.
        if (activity != null) {
            ContextCompat.registerReceiver(
                activity!!, pipReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
            )
        }
        onDispose { activity?.unregisterReceiver(pipReceiver) }
    }

    LaunchedEffect(isPlaying) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            activity?.isInPictureInPictureMode == true
        ) {
            activity?.setPictureInPictureParams(
                android.app.PictureInPictureParams.Builder()
                    .setAspectRatio(android.util.Rational(16, 9))
                    .setActions(buildPipActions(activity, isPlaying))
                    .build()
            )
        }
    }

    LaunchedEffect(Unit) { library.ensureProfileInit() }

    // Watch-time accumulator shared by the periodic tracker, episode restarts
    // and screen exit, so no played seconds are ever lost.
    val watch = remember { WatchSessionAccumulator() }

    // Periodic progress + watch session save so Continue Watching updates live
    // and survives process death — not just on pause/exit.
    LaunchedEffect(animeId, episode, exoPlayer) {
        // Episode changed (autoplay / manual nav): attribute any un-saved playback
        // to the episode it belongs to before switching the counter over.
        if (watch.episode != episode && watch.pendingPlayedMs > 0L) {
            library.recordWatchSession(
                watch.animeId, watch.episode,
                (watch.pendingPlayedMs / 1000L).coerceAtLeast(1L).toInt(),
                watch.lastFrac
            )
            watch.pendingPlayedMs = 0L
        }
        watch.animeId = animeId
        watch.episode = episode
        watch.lastObservedPosition = exoPlayer.currentPosition.coerceAtLeast(0L)
        watch.lastSessionSaveAt = 0L
        watch.lastFrac = 0f
        watch.completionRecorded = false
        while (isActive) {
            delay(5000)
            runCatching {
                val dur = exoPlayer.duration
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                if (dur > 0) {
                    val frac = (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
                    watch.lastFrac = frac
                    library.saveProgress(animeId, episode, frac)
                    val now = System.currentTimeMillis()
                    // Count only position advanced while ExoPlayer was actually
                    // playing. A jump larger than a 5s tick can cover (<= 20s at
                    // 4x speed) is a seek — not watched time — so it neither
                    // counts nor pollutes the baseline. Never store the full
                    // episode duration as a session.
                    if (exoPlayer.isPlaying) {
                        val delta = pos - watch.lastObservedPosition
                        if (delta in 1L..20_000L) {
                            watch.pendingPlayedMs += delta
                        }
                    }
                    // Every 30s persist the ACCUMULATED playback since the last
                    // save (the old code saved only the last 5s tick -> the
                    // weekly total showed ~1/6 of real watch time).
                    if (now - watch.lastSessionSaveAt >= 30_000L && watch.pendingPlayedMs > 0L) {
                        library.recordWatchSession(
                            animeId, episode,
                            (watch.pendingPlayedMs / 1000L).coerceAtLeast(1L).toInt(), frac
                        )
                        watch.pendingPlayedMs = 0L
                        watch.lastSessionSaveAt = now
                    }
                    if (frac >= 0.98f && !watch.completionRecorded) {
                        library.recordWatchSession(animeId, episode, 0, 1.0f)
                        watch.completionRecorded = true
                    }
                    watch.lastObservedPosition = pos
                }
            }
        }
    }

    // Save watch session when episode changes (autoplay / manual nav).
    var prevEpisode by remember { mutableIntStateOf(episode) }
    LaunchedEffect(episode) {
        if (episode != prevEpisode) {
            runCatching {
                val dur = exoPlayer.duration
                val pos = exoPlayer.currentPosition
                if (dur > 0) {
                    val frac = pos.toFloat() / dur.toFloat()
                    library.saveProgress(animeId, prevEpisode, frac)
                    // Progress is saved at the boundary; watch time is recorded
                    // only by the periodic real-playback tracker.
                }
            }
            prevEpisode = episode
        }
    }

    DisposableEffect(Unit) {
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            runCatching {
                val dur = exoPlayer.duration
                val pos = exoPlayer.currentPosition
                if (dur > 0) {
                    val frac = pos.toFloat() / dur.toFloat()
                    scope.launch {
                        library.saveProgress(animeId, episode, frac)
                        // Count playback since the tracker's last tick, then flush
                        // the remainder so the tail of the session is never lost.
                        if (exoPlayer.isPlaying) {
                            val delta = pos - watch.lastObservedPosition
                            if (delta in 1L..20_000L) watch.pendingPlayedMs += delta
                        }
                        if (watch.pendingPlayedMs > 0L) {
                            library.recordWatchSession(
                                watch.animeId, watch.episode,
                                (watch.pendingPlayedMs / 1000L).coerceAtLeast(1L).toInt(), frac
                            )
                            watch.pendingPlayedMs = 0L
                        }
                    }
                }
            }
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(orientationForced, forceLandscape) {
        activity?.requestedOrientation = when {
            !orientationForced -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            forceLandscape -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
    }

    var lastImmersiveAssertMs = 0L
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(250)
            runCatching {
                isPlaying = exoPlayer.isPlaying
                positionMs = exoPlayer.currentPosition
                if (resumeReady && positionMs > 0L) resumeAtMs = positionMs
                durationMs = if (exoPlayer.duration > 0) exoPlayer.duration else 0L
                bufferedMs = exoPlayer.bufferedPosition.coerceAtLeast(0L)
                val state = exoPlayer.playbackState
                isBuffering = (state == Player.STATE_BUFFERING) && vm.error.value == null && !resolveError
                // Mid-playback recovery: ExoPlayer retries transient load errors
                // on its own — once it reaches READY again, clear the error so
                // the snag banner disappears without any user action.
                if (vm.error.value != null && state == Player.STATE_READY) {
                    vm.clearError()
                    errorDetail = null
                }
                if (state == Player.STATE_ENDED &&
                    autoplay &&
                    !isLocal &&
                    !hasAutoAdvanced &&
                    episode < totalEps
                ) {
                    hasAutoAdvanced = true
                    onEpisodeChange(episode + 1)
                }
                inPipMode = activity?.isInPictureInPictureMode == true
                val now = System.currentTimeMillis()
                if (now - lastImmersiveAssertMs > 1000L) {
                    lastImmersiveAssertMs = now
                    activity?.window?.let { w ->
                        val ctrl = androidx.core.view.WindowInsetsControllerCompat(w, w.decorView)
                        ctrl.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                        ctrl.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                        ctrl.isAppearanceLightNavigationBars = false
                        ctrl.isAppearanceLightStatusBars = false
                    }
                }
            }
            val sheetOpen = showMoreMenu || showSettings || showTrackSheet || showAudioSheet ||
                showQualitySheet || showEpisodeSheet || showSpeedSheet || showServerSheet
            if (isPlaying && controlsVisible && !sheetOpen &&
                System.currentTimeMillis() - lastInteraction > 3500L
            ) {
                controlsVisible = false
                showMoreMenu = false
            }
            if (locked && lockIconVisible &&
                System.currentTimeMillis() - lastLockInteraction > 2800L
            ) {
                lockIconVisible = false
            }
        }
    }

    LaunchedEffect(seekFlash) {
        if (seekFlash != null) {
            delay(650)
            seekFlash = null
        }
    }

    LaunchedEffect(gestureHud) {
        if (gestureHud != null) {
            delay(900)
            gestureHud = null
        }
    }

    fun touchControls() {
        lastInteraction = System.currentTimeMillis()
        controlsVisible = true
    }

    fun seekBy(deltaMs: Long) {
        runCatching {
            exoPlayer.seekTo((exoPlayer.currentPosition + deltaMs).coerceAtLeast(0))
        }
    }

    fun seekTo(ms: Long) {
        runCatching { exoPlayer.seekTo(ms.coerceAtLeast(0)) }
    }

    val anySheet = showMoreMenu || showSettings || showTrackSheet || showAudioSheet ||
        showQualitySheet || showEpisodeSheet || showSpeedSheet || showServerSheet

    var backDebounce by remember { mutableLongStateOf(0L) }
    BackHandler {
        val now = System.currentTimeMillis()
        if (now - backDebounce < 600L) return@BackHandler
        backDebounce = now
        when {
            showMoreMenu -> showMoreMenu = false
            showSettings -> showSettings = false
            showEpisodeSheet -> showEpisodeSheet = false
            showServerSheet -> showServerSheet = false
            showAudioSheet -> showAudioSheet = false
            showTrackSheet -> showTrackSheet = false
            showQualitySheet -> showQualitySheet = false
            showSpeedSheet -> showSpeedSheet = false
            locked -> {
                locked = false
                lockIconVisible = true
                lastLockInteraction = System.currentTimeMillis()
            }
            orientationForced -> orientationForced = false
            else -> {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                activity?.window?.let { w ->
                    val lp = w.attributes
                    lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                    w.attributes = lp
                }
                exitPlayerImmersive()
                onBack()
            }
        }
    }

    val trackState = currentTracks?.toTrackSelectionUiState() ?: com.panime.app.player.TrackSelectionUiState()

    val showSkipIntro = durationMs > 0 && !locked && !inPipMode && !resolveError &&
        introMs?.let { (s, e) -> positionMs in s..e } == true

    val showSkipOutro = durationMs > 0 && !locked && !inPipMode && !resolveError &&
        outroMs?.let { (s, e) -> positionMs in s..e } == true

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    useController = false
                        setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                        setBackgroundColor(android.graphics.Color.BLACK)
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                        playerViewRef.value = this
                        resizeMode = when (resizeMode) {
                            0 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                            1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                            else -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        }
                    }
                },
                update = { view ->
                    if (view.player !== exoPlayer) view.player = exoPlayer
                    view.setBackgroundColor(android.graphics.Color.BLACK)
                    view.setShutterBackgroundColor(android.graphics.Color.BLACK)
                },
                modifier = Modifier.fillMaxSize()
            )

        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(locked, anySheet, inPipMode) {
                    if (inPipMode || anySheet) return@pointerInput
                    if (locked) {
                        detectTapGestures(
                            onTap = {
                                lastLockInteraction = System.currentTimeMillis()
                                lockIconVisible = true
                            }
                        )
                        return@pointerInput
                    }
                    detectTapGestures(
                        onTap = {
                            lastInteraction = System.currentTimeMillis()
                            if (showMoreMenu) {
                                showMoreMenu = false
                            } else {
                                controlsVisible = !controlsVisible
                            }
                        },
                        onDoubleTap = { offset ->
                            val w = size.width.toFloat()
                            val left = offset.x < w / 2f
                            if (left) {
                                seekBy(-10_000)
                                seekFlash = SeekFlash(left = true)
                            } else {
                                seekBy(10_000)
                                seekFlash = SeekFlash(left = false)
                            }
                            touchControls()
                        }
                    )
                }
                .pointerInput(locked, anySheet, inPipMode) {
                    if (inPipMode || locked || anySheet) return@pointerInput
                    var startValue = 0f
                    var isLeft = true
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            isLeft = offset.x < size.width / 2f
                            startValue = if (isLeft) brightness else volumeFraction()
                        },
                        onVerticalDrag = { change, dragAmount ->
                            change.consume()
                            val h = size.height.coerceAtLeast(1).toFloat()
                            val next = (startValue - dragAmount / h).coerceIn(0f, 1f)
                            startValue = next
                            if (isLeft) {
                                setWindowBrightness(next)
                                gestureHud = GestureHud.Brightness(next)
                            } else {
                                setVolumeFraction(next)
                                gestureHud = GestureHud.Volume(next)
                            }
                        }
                    )
                }
                .pointerInput(locked, anySheet, inPipMode) {
                    if (inPipMode || locked || anySheet || durationMs <= 0) return@pointerInput
                    var startX = 0f
                    var startPos = 0L
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            startX = offset.x
                            startPos = positionMs
                            touchControls()
                        },
                        onHorizontalDrag = { change, _ ->
                            change.consume()
                            val w = size.width.coerceAtLeast(1)
                            val frac = (change.position.x - startX) / w
                            val delta = (frac * 90_000).toLong()
                            val target = (startPos + delta).coerceIn(0L, durationMs)
                            positionMs = target
                            gestureHud = GestureHud.Scrub(target, durationMs)
                        },
                        onDragEnd = {
                            seekTo(positionMs)
                            gestureHud = null
                        },
                        onDragCancel = { gestureHud = null }
                    )
                }
        )

        SeekFlashOverlay(seekFlash)
        GestureHudOverlay(gestureHud)

        if (!inPipMode && isBuffering && playbackError == null && !resolveError) {
            CircularProgressIndicator(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(48.dp),
                color = Flame,
                strokeWidth = 3.dp
            )
        }

        if (!inPipMode && !locked) {
            AnimatedVisibility(
                visible = controlsVisible && !showMoreMenu,
                enter = fadeIn(tween(180)),
                exit = fadeOut(tween(220)),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(Modifier.fillMaxSize()) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .align(Alignment.TopCenter)
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.85f),
                                        Color.Black.copy(alpha = 0.45f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .align(Alignment.BottomCenter)
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.55f),
                                        Color.Black.copy(alpha = 0.92f)
                                    )
                                )
                            )
                    )
                }
            }

            AnimatedVisibility(
                visible = !inPipMode && controlsVisible && !showMoreMenu,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding(),
                enter = fadeIn() + slideInVertically { -it / 3 },
                exit = fadeOut() + slideOutVertically { -it / 3 }
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        touchControls()
                        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                        activity?.window?.let { w ->
                            val lp = w.attributes
                            lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                            w.attributes = lp
                        }
                        exitPlayerImmersive()
                        onBack()
                    }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.back),
                            tint = Color.White
                        )
                    }
                    Column(
                        Modifier
                            .weight(1f)
                            .padding(end = 8.dp)
                    ) {
                        Text(
                            title.ifBlank { "\u2026" },
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 0.2.sp
                            )
                        )
                        Text(
                            stringResource(R.string.episode_label, episode),
                            color = Color.White.copy(alpha = 0.72f),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Box {
                        IconButton(onClick = {
                            touchControls()
                            showMoreMenu = !showMoreMenu
                        }) {
                            Icon(
                                Icons.Filled.MoreVert,
                                contentDescription = stringResource(R.string.more),
                                tint = if (showMoreMenu) Flame else Color.White
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = !inPipMode && controlsVisible && !showMoreMenu,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 10.dp),
                enter = fadeIn() + scaleIn(initialScale = 0.9f),
                exit = fadeOut() + scaleOut(targetScale = 0.9f)
            ) {
                Box(
                    Modifier
                        .size(44.dp)
                        .shadow(8.dp, CircleShape)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.14f))
                        .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                        .clickable {
                            touchControls()
                            locked = true
                            controlsVisible = false
                            showMoreMenu = false
                            lockIconVisible = true
                            lastLockInteraction = System.currentTimeMillis()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Filled.LockOpen,
                        contentDescription = stringResource(R.string.lock_controls),
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            AnimatedVisibility(
                visible = !inPipMode && controlsVisible && !showMoreMenu,
                modifier = Modifier.align(Alignment.Center),
                enter = fadeIn() + scaleIn(initialScale = 0.92f),
                exit = fadeOut() + scaleOut(targetScale = 0.92f)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 28.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TransportIcon(
                        icon = Icons.Filled.SkipPrevious,
                        size = 36.dp,
                        enabled = !isLocal && episode > 1,
                        contentDescription = stringResource(R.string.previous_episode)
                    ) {
                        touchControls()
                        if (episode > 1) onEpisodeChange(episode - 1)
                    }
                    TransportIcon(
                        icon = Icons.Filled.Replay10,
                        size = 40.dp,
                        contentDescription = stringResource(R.string.rewind_10)
                    ) {
                        touchControls()
                        seekBy(-10_000)
                        seekFlash = SeekFlash(left = true)
                    }
                    Box(
                        Modifier
                            .size(72.dp)
                            .shadow(12.dp, CircleShape)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.14f))
                            .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                            .clickable {
                                touchControls()
                                runCatching {
                                    if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = stringResource(R.string.play),
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                    TransportIcon(
                        icon = Icons.Filled.Forward10,
                        size = 40.dp,
                        contentDescription = stringResource(R.string.forward_10)
                    ) {
                        touchControls()
                        seekBy(10_000)
                        seekFlash = SeekFlash(left = false)
                    }
                    TransportIcon(
                        icon = Icons.Filled.SkipNext,
                        size = 36.dp,
                        enabled = !isLocal && episode < totalEps,
                        contentDescription = stringResource(R.string.next_episode)
                    ) {
                        touchControls()
                        if (episode < totalEps) onEpisodeChange(episode + 1)
                    }
                }
            }

            AnimatedVisibility(
                visible = !inPipMode && controlsVisible && !showMoreMenu,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding(),
                enter = fadeIn() + slideInVertically { it / 3 },
                exit = fadeOut() + slideOutVertically { it / 3 }
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            formatTime(positionMs),
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Medium,
                                fontFeatureSettings = "tnum"
                            )
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (durationMs > 0) {
                                "\u2212${formatTime((durationMs - positionMs).coerceAtLeast(0))}"
                            } else {
                                "\u2212\u2212:\u2212\u2212"
                            },
                            color = Color.White.copy(alpha = 0.75f),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    PremiumScrubber(
                        position = positionMs.toFloat(),
                        buffered = bufferedMs.toFloat(),
                        duration = (if (durationMs > 0) durationMs else 1L).toFloat(),
                        onScrub = { v ->
                            touchControls()
                            positionMs = v.toLong()
                        },
                        onScrubFinished = { v ->
                            seekTo(v.toLong())
                        }
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            if (!isLocal) {
                                BottomAction(
                                    icon = Icons.AutoMirrored.Filled.VolumeUp,
                                    label = stringResource(R.string.audio_tracks),
                                    tint = if (currentType == "dub") Flame else Color.White
                                ) {
                                    touchControls()
                                    showMoreMenu = false
                                    showAudioSheet = true
                                }
                                BottomAction(
                                    icon = Icons.Outlined.ClosedCaption,
                                    label = stringResource(R.string.subtitles),
                                    tint = if (trackState.subtitleTracks.any { it.isSelected }) Flame else Color.White
                                ) {
                                    touchControls()
                                    showMoreMenu = false
                                    showTrackSheet = true
                                }
                                BottomAction(
                                    icon = Icons.Filled.Dns,
                                    label = stringResource(R.string.server),
                                    tint = if (selectedServerName != null) Flame else Color.White
                                ) {
                                    touchControls()
                                    showMoreMenu = false
                                    showServerSheet = true
                                }
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            if (!isLocal) {
                                BottomAction(
                                    icon = Icons.Outlined.ViewAgenda,
                                    label = stringResource(R.string.episodes)
                                ) {
                                    touchControls()
                                    showMoreMenu = false
                                    showEpisodeSheet = true
                                }
                                BottomAction(
                                    icon = Icons.Outlined.HighQuality,
                                    label = stringResource(R.string.quality)
                                ) {
                                    touchControls()
                                    showMoreMenu = false
                                    showQualitySheet = true
                                }
                            }
                            // Settings gear is a stream-time option (its sheet mainly
                            // exposes quality/audio/subtitle controls). For a downloaded
                            // episode those are unavailable, so hide it like the other
                            // bottom actions — speed/aspect remain set via the ⋯ menu.
                            if (!isLocal) {
                                BottomAction(
                                    icon = Icons.Filled.Settings,
                                    label = stringResource(R.string.settings)
                                ) {
                                    touchControls()
                                    showMoreMenu = false
                                    showSettings = true
                                }
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = !inPipMode && showSkipIntro,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = 20.dp, bottom = if (controlsVisible) 118.dp else 28.dp),
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut()
            ) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Flame)
                        .clickable {
                            touchControls()
                            val target = introMs?.second ?: 90_000L
                            seekTo(target.coerceAtMost(durationMs))
                        }
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    Text(
                        stringResource(R.string.skip_intro),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            AnimatedVisibility(
                visible = !inPipMode && showSkipOutro,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(end = 20.dp, bottom = if (controlsVisible) 118.dp else 28.dp),
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut()
            ) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                        .clickable {
                            touchControls()
                            val target = outroMs?.second ?: durationMs
                            seekTo(target.coerceAtMost(durationMs))
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        stringResource(R.string.skip_outro),
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelLarge
                    )
                    Spacer(Modifier.width(6.dp))
                    Icon(
                        Icons.Filled.SkipNext,
                        contentDescription = null,
                        tint = Flame,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = !inPipMode && locked && lockIconVisible,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 10.dp),
            enter = fadeIn() + scaleIn(initialScale = 0.9f),
            exit = fadeOut() + scaleOut(targetScale = 0.9f)
        ) {
            Box(
                Modifier
                    .size(44.dp)
                    .shadow(8.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.14f))
                    .border(1.dp, Color.White.copy(alpha = 0.22f), CircleShape)
                    .clickable {
                        locked = false
                        lockIconVisible = false
                        touchControls()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.Lock,
                    contentDescription = stringResource(R.string.tap_to_unlock),
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        if (castHint) {
            LaunchedEffect(castHint) {
                delay(1600)
                castHint = false
            }
            Box(
                Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                Text(
                    stringResource(R.string.cast_unavailable),
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }

        // Server auto-fallback: when the resolved stream can't actually play,
        // hop to the next untried server instead of dead-ending on the error
        // overlay. Two triggers:
        //   1. Codec failure — the server's encode can't be decoded on this
        //      device (e.g. avc1.6E0015 = H.264 High 4:4:4 10-bit); the site
        //      plays it via software decoding, on-device only another server
        //      helps.
        //   2. First-load failure — the stream never reached READY and the
        //      player reported an error (403/404/timeout on the m3u8 or its
        //      segments). A resolver can hand back a URL that is then
        //      unreachable on the device (e.g. animenosub's DUB split-series
        //      pages list Moon/Omega but the picked server's segments 404), so
        //      the NEXT server must be tried instead of retrying the same
        //      broken URL forever.
        // Never fires mid-playback (once the stream became ready a dropped
        // connection just shows the retry overlay) and never for local files.
            // After a MANUAL server/source pick the fallback is disabled for the
            // rest of this episode: the user chose where to play, so a failure
            // surfaces the error instead of hijacking their choice.
            var triedServers by remember(animeId, episode) { mutableStateOf(setOf<String>()) }
            LaunchedEffect(playbackError) {
                val err = playbackError ?: return@LaunchedEffect
                val codecFailure = err.errorCode ==
                    PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES ||
                    err.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ||
                    err.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                    err.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED
                val firstLoadFailure = !resumeReady && !codecFailure
                if (isLocal || (!codecFailure && !firstLoadFailure)) return@LaunchedEffect
                // Manual server/source pick disables auto-fallback for this
                // episode: surface the error instead of silently switching away
                // from what the user chose.
                if (manualServerPick) {
                    triedServers = emptySet()
                    errorDetail = if (codecFailure) {
                        "This server's video format can't be decoded on your device. Pick another server manually."
                    } else {
                        "This server couldn't load — pick another server from the server menu."
                    }
                    return@LaunchedEffect
                }
            // Which server is (probably) playing? An explicit pick wins; an
            // auto-pick is the first entry — animenosub lists the used server
            // first, other providers resolve in list order, so this is the
            // right guess for the common case and harmless otherwise.
            val current = selectedServerId ?: serverOptions.firstOrNull()?.first
            val next = serverOptions.firstOrNull {
                it.first !in triedServers && it.first != current && it.second != selectedServerName
            }
            if (next != null && triedServers.size < serverOptions.size) {
                if (hadPlayed && codecFailure) {
                    resumeAtMs = runCatching { exoPlayer.currentPosition }.getOrDefault(0L)
                }
                triedServers = triedServers + setOfNotNull(current, next.first)
                vm.clearError()
                resolveError = false
                errorDetail = null
                Toast.makeText(
                    context,
                    if (codecFailure) "Video format not supported here — switching to ${next.second}"
                    else "Stream couldn't load — switching to ${next.second}",
                    Toast.LENGTH_SHORT
                ).show()
                selectedServerId = next.first
                selectedServerName = next.second
                streamUrl = null
                loadKey++
                library.setLastSelectedServerId(next.first)
            } else {
                // Every server tried — explain the real cause instead of the
                // raw MediaCodecVideoRenderer dump or a bare "couldn't load".
                triedServers = emptySet()
                errorDetail = if (codecFailure) {
                    "Your device can't decode this server's video format " +
                        "(10-bit H.264). Switch to another server or source."
                } else {
                    "Couldn't load the stream from any server. " +
                        "Check your connection or try another source."
                }
            }
        }

        // Mid-playback snag vs hard failure: if the stream HAD been playing and
        // then dropped, show a compact reconnecting banner — the video stays on
        // screen and the banner auto-hides on recovery. The full-screen overlay
        // is reserved for real failures (never played / resolve failed / codec
        // / all servers tried).
        val midPlaybackSnag = !resolveError && hadPlayed && playbackError != null
        if (!inPipMode && midPlaybackSnag) {
            SnagBanner(
                detail = errorDetail,
                onRetry = {
                    vm.clearError()
                    resolveError = false
                    errorDetail = null
                    loadKey++
                }
            )
        } else if (!inPipMode && (playbackError != null || resolveError)) {
            PlaybackErrorOverlay(
                detail = errorDetail,
                onRetry = {
                    vm.clearError()
                    resolveError = false
                    errorDetail = null
                    resolveRetries = 0
                    triedServers = emptySet()
                    if (hadPlayed) {
                        loadKey++
                    } else {
                        loadKey++
                        reloadKey++
                    }
                }
            )
        }
    }

    if (showMoreMenu) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { showMoreMenu = false }
                )
        )
        Box(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(top = 56.dp, end = 4.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            MoreSolidMenu(
                resizeMode = resizeMode,
                speed = speed,
                offline = isLocal,
                onFit = {
                    touchControls()
                    resizeMode = (resizeMode + 1) % 3
                },
                onPip = {
                    touchControls()
                    showMoreMenu = false
                    pipEnter(activity, exoPlayer.isPlaying, exoPlayer.currentPosition, exoPlayer.duration)
                },
                onRotate = {
                    touchControls()
                    forceLandscape = !forceLandscape
                    orientationForced = true
                },
                onCast = {
                    touchControls()
                    castHint = true
                },
                onSpeed = {
                    touchControls()
                    showMoreMenu = false
                    showSpeedSheet = true
                }
            )
        }
    }

    if (showSettings) {
        SettingsSheet(
            speed = speed,
            resizeMode = resizeMode,
            currentType = currentType,
            trackState = trackState,
            offline = isLocal,
            onSpeed = {
                showSettings = false
                showSpeedSheet = true
            },
            onQuality = {
                showSettings = false
                showQualitySheet = true
            },
            onSubs = {
                showSettings = false
                showTrackSheet = true
            },
            onAudio = {
                showSettings = false
                showAudioSheet = true
            },
            onResizeCycle = { resizeMode = (resizeMode + 1) % 3 },
            onType = { next ->
                scope.launch {
                    currentType = next
                    library.setLastAudioType(next)
                    selectedServerId = null
                    selectedServerName = null
                    streamUrl = null
                    resolveError = false
                    loadKey++
                    showSettings = false
                    library.setLastSelectedServerId("")
                }
            },
            onDismiss = { showSettings = false }
        )
    }

    if (showServerSheet) {
        ServerSheet(
            servers = serverOptions,
            selectedId = selectedServerId,
            selectedName = selectedServerName,
            sourceMode = sourceMode,
            lockedSource = when {
                kotoLocked && lockedApiProvider == "koto" -> "anikoto"
                kotoLocked && lockedApiProvider == "wave" -> "aniwaves"
                kotoLocked -> "anikoto"
                // Fresh wrong-title pick: lock to the source it was picked for,
                // same as the locked-API modes — no source switching mid-play.
                wtSource != null && !wtSlug.isNullOrBlank() -> wtSource
                else -> null
            },
            onSourceChange = { next ->
                scope.launch {
                    sourceMode = next
                    selectedServerId = null
                    selectedServerName = null
                    streamUrl = null
                    resolveError = false
                    loadKey++
                    // Manual source change: no auto-fallback on the new source.
                    // The user chose this source; if it fails, show the error.
                    manualServerPick = true
                    serverQualities = emptyMap()
                    exoPlayer.clearVideoOverrides()
                    val fetched = preloadServers(next, currentType, title, animeId, episode, if (wtSource == next && !wtSlug.isNullOrBlank()) wtSlug else kotoSlug, seasonNumber, totalEps, animeYear)
                    filterServersForAudio(fetched, next, currentType).takeIf { it.isNotEmpty() }?.let { servers ->
                        serverOptions = servers
                        if (next == "anidb" || next == "anizone") servers.first().let { (id, name) ->
                            selectedServerId = id
                            selectedServerName = name
                        }
                    }
                    serversLoading = false
                    library.setLastSourceMode(next)
                    library.setLastSelectedServerId("")
                }
            },
            onSelect = { id, name ->
                scope.launch {
                    selectedServerId = id
                    selectedServerName = name
                    streamUrl = null
                    resolveError = false
                    loadKey++
                    showServerSheet = false
                    // Manual server pick: disable auto-fallback for this episode so
                    // a slow/failed chosen server shows its error instead of being
                    // silently switched away.
                    manualServerPick = true
                    library.setLastSelectedServerId(id)
                    library.setLastSourceMode(sourceMode)
                }
            },
            onDismiss = { showServerSheet = false },
            serverQualities = serverQualities
        )
    }

    // Moviebox language variants ("English dub", "Arabic sub", …) — zone-style:
    // the SERVER sheet stays a single "Movie" entry; languages live here in the
    // AUDIO sheet. Each variant is its own stream (like Zone's per-language
    // m3u8s); picking one re-resolves with the variant's own slug.
    var movieLangs by remember(animeId, episode) { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var movieLangLoading by remember(animeId, episode) { mutableStateOf(false) }
    LaunchedEffect(sourceMode, wtSlug, mbDefaultSlug, animeId, episode, streamUrl) {
        // Slug sources: a wrong-title pick (wtSlug) OR the default-mode matched
        // entry (mbDefaultSlug from resolveHybrid). Both enable the language list.
        val slugNow = wtSlug ?: mbDefaultSlug
        if (sourceMode != "moviebox" || slugNow.isNullOrBlank()) {
            movieLangs = emptyList()
            return@LaunchedEffect
        }
        movieLangLoading = true
        movieLangs = withContext(Dispatchers.IO) {
            runCatching { MovieboxProvider().listLanguagesFor(slugNow) }.getOrDefault(emptyList())
        }
        movieLangLoading = false
    }

    if (showTrackSheet) {
        SubtitleSheet(
            state = trackState,
            onSelect = { track ->
                runCatching {
                    exoPlayer.enableSubtitles()
                    currentTracks?.let { exoPlayer.selectTrack(track, it) }
                }
                showTrackSheet = false
            },
            onSubtitlesOff = {
                runCatching { exoPlayer.disableSubtitles() }
                showTrackSheet = false
            },
            onDismiss = { showTrackSheet = false }
        )
    }

    if (showAudioSheet) {
        AudioSheet(
            state = trackState,
            currentType = currentType,
            // Moviebox: real language variants replace the generic sub/dub pill
            // (same as Zone, where the language list IS the audio picker).
            languageVariants = if (sourceMode == "moviebox") movieLangs else emptyList(),
            languageLoading = if (sourceMode == "moviebox") movieLangLoading else false,
            // Highlighted row = the language ACTUALLY in use. selectedServerId
            // carries the variant slug picked in the Audio sheet (it re-resolves
            // through it); the base pick's own slug highlights "Original Audio".
            currentLanguageCode = if (sourceMode == "moviebox") {
                val base = (wtSlug ?: mbDefaultSlug)?.split("|")?.takeIf { it.size >= 2 }?.let { "${it[0]}|${it[1]}" }
                val sel = selectedServerId
                if (sel != null && movieLangs.any { it.first == sel }) sel else base
            } else null,
            onLanguageSelect = { code ->
                scope.launch {
                    showAudioSheet = false
                    // Same effective-selection logic as the highlight above —
                    // switching BACK to the base ("Original Audio") from a
                    // variant must re-resolve too.
                    val base = (wtSlug ?: mbDefaultSlug)?.split("|")?.takeIf { it.size >= 2 }?.let { "${it[0]}|${it[1]}" }
                    val effSel = selectedServerId
                    val current = if (effSel != null && movieLangs.any { it.first == effSel }) effSel else base
                    if (code != current) {
                        // Re-resolve through the variant's own subject slug —
                        // identical flow to picking a different server.
                        selectedServerId = code
                        selectedServerName = movieLangs.firstOrNull { it.first == code }?.second
                        streamUrl = null
                        resolveError = false
                        loadKey++
                        library.setLastSelectedServerId(code)
                    }
                }
            },
            onTypeChange = { next ->
                scope.launch {
                    currentType = next
                    library.setLastAudioType(next)
                    // sub<->dub switch = different audio tracks entirely; drop the
                    // persisted language so the next episode picks the new type's default.
                    preferredAudioLang = null
                    library.setLastAudioLang(null)
                    runCatching {
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                            .setPreferredAudioLanguage(null)
                            .build()
                    }
                    selectedServerId = null
                    selectedServerName = null
                    streamUrl = null
                    resolveError = false
                    loadKey++
                    showAudioSheet = false
                    val fetched = preloadServers(sourceMode, next, title, animeId, episode, if (wtSource == sourceMode && !wtSlug.isNullOrBlank()) wtSlug else kotoSlug, seasonNumber, totalEps, animeYear)
                    filterServersForAudio(fetched, sourceMode, next).takeIf { it.isNotEmpty() }?.let { servers ->
                        serverOptions = servers
                    }
                    library.setLastSelectedServerId("")
                }
            },
            onSelect = { track ->
                runCatching {
                    currentTracks?.let { exoPlayer.selectTrack(track, it) }
                    // Remember the language so the NEXT episode keeps it (the
                    // override above only covers this episode's track groups).
                    track.language?.let { lang ->
                        preferredAudioLang = lang
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .setPreferredAudioLanguage(lang)
                            .build()
                        scope.launch { library.setLastAudioLang(lang) }
                    }
                }
                showAudioSheet = false
            },
            onDismiss = { showAudioSheet = false }
        )
    }

    if (showQualitySheet) {
        QualitySheet(
            state = trackState,
            onAuto = {
                runCatching { exoPlayer.clearVideoOverrides() }
                showQualitySheet = false
            },
            onSelect = { track ->
                runCatching { currentTracks?.let { exoPlayer.selectTrack(track, it) } }
                showQualitySheet = false
            },
            onDismiss = { showQualitySheet = false }
        )
    }

    if (showSpeedSheet) {
        SpeedSheet(
            speeds = speeds,
            current = speed,
            onSelect = { s ->
                speed = s
                runCatching { exoPlayer.setPlaybackSpeed(s) }
                showSpeedSheet = false
            },
            onDismiss = { showSpeedSheet = false }
        )
    }

    if (showEpisodeSheet) {
        EpisodeSheet(
            current = episode,
            total = totalEps,
            onSelect = { ep ->
                if (ep != episode) onEpisodeChange(ep)
                showEpisodeSheet = false
            },
            onDismiss = { showEpisodeSheet = false }
        )
    }
}
