package com.panime.app.data.provider.aniwaves

import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.api.AniListApi
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.util.Obf
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/**
 * Direct (no backend) client for aniwaves.ru.
 *
 * aniwaves.ru serves its search/episodes/servers/sources AJAX endpoints to plain
 * HTTP clients without a Cloudflare challenge (verified live), so the device can
 * drive the whole discovery chain itself:
 *   1) /filter?keyword=<q>            -> catalog slugs (paginated)
 *   2) /ajax/episode/list/<numericId> -> episode rows (data-ids "<num>&eps=<n>")
 *   3) /ajax/server/list?servers=&eps=-> server rows (data-link-id + name)
 *   4) /ajax/sources?id=<linkId>      -> embed URL + skip_data
 * The embed URL is handed to the on-device extractors ([AniwavesExtractor]).
 * BYFMS + DGHG servers are intentionally never offered — their PoW /
 * browser-impersonation flows can't run on-device.
 */
object AniwavesScraper {

    private val BASE = Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoLw==")
    private const val MAX_PAGES = 3

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val slugCache = ConcurrentHashMap<String, Pair<Long, List<String>>>()
    private const val SLUG_CACHE_TTL_MS = 10 * 60_000L
    private val episodeCache = ConcurrentHashMap<String, Pair<Long, Int>>()
    /** Slug metadata (titles, year, synopsis, episode count) never changes —
     *  cache permanently to skip the /watch page fetch on repeat plays. */
    private const val META_CACHE_TTL_MS = 24 * 60 * 60_000L
    private val anilistEpisodesCache = ConcurrentHashMap<Int, Pair<Long, Int?>>()

    data class ServerRow(val id: String, val name: String)

    data class EmbedResult(
        val url: String,
        val intro: Pair<Int, Int>? = null,
        val outro: Pair<Int, Int>? = null
    )

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun headers(referer: String): Map<String, String> =
        ScraperEngine.defaultHeaders(referer) +
            mapOf("X-Requested-With" to "XMLHttpRequest")

    /**
     * Extract the `result` HTML string from an aniwaves AJAX JSON response.
     * Most endpoints (episode/list, server/list) return `result` as a plain
     * string, but the typeahead (/ajax/anime/search) wraps it as
     * `{"html": "...", "linkMore": "...", "count": N}` — unwrap either shape.
     */
    private fun htmlResult(txt: String): String? = runCatching {
        when (val r = json.parseToJsonElement(txt).jsonObject["result"]) {
            is JsonPrimitive -> r.contentOrNull
            is JsonObject -> r["html"]?.jsonPrimitive?.contentOrNull
            else -> null
        }
    }.getOrNull()

    /** JsonPrimitive.content that doesn't throw on non-string primitives. */
    private val JsonPrimitive.contentOrNull: String?
        get() = runCatching { content }.getOrNull()

    /** Alphanumeric-only, lowercase (titles compare cleanly). */
    fun normalize(s: String): String =
        s.lowercase().filter { it.isLetterOrDigit() }

    // ── Search / slug ──────────────────────────────────────────────────────────

    private data class Hit(val slug: String, val title: String)

    /**
     * Collect catalog slugs for [q] (mirrors backend searchAnime). The site's
     * plain /filter catalog search is unreliable for many full titles (returns 0
     * hits for e.g. "re zero starting life in another world"), while the
     * typeahead POST /ajax/anime/search reliably ranks the correct entries first
     * (it caps at 5, so /filter is used as a fallback fill).
     */
    private fun searchFilter(q: String): List<Hit> {
        val out = mutableListOf<Hit>()
        val seen = HashSet<String>()

        fun add(slug: String, title: String) {
            if (slug.isBlank() || slug in seen || title.isBlank()) return
            seen.add(slug)
            out.add(Hit(slug, title))
        }

        // 1. Reliable typeahead (POST, XMLHttpRequest) — ranks correct entries first.
        runCatching {
            val body = ScraperEngine.postForm(
                "$BASE/ajax/anime/search",
                mapOf("keyword" to q),
                headers("$BASE/")
            ) ?: return@runCatching
            val doc = Jsoup.parse(htmlResult(body) ?: return@runCatching)
            doc.select("a.item[href*='/watch/']").forEach { item ->
                val slug = item.attr("href").replace("/watch/", "").removeSuffix("/")
                val title = item.selectFirst(".name.d-title")?.text()
                    ?: item.selectFirst(".d-title")?.text()
                    ?: item.text().trim().takeIf { it.isNotBlank() }
                if (!title.isNullOrBlank()) add(slug, title)
            }
        }

        // 2. /filter catalog fill (paginated) for anything the typeahead missed.
        var page = 1
        while (page <= MAX_PAGES) {
            val html = ScraperEngine.fetchText(
                "$BASE/filter?keyword=${enc(q)}&page=$page",
                ScraperEngine.defaultHeaders("$BASE/"),
                timeoutMs = 10_000L, maxRetries = 1
            ) ?: break
            val doc = runCatching { Jsoup.parse(html) }.getOrNull() ?: break
            val scope = doc.getElementById("list-items") ?: break
            var pageHits = 0
            scope.select("div.item").forEach { item ->
                val link = item.selectFirst("a[href*='/watch/']") ?: return@forEach
                val slug = link.attr("href").replace("/watch/", "").removeSuffix("/")
                val title = item.selectFirst(".name.d-title")?.text()
                    ?: item.selectFirst("a.name")?.text()
                    ?: link.text().trim().takeIf { it.isNotBlank() }
                if (title.isNullOrBlank()) return@forEach
                add(slug, title)
                pageHits++
            }
            if (pageHits == 0) break
            // Follow pagination to the highest linked page (page=2,3,4…) so we
            // never stop early and silently drop results (backend parity).
            val maxLinked = Regex("page=(\\d+)").findAll(html)
                .mapNotNull { it.groupValues[1].toIntOrNull() }.maxOrNull() ?: 1
            if (maxLinked <= page) break
            page = minOf(page + 1, maxLinked)
        }
        return out
    }

    /**
     * Ranked slug candidates for a title (cached 10 min), best-first. Uses the
     * multi-pass matcher (exact season-preferred -> longest significant part ->
     * contains -> first result) but keeps EVERY hit so the provider can verify
     * each one (episode presence + count gate) before playing — anikoto-style.
     * Reuses the pure helpers [AniwavesApi.cleanTitle] / [AniwavesApi.extractSeason].
     */
    fun resolveSlugCandidates(candidates: List<String>, preferredSeason: Int = 0): List<String> {
        val nonBlank = candidates.map { it.trim() }.filter { it.isNotBlank() }
        if (nonBlank.isEmpty()) return emptyList()
        val key = nonBlank.joinToString("|").lowercase()
        slugCache[key]?.let { (ts, slugs) ->
            if (System.currentTimeMillis() - ts < SLUG_CACHE_TTL_MS) return slugs
            slugCache.remove(key)
        }
        val out = resolveSlugCandidatesCompute(nonBlank, preferredSeason)
        if (out.isNotEmpty()) slugCache[key] = System.currentTimeMillis() to out
        return out
    }

    /** Single best guess (kept for callers that don't verify). */
    fun resolveSlug(candidates: List<String>, preferredSeason: Int = 0): String? =
        resolveSlugCandidates(candidates, preferredSeason).firstOrNull()

    private fun resolveSlugCandidatesCompute(nonBlank: List<String>, preferredSeason: Int = 0): List<String> {
        val out = linkedSetOf<String>()
        for (cand in nonBlank) {
            val cleaned = AniwavesApi.cleanTitle(cand)
            val q = cleaned.ifBlank { cand.trim() }
            if (q.isBlank()) continue
            val hits = searchFilter(q)
            if (hits.isEmpty()) continue

            val cleanedLower = cleaned.lowercase()
            // Season intent from the title text, or the real season the player
            // passed in (arcs / JP subtitles never carry "Season N" in the title).
            val wantedSeason = AniwavesApi.extractSeason(cand)
                .takeIf { it > 0 }
                ?: preferredSeason.takeIf { it > 1 } ?: 0

            fun seasonOf(raw: String): Int {
                val t = raw.lowercase()
                if (wantedSeason > 0) {
                    val forms = when (wantedSeason) {
                        2 -> listOf("ii", "2nd", "second", "season 2", "part 2", "s2")
                        3 -> listOf("iii", "3rd", "third", "season 3", "part 3", "s3")
                        4 -> listOf("iv", "4th", "fourth", "season 4", "part 4", "s4")
                        else -> listOf("season $wantedSeason", "part $wantedSeason")
                    }
                    if (forms.any { t.contains(it) }) return wantedSeason
                }
                val m = Regex("""(season|part)\s*(\d+)""").find(t)
                if (m != null) return m.groupValues[2].toIntOrNull() ?: 0
                val rm = Regex("""\b(ii|iii|iv|v)\b""").find(t)
                if (rm != null) return mapOf("ii" to 2, "iii" to 3, "iv" to 4, "v" to 5)[rm.groupValues[1]] ?: 0
                return 0
            }
            fun cleanMatch(raw: String): Boolean =
                AniwavesApi.cleanTitle(raw).equals(cleanedLower, ignoreCase = true)

            // 1. Exact, season-preferred — collect all, season matches first.
            val exacts = hits.filter { cleanMatch(it.title) }
            if (wantedSeason > 0) {
                // Season/arc variants are the base title + suffix; cleanTitle leaves
                // residues like "2nd" / "4th" / "swordsmith village arc", so they never
                // clean-match exactly. Include any hit whose cleaned title is the base
                // query or extends it, ordering season-matching hits first.
                val basePrefixed = hits.filter {
                    val rc = AniwavesApi.cleanTitle(it.title).lowercase()
                    rc == cleanedLower || rc.startsWith(cleanedLower + " ")
                }
                val ordered = (basePrefixed + exacts).distinctBy { it.slug }
                ordered.filter { seasonOf(it.title) == wantedSeason }.forEach { out.add(it.slug) }
                exacts.forEach { out.add(it.slug) }
                ordered.forEach { out.add(it.slug) }
            } else {
                exacts.forEach { out.add(it.slug) }
            }

            // 2. Longest significant word-group of the query
            for (part in significantParts(cleanedLower)) {
                hits.filter {
                    AniwavesApi.cleanTitle(it.title).contains(part, ignoreCase = true)
                }.forEach { out.add(it.slug) }
            }

            // 3. Bidirectional contains (skipped for near-empty clean queries —
            //    a blank or single-char query would match literally everything)
            if (cleanedLower.length >= 2) {
                hits.filter {
                    val rc = AniwavesApi.cleanTitle(it.title).lowercase()
                    rc.contains(cleanedLower) || cleanedLower.contains(rc)
                }.forEach { out.add(it.slug) }
            }

            // 4. First result (safety net)
            hits.firstOrNull()?.let { out.add(it.slug) }
        }
        return out.toList()
    }

    /** Longest-first significant word-groups of a cleaned title (backend parity).
     *  2-char words are kept (e.g. "on" in "attack on titan"), since dropping
     *  them broke matching for titles whose short words are meaningful. */
    private fun significantParts(cleaned: String): List<String> {
        val words = cleaned.split(Regex("""\s+""")).filter { it.length >= 2 }
        if (words.isEmpty()) return emptyList()
        val out = mutableListOf<String>()
        out.add(words.joinToString(" "))
        for (size in words.size - 1 downTo 2) {
            for (start in 0..words.size - size) {
                out.add(words.subList(start, start + size).joinToString(" "))
            }
        }
        return out.distinct()
    }

    // ── Episodes / servers / embed ─────────────────────────────────────────────

    /** On-site metadata for a slug (parsed from the /watch/{slug} page). */
    data class SlugMeta(
        val slug: String,
        val jpTitle: String? = null,   // data-jp (romaji/JP title the site uses)
        val enTitle: String? = null,   // og:title minus the trailing (year)
        val year: Int? = null,         // from og:title "(YYYY)"
        val synopsis: String? = null,  // og:description / meta description
        val maxEpisode: Int = 0
    )

    private val slugMetaCache = ConcurrentHashMap<String, Pair<Long, SlugMeta>>()

    /** Fetch + parse /watch/{slug} metadata. Null on any failure. */
    fun slugMeta(slug: String): SlugMeta? {
        if (slug.isBlank()) return null
        slugMetaCache[slug]?.let { (ts, meta) ->
            if (System.currentTimeMillis() - ts < META_CACHE_TTL_MS) return meta
            slugMetaCache.remove(slug)
        }
        val html = ScraperEngine.fetchText(
            "$BASE/watch/$slug",
            ScraperEngine.defaultHeaders("$BASE/"),
            useCache = true, timeoutMs = 10_000L, maxRetries = 1
        ) ?: return null
        val doc = runCatching { Jsoup.parse(html) }.getOrNull() ?: return null
        val jp = doc.selectFirst("[data-jp]")?.attr("data-jp")?.trim()?.takeIf { it.isNotBlank() }
        val ogTitle = doc.selectFirst("meta[property='og:title']")?.attr("content")
        val en = ogTitle?.substringBefore(" – ")?.substringBefore(" –")?.trim()
            ?.replace(Regex("""\s*\(\d{4}\)\s*$"""), "")
            ?.takeIf { it.isNotBlank() }
        val year = ogTitle?.let { Regex("""\((\d{4})\)""").find(it)?.groupValues?.get(1)?.toIntOrNull() }
        val synopsis = doc.selectFirst("meta[property='og:description']")?.attr("content")
            ?: doc.selectFirst("meta[name='description']")?.attr("content")
            ?: doc.selectFirst("div.synopsis")?.text()
            ?: doc.selectFirst("div.film-description")?.text()
        val meta = SlugMeta(slug, jp, en, year, synopsis?.trim()?.takeIf { it.isNotBlank() }, slugMaxEpisode(slug))
        slugMetaCache[slug] = System.currentTimeMillis() to meta
        return meta
    }

    fun slugMaxEpisode(slug: String): Int {
        val numId = Regex("""-(\d+)$""").find(slug)?.groupValues?.get(1) ?: return 0
        episodeCache[slug]?.let { (ts, max) ->
            if (System.currentTimeMillis() - ts < META_CACHE_TTL_MS) return max
            episodeCache.remove(slug)
        }
        val epHtml = htmlResult(
            ScraperEngine.fetchText(
                "$BASE/ajax/episode/list/$numId",
                headers("$BASE/watch/$slug"),
                useCache = true, timeoutMs = 10_000L, maxRetries = 1
            ) ?: return 0
        ) ?: return 0
        val max = Jsoup.parse(epHtml).select("a[data-ids][data-num]")
            .mapNotNull { it.attr("data-num").toIntOrNull() }
            .maxOrNull() ?: 0
        episodeCache[slug] = System.currentTimeMillis() to max
        return max
    }

    /** True when the slug's episode list actually contains [episode]. */
    fun slugHasEpisode(slug: String, episode: Int): Boolean {
        val max = slugMaxEpisode(slug)
        return max > 0 && episode in 1..max
    }

    /** AniList detail used to VERIFY a slug candidate (title variants, year,
     *  total episodes, synopsis). Mirrors the app's AniList fields exactly. */
    data class AniDetail(
        val romaji: String? = null,
        val english: String? = null,
        val native: String? = null,
        val synonyms: List<String> = emptyList(),
        val year: Int? = null,
        val episodes: Int? = null,
        val synopsis: String? = null,
        val isAdult: Boolean = false
    ) {
        /** All known title spellings, normalized for matching.
         *  Keys shorter than 15 chars are dropped: normalize() strips non-ASCII
         *  (Japanese/Chinese/Korean), so a native title like "Re:ゼロから始める異世界
         *  生活 4th season" collapses to "re4thseason" — a substring of virtually
         *  every "Nth Season" anime and a source of false title-overlap hits. */
        val titleKeys: Set<String> by lazy {
            (listOfNotNull(romaji, english, native) + synonyms)
                .filter { it.isNotBlank() }
                .map { normalize(it) }
                .filter { it.length >= 15 }
                .toSet()
        }

        /** All known title spellings, RAW (for part-by-part word-group matching). */
        val titleTexts: List<String> by lazy {
            (listOfNotNull(romaji, english, native) + synonyms)
                .filter { it.isNotBlank() }
                .distinct()
        }
    }

    private val anilistDetailCache = ConcurrentHashMap<Int, Pair<Long, AniDetail?>>()

    /**
     * Every real name of one anime: romaji + english + native + synonyms.
     * Feeds the wrong-title picker's name gate (only rows carrying one of
     * these names are shown). NO cache — one cheap query per detail screen.
     * Empty on any failure (gate fails open).
     */
    fun anilistNames(anilistId: Int): List<String> {
        if (anilistId <= 0) return emptyList()
        return runCatching {
            val text = AniListApi.query(
                """query {
                    Media(id: $anilistId, type: ANIME) {
                      title { romaji english native }
                      synonyms
                    }
                  }"""
            )
            val media = json.parseToJsonElement(text).jsonObject["data"]?.jsonObject
                ?.get("Media")?.jsonObject
            val title = media?.get("title")?.jsonObject
            buildList {
                title?.get("romaji")?.jsonPrimitive?.contentOrNull?.let { if (it.isNotBlank()) add(it) }
                title?.get("english")?.jsonPrimitive?.contentOrNull?.let { if (it.isNotBlank()) add(it) }
                title?.get("native")?.jsonPrimitive?.contentOrNull?.let { if (it.isNotBlank()) add(it) }
                media?.get("synonyms")?.jsonArray?.forEach { s ->
                    s.jsonPrimitive.contentOrNull?.takeIf { it.isNotBlank() }?.let { add(it) }
                }
            }
        }.getOrDefault(emptyList())
    }

    /** Full AniList detail (cached 10 min). Null on any failure. */
    fun anilistDetail(anilistId: Int): AniDetail? {
        if (anilistId <= 0) return null
        anilistDetailCache[anilistId]?.let { (ts, d) ->
            if (System.currentTimeMillis() - ts < SLUG_CACHE_TTL_MS) return d
            anilistDetailCache.remove(anilistId)
        }
        val d = runCatching {
            val text = AniListApi.query(
                """query {
                    Media(id: $anilistId, type: ANIME) {
                      title { romaji english native }
                      synonyms episodes seasonYear description
                      isAdult
                    }
                  }"""
            )
            val media = json.parseToJsonElement(text).jsonObject["data"]?.jsonObject
                ?.get("Media")?.jsonObject ?: return@runCatching null
            val title = media["title"]?.jsonObject
            AniDetail(
                romaji = title?.get("romaji")?.jsonPrimitive?.contentOrNull,
                english = title?.get("english")?.jsonPrimitive?.contentOrNull,
                native = title?.get("native")?.jsonPrimitive?.contentOrNull,
                synonyms = media["synonyms"]?.jsonArray
                    ?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList(),
                year = media["seasonYear"]?.jsonPrimitive?.contentOrNull?.toIntOrNull(),
                episodes = media["episodes"]?.jsonPrimitive?.contentOrNull?.toIntOrNull(),
                synopsis = media["description"]?.jsonPrimitive?.contentOrNull
                    ?.replace(Regex("""<[^>]*>"""), "")?.trim()?.takeIf { it.isNotBlank() },
                isAdult = media["isAdult"]?.jsonPrimitive?.booleanOrNull ?: false
            )
        }.getOrNull()
        anilistDetailCache[anilistId] = System.currentTimeMillis() to d
        return d
    }

    /** Total episode count for the requested entry from AniList (best-effort +
     *  cached). Used for the episode-count gate when verifying a slug. */
    fun anilistEpisodes(anilistId: Int): Int? {
        if (anilistId <= 0) return null
        anilistEpisodesCache[anilistId]?.let { (ts, eps) ->
            if (System.currentTimeMillis() - ts < SLUG_CACHE_TTL_MS) return eps
            anilistEpisodesCache.remove(anilistId)
        }
        val eps = runCatching {
            val text = AniListApi.query(
                "query { Media(id: $anilistId, type: ANIME) { episodes } }"
            )
            json.parseToJsonElement(text).jsonObject["data"]?.jsonObject
                ?.get("Media")?.jsonObject
                ?.get("episodes")?.jsonPrimitive?.content?.toIntOrNull()
        }.getOrNull()
        anilistEpisodesCache[anilistId] = System.currentTimeMillis() to eps
        return eps
    }

    /**
     * Servers available for an episode, from the aniwaves site itself. The
     * returned ids are the linkIds the /ajax/sources call needs. BYFMS and DGHG
     * are filtered out — they can't be extracted on-device.
     */
    fun listServers(slug: String, episode: Int, type: String): List<ServerRow> {
        val numId = Regex("""-(\d+)$""").find(slug)?.groupValues?.get(1) ?: return emptyList()
        val watchRef = "$BASE/watch/$slug"

        // 1) Episode rows for the anime (numeric id -> data-ids).
        val epHtml = htmlResult(
            ScraperEngine.fetchText(
                "$BASE/ajax/episode/list/$numId", headers(watchRef),
                useCache = true, timeoutMs = 10_000L, maxRetries = 1
            ) ?: return emptyList()
        ) ?: return emptyList()
        val rawId = Jsoup.parse(epHtml).select("a[data-ids][data-num]").firstOrNull {
            it.attr("data-num").toIntOrNull() == episode
        }?.attr("data-ids") ?: return emptyList()

        // rawId format: "<animeNumId>&eps=<n>".
        val parts = rawId.split("&eps=")
        if (parts.size != 2) return emptyList()

        // 2) Server rows for the episode.
        val serversHtml = htmlResult(
            ScraperEngine.fetchText(
                "$BASE/ajax/server/list?servers=${parts[0]}&eps=${parts[1]}",
                headers(watchRef), useCache = true, timeoutMs = 10_000L, maxRetries = 1
            ) ?: return emptyList()
        ) ?: return emptyList()

        val doc = runCatching { Jsoup.parse(serversHtml) }.getOrNull() ?: return emptyList()
        val out = mutableListOf<ServerRow>()
        for (typeDiv in doc.select("div.type")) {
            val blockType = typeDiv.attr("data-type")
            val ok = when {
                type == "dub" -> blockType == "dub"
                else -> blockType == "sub" || blockType == "ssub"
            }
            if (!ok) continue
            for (li in typeDiv.select("li[data-link-id]")) {
                val id = li.attr("data-link-id")
                if (id.isBlank()) continue
                val name = li.text().trim().ifBlank { li.attr("data-sv-id") }
                if (name.isBlank() || isSkipped(name)) continue
                out.add(ServerRow(id, name))
            }
        }
        // The site sometimes has no servers for the requested audio track on a
        // specific episode (e.g. a dub missing for a filler — Liar Game ep 17 has
        // no "dub" block at all). Fail visibly instead of silently: fall back to
        // the OTHER track so the user still gets a playable stream.
        if (out.isEmpty()) {
            val otherType = if (type == "dub") "sub" else "dub"
            for (typeDiv in doc.select("div.type")) {
                if (typeDiv.attr("data-type") != otherType) continue
                for (li in typeDiv.select("li[data-link-id]")) {
                    val id = li.attr("data-link-id")
                    if (id.isBlank()) continue
                    val name = li.text().trim().ifBlank { li.attr("data-sv-id") }
                    if (name.isBlank() || isSkipped(name)) continue
                    out.add(ServerRow(id, name))
                }
            }
        }
        return out
    }

    /**
     * ALL servers for an episode across every audio block (sub/ssub/dub), each
     * tagged with its track — koto-style. Download server picker only: lets the
     * user pick any server regardless of the current SUB/DUB toggle. Ids are
     * prefixed ("<type>:<linkId>"); labels carry the type ("SUB <name>").
     */
    fun listServersAllTypes(slug: String, episode: Int): List<ServerRow> {
        val numId = Regex("""-(\d+)$""").find(slug)?.groupValues?.get(1) ?: return emptyList()
        val watchRef = "$BASE/watch/$slug"

        val epHtml = htmlResult(
            ScraperEngine.fetchText(
                "$BASE/ajax/episode/list/$numId", headers(watchRef),
                useCache = true, timeoutMs = 10_000L, maxRetries = 1
            ) ?: return emptyList()
        ) ?: return emptyList()
        val rawId = Jsoup.parse(epHtml).select("a[data-ids][data-num]").firstOrNull {
            it.attr("data-num").toIntOrNull() == episode
        }?.attr("data-ids") ?: return emptyList()
        val parts = rawId.split("&eps=")
        if (parts.size != 2) return emptyList()

        val serversHtml = htmlResult(
            ScraperEngine.fetchText(
                "$BASE/ajax/server/list?servers=${parts[0]}&eps=${parts[1]}",
                headers(watchRef), useCache = true, timeoutMs = 10_000L, maxRetries = 1
            ) ?: return emptyList()
        ) ?: return emptyList()
        val doc = runCatching { Jsoup.parse(serversHtml) }.getOrNull() ?: return emptyList()

        val out = mutableListOf<ServerRow>()
        for (typeDiv in doc.select("div.type")) {
            val blockType = typeDiv.attr("data-type")
            if (blockType.isBlank()) continue
            for (li in typeDiv.select("li[data-link-id]")) {
                val id = li.attr("data-link-id")
                if (id.isBlank()) continue
                val name = li.text().trim().ifBlank { li.attr("data-sv-id") }
                if (name.isBlank() || isSkipped(name)) continue
                out.add(ServerRow("$blockType:$id", "${blockType.uppercase()} $name"))
            }
        }
        return out
    }

    /** Servers we must never offer on-device (TLS-impersonation DGHG, etc.).
     *  BYFMS is allowed — its attestation + PoW now run on-device. */
    private fun isSkipped(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("dghg") || n.contains("dood") || n.contains("playmogo") ||
            n.contains("myvidplay")
    }

    /** Resolve the embed URL + skip times for a server linkId. */
    fun resolveEmbed(linkId: String, slug: String?): EmbedResult? {
        val ref = if (slug.isNullOrBlank()) "$BASE/" else "$BASE/watch/$slug"
        val txt = ScraperEngine.fetchText(
            "$BASE/ajax/sources?id=${enc(linkId)}", headers(ref),
            timeoutMs = 10_000L, maxRetries = 1
        ) ?: return null
        val root = runCatching { json.parseToJsonElement(txt).jsonObject }.getOrNull() ?: return null
        val result = root["result"]?.jsonObject ?: return null
        val url = result["url"]?.jsonPrimitive?.content ?: return null
        val skip = result["skip_data"]?.jsonObject
        return EmbedResult(
            url = url,
            intro = skip?.get("intro")?.let { pairOf(it) },
            outro = skip?.get("outro")?.let { pairOf(it) }
        )
    }

    private fun pairOf(el: JsonElement): Pair<Int, Int>? = runCatching {
        val arr = el as JsonArray
        if (arr.size != 2) return@runCatching null
        (arr[0].jsonPrimitive.content.toIntOrNull() ?: 0) to
            (arr[1].jsonPrimitive.content.toIntOrNull() ?: 0)
    }.getOrNull()
}
