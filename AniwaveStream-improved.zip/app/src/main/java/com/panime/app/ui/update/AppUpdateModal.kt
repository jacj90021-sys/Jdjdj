package com.panime.app.ui.update

import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.panime.app.ui.theme.JetBrainsMono
import com.panime.app.ui.theme.WorkSans
import com.panime.app.update.GitHubUpdater
import java.io.File
import kotlinx.coroutines.delay

/**
 * Paper-Brutalism app-update flow — Compose port of DOWNLOAD_PIPELINE_AUDIT.html.
 * Now wired to the REAL updater:
 *  - Checks GitHub releases/latest (the public panime releases repo)
 *  - Real DownloadManager download with polled progress
 *  - READY view → FileProvider → system installer
 *
 * Two still-supported behaviors:
 *  1. HOME TAB — auto-check on open → prompt modal (Version + NEW badge + changelog,
 *     "Later"/"Update Now"). Update Now → DOWNLOADING with live % from DM.
 *  2. SETTINGS/PROFILE — "Check for Updates" skips the prompt and jumps straight
 *     into DOWNLOADING (or prompts first if you tap it again after download).
 *
 * Styling tokens (exact spec): #F4EFE6, #1A1A1A 2px, #EFE8DA, #D94132, hard 6px shadow.
 */
private val UpdateBg = Color(0xFFF4EFE6)
private val UpdateCardBg = Color(0xFFEFE8DA)
private val UpdateInk = Color(0xFF1A1A1A)
private val UpdateMuted = Color(0xFF666666)
private val UpdateRed = Color(0xFFD94132)

/** UI model for the modal. apkUrl comes from GitHubUpdater (null should never happen in the real path). */
data class AppUpdateInfo(
    val version: String,          // stripped, e.g. "2.2.0"
    val displayTag: String,       // original tag, e.g. "v2.2.0"
    val sizeLabel: String,
    val changelog: List<String>,
    val apkUrl: String
)

enum class UpdateModalView { HIDDEN, PROMPT, DOWNLOADING, READY }

class UpdateFlowState {
    var view by mutableStateOf(UpdateModalView.HIDDEN)
        private set
    var info by mutableStateOf<AppUpdateInfo?>(null)
        private set
    var percent by mutableIntStateOf(0)
        private set
    internal var runId by mutableIntStateOf(0)
        private set
    internal var downloadId by mutableLongStateOf(-1L)
        private set
    var apkFile by mutableStateOf<File?>(null)
        private set
    // How many times the prompt has been shown for this update (persisted).
    var promptCount by mutableIntStateOf(0)
        private set

    fun showPrompt(update: AppUpdateInfo, promptCount: Int = 0) {
        info = update
        this.promptCount = promptCount
        view = UpdateModalView.PROMPT
    }

    /** Jump straight to the Install view — for an APK we already downloaded. */
    fun showReady(update: AppUpdateInfo, file: File) {
        info = update
        markReady(file)
    }

    /** Used by the Settings/Profile "Check for Updates" — skip the prompt, go straight to downloading. */
    fun showDownloading(update: AppUpdateInfo) {
        info = update
        percent = 0
        downloadId = -1L
        apkFile = null
        runId++
        view = UpdateModalView.DOWNLOADING
    }

    /** Called from the UI; enqueuing + polling happens in rememberUpdateFlow's effect. */
    fun startDownload() {
        val cur = info ?: return
        if (cur.apkUrl.isBlank()) return
        percent = 0
        downloadId = -1L
        apkFile = null
        runId++
        view = UpdateModalView.DOWNLOADING
    }

    fun dismiss() {
        view = UpdateModalView.HIDDEN
    }

    internal fun setDownloadId(id: Long) { downloadId = id }
    internal fun setPercentFromFraction(f: Float) { percent = (f * 100f).toInt().coerceIn(0, 100) }
    internal fun setPercentInt(p: Int) { percent = p.coerceIn(0, 100) }
    internal fun markReady(file: File) { apkFile = file; percent = 100; view = UpdateModalView.READY }
}

@Composable
fun rememberUpdateFlow(library: com.panime.app.data.repository.UserLibraryStore? = null): UpdateFlowState {
    val state = remember { UpdateFlowState() }
    val context = LocalContext.current
    val appCtx = context.applicationContext

    LaunchedEffect(state.runId) {
        if (state.runId == 0 || state.view != UpdateModalView.DOWNLOADING) return@LaunchedEffect
        val curInfo = state.info ?: run { state.dismiss(); return@LaunchedEffect }
        state.setPercentInt(0)
        val id = GitHubUpdater.enqueue(appCtx, curInfo.apkUrl, "AniwaveStream ${curInfo.displayTag}")
        if (id == -1L) {
            Toast.makeText(appCtx, "Download could not start.", Toast.LENGTH_LONG).show()
            state.dismiss()
            return@LaunchedEffect
        }
        state.setDownloadId(id)
        while (true) {
            when (val p = GitHubUpdater.progress(appCtx, id)) {
                is GitHubUpdater.Progress.Done -> {
                    state.markReady(GitHubUpdater.destFile(appCtx))
                    // Remember the download so a later check offers Install
                    // instead of re-downloading or claiming "up to date".
                    library?.rememberUpdateDownloaded(curInfo.version)
                    return@LaunchedEffect
                }
                is GitHubUpdater.Progress.Failed -> {
                    Toast.makeText(appCtx, "Download failed.", Toast.LENGTH_LONG).show()
                    state.dismiss()
                    return@LaunchedEffect
                }
                is GitHubUpdater.Progress.Running -> state.setPercentFromFraction(p.fraction)
            }
            if (state.view != UpdateModalView.DOWNLOADING && state.view != UpdateModalView.READY) return@LaunchedEffect
            delay(250)
        }
    }
    return state
}

/** Delegates to the real updater (GitHub releases/latest → RC override). Null = no update. */
suspend fun checkForAppUpdate(): AppUpdateInfo? {
    val rel = GitHubUpdater.checkForUpdate() ?: return null
    return AppUpdateInfo(
        version = rel.version,
        displayTag = rel.displayTag,
        sizeLabel = rel.sizeLabel,
        changelog = rel.changelog,
        apkUrl = rel.apkUrl
    )
}

// ---------------------------------------------------------------------------
// Modal overlay
// ---------------------------------------------------------------------------
@Composable
fun AppUpdateOverlay(state: UpdateFlowState) {
    if (state.view == UpdateModalView.HIDDEN) return
    val info = state.info ?: return
    val context = LocalContext.current

    Dialog(
        onDismissRequest = { state.dismiss() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0x99000000)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier
                    .widthIn(max = 400.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .hardShadow(6.dp, UpdateInk)
                    .clip(RoundedCornerShape(16.dp))
                    .background(UpdateBg)
                    .border(2.dp, UpdateInk, RoundedCornerShape(16.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.Text(
                        "APP UPDATE",
                        fontFamily = WorkSans,
                        fontWeight = FontWeight.Black,
                        fontSize = 19.sp,
                        color = UpdateInk
                    )
                    androidx.compose.material3.Text(
                        "✕",
                        fontFamily = WorkSans,
                        fontWeight = FontWeight.Black,
                        fontSize = 17.sp,
                        color = UpdateInk,
                        modifier = Modifier.clickable { state.dismiss() }
                    )
                }

                when (state.view) {
                    UpdateModalView.PROMPT -> PromptView(state, info)
                    UpdateModalView.DOWNLOADING -> DownloadingView(state)
                    UpdateModalView.READY -> ReadyView(state, info) { file ->
                        GitHubUpdater.launchInstall(context, file)
                    }
                    UpdateModalView.HIDDEN -> Unit
                }
            }
        }
    }
}

@Composable
private fun PromptView(state: UpdateFlowState, info: AppUpdateInfo) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(UpdateCardBg)
            .border(2.dp, UpdateInk, RoundedCornerShape(10.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            androidx.compose.material3.Text(
                "Version ${info.displayTag}",
                fontFamily = WorkSans,
                fontWeight = FontWeight.Black,
                fontSize = 17.5.sp,
                color = UpdateInk
            )
            androidx.compose.material3.Text(
                info.sizeLabel,
                fontFamily = JetBrainsMono,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = UpdateMuted
            )
            if (state.promptCount > 1) {
                androidx.compose.material3.Text(
                    "Reminder #${state.promptCount}",
                    fontFamily = JetBrainsMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = UpdateRed
                )
            }
        }
        androidx.compose.material3.Text(
            "NEW UPDATE",
            fontFamily = WorkSans,
            fontWeight = FontWeight.Black,
            fontSize = 10.5.sp,
            color = Color.White,
            modifier = Modifier
                .border(1.dp, UpdateInk, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(UpdateRed)
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }

    Column(Modifier.padding(top = 12.dp)) {
        androidx.compose.material3.Text(
            "WHAT'S NEW:",
            fontFamily = JetBrainsMono,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 12.sp,
            color = UpdateMuted
        )
        Spacer(Modifier.height(8.dp))
        info.changelog.forEach { line ->
            Row(Modifier.padding(vertical = 3.dp)) {
                androidx.compose.material3.Text("•", fontFamily = WorkSans, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = UpdateInk)
                Spacer(Modifier.width(9.dp))
                androidx.compose.material3.Text(
                    line,
                    fontFamily = WorkSans,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    lineHeight = 19.sp,
                    color = UpdateInk
                )
            }
        }
    }

    Row(
        Modifier.fillMaxWidth().padding(top = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                .background(UpdateCardBg)
                .border(2.dp, UpdateInk, RoundedCornerShape(10.dp))
                .clickable { state.dismiss() }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Text("Later", fontFamily = WorkSans, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = UpdateInk)
        }
        Box(
            Modifier.weight(1f).hardShadow(3.dp, UpdateInk)
                .clip(RoundedCornerShape(10.dp))
                .background(UpdateRed)
                .border(2.dp, UpdateInk, RoundedCornerShape(10.dp))
                .clickable { state.startDownload() }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Text("Update Now", fontFamily = WorkSans, fontWeight = FontWeight.Black, fontSize = 15.sp, color = Color.White)
        }
    }
}

@Composable
private fun DownloadingView(state: UpdateFlowState) {
    val animated by animateFloatAsState(
        targetValue = state.percent / 100f,
        animationSpec = tween(durationMillis = 200),
        label = "update-progress-fill"
    )
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            androidx.compose.material3.Text("Downloading update...", fontFamily = JetBrainsMono, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = UpdateRed)
            androidx.compose.material3.Text("${state.percent}%", fontFamily = JetBrainsMono, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = UpdateInk)
        }
        Box(
            Modifier.fillMaxWidth().height(10.dp)
                .border(2.dp, UpdateInk, RoundedCornerShape(6.dp))
                .clip(RoundedCornerShape(6.dp))
                .background(UpdateCardBg)
        ) {
            Box(Modifier.fillMaxWidth(animated.coerceIn(0f, 1f)).height(10.dp).background(UpdateRed))
        }
    }
}

@Composable
private fun ReadyView(state: UpdateFlowState, info: AppUpdateInfo, onInstall: (File) -> Unit) {
    val file = state.apkFile
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        androidx.compose.material3.Text(
            "Update downloaded — ${info.displayTag}",
            fontFamily = WorkSans, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = UpdateInk
        )
        androidx.compose.material3.Text(
            "Tap Install to open the system installer. If prompted, allow \"Install unknown apps\" for this app.",
            fontFamily = WorkSans, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = UpdateMuted, lineHeight = 16.sp
        )
        Box(
            Modifier.fillMaxWidth().hardShadow(3.dp, UpdateInk)
                .clip(RoundedCornerShape(10.dp))
                .background(UpdateRed)
                .border(2.dp, UpdateInk, RoundedCornerShape(10.dp))
                .clickable(enabled = file != null) { file?.let(onInstall) }
                .padding(vertical = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Text("Install Now", fontFamily = WorkSans, fontWeight = FontWeight.Black, fontSize = 15.sp, color = Color.White)
        }
        androidx.compose.material3.Text(
            "Later",
            fontFamily = WorkSans, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = UpdateInk,
            modifier = Modifier.align(Alignment.CenterHorizontally).clickable { state.dismiss() }
                .padding(vertical = 6.dp)
        )
    }
}

private fun Modifier.hardShadow(offset: androidx.compose.ui.unit.Dp, color: Color): Modifier = drawBehind {
    drawRect(color = color, topLeft = Offset(offset.toPx(), offset.toPx()), size = size)
}
