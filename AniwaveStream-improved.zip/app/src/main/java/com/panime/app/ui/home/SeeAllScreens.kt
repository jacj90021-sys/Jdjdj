package com.panime.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding

import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.automirrored.filled.ArrowBack

import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable

import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.setValue
import com.panime.app.data.model.ContinueItem
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.WindowInsets
import com.panime.app.data.model.Anime
import com.panime.app.data.model.DayAiring
import com.panime.app.ui.components.AnimePosterCard
import com.panime.app.ui.components.AnimeRankedCard
import com.panime.app.ui.components.AnivaveScheduleCard
import com.panime.app.ui.components.SecondaryPillButton
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.PaperWhite
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary
import com.panime.app.ui.theme.TextMuted
import com.panime.app.viewmodel.HomeViewModel
import com.panime.app.viewmodel.SeeAllViewModel
import com.panime.app.data.repository.UserLibraryStore

import androidx.lifecycle.viewmodel.compose.viewModel
import com.panime.app.data.repository.AnimeRepository

enum class SeeAllKind { TRENDING, TOP_RATED, SEASONAL, NEW_RELEASES, UPCOMING, CONTINUE, TOP_100 }

private const val PAGE_SIZE = 50

/** Custom type filter shown as a nav row in every See All screen. */
private val TYPE_FILTERS = listOf("All", "TV", "Movie", "Airing")

/**
 * "View All" screen for a Home section.
 * - 3-column poster grid
 * - server-side pagination using AniList's pageInfo.lastPage for real total
 * - a custom type-nav row (All / TV / Movie / Airing) to filter the current page
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeeAllScreen(
    kind: SeeAllKind,
    viewModel: SeeAllViewModel,
    homeViewModel: HomeViewModel,
    apiProvider: String,
    onAnimeClick: (Anime) -> Unit,
    onBack: () -> Unit
) {
    // Network-loaded kinds fetch their own data via SeeAllViewModel (independent of Home, so
    // opening this screen never triggers a home reload). Home-derived kinds (Continue Watching,
    // New Releases) still read from the shared HomeViewModel snapshot.
    val seesAll by viewModel.state.collectAsStateWithLifecycle()
    val homeState by homeViewModel.state.collectAsStateWithLifecycle()

    var typeFilter by rememberSaveable { mutableStateOf("All") }

    val networkKind = kind in setOf(
        SeeAllKind.TRENDING, SeeAllKind.TOP_RATED, SeeAllKind.SEASONAL,
        SeeAllKind.UPCOMING, SeeAllKind.TOP_100, SeeAllKind.NEW_RELEASES
    )
    // Reload only when the kind or provider actually changed — returning from a
    // detail screen re-runs this, but the ViewModel keeps the page for the same
    // kind+provider, so the user's place is preserved.
    LaunchedEffect(kind, apiProvider) {
        if (networkKind) viewModel.load(kind, apiProvider)
    }

    val continueItems = homeState.continueWatching
    val all: List<Anime> = when (kind) {
        SeeAllKind.TRENDING -> if (networkKind) seesAll.items else homeState.trending
        SeeAllKind.TOP_RATED -> if (networkKind) seesAll.items else homeState.topRated
        SeeAllKind.SEASONAL -> if (networkKind) seesAll.items else homeState.seasonal
        SeeAllKind.UPCOMING -> if (networkKind) seesAll.items else homeState.upcoming
        SeeAllKind.TOP_100 -> if (networkKind) seesAll.items else homeState.top100
        SeeAllKind.CONTINUE -> continueItems.map { it.anime }
        SeeAllKind.NEW_RELEASES -> if (networkKind) seesAll.items else homeState.newReleaseEpisodes.map { it.anime }
    }
    val title = when (kind) {
        SeeAllKind.TRENDING -> "Trending Now"
        SeeAllKind.TOP_RATED -> "All Time Popular"
        SeeAllKind.SEASONAL -> "Popular This Season"
        SeeAllKind.UPCOMING -> "Upcoming Anime"
        SeeAllKind.CONTINUE -> "Continue Watching"
        SeeAllKind.NEW_RELEASES -> "Recently Updated"
        SeeAllKind.TOP_100 -> "Top 100 Anime"
    }

    // Long-press target for Continue Watching delete sheet (local val avoids null races).
    var deleteTarget by remember { mutableStateOf<ContinueItem?>(null) }
    val deleteSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // While a network kind is still loading (and we have nothing yet), show a shimmer — do not
    // show an empty grid that looks like the app "refreshed itself".
    if (networkKind && seesAll.loading && seesAll.items.isEmpty()) {
        SeeAllLoading(title = title, onBack = onBack)
        return
    }
    if (networkKind && seesAll.error != null && seesAll.items.isEmpty()) {
        SeeAllError(error = seesAll.error ?: "Failed", onRetry = { viewModel.retry(kind, apiProvider) }, onBack = onBack)
        return
    }

    // Apply the type filter to current page items.
    val filtered = remember(all, typeFilter) {
        if (typeFilter == "All") all else all.filter { matchesType(it, typeFilter) }
    }
    // Server-side pagination: pageCount is the *resolved* last page from the
    // repository (real anime count / binary probe) — never AniList's fake 100 cap.
    val pageCount = if (networkKind) {
        maxOf(1, seesAll.lastPage)
    } else {
        maxOf(1, (all.size + PAGE_SIZE - 1) / PAGE_SIZE)
    }
    val safePage = seesAll.currentPage.coerceIn(1, pageCount)

    // Pad to a full multiple of 3 so the last row is never left dangling (no dead space).
    val fillers = (3 - (filtered.size % 3)) % 3
    val displayItems = filtered + List(fillers) { null }

    val gridState = rememberLazyGridState()

    Scaffold(
        containerColor = Background,
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets(0, 0, 0, 0),
                title = {
                    Text(
                        title,
                        color = TextPrimary,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                },
                actions = {
                    if (kind == SeeAllKind.CONTINUE && continueItems.isNotEmpty()) {
                        IconButton(onClick = { homeViewModel.clearAllContinueWatching() }) {
                            Icon(
                                Icons.Filled.DeleteSweep,
                                contentDescription = "Clear all continue watching",
                                tint = TextMuted
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            state = gridState,
            columns = GridCells.Fixed(3),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Filter chips (full-width header row)
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TYPE_FILTERS.forEach { t ->
                        val active = t == typeFilter
                        Box(
                            Modifier
                                .border(2.dp, if (active) Flame else Hairline)
                                .background(if (active) Flame else Surface)
                                .clickable { typeFilter = t }
                                .padding(horizontal = 16.dp, vertical = 9.dp)
                        ) {
                            Text(
                                t.uppercase(),
                                color = if (active) PaperWhite else TextPrimary,
                                fontFamily = PlexMono,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        }
                    }
                }
            }

            // Poster grid (3 fixed columns, cards fill their cell). Nulls render as empty
            // placeholder cells so the final row is always complete.
            // IMPORTANT: filler keys must be unique per index. Using indexOf(null) made every
            // null share one key when size % 3 == 1 (two fillers) → Compose crash on open.
            itemsIndexed(
                displayItems,
                key = { index, anime -> anime?.id?.let { "anime-$it" } ?: "filler-$index" }
            ) { _, anime ->
                if (anime != null) {
                    if (kind == SeeAllKind.TOP_100) {
                        val posOnPage = filtered.indexOf(anime)
                        val rank = (seesAll.currentPage - 1) * PAGE_SIZE + posOnPage + 1
                        AnimeRankedCard(
                            anime = anime,
                            rank = rank,
                            onClick = { onAnimeClick(anime) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else if (kind == SeeAllKind.CONTINUE) {
                        val ci = continueItems.firstOrNull { it.anime.id == anime.id }
                        AnimePosterCard(
                            anime = anime,
                            onClick = { onAnimeClick(anime) },
                            onLongPress = { if (ci != null) deleteTarget = ci },
                            modifier = Modifier.fillMaxWidth(),
                            watchedProgress = ci?.completedCount,
                            totalEpisodes = ci?.totalEpisodes ?: anime.episodes
                            // No Watching/Completed status badge on Continue See All
                        )
                    } else {
                        AnimePosterCard(
                            anime = anime,
                            onClick = { onAnimeClick(anime) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                } else {
                    Spacer(Modifier.height(1.dp))
                }
            }

            // Pagination footer (full-width)
            item(span = { GridItemSpan(maxLineSpan) }) {
                PaginationBar(
                    page = safePage,
                    pageCount = pageCount,
                    onPage = { p ->
                        if (networkKind) viewModel.loadPage(kind, p)
                    }
                )
            }
        }
    }

    // Long-press → bottom sheet with Cancel / Delete for one Continue Watching entry.
    val delItem = deleteTarget
    if (kind == SeeAllKind.CONTINUE && delItem != null) {
        ModalBottomSheet(
            onDismissRequest = { deleteTarget = null },
            sheetState = deleteSheetState,
            containerColor = Surface
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Text(
                    delItem.anime.title,
                    color = TextPrimary,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(Modifier.height(6.dp))
                val total = delItem.totalEpisodes
                val done = delItem.completedCount
                Text(
                    "Remove from Continue Watching?\nProgress: $done / ${if (total > 0) total else "?"}",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(20.dp))
                TextButton(
                    onClick = {
                        homeViewModel.clearContinueWatching(delItem.anime.id)
                        deleteTarget = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColors(contentColor = Flame)
                ) {
                    Icon(Icons.Filled.Delete, contentDescription = null, tint = Flame)
                    Spacer(Modifier.width(8.dp))
                    Text("Delete", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                TextButton(
                    onClick = { deleteTarget = null },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.textButtonColors(contentColor = TextMuted)
                ) {
                    Text("Cancel", fontSize = 15.sp)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

}

private fun matchesType(anime: Anime, type: String): Boolean {
    return when (type) {
        "TV" -> anime.type.equals("TV", true) || anime.type.equals("TV Series", true)
        "Movie" -> anime.type.equals("Movie", true) || anime.type.equals("Film", true)
        "Airing" -> anime.status.equals("Airing", true) || anime.status.equals("Currently Airing", true)
        else -> true
    }
}

@Composable
internal fun PaginationBar(page: Int, pageCount: Int, onPage: (Int) -> Unit) {
    if (pageCount <= 1) return
    var editing by remember(page) { mutableStateOf(false) }

    Row(
        Modifier
            .fillMaxWidth()
            .background(Background)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        TextButton(
            onClick = {
                editing = false
                onPage((page - 1).coerceAtLeast(1))
            },
            enabled = page > 1,
            colors = ButtonDefaults.textButtonColors(contentColor = TextPrimary),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
        ) { Text("‹ Prev", fontSize = 13.sp) }

        Spacer(Modifier.width(12.dp))

        if (editing) {
            var tv by remember(page) {
                mutableStateOf(
                    androidx.compose.ui.text.input.TextFieldValue(
                        text = "",
                        selection = androidx.compose.ui.text.TextRange(0)
                    )
                )
            }
            // BasicTextField (NOT Material3's TextField): the text color we set
            // here is authoritative — M3 TextField overrides textStyle color
            // internally, which is the actual reason typed digits stayed
            // invisible. BasicTextField has no such override layer.
            // Auto-focus on appear so the number keyboard pops up immediately.
            val focusRequester = remember { FocusRequester() }
            LaunchedEffect(editing) {
                if (editing) {
                    // Give the field one frame to lay out before stealing focus —
                    // same-frame requestFocus can silently no-op on some devices.
                    kotlinx.coroutines.delay(50)
                    focusRequester.requestFocus()
                }
            }
            BasicTextField(
                value = tv,
                onValueChange = { tv = it.copy(text = it.text.filter { c -> c.isDigit() }) },
                modifier = Modifier
                    .width(44.dp)
                    .height(32.dp)
                    .focusRequester(focusRequester)
                    .background(SurfaceRaised, RoundedCornerShape(4.dp))
                    .border(1.dp, Hairline, RoundedCornerShape(4.dp)),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontFamily = PlexMono,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                ),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(Flame),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Go
                ),
                keyboardActions = KeyboardActions(onGo = {
                    val raw = tv.text
                    val num = raw.toIntOrNull() ?: page
                    val target = num.coerceIn(1, pageCount)
                    editing = false
                    onPage(target)
                })
            )
        } else {
            Text(
                "$page",
                color = Flame,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .width(44.dp)
                    .height(32.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { editing = true }
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }

        Text("/ $pageCount", color = TextMuted, fontSize = 13.sp)

        Spacer(Modifier.width(12.dp))

        TextButton(
            onClick = {
                editing = false
                onPage((page + 1).coerceAtMost(pageCount))
            },
            enabled = page < pageCount,
            colors = ButtonDefaults.textButtonColors(contentColor = TextPrimary),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
        ) { Text("Next ›", fontSize = 13.sp) }
    }
}

/** Shimmer placeholder shown while a See All screen fetches its own data (so it never looks
 *  like the app "refreshed itself" with an empty/transient grid). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SeeAllLoading(title: String, onBack: () -> Unit) {
    Scaffold(
        containerColor = Background,
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets(0, 0, 0, 0),
                title = {
                    Text(title, color = TextPrimary, fontFamily = Bricolage, fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                }
            )
        }
    ) { padding ->
        Box(
            Modifier.fillMaxSize().padding(padding),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Flame)
        }
    }
}

/** Dark error screen for a failed See All fetch — Retry + Back, no white flash. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SeeAllError(error: String, onRetry: () -> Unit, onBack: () -> Unit) {
    Scaffold(
        containerColor = Background,
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets(0, 0, 0, 0),
                title = { Text("Error", color = TextPrimary, fontFamily = Bricolage, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(error, color = Flame, fontFamily = PlexMono, fontSize = 12.sp)
            Spacer(Modifier.height(16.dp))
            SecondaryPillButton(text = "Retry", leadingIcon = Icons.Default.Refresh, onClick = onRetry)
        }
    }
}

/**
 * Weekly Schedule "View All" — SAME card design as Home (day pills + timed rows),
 * just opened full-screen with its own day selector. Selecting a day shows that
 * day's full broadcast list.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeeklyScheduleScreen(
    repository: AnimeRepository,
    onAnimeClick: (Anime) -> Unit,
    onBack: () -> Unit
) {
    val vm: HomeViewModel = viewModel(factory = HomeViewModel.factory(repository, UserLibraryStore(LocalContext.current)))
    val state by vm.state.collectAsStateWithLifecycle()
    var activeDayIndex by remember { mutableIntStateOf(state.scheduleDayIndex) }
    val shows: List<DayAiring> = state.schedule

    Scaffold(
        containerColor = Background,
        contentWindowInsets = WindowInsets(0),
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets(0, 0, 0, 0),
                title = {
                    Text(
                        "Weekly Schedule",
                        color = TextPrimary,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            item {
                // Same Home card design, but show ALL rows for the selected day.
                AnivaveScheduleCard(
                    activeDayIndex = activeDayIndex,
                    onDay = { activeDayIndex = it; vm.setScheduleDayIndex(it) },
                    shows = shows,
                    days = state.scheduleDays,
                    onItem = {
                        onAnimeClick(
                            Anime(
                                id = it.animeId,
                                title = it.title,
                                posterUrl = it.cover
                            )
                        )
                    },
                    maxRows = Int.MAX_VALUE,
                    loading = state.scheduleLoading,
                    error = state.scheduleError,
                    onRetry = { vm.retrySchedule() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
