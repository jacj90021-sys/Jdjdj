package com.panime.app.util

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement

/**
 * JSON `null` (and any wrong-typed element) must read as absent, never throw.
 *
 * kotlinx.serialization's built-in `JsonElement.jsonArray` throws for anything
 * that is not a JsonArray — INCLUDING a JSON null literal, because indexing a
 * JsonObject returns a non-null `JsonNull` for `"key": null`. So the common
 * idiom `obj["tracks"]?.jsonArray` crashes the entire provider the moment an
 * API answers `"tracks": null` (anidap returns exactly that for its yuki / neko
 * / loli sub servers). Use [jsonArrayOrNull] there instead.
 */
val JsonElement?.jsonArrayOrNull: JsonArray?
    get() = this as? JsonArray
