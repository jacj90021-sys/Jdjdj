package com.panime.app.data.provider

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Remote-controllable provider configuration.
 *
 * The APK ships a bundled default (see [DEFAULT_JSON]). At runtime the app may
 * fetch a newer config from a URL you control. ONLY declarative values are
 * honored here — endpoints, headers, referers, timeouts, priority, enabled flags,
 * and version. The scraper ENGINE + provider code live in the APK; the remote
 * config never delivers executable code (no scripts/classes are loaded).
 */
@Serializable
data class RemoteProviderConfig(
    /** Monotonic version. If remote < installed engine version, config is rejected. */
    val version: Int = 1,
    /** Installed engine version this config is compatible with. */
    val engineVersion: Int = ENGINE_VERSION,
    val providers: List<ProviderCfg> = emptyList(),
    /**
     * Remote ad control. Absent (null) = ads OFF (safe fallback). Only present
     * when the remote config explicitly carries an "ads" section.
     */
    val ads: RemoteAdConfig? = null
) {
    companion object {
        const val ENGINE_VERSION = 1

        /** Bundle default — every provider enabled at default priority, ads OFF. */
        val DEFAULT = RemoteProviderConfig(
            version = 1,
            providers = listOf(
                ProviderCfg("anidb", enabled = true, priority = 50),
                ProviderCfg("anidap", enabled = true, priority = 60),
                ProviderCfg("anikoto", enabled = true, priority = 55),
                ProviderCfg("anizone", enabled = true, priority = 40),
                ProviderCfg("anikage", enabled = true, priority = 30),
                ProviderCfg("just4anime", enabled = true, priority = 20),
                ProviderCfg("aniwaves", enabled = true, priority = 65, backendRequired = false),
                ProviderCfg("animenosub", enabled = true, priority = 50)
            ),
            ads = RemoteAdConfig.DEFAULT // enabled=false → safe: no ads by default
        )

        val DEFAULT_JSON = Json.encodeToString(serializer(), DEFAULT)
    }
}

/**
 * Remote ad control flags.
 *
 * [enabled] is the master switch: false (default) = no ads at all, regardless
 * of the per-format flags. The per-format flags default to true so a config
 * like `{ "ads": { "enabled": true } }` enables all formats; a format is only
 * disabled when the remote config explicitly sets its flag to false.
 *
 * The AdMob App ID + ad unit IDs are NOT part of this config — they stay in
 * BuildConfig. The remote config only controls whether/how ads are allowed.
 */
@Serializable
data class RemoteAdConfig(
    val enabled: Boolean = false,
    val bannerEnabled: Boolean = true,
    val interstitialEnabled: Boolean = true,
    val rewardedEnabled: Boolean = true
) {
    companion object {
        /** Bundle default — master OFF, all formats allowed if ever enabled. */
        val DEFAULT = RemoteAdConfig()
    }
}

@Serializable
data class ProviderCfg(
    val id: String,
    val enabled: Boolean = true,
    /** Higher = tried first on auto-select. */
    val priority: Int = 50,
    /** Per-provider timeout in seconds (default 60). */
    val timeoutSec: Int = 60,
    /** True if the provider must use a server backend. */
    val backendRequired: Boolean = false,
    /** Optional endpoint overrides (safe, declarative only). */
    val baseUrl: String? = null,
    /** Optional referer override for the m3u8 fetch. */
    val referer: String? = null,
    /** Health-check path (relative to baseUrl) for a lightweight liveness probe. */
    val healthPath: String? = null
)

object RemoteConfigParser {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun parse(jsonText: String): RemoteProviderConfig? = runCatching {
        json.decodeFromString<RemoteProviderConfig>(jsonText)
    }.getOrNull()

    /**
     * Validate a remote config against the installed engine. Returns null if the
     * config is stale/incompatible so the app keeps using the bundled default
     * (safe rollback). Never throws.
     */
    fun safeMerge(remote: RemoteProviderConfig?): RemoteProviderConfig {
        if (remote == null) return RemoteProviderConfig.DEFAULT
        if (remote.engineVersion > RemoteProviderConfig.ENGINE_VERSION) {
            // Config wants a newer engine than we have — reject, keep bundled.
            return RemoteProviderConfig.DEFAULT
        }
        if (remote.version < 1) return RemoteProviderConfig.DEFAULT
        return remote
    }
}
