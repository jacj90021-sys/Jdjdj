@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.panime.app.player

import android.net.Uri
import android.util.Base64
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.TransferListener
import java.io.ByteArrayOutputStream

/**
 * ExoPlayer [DataSource] that transparently decrypts flixcloud.cc CDN responses.
 *
 * Matches the exact logic of flixcloud.cc's custom hls.js:
 *  1. If response starts with "#EXTM3U" → already plain text, pass through
 *  2. Try base64 decode → if fails, pass through (binary segment data)
 *  3. XOR-decrypt → only USE the result if it starts with "#EXTM3U"
 *  4. If decrypted result is NOT "#EXTM3U" → discard, return original bytes
 *
 * This prevents corruption of binary TS/segment data that happens to be valid base64.
 */
@UnstableApi
class FlixcloudDecryptingDataSource(
    private val upstream: DataSource,
    private val xorKey: ByteArray
) : DataSource {

    private var decryptedBytes: ByteArray? = null
    private var readOffset = 0

    override fun addTransferListener(transferListener: TransferListener) {
        upstream.addTransferListener(transferListener)
    }

    override fun getUri(): Uri? = upstream.uri

    override fun open(dataSpec: DataSpec): Long {
        val uri = dataSpec.uri
        val resultLen = upstream.open(dataSpec)
        val raw = readAllUpstream(upstream)
        Log.d("FlixDecrypt", "open: uri=$uri rawSize=${raw?.size ?: 0} upstreamLen=$resultLen")

        if (raw != null && raw.isNotEmpty()) {
            val decrypted = xorDecryptIfM3u8(raw)
            val wasDecrypted = decrypted !== raw
            Log.d("FlixDecrypt", "open: wasDecrypted=$wasDecrypted resultSize=${decrypted.size}")
            decryptedBytes = decrypted
            readOffset = 0
            return decrypted.size.toLong()
        }

        return resultLen
    }

    override fun read(target: ByteArray, offset: Int, length: Int): Int {
        val data = decryptedBytes ?: return upstream.read(target, offset, length)
        val remaining = data.size - readOffset
        if (remaining <= 0) return C.RESULT_END_OF_INPUT
        val toRead = minOf(length, remaining)
        System.arraycopy(data, readOffset, target, offset, toRead)
        readOffset += toRead
        return toRead
    }

    override fun close() {
        decryptedBytes = null
        readOffset = 0
        upstream.close()
    }

    private fun readAllUpstream(source: DataSource): ByteArray? {
        val buf = ByteArrayOutputStream()
        val tmp = ByteArray(8192)
        while (true) {
            val n = source.read(tmp, 0, tmp.size)
            if (n == C.RESULT_END_OF_INPUT || n <= 0) break
            buf.write(tmp, 0, n)
        }
        return if (buf.size() > 0) buf.toByteArray() else null
    }

    /**
     * Matches flixcloud.cc's custom hls.js XOR decryption logic exactly:
     *  - Already #EXTM3U? Pass through (plain text m3u8).
     *  - Not valid base64? Pass through (binary segment data).
     *  - Base64-decode + XOR → only replace if result starts with #EXTM3U.
     *  - Otherwise discard decrypted result and return original bytes.
     */
    private fun xorDecryptIfM3u8(raw: ByteArray): ByteArray {
        val text = try {
            String(raw, Charsets.UTF_8).trim()
        } catch (_: Exception) {
            Log.d("FlixDecrypt", "not valid UTF-8, pass through ${raw.size}B")
            return raw
        }

        if (text.startsWith("#EXTM3U")) {
            Log.d("FlixDecrypt", "already #EXTM3U, pass through")
            return raw
        }

        val decoded = try {
            Base64.decode(text, Base64.NO_WRAP)
        } catch (_: Exception) {
            Log.d("FlixDecrypt", "not valid base64, pass through ${raw.size}B")
            return raw
        }

        val result = ByteArray(decoded.size)
        for (i in decoded.indices) {
            result[i] = (decoded[i].toInt() xor xorKey[i % xorKey.size].toInt()).toByte()
        }

        // KEY: only use decrypted result if it's an m3u8 playlist (matches hls.js)
        val resultStr = try {
            String(result, 0, minOf(64, result.size), Charsets.UTF_8)
        } catch (_: Exception) { "" }

        if (resultStr.startsWith("#EXTM3U")) {
            Log.d("FlixDecrypt", "base64+XOR decrypted to #EXTM3U (${raw.size}B -> ${result.size}B)")
            return result
        }

        Log.d("FlixDecrypt", "base64 decoded but not #EXTM3U after XOR, pass through original ${raw.size}B")
        return raw
    }

    class Factory(
        private val xorKey: ByteArray?,
        private val userAgent: String = "AniwaveStream/1.0 (Android)",
        private val connectTimeoutMs: Int = 30_000,
        private val readTimeoutMs: Int = 30_000,
        private val defaultRequestProperties: Map<String, String> = emptyMap(),
        private val upstreamFactory: DataSource.Factory? = null
    ) : DataSource.Factory {

        override fun createDataSource(): DataSource {
            val upstream = if (upstreamFactory != null) {
                upstreamFactory.createDataSource()
            } else {
                val httpFactory = DefaultHttpDataSource.Factory()
                    .setUserAgent(userAgent)
                    .setConnectTimeoutMs(connectTimeoutMs)
                    .setReadTimeoutMs(readTimeoutMs)
                    .setAllowCrossProtocolRedirects(true)
                    .apply {
                        if (defaultRequestProperties.isNotEmpty()) {
                            setDefaultRequestProperties(defaultRequestProperties)
                        }
                    }
                httpFactory.createDataSource()
            }
            val key = xorKey
            return if (key != null && key.size == 32) {
                FlixcloudDecryptingDataSource(upstream, key)
            } else {
                upstream
            }
        }
    }
}
