package com.panime.app.ad

import android.app.Activity
import android.content.Context
import android.view.View

/**
 * Abstraction over a mobile ad SDK so the rest of the app can drive ads without
 * caring which network is compiled in.
 *
 * One implementation is selected at build time via the `-PadsNetwork` Gradle
 * flag (`admob` default, or `unity`). [AdManager] holds all network-agnostic
 * policy (remote-config gating, cooldowns) and delegates here for the actual
 * SDK work.
 */
interface AdNetwork {
    /** Short tag for logcat. */
    val tag: String

    /**
     * True when the underlying SDK can run on this device. For AdMob that is
     * Google Play Services presence; for Unity Ads it is the SDK's own
     * support check.
     */
    fun isSupported(context: Context): Boolean

    /** Initialize the SDK once at app startup. Must preload allowed formats. */
    fun initialize(context: Context)

    /** Reload a fresh ad after one has been shown/consumed. */
    fun preload(context: Context)

    /**
     * Show a full-screen interstitial. Returns true only if an ad was actually
     * shown. [onDismissed] must fire once the ad is gone (shown then closed, or
     * failed to show) and must trigger a reload.
     */
    fun showInterstitial(activity: Activity, onDismissed: () -> Unit): Boolean

    /**
     * Show a rewarded ad. Returns true only if an ad was actually shown.
     * [onReward] fires when the user earned the reward; [onDismissed] fires
     * once the ad is gone. Both sides must trigger a reload.
     */
    fun showRewarded(
        activity: Activity,
        onReward: () -> Unit,
        onDismissed: () -> Unit
    ): Boolean

    /**
     * Build an embeddable banner view, or null when banners don't apply for
     * this network. Returned view must already be loading once the call
     * returns (the caller drops it straight into the view tree).
     */
    fun createBanner(context: Context): View?
}