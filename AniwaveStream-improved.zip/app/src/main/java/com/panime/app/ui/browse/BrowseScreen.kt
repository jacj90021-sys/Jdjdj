package com.panime.app.ui.browse

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.panime.app.data.model.Anime
import com.panime.app.data.model.BrowseGenres
import com.panime.app.data.model.GenreChip
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.data.repository.UserLibraryStore
import com.panime.app.ui.components.ErrorBox
import com.panime.app.ui.components.PosterGridShimmer
import com.panime.app.ui.home.PaginationBar
import com.panime.app.ui.theme.AnivaveArt
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.PaperWhite
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary
import com.panime.app.ui.theme.Void

/** Top-level filter modes for the Browse hub. */
private enum class BrowseMode { GENRE, LETTER, YEAR }

private val LETTER_RANGES = listOf(
    "All",
    "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
    "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
)

/** Decade label for a year, e.g. 1997 -> "1990s". */
private fun decadeOf(year: Int): String = "${(year / 10) * 10}s"

@Composable
fun BrowseScreen(
    repository: AnimeRepository,
    library: UserLibraryStore,
    onAnimeClick: (Anime) -> Unit
) {
    val apiProvider by library.apiProvider.collectAsStateWithLifecycle("anilist")
    // User-visible state (mode, filters, page) is rememberSaveable so it survives
    // opening an anime and coming back — without it the list resets to page 1.
    var mode by rememberSaveable { mutableStateOf(BrowseMode.LETTER) }
    // Genre chips come from the data source itself (koto scrapes its own
    // /genre/<slug> header nav — 48 real genres) — never a hardcoded list of ours.
    var genres by remember { mutableStateOf(BrowseGenres) }
    var selectedGenre by rememberSaveable { mutableIntStateOf(BrowseGenres.first().id) }
    var selectedLetter by rememberSaveable { mutableStateOf("All") }
    var selectedDecade by rememberSaveable { mutableStateOf<String?>(null) }
    var selectedYear by rememberSaveable { mutableStateOf<Int?>(null) }

    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<Throwable?>(null) }
    var items by remember { mutableStateOf<List<Anime>>(emptyList()) }
    var currentPage by rememberSaveable { mutableIntStateOf(1) }
    var lastPage by rememberSaveable { mutableIntStateOf(1) }

    var reloadToken by remember { mutableIntStateOf(0) }
    // Tracks which provider the loaded genres/years/results came from — a switch
    // (koto <-> wave) must wipe the previous provider's data and selections.
    var lastProvider by rememberSaveable { mutableStateOf("") }

    // Release years come from the data source itself (anikoto.cz scrapes its own
    // /filter year list) — never a hardcoded range/cap of ours.
    var availableYears by remember { mutableStateOf<List<Int>>(emptyList()) }
    LaunchedEffect(reloadToken, apiProvider) {
        val providerChanged = lastProvider != apiProvider
        lastProvider = apiProvider
        availableYears = repository.browseYears().getOrDefault(emptyList())
        genres = repository.genres().getOrDefault(BrowseGenres)
        if (providerChanged) {
            // API provider switched: the previous provider's genres, years and
            // results must NOT survive — reset everything to the new provider's
            // first options (and force a fresh fetch below).
            selectedGenre = genres.firstOrNull()?.id ?: BrowseGenres.first().id
            val newest = availableYears.firstOrNull()
            selectedDecade = newest?.let { decadeOf(it) }
            selectedYear = newest
            selectedLetter = "All"
            items = emptyList()
            currentPage = 1
            lastPage = 1
        } else {
            // If the user is already on the Genre tab but the provider's list
            // landed late (or the selection isn't in it), default to the first chip.
            if (mode == BrowseMode.GENRE && genres.none { it.id == selectedGenre }) {
                selectedGenre = genres.firstOrNull()?.id ?: BrowseGenres.first().id
            }
            // If the user is already on the Year tab but the source list landed
            // late, default the selection to the newest available year.
            if (mode == BrowseMode.YEAR && selectedYear == null && availableYears.isNotEmpty()) {
                val newest = availableYears.first()
                selectedDecade = decadeOf(newest)
                selectedYear = newest
            }
        }
    }

    // (Re)load whenever the active filter OR page changes.
    // lastPage comes from the repository's real-page detection (AniList's pageInfo
    // often lies with a fixed 1/100 cap — we never seed UI with that default).
    LaunchedEffect(mode, selectedGenre, selectedLetter, selectedDecade, selectedYear, currentPage, reloadToken, apiProvider) {
        if (mode == BrowseMode.YEAR && selectedYear == null) {
            loading = false; error = null; items = emptyList(); lastPage = 1
            return@LaunchedEffect
        }
        loading = true; error = null
        // Drop the previous filter's page count so the bar never flashes "1/100"
        // (or last year's total) while the new request is in flight.
        if (currentPage == 1) lastPage = 1

        val result = when (mode) {
            BrowseMode.GENRE -> repository.byGenrePaged(selectedGenre, currentPage)
            BrowseMode.LETTER -> {
                val letter = selectedLetter ?: "All"
                if (letter == "All") repository.allAnimePaged(currentPage)
                else repository.byLetterPaged(letter, currentPage)
            }
            BrowseMode.YEAR -> repository.byYearPaged(selectedYear ?: return@LaunchedEffect, currentPage)
        }
        result
            .onSuccess { pr ->
                items = pr.items
                // Trust only the resolved last page (probed from real anime counts).
                lastPage = pr.lastPage.coerceAtLeast(1)
                // Clamp current page if the filter has fewer pages than we asked for.
                if (currentPage > lastPage) currentPage = lastPage
                loading = false; error = null
            }
            .onFailure { e ->
                error = e; loading = false
            }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        Text(
            "Browse",
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
            fontFamily = Bricolage,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(16.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            BrowseTopBox(
                label = "All Anime",
                selected = mode == BrowseMode.LETTER,
                onClick = {
                    mode = BrowseMode.LETTER
                    selectedLetter = "All"
                    currentPage = 1
                }
            )
            BrowseTopBox(
                label = "Genre",
                selected = mode == BrowseMode.GENRE,
                onClick = {
                    mode = BrowseMode.GENRE
                    currentPage = 1
                }
            )
            BrowseTopBox(
                label = "Release Year",
                selected = mode == BrowseMode.YEAR,
                onClick = {
                    mode = BrowseMode.YEAR
                    currentPage = 1
                    if (selectedDecade == null) {
                        val newest = availableYears.firstOrNull()
                        selectedDecade = newest?.let { decadeOf(it) }
                        selectedYear = newest
                    }
                }
            )
        }

        Spacer(Modifier.height(12.dp))

        when (mode) {
            BrowseMode.GENRE -> GenreChips(
                genres = genres,
                selectedGenre = selectedGenre,
                onSelect = { selectedGenre = it; currentPage = 1 }
            )
            BrowseMode.LETTER -> LetterRangeSelector(
                selectedLetter = selectedLetter,
                onSelect = { range ->
                    selectedLetter = range
                    currentPage = 1
                }
            )
            BrowseMode.YEAR -> DecadeYearSelector(
                availableYears = availableYears,
                selectedDecade = selectedDecade,
                selectedYear = selectedYear,
                onDecade = { decade ->
                    selectedDecade = decade
                    availableYears.firstOrNull { decadeOf(it) == decade }?.let { selectedYear = it }
                    currentPage = 1
                },
                onYear = { selectedYear = it; currentPage = 1 }
            )
        }

        Spacer(Modifier.height(12.dp))

        when {
            loading -> PosterGridShimmer(modifier = Modifier.fillMaxSize())
            error != null -> {
                val err = error
                if (err != null) ErrorBox(err) { reloadToken++ }
            }
            items.isEmpty() -> ErrorBox("No anime found for this filter.") {
                reloadToken++
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(items, key = { it.id }) { anime ->
                    Column(Modifier.clickable { onAnimeClick(anime) }) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(2f / 3f)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, Hairline, RoundedCornerShape(14.dp))
                        ) {
                            AnivaveArt(anime = anime, modifier = Modifier.fillMaxSize())
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            anime.title,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = TextPrimary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                        anime.year?.let { yr ->
                            Spacer(Modifier.height(2.dp))
                            Text(
                                yr.toString(),
                                color = TextSecondary,
                                fontFamily = PlexMono,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Pagination footer (full-width)
                if (lastPage > 1) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        PaginationBar(
                            page = currentPage,
                            pageCount = lastPage,
                            onPage = { p -> currentPage = p }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BrowseTopBox(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .border(2.dp, if (selected) Flame else Hairline)
            .background(if (selected) Flame else Surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(
            label.uppercase(),
            color = if (selected) PaperWhite else TextPrimary,
            fontFamily = PlexMono,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun GenreChips(genres: List<GenreChip>, selectedGenre: Int, onSelect: (Int) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(genres, key = { it.id }) { genre ->
            val selected = genre.id == selectedGenre
            Box(
                Modifier
                    .border(2.dp, if (selected) Flame else Hairline)
                    .background(if (selected) Flame else Surface)
                    .clickable { onSelect(genre.id) }
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            ) {
                Text(
                    genre.name.uppercase(),
                    color = if (selected) PaperWhite else TextPrimary,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp
                )
            }
        }
    }
}

@Composable
private fun LetterRangeSelector(
    selectedLetter: String?,
    onSelect: (String) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(LETTER_RANGES) { range ->
            val isSel = range == selectedLetter
            Box(
                Modifier
                    .size(40.dp)
                    .border(2.dp, if (isSel) Flame else Hairline)
                    .background(if (isSel) Flame else Surface)
                    .clickable { onSelect(range) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    range,
                    color = if (isSel) PaperWhite else TextPrimary,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
private fun DecadeYearSelector(
    availableYears: List<Int>,
    selectedDecade: String?,
    selectedYear: Int?,
    onDecade: (String) -> Unit,
    onYear: (Int) -> Unit
) {
    // Decades (newest first) derived from the years the source actually has.
    val decades = remember(availableYears) {
        availableYears.map { decadeOf(it) }.distinct()
    }
    Column(Modifier.fillMaxWidth()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(decades) { decade ->
                val isSel = decade == selectedDecade
                Box(
                    Modifier
                        .border(2.dp, if (isSel) Flame else Hairline)
                        .background(if (isSel) Flame else Surface)
                        .clickable { onDecade(decade) }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        decade,
                        color = if (isSel) PaperWhite else TextPrimary,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            maxItemsInEachRow = 5,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val years = availableYears.filter { decadeOf(it) == selectedDecade }
            years.forEach { year ->
                val isSel = year == selectedYear
                Box(
                    Modifier
                        .size(width = 56.dp, height = 38.dp)
                        .border(2.dp, if (isSel) Flame else Hairline)
                        .background(if (isSel) Flame else Surface)
                        .clickable { onYear(year) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        year.toString(),
                        color = if (isSel) PaperWhite else TextPrimary,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
