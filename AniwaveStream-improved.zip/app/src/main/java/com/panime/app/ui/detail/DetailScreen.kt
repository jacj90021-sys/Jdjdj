package com.panime.app.ui.detail

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.zIndex
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextOverflow
import com.panime.app.ui.theme.UpcomingPurple
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import com.panime.app.data.model.Anime
import com.panime.app.data.model.Character
import com.panime.app.data.model.Episode
import com.panime.app.data.api.AnidapApi
import com.panime.app.data.api.AnizoneApi
import com.panime.app.data.provider.animenosub.AnimenosubApi
import com.panime.app.data.provider.anikoto.AnikotoProvider
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.data.repository.UserLibraryStore
import com.panime.app.download.DownloadHelper
import com.panime.app.download.sourceEpisodeCount
import com.panime.app.download.sourceSeasonMap
import com.panime.app.ui.components.BatchDownloadBar
import com.panime.app.ui.components.EpisodeCard
import com.panime.app.ui.components.AnivaveSectionCard
import com.panime.app.ui.components.CharacterRow
import com.panime.app.ui.components.EpisodeListShimmer
import com.panime.app.ui.components.ErrorBox
import com.panime.app.ui.components.PrimaryPillButton
import com.panime.app.ui.components.SecondaryPillButton
import com.panime.app.ui.components.SelectionControlsBar
import com.panime.app.ui.theme.AnivaveArt
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Gold
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.Ink
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.Purple
import com.panime.app.ui.theme.SharpCorner
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.theme.TextOnDark
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary
import com.panime.app.ui.theme.Void
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Generic numbered episode cards (AniList metadata carries no per-ep titles). */
private fun buildEpisodeCards(count: Int): List<Episode> =
    (1..count.coerceAtLeast(0)).map { n ->
        Episode(number = n, title = "Episode $n", durationLabel = "", streamUrl = "")
    }

/** Index of season [picked] in [smap]; falls back to the slug's encoded "se=N", else 0. */
private fun smapIdxOf(picked: Int, slug: String, smap: List<Pair<Int, Int>>? = null): Int {
    val map = smap ?: return 0
    if (map.size <= 1) return 0
    val want = if (picked > 0) picked else com.panime.app.download.parsePickedSeason(slug) ?: 0
    return map.indexOfFirst { it.first == want }.takeIf { it >= 0 } ?: 0
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    animeId: Int,
    repository: AnimeRepository,
    library: UserLibraryStore,
    onBack: () -> Unit,
    onPlay: (Int) -> Unit,
    onRelated: (Int) -> Unit,
    onWrongTitle: (String) -> Unit = {}
) {
    var anime by remember { mutableStateOf<Anime?>(null) }
    var episodes by remember { mutableStateOf<List<Episode>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedRangeStart by remember { mutableStateOf(1) }
    var rangeMenuExpanded by remember { mutableStateOf(false) }
    // Batch download selection state
    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedEpisodes by remember { mutableStateOf(emptySet<Int>()) }
    var selectedQuality by remember { mutableStateOf("720p") }
    var showBatchSheet by remember { mutableStateOf(false) }
    var batchEps by remember { mutableStateOf(emptyList<Int>()) }
    var showWrongTitleSheet by remember { mutableStateOf(false) }
    var wrongTitleOverride by remember { mutableStateOf<String?>(null) }
    // The anime's real AniList names — feeds the picker's name gate so only
    // rows carrying this anime's name ever show (porn/hentai/look-alikes die).
    var animeNames by remember { mutableStateOf<List<String>>(emptyList()) }
    LaunchedEffect(anime?.id ?: animeId) {
        val id = anime?.id ?: animeId
        if (id > 0) {
            animeNames = withContext(Dispatchers.IO) {
                com.panime.app.data.provider.aniwaves.AniwavesScraper.anilistNames(id)
            }
        }
    }
    // Wrong Title exists to rescue mismatched AniList episodes. In KOTO/WAVE
    // provider mode the source IS the site itself (direct slug, no title
    // matching needed), so the entry point and any stale override are disabled.
    val kotoLocked = repository.provider == "koto" || repository.provider == "wave"
    // Dantotsu parity: a fresh wrong-title pick replaces the AniList episode
    // list with the picked source's real episode count (e.g. 64 instead of 12).
    // Null = no (or expired) override -> plain AniList behavior, untouched.
    var overrideEps by remember { mutableStateOf<Int?>(null) }
    // Moviebox combined entries ("Hunter x Hunter S1-S6"): exact per-season
    // (se, maxEp) blocks from the picked source's own detail API. Null/empty
    // = single-season behavior (unchanged). Combined shows get season chips:
    // S1 (148) -> episodes 1..148 in the normal 50-chunks, then S2 (12) -> 1..12.
    var overrideSeasons by remember { mutableStateOf<List<Pair<Int, Int>>?>(null) }
    // Season chip currently shown for combined entries (index into the map).
    var selectedSeasonIdx by remember { mutableStateOf(0) }
    // Season number the pick targets: explicit "|se=N" from a per-season row,
    // or the chip selection of a combined entry; 0/1 = all-seasons (default).
    var overrideSeason by remember { mutableStateOf(0) }
    // The active pick's stored slug/source (mirrored so the chip switcher can
    // persist the chosen season back into the saved override).
    var ovSlug by remember { mutableStateOf<String?>(null) }
    var ovSource by remember { mutableStateOf<String?>(null) }

    // Derived episode-view state (design spec: ranges of 50, capped 24 visible)
    val totalEps = (anime?.episodes ?: 0).coerceAtLeast(0)
    // Header "Episodes (X)" shows episodes RELEASED so far. While airing, AniList's
    // nextAiringEpisode.episode is the upcoming ep, so released = that - 1. Finished
    // anime (no nextAiringEpisode) fall back to the total planned count.
    val releasedEps = if ((anime?.nextEpisode ?: 0) > 0) {
        (anime?.nextEpisode ?: 1) - 1
    } else totalEps
    // Wrong-title override wins when fresh: source's real count replaces AniList's.
    // Combined entries (season chips): the count shown is the SELECTED season's
    // own maxEp — episodes restart per season, exactly like moviebox's app.
    val ovSeasons = overrideSeasons
    val selSeasonMax = ovSeasons?.getOrNull(selectedSeasonIdx)?.second ?: 0
    val effReleased = when {
        ovSeasons != null && ovSeasons.size > 1 -> selSeasonMax
        else -> overrideEps ?: releasedEps
    }
    val hasSeasonChips = ovSeasons != null && ovSeasons.size > 1
    // Ranges built from releasedEps (1170), NOT the planned total (1171) — so the last
    // chunk reads "…1170" and never surfaces the not-yet-aired episode.
    val epRanges = remember(effReleased) {
        if (effReleased <= 50) emptyList()
        else buildList {
            var start = 1
            while (start <= effReleased) {
                val end = minOf(start + 49, effReleased)
                add(start to end)
                start = end + 1
            }
        }
    }
    val showDropdown = epRanges.size > 1
    val visibleEpisodes = remember(episodes, epRanges, selectedRangeStart, searchQuery) {
        val q = searchQuery.trim().lowercase()
        val scoped = if (epRanges.isEmpty() || !showDropdown) episodes
        else episodes.filter { it.number in selectedRangeStart..minOf(selectedRangeStart + 49, effReleased) }
        if (q.isEmpty()) scoped else scoped.filter { it.title.lowercase().contains(q) }
    }
    // Bug 3 fix: global search. The visible list is scoped to the current chunk (above),
    // but the query itself runs across ALL released episodes. When the first match lives
    // outside the current chunk, auto-jump the dropdown to the chunk containing it so the
    // result becomes visible — no need to manually switch ranges.
    LaunchedEffect(searchQuery, episodes, epRanges) {
        val q = searchQuery.trim().lowercase()
        if (q.isNotEmpty() && epRanges.isNotEmpty()) {
            val firstMatch = episodes.firstOrNull { it.title.lowercase().contains(q) }?.number ?: return@LaunchedEffect
            val inCurrent = firstMatch in selectedRangeStart..minOf(selectedRangeStart + 49, effReleased)
            if (!inCurrent) {
                epRanges.firstOrNull { firstMatch in it.first..it.second }?.first
                    ?.let { selectedRangeStart = it }
            }
        }
    }
    var characters by remember { mutableStateOf<List<Character>>(emptyList()) }
    var related by remember { mutableStateOf<List<Anime>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<Throwable?>(null) }
    var crash by remember { mutableStateOf<Throwable?>(null) }
    var synopsisExpanded by remember { mutableStateOf(false) }
    // Language availability chips — per-episode, computed ONCE per anime while a
    // Wrong-Title pick is active (empty otherwise). REAL data only: aniwaves
    // SUB/DUB flags from the episode list, anizone language codes from the
    // episode page's subtitle tracks. Nothing is ever guessed from a label.
    var langByEpisode by remember { mutableStateOf<Map<Int, List<String>>>(emptyMap()) }
    // Which source (provider + slug) produced [langByEpisode]. When a Wrong-Title
    // pick switches the provider, the old provider's chips must not survive — the
    // map only carries over when the source is unchanged (range switches / revisits).
    var langSourceKey by remember { mutableStateOf("") }
    val myList by library.myListIds.collectAsStateWithLifecycle(emptySet())
    // Prefer resolved AniList Media.id after load (nav may still pass a legacy MAL id).
    val resolvedId = anime?.id ?: animeId
    val inList = resolvedId in myList
    val scope = rememberCoroutineScope()

    fun loadAll(): kotlinx.coroutines.Job {
        loading = true
        error = null
        characters = emptyList()
        related = emptyList()
        return scope.launch {
            // One GraphQL round-trip: media + key characters + recommendations.
            // Root cause of empty Key Characters: AlMedia.toAnime() used idMal as Anime.id
            // while characters() queried Media(id: …) expecting AniList Media.id — wrong
            // id → Not Found → silent empty row. detailBundle + AniList ids fix that.
            repository.detailBundle(animeId)
                .onSuccess { bundle ->
                    runCatching {
                        anime = bundle.anime
                        characters = bundle.characters
                        related = bundle.recommendations
                        val epCount = (bundle.anime.episodes ?: 0).coerceAtLeast(0)
                        if (epCount > 0) library.setListTotalEpisodes(animeId, epCount)
                        // Cap the episode list at episodes RELEASED so far (same logic as the
                        // header): while airing, nextAiringEpisode.episode is the upcoming ep,
                        // so released = that - 1. The not-yet-aired episode is never listed.
                        val next = bundle.anime.nextEpisode ?: 0
                        val releasedCount = if (next > 0) (next - 1).coerceAtLeast(0) else epCount
                        // A fresh wrong-title pick owns the episode list — never
                        // let the (cached, fast) AniList response overwrite it.
                        if (overrideEps == null) {
                            episodes = if (releasedCount > 0) {
                                (1..releasedCount).map { n ->
                                    Episode(
                                        number = n,
                                        title = "Episode $n",
                                        durationLabel = "",
                                        streamUrl = ""
                                    )
                                }
                            } else emptyList()
                        }
                    }.onFailure { crash = it }
                    loading = false
                }
                .onFailure { e ->
                    // Fallback: still show the page if only the bundle query fails
                    // (e.g. partial GraphQL); try separate calls.
                    repository.detail(animeId)
                        .onSuccess { data ->
                            anime = data
                            val epCount = (data.episodes ?: 0).coerceAtLeast(0)
                            val next = data.nextEpisode ?: 0
                            val releasedCount = if (next > 0) (next - 1).coerceAtLeast(0) else epCount
                            if (overrideEps == null) {
                                episodes = if (releasedCount > 0) {
                                    (1..releasedCount).map { n ->
                                        Episode(
                                            number = n,
                                            title = "Episode $n",
                                            durationLabel = "",
                                            streamUrl = ""
                                        )
                                    }
                                } else emptyList()
                            }
                            loading = false
                            // Use resolved AniList id when available so characters always hit
                            // Media(id: anilistId) rather than a legacy MAL id.
                            val charId = data.id
                            repository.characters(charId).onSuccess { characters = it }
                            repository.recommendations(charId).onSuccess { related = it }
                        }
                        .onFailure {
                            error = e
                            loading = false
                        }
                }
        }
    }

    LaunchedEffect(animeId) {
        // Wait for the AniList load to finish BEFORE applying the override, so
        // the pick's episode list can never be overwritten by a late response.
        loadAll().join()
        // Wrong-title override: checked ONCE per entry (never mid-session).
        // Fresh (<6h) -> replace AniList episode cards with the picked source's
        // real episode list; expired/absent -> plain AniList behavior.
        val ov = if (kotoLocked) null else library.getWrongTitleOverride(animeId)
        wrongTitleOverride = ov?.selectedTitle
        overrideEps = null
        overrideSeasons = null
        overrideSeason = 0
        selectedSeasonIdx = 0
        if (ov != null && ov.slug.isNotBlank()) {
            ovSlug = ov.slug
            ovSource = ov.sourceId
            // Explicit picked season ("|se=N" encoded by the picker when the
            // row IS one season, e.g. "BoJack Horseman S2").
            val picked = com.panime.app.download.parsePickedSeason(ov.slug) ?: 0
            overrideSeason = picked
            // Moviebox combined entries: pull the exact per-season map so the
            // UI can offer season chips (S1 148 / S2 12 / ...). Other sources
            // return empty — plain count behavior.
            val smap = withContext(Dispatchers.IO) { sourceSeasonMap(ov.sourceId, ov.slug) }
            overrideSeasons = smap.takeIf { it.isNotEmpty() }
            selectedSeasonIdx = smapIdxOf(picked, ov.slug, smap)
            // Prefer the count stored WITH the pick (the picked entry's own
            // totalEpisodes — zero re-search); older picks fall back to a lookup.
            val n = ov.totalEpisodes?.takeIf { it > 0 }
                ?: withContext(Dispatchers.IO) {
                    sourceEpisodeCount(ov.sourceId, ov.slug, ov.selectedTitle, picked)
                }
            if (n != null && n > 0) {
                overrideEps = n
                episodes = buildEpisodeCards(n)
                selectedRangeStart = 1
            }
        }
    }

    // Season chip switch (combined entries): rebuild the episode cards for the
    // selected season's own count — episodes restart at 1 per season, exactly
    // like moviebox's own app, and the 50-chunk dropdown re-scopes to it. The
    // chosen season is ALSO persisted into the saved override slug ("|se=N"),
    // so Play/Player/downloads/resume all target the shown season — one source
    // of truth, no parallel season plumbing.
    LaunchedEffect(overrideSeasons, selectedSeasonIdx) {
        val smap = overrideSeasons ?: return@LaunchedEffect
        if (smap.size <= 1) return@LaunchedEffect
        val (se, max) = smap.getOrNull(selectedSeasonIdx) ?: return@LaunchedEffect
        if (max > 0) {
            overrideEps = max
            overrideSeason = se
            episodes = buildEpisodeCards(max)
            selectedRangeStart = 1
            selectedEpisodes = emptySet()
            // Persist the season into the stored slug so every consumer
            // (player resolve, downloads, fallback count) sees the same season.
            ovSlug?.let { base ->
                if (com.panime.app.download.parsePickedSeason(base) != se) {
                    val stripped = base.substringBeforeLast("|se=")
                    val updated = "$stripped|se=$se"
                    ovSlug = updated
                    // Keep the stored count in sync with the shown season
                    // (max of the season we just rendered) so the player and
                    // detail never disagree after a chip switch.
                    library.saveWrongTitleOverride(
                        animeId, ovSource ?: "moviebox", updated,
                        wrongTitleOverride ?: "", totalEpisodes = max
                    )
                }
            }
        }
    }

    // Resolve the language chips per-episode while a Wrong-Title pick is active.
    // AniWaves + Anikoto: scrape each visible episode's REAL server blocks
    // (aniwaves: sub/ssub/dub; anikoto: sub/hsub/dub — all distinct on the
    // sites, e.g. Liar Game aniwaves ep 13-18 have ssub). AniDAP: real
    // subProviders[]/dubProviders[] per episode (e.g. Liar Game eps 20-21 have
    // no dub). AniDB: real language codes from its servers array (eng/jpn — no
    // sub/dub at all, e.g. Liar Game eps 4-21 are jpn-only). Animenosub: real
    // mirror-label prefixes (SUB/DUB/RAW; Liar Game eps 20-21 have no DUB).
    // AniZone: real language codes from the episode page's subtitle tracks. New
    // results are MERGED into the map, so scrolling to another range adds chips
    // for those episodes without recomputing (or losing) the ones already shown.
    // anime?.id in the keys: the FIRST run fires while the detail is still
    // loading (anime == null -> early return). Without re-running on load, the
    // chips would stay empty forever in KOTO/WAVE provider mode (nothing else
    // changes after load — wrong-title picks worked only because the pick
    // itself changed a key). Re-running once anime lands fixes that.
    LaunchedEffect(animeId, wrongTitleOverride, selectedRangeStart, searchQuery, repository.provider, anime?.id) {
        val a0 = anime
        if (a0 == null) return@LaunchedEffect
        // Resolve the source BEFORE downloading anything so a provider switch
        // (new wrong-title pick, or API provider flipped to koto/wave) wipes the
        // OLD provider's chips IMMEDIATELY — never after the slow fetch finishes
        // (that linger was the "old box stays" bug: only anikage was fast enough
        // to look like it replaced instantly).
        val source = DownloadHelper.sourceContext(repository, library, animeId)
        // Chips run while a Wrong-Title pick is active OR when the API provider
        // switch is KOTO/WAVE — there the source is the site itself (slugHint
        // comes straight from the catalog), so no title matching is needed. In
        // plain AniList mode without a pick there is no known source, so
        // nothing is shown.
        val slugCandidate = source.slugHint
        val noSource = (wrongTitleOverride == null && !source.kotoLocked) || slugCandidate.isNullOrBlank()
        val sourceKey = if (noSource) "" else "$animeId|${source.sourceMode}|$slugCandidate"
        // Source identity: Wrong-Title picks can switch the provider (aniwaves
        // -> anidap), and the API-provider switch flips koto<->wave. When the
        // source changes, the OLD provider's chips must vanish RIGHT NOW. Only
        // when the source is unchanged do we keep the skip-already-fetched map
        // (no refetch on episode-range switches or revisits).
        if (langSourceKey != sourceKey) {
            langSourceKey = ""
            langByEpisode = emptyMap()
        }
        if (noSource) return@LaunchedEffect
        langByEpisode = withContext(Dispatchers.IO) {
            runCatching {
                val slug = source.slugHint ?: return@runCatching emptyMap()
                val base = if (langSourceKey == sourceKey) langByEpisode else emptyMap()
                val missing = visibleEpisodes.filter { it.number !in base }
                if (missing.isEmpty()) {
                    langSourceKey = sourceKey
                    return@runCatching base
                }
                // Mark the source as current BEFORE streaming so a range switch
                // mid-batch keeps the chips already fetched (they stream in below)
                // instead of discarding them and refetching everything.
                langSourceKey = sourceKey
                // Series-level lookups used by the per-episode stream: just4anime
                // and animenosub availability are per-ANIME (one fetch, applied to
                // every episode) — fetching them per episode would be 50x waste.
                val just4Blocks = if (source.sourceMode == "just4anime") {
                    runCatching {
                        com.panime.app.data.provider.just4anime.Just4AnimeProvider()
                            .audioBlocksFor(slug.toIntOrNull() ?: animeId)
                    }.getOrDefault(emptyList())
                } else emptyList()
                val animenosubEps = if (source.sourceMode == "animenosub") {
                    runCatching {
                        com.panime.app.data.provider.animenosub.AnimenosubApi.listEpisodes(slug)
                    }.getOrDefault(emptyList())
                } else emptyList()
                val anidbPickedId = if (source.sourceMode == "anidb") {
                    slug.takeIf { it.isNotBlank() }
                        ?.substringAfterLast('-')
                        ?.takeIf { it.toIntOrNull() != null }
                } else null
                val awProvider = com.panime.app.data.provider.aniwaves.AniwavesDirectProvider()
                val ktProvider = com.panime.app.data.provider.anikoto.AnikotoProvider()
                val anikageProvider = com.panime.app.data.provider.anikage.AnikageProvider()
                val anidbProvider = com.panime.app.data.provider.anidb.AnidbProvider()
                // REAL per-episode truth — one call per episode, failure-isolated so
                // one bad server never blanks the rest of the batch:
                //  - aniwaves/anikoto: server-list response carries the block type
                //    per server ("sub:<id>", "ssub:<id>", "dub:<id>" / "hsub:<id>")
                //  - anikage: servers API carries subTypes per server
                //  - anidap: subProviders[]/dubProviders[] arrays
                //  - anidb: on-device scrape -> language codes (eng/jpn, no sub/dub)
                //  - anizone: audio languages from each episode page's badges
                //  - animenosub: mirror-label prefixes (SUB/DUB/RAW)
                suspend fun chipsFor(ep: Episode): List<String> = when (source.sourceMode) {
                    "aniwaves", "anikoto" -> {
                        // Language chips must show EVERY type the site lists for the
                        // episode (SUB/HSUB/SSUB/RAW/DUB) — including DUB while watching
                        // SUB. listServersFor's type filter is only for the player's
                        // server picker, never for availability display.
                        val chips = runCatching {
                            if (source.sourceMode == "anikoto") {
                                ktProvider.serverTypesFor(slug, ep.number)
                            } else {
                                awProvider.listServersAllFor(
                                    title = a0.title,
                                    episode = ep.number,
                                    seasonNumber = a0.seasonNumber,
                                    slugHint = slug
                                ).mapNotNull { it.first.substringBefore(':') }.toSet()
                            }
                        }.getOrDefault(emptySet())
                        com.panime.app.ui.components.audioBlockChips(chips)
                    }
                    "anikage" -> com.panime.app.ui.components.audioBlockChips(
                        runCatching { anikageProvider.audioBlocksFor(slug, ep.number) }
                            .getOrDefault(emptyList())
                    )
                    "just4anime" -> com.panime.app.ui.components.audioBlockChips(just4Blocks)
                    "anidap" -> {
                        val (hasSub, hasDub) = runCatching {
                            com.panime.app.data.api.AnidapApi
                                .audioAvailability(animeId, ep.number)
                        }.getOrDefault(false to false)
                        com.panime.app.ui.components.audioBlockChips(
                            buildList {
                                if (hasSub) add("sub")
                                if (hasDub) add("dub")
                            }
                        )
                    }
                    "anidb" -> {
                        val codes = if (anidbPickedId != null) {
                            runCatching {
                                anidbProvider.languageCodesForEpisode(anidbPickedId, ep.number)
                            }.getOrDefault(emptyList())
                        } else emptyList()
                        com.panime.app.ui.components.anidbLanguageChips(codes)
                    }
                    "anizone" -> com.panime.app.ui.components.anizoneLanguageCodes(
                        runCatching {
                            com.panime.app.data.api.AnizoneApi.audioLanguages(slug, ep.number)
                        }.getOrDefault(emptyList())
                    )
                    "moviebox" -> com.panime.app.ui.components.movieboxLanguageChips(
                        runCatching {
                            // Show-level language list (same for every episode).
                            com.panime.app.data.provider.moviebox.MovieboxProvider()
                                .listLanguagesFor(slug).map { it.second }
                        }.getOrDefault(emptyList())
                    )
                    "animenosub" -> {
                        val labels = animenosubEps.firstOrNull { it.first == ep.number }?.second
                            ?.let { exact ->
                                runCatching {
                                    com.panime.app.data.provider.animenosub.AnimenosubApi
                                        .serversFromSlug(exact, expectedEpisode = ep.number)
                                }.getOrDefault(emptyList())
                                    .map { it.first }
                            } ?: emptyList()
                        com.panime.app.ui.components.animenosubChips(labels)
                    }
                    else -> emptyList()
                }
                // Stream: each episode's chips land in the map the moment that
                // episode's fetch finishes (bounded at 6 in flight), so the cards
                // fill in progressively instead of all appearing after the whole
                // range finishes — never a blank waiting screen. State writes hop
                // to Main; the batch still waits for the last episode so
                // langSourceKey is only meaningful once every visible card landed.
                val semaphore = Semaphore(6)
                coroutineScope {
                    missing.forEach { ep ->
                        async {
                            semaphore.withPermit {
                                val chips = chipsFor(ep)
                                withContext(Dispatchers.Main) {
                                    langByEpisode = langByEpisode + (ep.number to chips)
                                }
                            }
                        }
                    }
                }
                langByEpisode
            }.getOrDefault(langByEpisode)
        }
    }

    val currentError = error
    val currentCrash = crash
    val currentAnime = anime
    when {
        loading -> EpisodeListShimmer(modifier = Modifier.fillMaxSize().background(Background))
        currentError != null -> ErrorBox(currentError) {
            loadAll()
        }
        currentCrash != null -> DetailCrashScreen(currentCrash) { loadAll() }
        currentAnime != null -> {
            val a = currentAnime
            Box(Modifier.fillMaxSize().background(Background)) {
                // Blurred backdrop is confined to a SINGLE hero block that ends exactly at the
                // genre row. Below the genre tags everything is solid Background (Play E1, Info
                // grid, Synopsis) — never blurred. No fixed band, no black gap above the poster.
                // Backdrop image priority: wide COVER/banner first; fall back to the poster
                // (card) image only if the anime has no cover. (poster = card, banner = cover)
                val bgUrl = a.bannerUrl ?: a.posterUrl

                // Back button (overlay, top-left)
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .zIndex(10f)
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(0.45f))
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }

                // Scrolling content
                LazyColumn(Modifier.fillMaxSize()) {
                    // ---- HERO (blurred backdrop covers this whole item: arrow -> poster/title/rating -> genre chips) ----
                    item {
                        // Hero: crossfading Ken-Burns backdrop carousel behind the content.
                        val heroImages = remember(a.id, characters) {
                            (listOfNotNull(a.bannerUrl, a.posterUrl) +
                                characters.mapNotNull { it.imageUrl }).distinct().take(5)
                        }
                        // The hero block composites as ONE atomic, pre-clipped layer:
                        //   - Box.clipToBounds() confines every child to the hero item's bounds.
                        //   - The whole backdrop stack (blur + Ken-Burns images + beige fade) is
                        //     wrapped in a graphicsLayer with clip = true and
                        //     CompositingStrategy.Offscreen, so it renders into a single
                        //     offscreen buffer clipped to the hero bounds BEFORE it is placed
                        //     in the LazyColumn. That flat, pre-clipped quad can never be merged
                        //     above later items (the Key Characters row included), so the
                        //     hero's rounded/blurred edge can never paint over them.
                        Box(Modifier.fillMaxWidth().clipToBounds()) {
                            // Atomic backdrop layer — declared first, so it stays strictly BEHIND
                            // the hero content (poster/title/genres/buttons) by construction.
                            Box(
                                Modifier
                                    .matchParentSize()
                                    .graphicsLayer {
                                        clip = true
                                        compositingStrategy = CompositingStrategy.Offscreen
                                    }
                            ) {
                                HeroBackdrop(images = heroImages, fallback = a, modifier = Modifier.fillMaxSize())
                                // Gradual soft fade: clear over poster/title/genres, fading to solid
                                // black through the Play E1 / My List buttons at the hero bottom.
                                Box(
                                    Modifier
                                        .matchParentSize()
                                        .background(
                                            Brush.verticalGradient(
                                                0.0f to Color.Transparent,
                                                0.45f to Color.Transparent,
                                                0.8f to Background.copy(alpha = 0.75f),
                                                1.0f to Background
                                            )
                                        )
                                )
                            }
                            // Title card + genres sit ON TOP of the blurred image (no offset hack).
                            Column(Modifier.fillMaxWidth().padding(top = 72.dp, bottom = 16.dp)) {
                                // Left mini poster card + right-side title block
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp),
                                    verticalAlignment = Alignment.Bottom
                                ) {
                                    Box(
                                        Modifier
                                            .width(100.dp)
                                            .height(150.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .border(1.dp, Hairline, RoundedCornerShape(16.dp))
                                            .background(SurfaceRaised)
                                    ) {
                                        AsyncImage(
                                            model = a.posterUrl,
                                            contentDescription = a.title,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        // Studio / source eyebrow
                                        Row(
                                            Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color.Black.copy(alpha = 0.4f))
                                                .padding(horizontal = 8.dp, vertical = 4.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                Modifier.size(5.dp).clip(CircleShape).background(Flame)
                                            )
                                            Spacer(Modifier.width(6.dp))
                                            Text(
                                                a.studios.firstOrNull() ?: "FEATURED",
                                                color = Flame,
                                                fontFamily = PlexMono,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 10.sp,
                                                letterSpacing = 1.sp
                                            )
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        Text(
                                            a.title,
                                            color = TextOnDark,
                                            fontFamily = Bricolage,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 24.sp,
                                            lineHeight = 28.sp,
                                            letterSpacing = 0.2.sp
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (a.score != null) {
                                                Icon(Icons.Default.Star, contentDescription = null, tint = Flame, modifier = Modifier.size(13.dp))
                                                Spacer(Modifier.width(3.dp))
                                                Text(
                                                    "%.1f".format(a.score),
                                                    color = Flame,
                                                    fontFamily = PlexMono,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 11.sp
                                                )
                                                Spacer(Modifier.width(10.dp))
                                            }
                                            Text(
                                                listOfNotNull(a.year?.toString(), a.type, a.status).joinToString(" · "),
                                                color = TextOnDark.copy(alpha = 0.75f),
                                                fontFamily = PlexMono,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(12.dp))
                                // Genre pills
                                androidx.compose.foundation.lazy.LazyRow(
                                    contentPadding = PaddingValues(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(a.genres) { g ->
                                        Box(
                                            Modifier
                                                .border(2.dp, TextOnDark.copy(alpha = 0.45f))
                                                .background(Color.Black.copy(alpha = 0.35f))
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(
                                                g.uppercase(),
                                                color = TextOnDark,
                                                fontFamily = PlexMono,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(16.dp))
                                // Play E1 / My List — same position (below genres, above Info box).
                                // Secondary uses a solid dark scrim (onMedia) so My List stays
                                // readable over the blurred backdrop + paper fade — same clarity
                                // as home Watchlist.
                                Row(
                                    Modifier.padding(horizontal = 16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    PrimaryPillButton(
                                        text = "Play E1",
                                        leadingIcon = Icons.Default.PlayArrow,
                                        onClick = { onPlay(1) },
                                        onMedia = true
                                    )
                                    SecondaryPillButton(
                                        text = if (inList) "In List" else "My List",
                                        leadingIcon = if (inList) Icons.Default.Check else Icons.Default.Add,
                                        onClick = { scope.launch { library.toggleMyList(resolvedId) } },
                                        onMedia = true,
                                        marked = inList
                                    )
                                }
                            }
                        }
                    }

                    // ---- BELOW HERO: solid Background, never blurred ----
                    item {
                        Column(Modifier.padding(horizontal = 16.dp)) {
                            Spacer(Modifier.height(20.dp))
                        // Info grid (Source / Status / Episodes)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, Hairline, RoundedCornerShape(14.dp))
                                .background(SurfaceRaised)
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            InfoCell("SOURCE", "AniList")
                            InfoCell("STATUS", a.status ?: "—")
                            InfoCell("EPISODES", (a.episodes ?: 0).toString())
                        }
                        Spacer(Modifier.height(20.dp))
                        Text("Synopsis", color = TextPrimary, fontFamily = Bricolage, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(8.dp))
                        val full = a.synopsis.ifBlank { "No synopsis available." }
                        val display = if (synopsisExpanded || full.length <= 160) full else full.take(160).trimEnd() + "…"
                        Text(
                            display,
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        if (full.length > 160) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                if (synopsisExpanded) "Less" else "More",
                                color = Purple,
                                fontFamily = Bricolage,
                                fontWeight = FontWeight.Medium,
                                fontSize = 13.sp,
                                modifier = Modifier.clickable { synopsisExpanded = !synopsisExpanded }
                            )
                        }
                        Spacer(Modifier.height(20.dp))
                        }
                        // Key Characters spans edge-to-edge — OUTSIDE the padded
                        // column above. Its carousel previously lived inside the
                        // 16dp-padded column, so it clipped its content 16dp short
                        // of the true screen edge while swiping; the beige page
                        // background showed through that 16dp gutter on BOTH sides,
                        // which looked exactly like "the background covering the
                        // character at the corner." Now the row spans full width
                        // and clips at the real screen edge. Its own 16dp
                        // contentPadding still aligns the first portrait with the
                        // page margin when the row is at rest.
                        CharacterRow(characters = characters)
                        Column(Modifier.padding(horizontal = 16.dp)) {
                        Spacer(Modifier.height(20.dp))
                        if (!kotoLocked) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { showWrongTitleSheet = true },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Choose Accurate Title?",
                                    color = Flame,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                if (wrongTitleOverride != null) {
                                    Text(
                                        " Selected: $wrongTitleOverride",
                                        color = TextMuted,
                                        fontFamily = PlexMono,
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 12.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Episodes (${effReleased})",
                                color = TextPrimary,
                                fontFamily = Bricolage,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Spacer(Modifier.width(10.dp))
                            // Live "Ep X" + countdown chip — only while the anime is still airing.
                            NextEpisodeChip(
                                nextEpisode = a.nextEpisode,
                                nextAiringAt = a.nextAiringAt
                            )
                            Spacer(Modifier.weight(1f))
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(2.dp, Ink, RoundedCornerShape(8.dp))
                                    .background(Flame)
                                    .clickable {
                                        isSelectionMode = !isSelectionMode
                                        if (!isSelectionMode) selectedEpisodes = emptySet()
                                    }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.KeyboardArrowDown,
                                    contentDescription = "Download",
                                    tint = TextOnDark,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    "DOWNLOAD",
                                    color = TextOnDark,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        // Season chips (moviebox combined entries only): exact
                        // counts from the picked source's detail API. Tapping a
                        // chip rebuilds the episode list for THAT season (episodes
                        // restart at 1, like moviebox's own app).
                        if (hasSeasonChips) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val chipsNow = overrideSeasons
                                chipsNow?.forEachIndexed { idx, (se, maxEp) ->
                                    val on = idx == selectedSeasonIdx
                                    Box(
                                        Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (on) Flame else SurfaceRaised)
                                            .border(1.dp, if (on) Flame else Hairline, RoundedCornerShape(8.dp))
                                            .clickable {
                                                if (idx != selectedSeasonIdx) {
                                                    selectedSeasonIdx = idx
                                                    overrideSeason = se
                                                }
                                            }
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            "S$se ($maxEp)",
                                            color = if (on) TextOnDark else TextMuted,
                                            fontFamily = PlexMono,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        if (showDropdown) {
                            val curLabel = "${selectedRangeStart}\u2013${minOf(selectedRangeStart + 49, effReleased)}"
                            ExposedDropdownMenuBox(
                                expanded = rangeMenuExpanded,
                                onExpandedChange = { rangeMenuExpanded = it },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                TextField(
                                    value = curLabel,
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = rangeMenuExpanded) },
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = SurfaceRaised,
                                        unfocusedContainerColor = SurfaceRaised,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        cursorColor = Flame
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = rangeMenuExpanded,
                                    onDismissRequest = { rangeMenuExpanded = false }
                                ) {
                                    epRanges.forEach { (s, e) ->
                                        DropdownMenuItem(
                                            text = { Text("${s}\u2013${e}", color = TextPrimary) },
                                            onClick = {
                                                selectedRangeStart = s
                                                rangeMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                        }
                        if (isSelectionMode) {
                            SelectionControlsBar(
                                selectedCount = selectedEpisodes.size,
                                totalVisible = visibleEpisodes.size,
                                onSelectAll = {
                                    selectedEpisodes = visibleEpisodes.map { it.number }.toSet()
                                },
                                onDeselectAll = { selectedEpisodes = emptySet() },
                                onCancel = {
                                    isSelectionMode = false
                                    selectedEpisodes = emptySet()
                                }
                            )
                        } else {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Search episodes", color = TextMuted) },
                                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = TextMuted) },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = SurfaceRaised,
                                    unfocusedContainerColor = SurfaceRaised,
                                    disabledContainerColor = SurfaceRaised,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    unfocusedIndicatorColor = Hairline,
                                    focusedIndicatorColor = Flame,
                                    cursorColor = Flame
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                }
                items(visibleEpisodes, key = { it.number }) { ep ->
                    EpisodeCard(
                        episode = ep,
                        thumbnailUrl = a.bannerUrl ?: a.posterUrl,
                        watchProgress = 0f,
                        onClick = { onPlay(ep.number) },
                        isSelectable = isSelectionMode,
                        isSelected = ep.number in selectedEpisodes,
                        onToggle = {
                            selectedEpisodes = if (ep.number in selectedEpisodes) selectedEpisodes - ep.number
                            else selectedEpisodes + ep.number
                        },
                        // Language availability chips: only when the user manually
                        // picked a source via "Wrong Title?" (default AniList mode
                        // stays clean). Computed once per anime — no per-card work.
                        languageChips = langByEpisode[ep.number]
                    )
                }
                item {
                    Spacer(Modifier.height(20.dp))
                    AnivaveSectionCard("More Like This", related) { onRelated(it.id) }
                    Spacer(Modifier.height(24.dp))
                }
                }
                // Sticky bottom: banner + download bar (overlaid at screen bottom)
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
                    // Ad banner — only when not in download-select mode
                    if (!isSelectionMode) {
                        val detailCtx = LocalContext.current
                        val detailBanner = remember { com.panime.app.ad.AdManager.createBannerView(detailCtx) }
                        if (detailBanner != null) {
                            androidx.compose.ui.viewinterop.AndroidView(
                                factory = { detailBanner },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    val ctx = LocalContext.current
                    BatchDownloadBar(
                        visible = isSelectionMode,
                        selectedQuality = selectedQuality,
                        onQualityChange = { selectedQuality = it },
                        selectedCount = selectedEpisodes.size,
                        totalCount = visibleEpisodes.size,
                        onStartDownload = {
                            val eps = selectedEpisodes.toList().sorted()
                            if (eps.isEmpty()) return@BatchDownloadBar
                            if (com.panime.app.download.DownloadsManager(ctx)
                                    .getDownloadLocation() == null
                            ) {
                                Toast.makeText(
                                    ctx,
                                    "Pick a download folder first: My List > Downloads > CHOOSE",
                                    Toast.LENGTH_LONG
                                ).show()
                                return@BatchDownloadBar
                            }
                            // Show rewarded ad before starting download (1 per 2h)
                            val activity = ctx as? android.app.Activity
                            val startDl = {
                                batchEps = eps
                                showBatchSheet = true
                                isSelectionMode = false
                                selectedEpisodes = emptySet()
                            }
                            if (activity != null && !com.panime.app.ad.AdManager.showRewarded(activity, onReward = {}, onDismissed = { startDl() })) {
                                startDl()
                            }
                        },
                        onCancel = {
                            isSelectionMode = false
                            selectedEpisodes = emptySet()
                        }
                    )
                } // Column
        }
        }
    }

    if (showWrongTitleSheet && currentAnime != null) {
        WrongTitleSheet(
            animeTitle = currentAnime.title,
            knownNames = animeNames,
            onDismiss = { showWrongTitleSheet = false },
            onResultSelected = { sourceId, slug, title, totalEpisodes ->
                showWrongTitleSheet = false
                scope.launch {
                    library.saveWrongTitleOverride(animeId, sourceId, slug, title, totalEpisodes)
                    wrongTitleOverride = title
                    ovSlug = slug
                    ovSource = sourceId
                    // Explicit picked season ("|se=N") encoded by the picker —
                    // per-season rows ("BoJack Horseman S2") play + count THAT
                    // season only.
                    val picked = com.panime.app.download.parsePickedSeason(slug) ?: 0
                    overrideSeason = picked
                    // Combined entries: pull the exact season map for the chips.
                    val smap = withContext(Dispatchers.IO) { sourceSeasonMap(sourceId, slug) }
                    overrideSeasons = smap.takeIf { it.isNotEmpty() }
                    selectedSeasonIdx = smap.indexOfFirst { it.first == picked }.takeIf { it >= 0 } ?: 0
                    // Dantotsu parity: the pick immediately replaces the episode
                    // list with the picked source's own count (1175 for One Piece,
                    // not Eyeshield 21's 145). Stored count wins — no re-search.
                    // Season-scoped: per-season rows count only THAT season;
                    // combined rows start on S1 (chip switch rebuilds the list).
                    val n = totalEpisodes?.takeIf { it > 0 }
                        ?: withContext(Dispatchers.IO) {
                            sourceEpisodeCount(sourceId, slug, title, picked)
                        }
                    if (n != null && n > 0) {
                        overrideEps = n
                        episodes = buildEpisodeCards(n)
                        selectedRangeStart = 1
                    }
                }
            }
        )
    }

    if (showBatchSheet && currentAnime != null) {
        val ctxDl = LocalContext.current
        val dlAnime = currentAnime
        BatchServerSheet(
            episodes = batchEps,
            initialAudioType = library.lastAudioType.collectAsStateWithLifecycle(initialValue = "sub").value.ifBlank { "sub" },
            loadServers = { audioType ->
                val sc = DownloadHelper.sourceContext(repository, library, animeId)
                com.panime.app.ui.player.preloadServers(
                    sc.sourceMode, audioType, dlAnime.title, animeId,
                    batchEps.firstOrNull() ?: 1, sc.slugHint, dlAnime.seasonNumber,
                    overrideEps ?: 0, dlAnime.year
                )
            },
            onDismiss = { showBatchSheet = false },
            onConfirm = { audioType, choices, chain ->
                showBatchSheet = false
                val eps = batchEps
                scope.launch {
                    var queued = 0
                    var fellBack = 0
                    var lastErr: String? = null
                    for (ep in eps) {
                        val res = DownloadHelper.downloadEpisode(
                            context = ctxDl,
                            repository = repository,
                            library = library,
                            animeId = animeId,
                            title = dlAnime.title,
                            episode = ep,
                            // Season the pick targets ("|se=N" / season chip);
                            // 0 (no pick or non-moviebox) keeps the legacy key 1
                            // so existing duplicate-download guards still match.
                            seasonNumber = if (overrideSeason > 0) overrideSeason else 1,
                            totalEps = overrideEps ?: 0,
                            posterUrl = dlAnime.posterUrl,
                            preferredServer = choices[ep],
                            serverChain = chain,
                            audioTypeOverride = audioType
                        )
                        if (res.error == null) {
                            queued++
                            if (res.fellBack) fellBack++
                        } else lastErr = res.error
                    }
                    Toast.makeText(
                        ctxDl,
                        when {
                            queued > 0 && fellBack == 0 && lastErr == null ->
                                "Queued $queued download${if (queued == 1) "" else "s"}"
                            queued > 0 ->
                                "Queued $queued · $fellBack fell back" +
                                    (lastErr?.let { " · failed: $it" } ?: "")
                            else -> lastErr ?: "Download failed"
                        },
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )
    }
}

@Composable
private fun DetailCrashScreen(error: Throwable, onRetry: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Background)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "This anime failed to render",
            color = TextPrimary,
            fontFamily = Bricolage,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            error.message ?: error.toString(),
            color = Flame,
            fontFamily = PlexMono,
            fontSize = 12.sp
        )
        Spacer(Modifier.height(16.dp))
        SecondaryPillButton(text = "Retry", leadingIcon = Icons.Default.Refresh, onClick = onRetry)
    }
}

@Composable
private fun InfoCell(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextMuted, fontFamily = PlexMono, fontSize = 10.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = TextPrimary, fontFamily = PlexMono, fontWeight = FontWeight.Medium, fontSize = 12.sp)
    }
}

/**
 * Small "EP X" + live countdown chip shown on the right of the Episodes header while the
 * anime is still airing (AniList nextAiringEpisode). Ticks every 1s; shows "LIVE NOW" at zero.
 * Hidden entirely when there is no upcoming episode (finished/not-yet-releasing anime).
 */
@Composable
private fun NextEpisodeChip(nextEpisode: Int?, nextAiringAt: Long?) {
    val airingSec = (nextAiringAt ?: 0L)
    val ep = nextEpisode ?: 0
    if (ep <= 0 || airingSec <= 0L) return
    val nowSec = System.currentTimeMillis() / 1000L
    val left0 = (airingSec - nowSec).coerceAtLeast(0L)
    val cdState = remember(airingSec) { mutableStateOf(left0) }
    LaunchedEffect(airingSec) {
        while (true) {
            val left = (airingSec - System.currentTimeMillis() / 1000L).coerceAtLeast(0L)
            cdState.value = left
            if (left <= 0L) break
            delay(1000L)
        }
    }
    val cd = cdState.value
    val (cdText, live) = if (cd <= 0L) {
        "LIVE NOW" to true
    } else {
        val d = cd / 86400L
        val h = (cd % 86400L) / 3600L
        val m = (cd % 3600L) / 60L
        (if (d > 0) "${d}d ${h}h ${m}m" else "${h}h ${m}m") to false
    }
    Row(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (live) Flame.copy(alpha = 0.18f) else SurfaceRaised)
            .border(1.dp, if (live) Flame.copy(alpha = 0.5f) else Hairline, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "EP $ep",
            color = if (live) Flame else TextPrimary,
            fontFamily = PlexMono,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
        Spacer(Modifier.width(6.dp))
        // Countdown only (e.g. "5d 22h 14m" / "1h 25m") — blue for clear paper contrast.
        // EP label stays TextPrimary/Flame; do not recolor air-time red elsewhere.
        Text(
            cdText,
            color = if (live) Flame else UpcomingPurple,
            fontFamily = PlexMono,
            fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Crossfading blurred backdrop carousel with a slow Ken Burns zoom/pan per image.
 * Fills its parent (the hero's atomic backdrop layer) and fades out behind the
 * Play E1 / My List buttons — no overflow, no black gap, and it never pushes
 * layout around. The caller clips it to the hero bounds.
 */
@Composable
private fun HeroBackdrop(images: List<String>, fallback: Anime, modifier: Modifier = Modifier) {
    val list = if (images.isNotEmpty()) images else listOf(fallback.posterUrl ?: "")
    if (list.isEmpty() || list.first().isEmpty()) {
        AnivaveArt(anime = fallback, modifier = modifier.blur(2.dp).clipToBounds())
        return
    }
    var index by remember { mutableStateOf(0) }
    LaunchedEffect(list) {
        while (true) {
            delay(4500L)
            index = (index + 1) % list.size
        }
    }
    // The whole backdrop renders into ONE layer: a graphicsLayer with clip = true
    // and CompositingStrategy.Offscreen wraps the single blur RenderEffect, so all
    // crossfading Ken-Burns images composite into one offscreen buffer clipped to
    // the hero bounds BEFORE being placed in the LazyColumn. No per-image layer is
    // left that could escape and be merged above later page content.
    Box(
        modifier
            .graphicsLayer {
                clip = true
                compositingStrategy = CompositingStrategy.Offscreen
            }
            .blur(2.dp)
    ) {
        list.forEachIndexed { i, url ->
            val visible = i == index
            val kb = rememberInfiniteTransition()
            val scale by kb.animateFloat(
                initialValue = 1.08f, targetValue = 1.16f,
                animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse)
            )
            val pan by kb.animateFloat(
                initialValue = -12f, targetValue = 12f,
                animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse)
            )
            Crossfade(
                targetState = visible,
                animationSpec = tween(900),
                modifier = Modifier.fillMaxSize()
            ) { show ->
                if (show) {
                    AsyncImage(
                        model = url,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                clip = true
                                scaleX = scale
                                scaleY = scale
                                translationX = pan.dp.toPx()
                            }
                            .clipToBounds()
                    )
                }
            }
        }
    }
}