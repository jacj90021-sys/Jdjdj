package com.panime.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import com.panime.app.data.api.AniListApi
import com.panime.app.data.auth.OAuthPkce
import com.panime.app.data.auth.SecureTokenStore
import com.panime.app.data.auth.authUrl
import com.panime.app.data.auth.exchangeCodeForToken
import com.panime.app.data.auth.fetchAccountName
import com.panime.app.data.auth.isConfigured
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

/**
 * Headless OAuth redirect receiver.
 *
 * AniList implicit flow redirects with token in URL fragment:
 *   panime://oauth/callback#access_token=...&token_type=Bearer
 * MAL auth-code flow redirects with code in query:
 *   panime://oauth/callback?code=...
 *
 * Dantotsu-style: no state verification. AniList passes an explicit redirect_uri
 * so the token lands on panime://oauth/callback (the client's registered URL).
 */
class AniwaveAuthActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val uri: Uri? = if (Intent.ACTION_VIEW == intent?.action) intent.data else null
        if (uri == null || uri.scheme != "panime" || uri.host != "oauth") {
            finish()
            return
        }
        val error = uri.getQueryParameter("error")
        val errorDesc = uri.getQueryParameter("error_description")
        if (error != null) {
            Toast.makeText(
                this,
                "Authorization failed: $error${errorDesc?.let { " — $it" } ?: ""}",
                Toast.LENGTH_LONG
            ).show()
            finish()
            return
        }

        val code = uri.getQueryParameter("code")
        if (!code.isNullOrBlank()) {
            // MAL auth-code flow — no state verification, no stored verifier needed.
            completeCodeFlow(code)
            return
        }

        // AniList implicit flow: token in fragment (panime://oauth/callback#access_token=...).
        // Dantotsu-style parsing: grab access_token off the RAW uri string with a
        // regex — more forgiving than Uri fragment parsing (which some browsers
        // mangle for custom schemes).
        val dataString = intent?.dataString ?: ""
        val fragment = dataString.substringAfter('#', "")
        val fragmentToken = if (fragment.isNotBlank()) {
            Uri.parse("?$fragment").getQueryParameter("access_token")
        } else null
        val regexToken = Regex("""(?<=access_token=)[^&#]+""").find(dataString)?.value
        val accessToken = fragmentToken ?: regexToken
        if (!accessToken.isNullOrBlank()) {
            completeImplicitAniList(accessToken)
            return
        }

        Toast.makeText(this, "Authorization failed: no code or token in redirect", Toast.LENGTH_LONG).show()
        finish()
    }

    private fun completeCodeFlow(code: String) {
        val app = application as AniwaveApp
        val tokens = SecureTokenStore(this)
        val library = app.library
        // Read the persisted PKCE verifier (stored in startAuth). Empty only if the
        // store was cleared between launch and callback — MAL rejects an empty verifier.
        val verifier = runBlocking { library.takePendingVerifier("mal") }
        lifecycleScope.launch {
            try {
                val pair = exchangeCodeForToken("mal", code, verifier)
                val name = fetchAccountName("mal", pair.accessToken)
                tokens.save("mal", pair.accessToken, pair.refreshToken, pair.expiresInSeconds)
                library.setAccount("mal", name)
                Toast.makeText(this@AniwaveAuthActivity, "Connected as $name", Toast.LENGTH_SHORT).show()
                finish()
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                    runCatching {
                        val imported = library.syncMalOnLoad()
                        library.setLastSyncAt(System.currentTimeMillis())
                    }
                }
            } catch (e: Throwable) {
                Toast.makeText(this@AniwaveAuthActivity, "Connect failed: ${e.message}", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun completeImplicitAniList(accessToken: String) {
        val app = application as AniwaveApp
        val library = app.library
        lifecycleScope.launch {
            try {
                val (name, imported) = withContext(Dispatchers.IO) {
                    val tokens = SecureTokenStore(this@AniwaveAuthActivity)
                    val resolvedName = fetchAccountName("anilist", accessToken)
                    tokens.save("anilist", accessToken, null, null)
                    library.setAccount("anilist", resolvedName)
                    val entries = AniListApi.fetchViewerMediaList(accessToken)
                    val count = library.importAniListList(entries)
                    library.setLastSyncAt(System.currentTimeMillis())
                    resolvedName to count
                }
                Toast.makeText(
                    this@AniwaveAuthActivity,
                    "Connected as $name — synced $imported anime",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: Throwable) {
                Toast.makeText(this@AniwaveAuthActivity, "Connect failed: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                finish()
            }
        }
    }

    companion object {
        fun startAuth(activity: Activity, service: String) {
            if (!isConfigured(service)) {
                Toast.makeText(activity, "OAuth not configured for ${service.uppercase()}", Toast.LENGTH_LONG).show()
                return
            }
            // Generate a fresh PKCE verifier (and derive the plain challenge) per auth
            // attempt. MAL's auth-code flow requires code_verifier at token exchange —
            // the previous empty-challenge/empty-verifier path made the exchange fail.
            // Persist the verifier (DataStore) so it survives the browser round-trip even
            // if the app/activity is killed while the browser is open.
            val app = activity.application as AniwaveApp
            val verifier = OAuthPkce.randomVerifier()
            val challenge = OAuthPkce.challenge(verifier)
            val state = OAuthPkce.randomState()
            // Fire-and-forget store; the value is read in completeCodeFlow.
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                app.library.putPendingVerifier(service, verifier)
            }
            val url = authUrl(service, state, challenge)
            activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }
}
