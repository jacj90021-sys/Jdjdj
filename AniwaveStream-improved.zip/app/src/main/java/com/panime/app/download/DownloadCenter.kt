package com.panime.app.download

import android.content.Context
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlin.coroutines.CoroutineContext

/**
 * UI-facing facade over the Media3 download engine. One place that knows how
 * to enqueue, pause (REAL stop), resume, retry, cancel, delete and observe.
 */
object DownloadCenter {

    /** UI row model — merged view of Media3 state + app metadata. */
    data class Row(
        val id: String,
        val meta: EpisodeDownloadMeta?,
        val stateLabel: String,      // QUEUED / DOWNLOADING / PAUSED / WAITING_NETWORK / RETRYING / COMPLETED / FAILED / REMOVING
        val percent: Float,
        val bytesDownloaded: Long,
        val contentLength: Long,
        val lastError: String? = null,
        val completedAtMs: Long = 0L,
        val createdAtMs: Long = 0L
    ) {
        val title: String get() = meta?.title ?: id
        val episodeLabel: String get() = meta?.episodeLabel ?: ""
        val posterUrl: String? get() = meta?.posterUrl
        val quality: String? get() = meta?.quality
        val serverLabel: String? get() = meta?.serverLabel
        val animeId: Int get() = meta?.animeId ?: 0
        val episodeNumber: Int get() = meta?.episode ?: 1
    }

    private var appCtx: Context? = null

    /** Called once from AniwaveApp.onCreate so notification labels resolve. */
    fun init(context: Context) {
        appCtx = context.applicationContext
    }

    fun ensureStarted(context: Context) {
        EpisodeDownloadService.ensureStarted(context.applicationContext)
    }

    // ── Actions ──────────────────────────────────────────────────────────

    fun enqueue(context: Context, meta: EpisodeDownloadMeta): String {
        ensureStarted(context)
        // Stable cache identity: point this download's manifest base (directory of
        // the resolved m3u8) at the episode's stable id. Survives process death via
        // SharedPreferences, so a resumed download in a fresh process keeps keying
        // its (possibly path-rotated) segments into the SAME cache namespace.
        com.panime.app.download.DownloadCacheRegistry.register(
            context, meta.streamUrl, meta.id
        )
        DownloadHeaderRegistry.put(context, meta.id, meta.headers)
        // Do NOT steal activeId from a download that is still running. Media3 keeps a
        // single active slot (maxParallelDownloads = 1) and queues this one behind the
        // current downloader; flipping activeId here would make the in-flight episode
        // send the WRONG provider headers (Referer/Origin) on its ongoing requests ->
        // 403 -> "stream link expired — refreshing". activeId stays with the true
        // STATE_DOWNLOADING download (tracked by the manager listener); only when THAT
        // finishes does this one start and claim activeId.
        if (currentlyDownloadingId(context) == null) {
            DownloadHeaderRegistry.activeId = meta.id
        }
        EpisodeDownloadStore.setLastError(context, meta.id, null)
        DownloadService.sendAddDownload(
            context.applicationContext,
            EpisodeDownloadService::class.java,
            meta.toDownloadRequest(),
            /* foregroundNotification = */ false
        )
        return meta.id
    }

    /**
     * Id of the download currently in [Download.STATE_DOWNLOADING] (Media3's active
     * slot), or null when nothing is mid-transfer. Used to keep the header registry's
     * activeId aligned with the ACTUAL active download, not the most recent enqueue.
     */
    private fun currentlyDownloadingId(context: Context): String? {
        val mgr = EpisodeDownloadService.currentManager() ?: return null
        return try {
            mgr.downloadIndex.getDownloads().use { cursor ->
                var found: String? = null
                while (cursor.moveToNext()) {
                    if (cursor.download.state == Download.STATE_DOWNLOADING) {
                        found = cursor.download.request.id
                        break
                    }
                }
                found
            }
        } catch (_: Exception) {
            null
        }
    }

    /** REAL pause — stops the transfer mid-flight; partial data retained. */
    fun pause(context: Context, id: String) {
        DownloadService.sendSetStopReason(
            context, EpisodeDownloadService::class.java, id,
            EpisodeDownloadService.STOP_REASON_USER_PAUSE, false
        )
    }

    fun resume(context: Context, id: String) {
        ensureStarted(context)
        // Only claim activeId when nothing else is mid-download; otherwise the
        // running episode would lose its provider headers on in-flight requests.
        // (Media3 queues this behind the active slot; the manager listener moves
        // activeId here once it actually starts.)
        if (currentlyDownloadingId(context) == null) {
            DownloadHeaderRegistry.activeId = id
        }
        DownloadService.sendSetStopReason(
            context, EpisodeDownloadService::class.java, id,
            Download.STOP_REASON_NONE, false
        )
    }

    /** Manual retry after a failure. Re-adds the stored request as-is. */
    fun retryNow(context: Context, id: String) {
        ensureStarted(context)
        val request = readRequest(context, id) ?: return
        if (currentlyDownloadingId(context) == null) {
            DownloadHeaderRegistry.activeId = id
        }
        EpisodeDownloadStore.setLastError(context, id, null)
        DownloadService.sendAddDownload(
            context, EpisodeDownloadService::class.java, request, false
        )
    }

    /** Cancel active/queued OR remove a completed download (wipes cached spans). */
    fun remove(context: Context, id: String) {
        DownloadService.sendRemoveDownload(
            context, EpisodeDownloadService::class.java, id, false
        )
        DownloadHeaderRegistry.remove(context, id)
        DownloadCacheRegistry.unregister(context, id)
        EpisodeDownloadService.deleteSubtitles(context, id)
        EpisodeDownloadStore.clearAllFor(context, id)
    }

    fun readRequest(context: Context, id: String): androidx.media3.exoplayer.offline.DownloadRequest? =
        try {
            ensureStarted(context)
            EpisodeDownloadService.currentManager()?.downloadIndex?.getDownload(id)?.request
        } catch (_: Exception) {
            null
        }

    fun readMeta(context: Context, id: String): EpisodeDownloadMeta? =
        EpisodeDownloadMeta.decode(readRequest(context, id)?.data)

    /** id → "Title — Episode N" map for notification personalization. */
    fun displayNames(ids: List<String>): Map<String, String> {
        val ctx = appCtx ?: return emptyMap()
        return ids.mapNotNull { id ->
            EpisodeDownloadMeta.decode(EpisodeDownloadService.readStoredData(ctx, id))
                ?.let { it.id to "${it.title} — ${it.episodeLabel}" }
        }.toMap()
    }

    // ── Observation ──────────────────────────────────────────────────────

    /**
     * Polls Media3's persistent index and maps each entry to a [Row].
     * Polling (1 s, screen-visible only) is deliberate: SQLite reads at this
     * rate are negligible next to the old 2 s SAF file-size probes.
     */
    fun observe(context: Context, dispatcher: CoroutineContext): Flow<List<Row>> = flow {
        val appContext = context.applicationContext
        while (true) {
            emit(snapshots(appContext))
            delay(1000)
        }
    }.flowOn(dispatcher)

    fun snapshots(context: Context): List<Row> {
        ensureStarted(context)
        val mgr = EpisodeDownloadService.currentManager() ?: return emptyList()
        val waitingForNetwork = runCatching { mgr.isWaitingForRequirements() }.getOrDefault(false)
        val rows = mutableListOf<Row>()
        try {
            mgr.downloadIndex.getDownloads().use { cursor ->
                while (cursor.moveToNext()) rows.add(toRow(context, cursor.download, waitingForNetwork))
            }
        } catch (_: Exception) {
        }
        return rows.sortedWith(
            compareBy<Row> { it.stateLabel !in listOf("DOWNLOADING", "RETRYING") }
                .thenByDescending { it.createdAtMs }
        )
    }

    private fun toRow(context: Context, d: Download, waitingForNetwork: Boolean): Row {
        val meta = EpisodeDownloadMeta.decode(d.request.data)
        val storedError = EpisodeDownloadStore.lastError(context, d.request.id)

        val label = when (d.state) {
            Download.STATE_DOWNLOADING -> "DOWNLOADING"
            Download.STATE_QUEUED ->
                if (waitingForNetwork && d.stopReason == Download.STOP_REASON_NONE) "WAITING_NETWORK"
                else "QUEUED"
            Download.STATE_STOPPED -> "PAUSED"
            Download.STATE_RESTARTING -> "RETRYING"
            Download.STATE_REMOVING -> "REMOVING"
            Download.STATE_FAILED -> when {
                storedError != null && (
                    storedError.startsWith("Retrying") ||
                        storedError.startsWith("Stream link expired")
                    ) -> "RETRYING"
                else -> "FAILED"
            }
            Download.STATE_COMPLETED -> "COMPLETED"
            else -> "QUEUED"
        }

        // Only surface an error line while the row is actually FAILED or inside
        // its retry/refresh window. A recovered download (DOWNLOADING/QUEUED/
        // PAUSED/COMPLETED) must show its status + progress bar — never a stale
        // "Stream link expired" message that hides the real progress.
        val errorText = when (label) {
            "FAILED" -> storedError ?: "Download failed"
            "RETRYING" -> storedError
            else -> null
        }

        return Row(
            id = d.request.id,
            meta = meta,
            stateLabel = label,
            percent = d.percentDownloaded.coerceIn(0f, 100f),
            bytesDownloaded = d.bytesDownloaded.coerceAtLeast(0L),
            contentLength = d.contentLength.coerceAtLeast(0L),
            lastError = errorText,
            completedAtMs = EpisodeDownloadStore.completedAt(context, d.request.id),
            createdAtMs = meta?.createdAtMs ?: d.startTimeMs
        )
    }
}
