package com.panime.app.push

import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * FCM push entry-point — analytics topic "all" / targeted pushes land here.
 * Enabled by the Firebase BOM + google-services.json already in app/.
 */
class AniwaveMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        Log.i("AniwaveFcm", "FCM token refreshed: ${token.take(12)}…")
        // If you add a backend later, send the token there for targeted pushes.
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: message.data["title"] ?: return
        val body = message.notification?.body ?: message.data["body"] ?: ""

        // No custom Activity entry for pushes yet — just post to the general
        // channel (created in AniwaveApp). The user taps the notification
        // and the launcher handles the default intent.
        if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) return

        val n = NotificationCompat.Builder(this, "general")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(this).notify(System.currentTimeMillis().toInt(), n)
        }
    }
}
