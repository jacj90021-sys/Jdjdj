package com.panime.app.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * AnimeX dual-theme palette.
 *
 * Light (default): paper #eee9db / ink #171410 / red #d1291b
 * Dark: near-black surfaces, light text, same red accent
 *
 * Semantic names are CompositionLocal-backed so every screen that imports
 * Background / Ink / TextPrimary / etc. recolors when the user toggles Theme.
 */

data class AniwavePalette(
    val paper: Color,
    val paper2: Color,
    val ink: Color,
    val inkSoft: Color,
    val inkFaint: Color,
    val red: Color,
    val paperWhite: Color,
    val liveGreen: Color,
    val upcomingPurple: Color,
    val flame: Color,
    val flameDim: Color,
    val cool: Color,
    val coolDim: Color,
    val gold: Color,
    val purple: Color,
    val purpleDim: Color,
    val void: Color,
    val surface: Color,
    val surfaceRaised: Color,
    val hairline: Color,
    val hairlineBright: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val textOnDark: Color,
    val danger: Color,
    val isDark: Boolean
)

val LightAniwavePalette = AniwavePalette(
    paper = Color(0xFFEEE9DB),
    paper2 = Color(0xFFE3DDCB),
    ink = Color(0xFF171410),
    inkSoft = Color(0xFF4A4438),
    inkFaint = Color(0xFF8B8474),
    red = Color(0xFFD1291B),
    paperWhite = Color(0xFFFAF7EE),
    liveGreen = Color(0xFF5FD6A0),
    upcomingPurple = Color(0xFF6A5CFF),
    flame = Color(0xFFD1291B),
    flameDim = Color(0x26D1291B),
    cool = Color(0xFF5FD6A0),
    coolDim = Color(0x1F5FD6A0),
    gold = Color(0xFFD1291B),
    purple = Color(0xFF6A5CFF),
    purpleDim = Color(0x266A5CFF),
    void = Color(0xFFEEE9DB),
    surface = Color(0xFFFAF7EE),
    surfaceRaised = Color(0xFFE3DDCB),
    hairline = Color(0xFF171410),
    hairlineBright = Color(0xFF4A4438),
    textPrimary = Color(0xFF171410),
    textSecondary = Color(0xFF4A4438),
    textMuted = Color(0xFF8B8474),
    textOnDark = Color(0xFFFAF7EE),
    danger = Color(0xFFD1291B),
    isDark = false
)

val DarkAniwavePalette = AniwavePalette(
    paper = Color(0xFF121212),
    paper2 = Color(0xFF1A1A1A),
    ink = Color(0xFFF2EDE3),
    inkSoft = Color(0xFFB8B0A4),
    inkFaint = Color(0xFF7A746A),
    red = Color(0xFFE03A2C),
    paperWhite = Color(0xFF1E1E1E),
    liveGreen = Color(0xFF5FD6A0),
    upcomingPurple = Color(0xFF8B7CFF),
    flame = Color(0xFFE03A2C),
    flameDim = Color(0x33E03A2C),
    cool = Color(0xFF5FD6A0),
    coolDim = Color(0x1F5FD6A0),
    gold = Color(0xFFE03A2C),
    purple = Color(0xFF8B7CFF),
    purpleDim = Color(0x338B7CFF),
    void = Color(0xFF0E0E0E),
    surface = Color(0xFF1A1A1A),
    surfaceRaised = Color(0xFF242424),
    hairline = Color(0xFF3A3A3A),
    hairlineBright = Color(0xFF555555),
    textPrimary = Color(0xFFF2EDE3),
    textSecondary = Color(0xFFB8B0A4),
    textMuted = Color(0xFF7A746A),
    // On media / hero images still need a light readable color
    textOnDark = Color(0xFFFAF7EE),
    danger = Color(0xFFE03A2C),
    isDark = true
)

val LocalAniwavePalette = staticCompositionLocalOf { LightAniwavePalette }

/** Active palette — prefer this inside custom draw scopes after reading once. */
val AniwaveColors: AniwavePalette
    @Composable
    @ReadOnlyComposable
    get() = LocalAniwavePalette.current

// ---- AnimeX raw tokens (theme-aware) ----
val Paper: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.paper
val Paper2: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.paper2
val Ink: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.ink
val InkSoft: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.inkSoft
val InkFaint: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.inkFaint
val Red: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.red
val PaperWhite: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.paperWhite
val LiveGreen: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.liveGreen
val UpcomingPurple: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.upcomingPurple

// ---- Semantic aliases ----
val Flame: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.flame
val FlameDim: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.flameDim
val Cool: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.cool
val CoolDim: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.coolDim
val Gold: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.gold
val Purple: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.purple
val PurpleDim: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.purpleDim

val Void: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.void
val Surface: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.surface
val SurfaceRaised: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.surfaceRaised

val Hairline: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.hairline
val HairlineBright: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.hairlineBright

val TextPrimary: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.textPrimary
val TextSecondary: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.textSecondary
val TextMuted: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.textMuted

/** Text/icons drawn on dark media (hero image, poster badges, player chrome). */
val TextOnDark: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.textOnDark

// Backwards-compatible aliases
val OrangePrimary: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.flame
val OrangeDim: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.flame
val OrangeGlow: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.flameDim
val Background: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.void
val SurfaceDark: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.void
val SurfaceElevated: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.surfaceRaised
val CardBorder: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.hairline
val TextMutedOld: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.textMuted
val Success: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.cool
val Danger: Color
    @Composable @ReadOnlyComposable get() = LocalAniwavePalette.current.danger
