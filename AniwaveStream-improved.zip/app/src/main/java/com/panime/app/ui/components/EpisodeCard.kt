package com.panime.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.panime.app.data.model.Episode
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.AniwaveColors
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.SharpCorner
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.theme.TextOnDark
import com.panime.app.ui.theme.TextPrimary

// How many micro chips to show before collapsing the rest into "+N".
internal const val MaxLangChips = 9

/**
 * Audio-block chips — the TRUTH, never inferred. The koto-family sites report
 * the actual blocks each episode really has, with slightly different vocab:
 *   aniwaves: sub, ssub, dub
 *   anikoto:  sub, hsub, dub
 * One chip per block that actually exists (SUB / SSUB / HSUB / DUB); unknown
 * block types are ignored, nothing is ever guessed from a label.
 */
internal fun audioBlockChips(blockTypes: Collection<String>): List<String> {
    val set = blockTypes.toSet()
    val out = ArrayList<String>(3)
    if ("sub" in set) out.add("SUB")
    if ("ssub" in set) out.add("SSUB")
    if ("hsub" in set) out.add("HSUB")
    if ("dub" in set) out.add("DUB")
    return out
}

/**
 * Animenosub chips — real audio blocks from the mirror-label prefixes
 * ("SUB - Moon", "DUB - HD", "RAW - Nova"). The site genuinely distinguishes
 * SUB / DUB / RAW; unknown prefixes are ignored. Per-episode truth: some eps
 * have no DUB mirrors (e.g. Liar Game eps 20-21).
 */
internal fun animenosubChips(labels: List<String>): List<String> {
    val out = LinkedHashSet<String>()
    for (raw in labels) {
        val head = raw.trim().substringBefore(" - ").trim().uppercase()
        if (head in setOf("SUB", "DUB", "RAW")) out.add(head)
    }
    return out.toList()
}

/**
 * AniDB chips — real language codes from the servers array (eng/jpn). AniDB
 * has no sub/dub at all; its API reports actual languages, e.g. `eng`
 * (English) and `jpn` (Japanese), per episode. Codes are uppercased and
 * deduped in the order the site reports them — never inferred.
 */
internal fun anidbLanguageChips(codes: List<String>): List<String> {
    val valid = setOf("ENG", "JPN")
    val out = LinkedHashSet<String>()
    for (c in codes) {
        val up = c.trim().uppercase()
        if (up in valid) out.add(up)
    }
    return out.toList()
}

/**
 * AniZone chips — real language codes from the episode page's subtitle-track
 * language fields (e.g. "Japanese", "Hindi", "English", "Spanish (Latin
 * American)"). Known labels map to codes; UNKNOWN labels are surfaced as raw
 * chips (uppercased, first 3 words, capped) so nothing the site offers is ever
 * hidden. No SUB/DUB markers — anizone has a single server, so SUB/DUB is
 * meaningless there.
 */
internal fun anizoneLanguageCodes(labels: List<String>): List<String> {
    if (labels.isEmpty()) return emptyList()
    val codeOf = mapOf(
        "japanese" to "JPN", "jpn" to "JPN", "ja" to "JPN",
        "hindi" to "HIN", "hin" to "HIN", "hi" to "HIN",
        "english" to "ENG", "eng" to "ENG", "en" to "ENG",
        "tamil" to "TAM", "tam" to "TAM", "ta" to "TAM",
        "telugu" to "TEL", "tel" to "TEL", "te" to "TEL",
        "bengali" to "BEN", "bangla" to "BEN", "ben" to "BEN", "bn" to "BEN",
        "spanish" to "SPA", "spa" to "SPA", "es" to "SPA",
        "korean" to "KOR", "kor" to "KOR", "ko" to "KOR",
        "chinese" to "CHI", "chi" to "CHI", "zh" to "CHI",
        "french" to "FRE", "fre" to "FRE", "fr" to "FRE",
        "german" to "GER", "ger" to "GER", "de" to "GER",
        "italian" to "ITA", "ita" to "ITA", "it" to "ITA",
        "portuguese" to "POR", "por" to "POR", "pt" to "POR",
        "russian" to "RUS", "rus" to "RUS", "ru" to "RUS",
        "thai" to "THA", "tha" to "THA", "th" to "THA",
        "indonesian" to "IND", "ind" to "IND", "id" to "IND",
        "vietnamese" to "VIE", "vie" to "VIE", "vi" to "VIE",
        "malay" to "MAY", "ms" to "MAY",
        "turkish" to "TUR", "tur" to "TUR", "tr" to "TUR",
        "arabic" to "ARA", "ara" to "ARA", "ar" to "ARA"
    )
    val out = LinkedHashSet<String>()
    for (raw in labels) {
        val low = raw.trim().lowercase()
        if (low.isBlank()) continue
        val code = codeOf[low] ?: codeOf[low.substringBefore(' ').trim()]
        if (code != null) {
            out.add(code)
        } else {
            // Unknown language — never hide it: show the real name as a raw
            // chip (uppercased, first 3 words, capped) instead of dropping it.
            val rawToken = raw.trim().uppercase()
                .split(Regex("\\s+")).filter { it.isNotBlank() }
                .take(3).joinToString(" ").take(12)
            if (rawToken.isNotBlank()) out.add(rawToken)
        }
    }
    // Stable, sensible order: JPN/HIN first (anizone's core langs), then the rest.
    val preferred = listOf("JPN", "HIN", "ENG", "TAM", "TEL", "BEN", "SPA", "KOR", "CHI", "FRE", "GER", "ITA", "POR", "RUS", "THA", "IND", "VIE", "MAY", "TUR", "ARA")
    return preferred.filter { it in out } + out.filter { it !in preferred }
}

/**
 * Moviebox chips — zone-style short codes, exactly like [anizoneLanguageCodes].
 * The show's dubs array ("Original Audio", "Arabic sub", "French dub",
 * "esla dub", "ptbr dub", …) maps to 3-letter codes; the meaningless site
 * codes "esla" (Spanish LatAm) and "ptbr" (Portuguese BR) become SPA/POR.
 * Deduped, stable order — never guessed.
 */
internal fun movieboxLanguageChips(lanNames: List<String>): List<String> {
    if (lanNames.isEmpty()) return emptyList()
    val codeOf = mapOf(
        "english" to "ENG", "original audio" to "ENG", "eng" to "ENG", "en" to "ENG",
        "arabic" to "ARA", "ara" to "ARA", "ar" to "ARA",
        "french" to "FRE", "fre" to "FRE", "fr" to "FRE", "français" to "FRE",
        "russian" to "RUS", "rus" to "RUS", "ru" to "RUS",
        "spanish" to "SPA", "spa" to "SPA", "es" to "SPA", "español" to "SPA", "esla" to "SPA",
        "portuguese" to "POR", "por" to "POR", "pt" to "POR", "português" to "POR", "ptbr" to "POR",
        "hindi" to "HIN", "tamil" to "TAM", "telugu" to "TEL",
        "korean" to "KOR", "japanese" to "JPN", "jpn" to "JPN", "ja" to "JPN",
        "chinese" to "CHI", "german" to "GER", "italian" to "ITA",
        "indonesian" to "IND", "thai" to "THA", "turkish" to "TUR", "vietnamese" to "VIE", "malay" to "MAY", "bengali" to "BEN"
    )
    val out = LinkedHashSet<String>()
    for (raw in lanNames) {
        val low = raw.trim().lowercase()
        if (low.isBlank()) continue
        // Language word = everything before "sub"/"dub"; "original audio" -> ENG.
        val token = low.replace(Regex("""\s*(sub|dub)\s*$"""), "").trim()
        val code = codeOf[token] ?: codeOf[token.substringBefore(' ').trim()]
        if (code != null) {
            out.add(code)
        } else {
            // Unknown language — never hide it: raw chip, zone's fallback style.
            val rawToken = raw.trim().uppercase()
                .split(Regex("\\s+")).filter { it.isNotBlank() }
                .take(3).joinToString(" ").take(12)
            if (rawToken.isNotBlank()) out.add(rawToken)
        }
    }
    // Stable, sensible order (zone's preferred order).
    val preferred = listOf("ENG", "ARA", "FRE", "RUS", "SPA", "POR", "HIN", "TAM", "TEL", "BEN", "KOR", "JPN", "CHI", "GER", "ITA", "IND", "THA", "TUR", "VIE", "MAY")
    return preferred.filter { it in out } + out.filter { it !in preferred }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun EpisodeLanguageBadges(chips: List<String>?) {
    // Computed once per anime by the caller (Wrong-Title pick only). No per-card
    // loading or scraping — the chips are just rendered, rock-still layout.
    // maxItemsInEachRow = 5: a full 10-chip set (9 + "+N") wraps 5 + 5 instead
    // of overflowing one lopsided row and leaving dead space underneath.
    FlowRow(
        maxItemsInEachRow = 5,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        if (!chips.isNullOrEmpty()) {
            chips.take(MaxLangChips).forEach { code -> LanguageChip(code) }
            if (chips.size > MaxLangChips) {
                LanguageChip("+${chips.size - MaxLangChips}")
            }
        }
    }
}

@Composable
private fun LanguageChip(text: String) {
    // Paper mode keeps the ORIGINAL hardcoded ink (0xFF1A1A1A) — untouched.
    // Only dark mode switches to theme tokens (cream text, gray border) so the
    // chip stops being invisible there.
    val dark = AniwaveColors.isDark
    Box(
        modifier = Modifier
            .height(18.dp)
            .width(IntrinsicSize.Min)
            .clip(RoundedCornerShape(4.dp))
            .background(Color.Transparent)
            .border(1.dp, if (dark) Hairline else Color(0xFF1A1A1A), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (dark) TextPrimary else Color(0xFF1A1A1A),
            fontFamily = PlexMono,
            // Longer raw-language chips (unknown labels) render at a smaller
            // size so they stay inside the same compact box.
            fontSize = if (text.length > 4) 6.5.sp else 8.5.sp,
            fontWeight = FontWeight.Black,
            lineHeight = if (text.length > 4) 8.sp else 11.sp,
            maxLines = 1
        )
    }
}

/**
 * Rule 3 — Polished media / episode card.
 * Horizontal Coil thumbnail with an integrated watch-progress bar pinned to the
 * bottom edge of the image, plus a cleanly stacked metadata column on the right.
 * When [isSelectable] is true, a checkbox overlay appears on the thumbnail and
 * tapping the card toggles selection instead of playing.
 */
@Composable
fun EpisodeCard(
    episode: Episode,
    thumbnailUrl: String?,
    watchProgress: Float = 0f,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isSelectable: Boolean = false,
    isSelected: Boolean = false,
    onToggle: (() -> Unit)? = null,
    languageChips: List<String>? = null
) {
    val clickAction = if (isSelectable && onToggle != null) onToggle else onClick

    Row(modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp)
        .clip(RoundedCornerShape(14.dp))
        .border(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) Flame else Hairline,
            shape = RoundedCornerShape(14.dp)
        )
        .background(if (isSelected) Flame.copy(alpha = 0.08f) else SurfaceRaised)
        .clickable(onClick = clickAction)
        .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .width(140.dp)
                .height(80.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Background)
        ) {
            AsyncImage(
                model = thumbnailUrl,
                contentDescription = episode.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Play affordance (hidden when in selection mode)
            if (!isSelectable) {
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            // Episode chip
            Text(
                "E${episode.number}",
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Flame)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
            // Selection checkbox (top-right)
            if (isSelectable) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(24.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) Flame else Color.Black.copy(alpha = 0.55f))
                        .border(1.5f.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
            // Integrated watch-progress bar on the bottom edge of the image
            if (watchProgress > 0f) {
                LinearProgressIndicator(
                    progress = { watchProgress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .height(3.dp),
                    color = Flame,
                    trackColor = Color.Black.copy(alpha = 0.4f)
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "Episode ${episode.number}",
                color = Flame,
                fontFamily = PlexMono,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp,
                letterSpacing = 1.sp
            )
            Spacer(Modifier.height(3.dp))
            Text(
                episode.title,
                color = TextPrimary,
                fontFamily = Bricolage,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                lineHeight = 19.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            EpisodeLanguageBadges(chips = languageChips)
            Spacer(Modifier.height(4.dp))
            Text(
                episode.durationLabel,
                color = TextMuted,
                fontFamily = PlexMono,
                fontSize = 11.sp
            )
        }
    }
}
