package com.panime.app.data.api

import com.panime.app.data.model.Anime
import com.panime.app.data.model.AiringSchedule
import com.panime.app.data.model.DetailData
import com.panime.app.data.model.GenreChip
import com.panime.app.data.model.ScheduleDay
import com.panime.app.data.model.WeekSchedule
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.data.provider.anikoto.AnikotoProvider
import com.panime.app.util.Obf
import java.net.URLEncoder

/**
 * On-device scraper for anikoto.cz — the "Koto" discovery data source.
 *
 * When the user switches the provider switch to KOTO the repository routes every
 * browse/search/detail call through this object instead of AniList. The PLAYER
 * keeps using [AnikotoProvider]; this object only serves catalog + detail pages.
 *
 * === Id scheme ===
 * anikoto.cz cards carry an internal numeric id (`data-tip="1234"`) plus a URL
 * slug (`/watch/<slug>`). The app-wide [Anime.id] is `rawId + OFFSET` so Koto
 * ids can never collide with the AniList ids stored by the other provider mode
 * (shared cache / progress / My List). Every parsed card registers
 * rawId -> slug so [detail] can jump straight to the watch page. When the slug
 * is not in the registry (cold-start My List / Continue Watching), [detail]
 * falls back to a MAL bridge via [AnikotoProvider.resolveByMalId].
 *
 * === Endpoints (all verified against the live site) ===
 *  - /most-viewed                           popular (trending)
 *  - /status/finished-airing                completed (all-time popular)
 *  - /status/currently-airing               ongoing
 *  - /status/not-yet-aired                  upcoming
 *  - /new-release                           recently added
 *  - /latest-updated (paginated)            recently updated feed
 *  - /az-list?page=N&slug=<LETTER>          A-Z browse
 *  - /filter?season[]=&year[]=&page=N       seasonal listing
 *  - /filter?year[]=YYYY&page=N             year listing
 *  - /filter?sort=score&page=N              top 100 by score
 *  - /filter?keyword=&page=N                search (site keyword search)
 *  - /genre/<slug>?page=N                   genre browse
 *  - /watch/<slug>                          detail
 *  - /ajax/episode/list/<rawId>             real released-episode count
 *  - /ajax/schedule (+ /ajax/schedule/date) estimated weekly schedule
 *
 * Any failure throws; the repository wraps everything in Result/runCatching.
 */
object KotoApi {

    private val BASE = Obf.s("Mi4uKilgdXU7NDMxNS41dDkg")
    private const val OFFSET = 90_000_000

    /** rawId -> slug registry, populated from every parsed card + detail page. */
    private val slugByRawId = mutableMapOf<Int, String>()

    /** Browse genre id -> anikoto.cz slug, populated from the site's own /filter
     *  nav (48 real genres). The hardcoded [GENRE_SLUG] covers the first 19 as a
     *  pre-scrape fallback. */
    private val genreIdToSlug = mutableMapOf<Int, String>()

    /** rawId -> (released episode count, MAL id) from /ajax/episode/list. */
    private val epInfoByRawId = mutableMapOf<Int, Pair<Int, Int>>()

    fun appId(rawId: Int): Int = rawId + OFFSET

    fun rawId(appIdValue: Int): Int = appIdValue - OFFSET

    fun slugForRawId(rawId: Int): String? = slugByRawId[rawId]

    private fun html() = ScraperEngine.defaultHeaders(referer = "$BASE/")

    private fun fetch(url: String): String? =
        ScraperEngine.fetchText(url, html(), useCache = false)

    /** GET an ajax endpoint and unwrap its `{ status, result }` JSON body. */
    private suspend fun ajaxGet(url: String): String? {
        val body = ScraperEngine.fetchText(url, html() + mapOf("X-Requested-With" to "XMLHttpRequest"))
            ?: return null
        return runCatching { org.json.JSONObject(body) }
            .getOrNull()?.optString("result", "")?.ifBlank { body } ?: body
    }

    /** Unescape the common HTML entities anikoto emits (&amp;, &#039;, &quot;, &nbsp;…). */
    fun unescape(s: String): String = s
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#039;", "'")
        .replace("&#39;", "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&nbsp;", " ")
        .replace("&NBSP;", " ")

    private fun encode(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun seasonName(): String {
        val month = java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) + 1
        return when (month) {
            in 3..5 -> "spring"
            in 6..8 -> "summer"
            in 9..11 -> "fall"
            else -> "winter"
        }
    }

    private fun currentYear(): Int = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)

    // ── Release years ────────────────────────────────────────────────────────

    /**
     * The site's OWN release-year list, scraped from the /filter sidebar
     * (name="year[]" checkboxes, e.g. 1980..2026). Session-only cache — the
     * Browse "Release Year" filter uses exactly these years, never a hardcoded
     * range/cap of ours.
     */
    private var cachedYears: List<Int>? = null

    suspend fun siteYears(): List<Int> {
        cachedYears?.let { return it }
        val html = fetch("$BASE/filter?sort=score") ?: return emptyList()
        val years = Regex("""name="year\[\]" value="(\d{4})"""")
            .findAll(html).mapNotNull { it.groupValues[1].toIntOrNull() }
            .distinct().sortedDescending().toList()
        cachedYears = years
        return years
    }

    // ── Catalog ──────────────────────────────────────────────────────────────

    /** Trending: the site's Popular list (/most-viewed). */
    suspend fun trending(limit: Int = 24): List<Anime> =
        pagedList("/most-viewed", 1).items.take(limit)

    /** Top rated: the site's Completed catalogue (/status/finished-airing). */
    suspend fun topRated(limit: Int = 24): List<Anime> =
        pagedList("/status/finished-airing", 1).items.take(limit)

    /** Top 100 by score — pages 1..3 (the site serves ~40 cards per page). */
    suspend fun top100(): List<Anime> {
        val out = mutableListOf<Anime>()
        for (page in 1..3) {
            out += filterPage("sort=score", page).items
            if (out.size >= 100) break
        }
        return out.distinctBy { it.id }.take(100)
    }

    /** Current season + year. */
    suspend fun seasonal(limit: Int = 25): List<Anime> =
        filterPage("season%5B%5D=${seasonName()}&year%5B%5D=${currentYear()}", 1)
            .items.take(limit)

    /** New releases. */
    suspend fun newRelease(limit: Int = 24): List<Anime> =
        gridPage("$BASE/new-release").take(limit)

    /** Upcoming (not yet aired) — every page of the site's own /status/not-yet-aired list. */
    suspend fun upcoming(): List<Anime> {
        val out = mutableListOf<Anime>()
        var page = 1
        while (true) {
            val res = statusPage("not-yet-aired", page)
            if (res.items.isEmpty()) break
            out += res.items
            if (page >= res.lastPage) break
            page++
        }
        return out.distinctBy { it.id }
    }

    /** Recently updated — feeds the Home "Recently Updated" tiles.
     *  [episode] = latest released episode from the card's ep-status. The site lists
     *  no per-entry timestamp, so [airingAt] is left 0 — the tile shows ONLY what the
     *  site returns (episode + title), never a fabricated "x min ago" time.
     */
    suspend fun latestUpdated(limit: Int = 50): List<AiringSchedule> {
        val page = 1
        val html = fetch("$BASE/latest-updated?page=$page") ?: return emptyList()
        val cards = parseCards(html)
        if (cards.isEmpty()) return emptyList()
        return cards.take(limit).map { anime ->
            val eps = maxOf(
                anime.episodes ?: 0,
                (anime.nextEpisode?.minus(1))?.coerceAtLeast(0) ?: 0
            )
            AiringSchedule(
                id = anime.id,
                title = anime.title,
                cover = anime.posterUrl,
                episode = eps,
                totalEpisodes = anime.episodes,
                airingAt = 0L,
                status = "RELEASING",
                durationMin = null,
                anime = anime
            )
        }
    }

    /** Same list, flattened to Anime for the See-All screen. */
    suspend fun latestUpdatedAnime(limit: Int = 50): List<Anime> =
        latestUpdated(limit).mapNotNull { it.anime }

    // ── Search ───────────────────────────────────────────────────────────────

    /**
     * Site keyword search via /filter?keyword=. The site's keyword search is NOT
     * relevance-ranked (a failed multi-word query can dump the whole catalog), so
     * results are token-filtered: a card must share a meaningful fraction of the
     * query's tokens (or contain the query verbatim) to be shown.
     */
    suspend fun search(query: String): List<Anime> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val results = mutableListOf<Anime>()
        for (page in 1..2) {
            val html = fetch("$BASE/filter?keyword=${encode(q)}&page=$page") ?: break
            val batch = parseCards(html).filter { relevant(it, q) }
            results += batch
            if (batch.isEmpty()) break
        }
        return results.distinctBy { it.id }
    }

    /**
     * One page of keyword search (site parity: /filter?keyword=&page=N) plus the
     * site's true last page from its own pager, so the UI can paginate manually.
     * Same token relevance filter as [search] — a page may show fewer cards.
     */
    suspend fun searchPage(query: String, page: Int = 1): PagedItems {
        val q = query.trim()
        if (q.isEmpty()) return PagedItems(emptyList(), 1)
        val html = fetch("$BASE/filter?keyword=${encode(q)}&page=${page.coerceAtLeast(1)}")
            ?: return PagedItems(emptyList(), 1)
        val cards = parseCards(html).filter { relevant(it, q) }.distinctBy { it.id }
        return PagedItems(cards, lastPageOf(html))
    }

    private fun relevant(anime: Anime, query: String): Boolean {
        val qTokens = tokens(query)
        val tTokens = tokens(anime.title)
        if (qTokens.isEmpty()) return false
        if (anime.title.contains(query, ignoreCase = true)) return true
        if (tTokens.isEmpty()) return false
        val overlap = qTokens.intersect(tTokens).size
        val ratio = overlap.toDouble() / qTokens.size
        return ratio >= 0.3
    }

    private fun tokens(text: String): Set<String> =
        text.lowercase().split(Regex("[^a-z0-9]+")).filter { it.length >= 2 }.toSet()

    // ── Browse ───────────────────────────────────────────────────────────────

    /** Numeric BrowseGenres ids (1..19) -> anikoto.cz genre slug. */
    private val GENRE_SLUG = mapOf(
        1 to "action", 2 to "adventure", 3 to "comedy", 4 to "drama",
        5 to "ecchi", 6 to "fantasy", 7 to "horror", 8 to "mecha",
        9 to "music", 10 to "mystery", 11 to "psychological", 12 to "romance",
        13 to "sci-fi", 14 to "mahou-shoujo", 15 to "slice-of-life",
        16 to "space", 17 to "sports", 18 to "supernatural", 19 to "thriller"
    )

    fun genreSlug(genreId: Int): String? = genreIdToSlug[genreId] ?: GENRE_SLUG[genreId]

    /**
     * The site's REAL genre list scraped from the /filter header nav — every
     * `/genre/<slug>` link with its `title` label (48 genres: Action, Boys Love,
     * Cars, Dementia, Demons, Isekai, Josei, Magic, Martial Arts, Samurai, Seinen,
     * Shoujo, Shounen, Super Power, Suspense, Vampire, …). Ids are assigned in site
     * order so the chips can resolve to a slug immediately; the scrape also fills
     * [genreIdToSlug] so [genrePage] needs no hardcoded id->slug table for them.
     */
    suspend fun genres(): List<GenreChip> {
        val html = fetch("$BASE/filter") ?: return emptyList()
        val matches = Regex("href=\"/genre/([a-z0-9-]+)\" title=\"([^\"]+)\"")
            .findAll(html).toList()
        return matches.mapIndexed { i, m ->
            val slug = m.groupValues[1]
            genreIdToSlug[i + 1] = slug
            GenreChip(i + 1, unescape(m.groupValues[2]).trim())
        }
    }

    suspend fun genrePage(genreId: Int, page: Int): PagedItems {
        val slug = genreSlug(genreId) ?: return PagedItems(emptyList(), 1)
        return gridPagePaged("$BASE/genre/$slug?page=$page")
    }

    suspend fun yearPage(year: Int, page: Int): PagedItems =
        filterPage("year%5B%5D=$year", page)

    /** A-Z — the site's REAL letter pages, path form `/az-list/<LETTER>?page=N`
     *  (server-side filtered, e.g. A = Acro Trip/Arifureta/… only). The `?slug=`
     *  query form is ignored by the site and returns the full catalogue, so we
     *  never use it. "All" = the full catalogue. */
    suspend fun letterPage(letter: String, page: Int): PagedItems {
        if (letter.isBlank() || letter.equals("All", ignoreCase = true)) return allPage(page)
        val target = letter.trim().first().uppercaseChar()
        val html = fetch("$BASE/az-list/$target?page=$page") ?: return PagedItems(emptyList(), 1)
        return PagedItems(parseCards(html), lastPageOf(html))
    }

    /** Full A-Z catalogue (/az-list). */
    suspend fun allPage(page: Int): PagedItems = pagedList("/az-list", page)

    /** One page of /filter results with the site's real last page. */
    suspend fun filterPage(params: String, page: Int): PagedItems {
        val html = fetch("$BASE/filter?$params&page=$page") ?: return PagedItems(emptyList(), 1)
        return PagedItems(parseCards(html), lastPageOf(html))
    }

    /** One page of a plain paginated list path (e.g. /most-viewed?page=N). */
    private suspend fun pagedList(path: String, page: Int): PagedItems {
        val html = fetch("$BASE$path?page=$page") ?: return PagedItems(emptyList(), 1)
        return PagedItems(parseCards(html), lastPageOf(html))
    }

    private fun gridPage(url: String): List<Anime> {
        val html = fetch(url) ?: return emptyList()
        return parseCards(html)
    }

    private fun gridPagePaged(url: String): PagedItems {
        val html = fetch(url) ?: return PagedItems(emptyList(), 1)
        return PagedItems(parseCards(html), lastPageOf(html))
    }

    /** Paged /status/<slug> grid, e.g. not-yet-aired. */
    suspend fun statusPage(statusSlug: String, page: Int): PagedItems =
        gridPagePaged("$BASE/status/$statusSlug?page=$page")

    /** Paged Recently Updated feed (the site's /latest-updated?page=N). */
    suspend fun latestUpdatedPaged(page: Int): PagedItems = pagedList("/latest-updated", page)

    private fun lastPageOf(html: String): Int {
        val m = Regex("""title="Last"[^>]*href="[^"]*page=(\d+)""").find(html)
        return m?.groupValues?.get(1)?.toIntOrNull()?.coerceAtLeast(1) ?: 1
    }

    // ── Weekly schedule ───────────────────────────────────────────────────────

    /** Last-scraped week (day window + entries), reused by [scheduleDays] so the
     *  card never triggers a second batch of site fetches. In-memory only. */
    private var cachedWeek: WeekSchedule? = null

    /**
     * REAL estimated weekly schedule straight from the site's own widget:
     * /ajax/schedule returns the day tabs (UTC-midnight epoch + the site's own
     * date/weekday labels, e.g. "Aug 14"/"Fri"); each tab is then fetched via
     * /ajax/schedule/date?tz=0&time=<epoch>, whose entries carry the anime's
     * broadcast time (HH:MM UTC), episode number and title. No synthetic data —
     * every entry is scraped live and the day window is the site's own.
     */
    suspend fun schedule(): WeekSchedule {
        val widget = ajaxGet("$BASE/ajax/schedule?tz=0") ?: return WeekSchedule(emptyList(), emptyList())
        val dayTab = Regex(
            """<div class="inner"[^>]*data-time="(\d+)"[^>]*>\s*<div class="date">([^<]+)</div>\s*<div class="wday">([^<]+)</div>""",
            RegexOption.DOT_MATCHES_ALL
        )
        val days = dayTab.findAll(widget)
            .map { m ->
                val (epRaw, dateRaw, wdayRaw) = m.destructured
                val epoch = epRaw.toLongOrNull() ?: 0L
                if (epoch > 0L) ScheduleDay(epoch, unescape(dateRaw).trim(), unescape(wdayRaw).trim()) else null
            }
            .filterNotNull()
            .distinctBy { it.epoch }
            .take(7)
            .toList()
        if (days.isEmpty()) return WeekSchedule(emptyList(), emptyList())
        val out = mutableListOf<AiringSchedule>()
        val entry = Regex(
            """<a class="item[^"]*" href="[^"]*/watch/([a-z0-9-]+)[^"]*">.*?<div class="time" data-tip="(\d+)">(\d{1,2}):(\d{2})</div>.*?<span>Episode (\d+)</span>.*?<div class="title[^"]*"[^>]*>\s*([^<]+)<""",
            RegexOption.DOT_MATCHES_ALL
        )
        for (day in days) {
            val html = ajaxGet("$BASE/ajax/schedule/date?tz=0&time=${day.epoch}") ?: continue
            for (m in entry.findAll(html)) {
                val (slug, tipRaw, hhRaw, mmRaw, epRaw, titleRaw) = m.destructured
                val tip = tipRaw.toIntOrNull() ?: continue
                val hh = hhRaw.toIntOrNull() ?: continue
                val mm = mmRaw.toIntOrNull() ?: continue
                val title = unescape(titleRaw).trim()
                if (title.isBlank()) continue
                slugByRawId[tip] = slug
                out += AiringSchedule(
                    id = appId(tip),
                    title = title,
                    episode = epRaw.toIntOrNull() ?: 0,
                    airingAt = day.epoch + hh * 3600L + mm * 60L,
                    status = "RELEASING",
                    anime = null
                )
            }
        }
        val week = WeekSchedule(days, out.distinctBy { it.id })
        cachedWeek = week
        return week
    }

    /** The site's schedule day window — served from the last [schedule] scrape. */
    suspend fun scheduleDays(): List<ScheduleDay> = cachedWeek?.days ?: schedule().days

    // ── Detail ───────────────────────────────────────────────────────────────

    /**
     * Detail for a Koto app id. Resolves the slug from the in-memory registry and
     * falls back to the MAL bridge for cold-start ids (My List / Continue Watching).
     */
    suspend fun detail(appIdValue: Int): DetailData {
        val rawId = rawId(appIdValue)
        if (rawId <= 0) throw RuntimeException("Koto: not a Koto id ($appIdValue)")
        val slug = resolveSlugFor(rawId)
            ?: throw RuntimeException("Koto: could not resolve id $appIdValue")
        slugByRawId[rawId] = slug

        val html = fetch("$BASE/watch/$slug")
            ?: throw RuntimeException("Koto: failed to load '$slug'")
        val anime = parseWatch(html, rawId, slug)
            ?: throw RuntimeException("Koto: could not parse '$slug'")

        // Real released-episode count from the site's episode list (the watch page
        // itself reports "?" for airing shows).
        val epInfo = episodeInfo(rawId)
        val withCount = if (epInfo.first > 0) anime.copy(episodes = epInfo.first) else anime

        // The sidebar "Trending" widget (the same 10 cards as every grid page)
        // sits right after `class="sidebar"`; the real related grid is
        // `class="scaff side items md"`, so parse only that section.
        val relatedStart = html.indexOf("""class="scaff side items md"""")
        val related = parseCards(if (relatedStart >= 0) html.substring(relatedStart) else html).take(12)
        return DetailData(anime = withCount, characters = emptyList(), recommendations = related)
    }

    /** Slug for a raw koto id: registry, else data-mal bridge via AnikotoProvider. */
    private suspend fun resolveSlugFor(rawId: Int): String? {
        slugByRawId[rawId]?.let { return it }
        val mal = episodeInfo(rawId).second
        if (mal <= 0) return null
        return runCatching { AnikotoProvider().resolveByMalId(mal) }.getOrNull()
    }

    /** Fetch /ajax/episode/list once per rawId; returns (released count, MAL id). */
    private suspend fun episodeInfo(rawId: Int): Pair<Int, Int> {
        epInfoByRawId[rawId]?.let { return it }
        val html = ajaxGet("$BASE/ajax/episode/list/$rawId") ?: return 0 to 0
        var count = 0
        var mal = 0
        for (m in Regex("""data-num="(\d+)""").findAll(html)) {
            m.groupValues[1].toIntOrNull()?.let { if (it > count) count = it }
        }
        Regex("""data-mal="(\d+)""").find(html)?.groupValues?.get(1)?.toIntOrNull()?.let { mal = it }
        val info = count to mal
        epInfoByRawId[rawId] = info
        return info
    }

    private fun parseWatch(html: String, rawId: Int, slug: String): Anime? {
        val title = Regex("""<h1 itemprop="name"[^>]*>\s*([^<]{1,300})\s*</h1>""")
            .find(html)?.groupValues?.get(1)?.let { unescape(it).trim() }
            ?: return null
        if (title.isBlank()) return null

        val poster = Regex("""itemprop="image" src="([^"]+)""").find(html)?.groupValues?.get(1)
        val scoreRaw = Regex("""itemprop="ratingValue"[^>]*>\s*([\d.]+)""")
            .find(html)?.groupValues?.get(1)?.toDoubleOrNull()
        val rating = Regex("""<i class="rating">([^<]+)</i>""")
            .find(html)?.groupValues?.get(1)?.trim()

        val synopsis = Regex(
            """<div class="shorting">\s*<div class="content">(.*?)</div>""",
            RegexOption.DOT_MATCHES_ALL
        ).find(html)?.groupValues?.get(1)
            ?.replace(Regex("<[^>]*>"), "")
            ?.replace(Regex("""\[Written by MAL Rewrite]"""), "")
            ?.let { unescape(it).trim() }
            .orEmpty()

        // Meta block. Sidebar widgets contain genre/status links with empty text,
        // so every field that also exists outside the block (status, genres,
        // studios, producers, MAL score) is parsed from the .bmeta segment only.
        val bmetaStart = html.indexOf("class=\"bmeta\"")
        val bmetaEnd = html.indexOf("class=\"brating\"", if (bmetaStart >= 0) bmetaStart else 0)
        val bm = if (bmetaStart >= 0 && bmetaEnd > bmetaStart) {
            html.substring(bmetaStart, bmetaEnd)
        } else html

        val malScore = Regex("""MAL:\s*<span>\s*([\d.]+)""")
            .find(bm)?.groupValues?.get(1)?.toDoubleOrNull()
        val typeRaw = Regex("""Type:\s*<span>\s*([^<]+)""")
            .find(bm)?.groupValues?.get(1)?.trim()
        val aired = Regex("""Aired:\s*<span>\s*([^<]+)""")
            .find(bm)?.groupValues?.get(1)?.trim()
        val statusText = Regex("""/status/(?:[a-z-]+)"[^>]*>\s*(?:<[^>]*>\s*)*([^<]+)<""")
            .find(bm)?.groupValues?.get(1)?.trim()

        // Links may wrap their label in <span itemprop="name"> — skip any inner tags.
        fun namedLinks(path: String): List<String> =
            Regex("""/$path/[a-z0-9-]+"[^>]*>\s*(?:<[^>]*>\s*)*([^<]{1,100})<""")
                .findAll(bm).map { unescape(it.groupValues[1]).trim() }
                .filter { it.isNotBlank() }.distinct().toList()
        val genres = namedLinks("genre")
        val studios = namedLinks("studio")

        val startDate = parseAired(aired)
        val season = startDate?.let { monthSeason(it.first) }
        val isAdult = rating?.startsWith("Rx", ignoreCase = true) == true

        return Anime(
            id = appId(rawId),
            title = title,
            synopsis = synopsis,
            posterUrl = poster,
            bannerUrl = poster,
            score = malScore ?: scoreRaw,
            episodes = null, // filled in from the ajax episode list by [detail]
            year = startDate?.second,
            season = season,
            startYear = startDate?.second,
            startMonth = startDate?.first,
            type = mapType(typeRaw),
            status = mapStatus(statusText),
            rating = rating?.trim()?.takeIf { it.isNotBlank() },
            genres = genres,
            studios = studios,
            isAdult = isAdult,
            kotoSlug = slug
        )
    }

    /** "Oct 20, 1999 to ?" -> (month, year). */
    private fun parseAired(aired: String?): Pair<Int, Int>? {
        val text = aired?.trim().orEmpty()
        val m = Regex("""^([A-Za-z]+)\s+\d{1,2},\s+(\d{4})""").find(text) ?: return null
        val month = monthNum(m.groupValues[1]) ?: return null
        val year = m.groupValues[2].toIntOrNull() ?: return null
        return month to year
    }

    private fun monthNum(name: String): Int? = when (name.lowercase().take(3)) {
        "jan" -> 1; "feb" -> 2; "mar" -> 3; "apr" -> 4; "may" -> 5; "jun" -> 6
        "jul" -> 7; "aug" -> 8; "sep" -> 9; "oct" -> 10; "nov" -> 11; "dec" -> 12
        else -> null
    }

    private fun monthSeason(month: Int): String = when (month) {
        in 3..5 -> "SPRING"; in 6..8 -> "SUMMER"; in 9..11 -> "FALL"; else -> "WINTER"
    }

    private fun mapType(raw: String?): String? = when (raw?.trim()?.uppercase()) {
        "TV SPECIAL", "SPECIAL" -> "SPECIAL"
        "TV_SHORT", "TV SHORT" -> "TV_SHORT"
        "MUSIC" -> "MUSIC"
        else -> raw?.trim()?.uppercase()
    }

    /** Site status labels -> the app's AniList-style status strings. */
    private fun mapStatus(text: String?): String? = when (text?.lowercase()?.trim()) {
        "currently airing", "currently-airing" -> "RELEASING"
        "finished", "finished airing", "finished-airing" -> "FINISHED"
        "not yet aired", "not-yet-aired" -> "NOT_YET_RELEASED"
        else -> null
    }

    // ── Card parsing ─────────────────────────────────────────────────────────

    /**
     * Parse the page's real card grid. anikoto embeds a "Top rated anime" sidebar
     * widget (10 cards, `class="sidebar"`) AFTER the main `#list-items` grid on
     * EVERY page — scraping it would append the same ten titles to every browse/
     * search/home grid. So we only read the main `#list-items` container. Detail
     * pages have no `#list-items`, so they keep the whole document (their "related"
     * rows live elsewhere on the page).
     */
    fun parseCards(html: String): List<Anime> {
        val gridStart = html.indexOf("""id="list-items"""")
        val main = if (gridStart >= 0) {
            html.substring(gridStart).substringBefore("""class="sidebar"""")
        } else {
            html
        }
        val starts = Regex("""class="item["\s>]""").findAll(main).map { it.range.first }.toList()
        val out = mutableListOf<Anime>()
        for (i in starts.indices) {
            val end = if (i + 1 < starts.size) starts[i + 1] else main.length
            val block = main.substring(starts[i], end)
            parseCard(block)?.let { out += it }
        }
        return out.distinctBy { it.id }
    }

    private fun parseCard(block: String): Anime? {
        val tip = Regex("""data-tip="(\d+)""").find(block)?.groupValues?.get(1)?.toIntOrNull()
            ?: return null
        if (tip <= 0) return null
        val slug = Regex("""/watch/([a-z0-9-]+)(?:/ep-\d+)?""").find(block)?.groupValues?.get(1)
            ?: return null
        val img = Regex("""<img[^>]*src="([^"]+)""").find(block)?.groupValues?.get(1)
        val alt = Regex("""<img[^>]*alt="([^"]*)""").find(block)?.groupValues?.get(1).orEmpty()

        val sub = Regex("""ep-status sub"><span>\s*(\d+)""").find(block)?.groupValues?.get(1)?.toIntOrNull()
        val dub = Regex("""ep-status dub"><span>\s*(\d+)""").find(block)?.groupValues?.get(1)?.toIntOrNull()
        val total = Regex("""ep-status total"><span>\s*(\d+)""").find(block)?.groupValues?.get(1)?.toIntOrNull()

        val type = Regex("""class="right">\s*([^<]+)""").find(block)?.groupValues?.get(1)?.trim()
            ?: Regex("""<span class="dot">\s*([^<]+)""").find(block)?.groupValues?.get(1)?.trim()

        val titleRaw = Regex("""d-title"[^>]*>\s*([^<]{1,200})\s*</a>""")
            .find(block)?.groupValues?.get(1)
            ?: Regex("""d-title"[^>]*>\s*([^<]{1,200})\s*</div>""")
                .find(block)?.groupValues?.get(1)
        var title = unescape(titleRaw?.trim().orEmpty()).trim()
        if (title.isBlank()) title = unescape(alt).trim()
        if (title.isBlank()) return null

        val score = Regex("""m-item rated"><span>\s*([\d.]+)""")
            .find(block)?.groupValues?.get(1)?.toDoubleOrNull()
        val genres = Regex("""/genre/[a-z0-9-]+"[^>]*>\s*([^<]+)<""")
            .findAll(block).map { unescape(it.groupValues[1]).trim() }
            .filter { it.isNotBlank() }.distinct().toList()

        slugByRawId[tip] = slug

        val released = maxOf(sub ?: 0, dub ?: 0)
        val hasEp = released > 0
        val status = when {
            total != null && total > 0 && (!hasEp || released >= total) -> "FINISHED"
            hasEp -> "RELEASING"
            else -> "NOT_YET_RELEASED"
        }
        val episodes = total ?: if (hasEp) released else null
        val adult = block.contains("class=\"adult\"") || block.contains(">Rx<")

        return Anime(
            id = appId(tip),
            title = title,
            synopsis = "",
            posterUrl = img,
            bannerUrl = img,
            score = score,
            episodes = episodes,
            type = mapType(type),
            status = status,
            rating = null,
            genres = genres,
            isAdult = adult,
            kotoSlug = slug
        )
    }
}

/** One page of grid results plus the site's true last page. */
data class PagedItems(
    val items: List<Anime>,
    val lastPage: Int
)
