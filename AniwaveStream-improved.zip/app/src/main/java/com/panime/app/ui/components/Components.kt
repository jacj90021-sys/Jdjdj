package com.panime.app.ui.components

// ── Backward-compatibility shim ───────────────────────────────────────────────
// All composables that lived here have been split into focused files:
//
//   LoadingBox.kt         — LoadingBox
//   ErrorBox.kt           — ErrorBox, FriendlyErrorScreen
//   FriendlyError.kt      — FriendlyError, FriendlyErrorIcon, toFriendlyError()
//   Shimmer.kt            — Modifier.shimmer, ShimmerBox, HomeShimmer, etc.
//   EpisodeCard.kt        — EpisodeCard
//   CharacterRow.kt       — CharacterRow
//   SectionCard.kt        — SectionHeader, AnivaveSectionCard, AnivaveSectionCardNoHeader
//   Buttons.kt            — PrimaryPillButton, SecondaryPillButton
//   MiscComponents.kt     — AnimePosterCard, AnimeRow, AnimeRankedCard, AnimeRankedRow,
//                            ContinueCard, HeroBanner, AnivaveHeroSlider, AnivaveChipRow,
//                            AnivaveUpcomingRow, AnivaveUpcomingCard, AnivaveNewReleasesGrid,
//                            AnivaveScheduleCard, ScheduleRow
//
// Since all files share the same package (com.panime.app.ui.components), existing
// imports like `import com.panime.app.ui.components.PrimaryPillButton` continue
// to resolve correctly — no code changes needed in callers.
