package com.panime.app.download

import android.content.Context
import org.json.JSONObject

/**
 * Persistent mapping of a download's manifest base path -> its stable download id.
 *
 * The whole point of this registry is durability: the HLS cache identity for a
 * download must survive process death, otherwise a user who downloads 10%, gets
 * killed, comes back a day later via a fresh process (with the URL now rotated to
 * a DIFFERENT path) would still lose the 10% — because the app would not know the
 * new segments belong to the pre-existing download.
 *
 * SharedPreferences is the same persistence mechanism Media3's own retry counters
 * and header registry use, and it is read synchronously at factory construction,
 * so the [StableDownloadCacheKeyFactory] can pick up prior registrations even in
 * a brand-new process before any download is started.
 */
object DownloadCacheRegistry {

    private const val PREFS = "dl_cache_registry"
    private const val JSON_KEY = "bases" // JSONObject { basePath: downloadId }

    @Volatile
    private var cache: Map<String, String>? = null

    /**
     * Registers (or re-registers) `manifestBasePath -> downloadId`.
     *
     * Re-registration with a NEW base path (after a URL refresh that changed the
     * CDN path) pointing at the SAME downloadId is what lets segments downloaded
     * under the old path resolve to the same stable cache namespace.
     */
    fun register(context: Context, manifestBasePath: String, downloadId: String) {
        if (manifestBasePath.isBlank() || downloadId.isBlank()) return
        // Normalize: keep the directory form, no query/fragment, no trailing slash.
        val norm = normalizeBase(manifestBasePath) ?: return
        val map = snapshot(context).toMutableMap()
        map[norm] = downloadId
        persist(context, map)
        cache = map
    }

    /** Removes every entry owned by [downloadId] (used when a download is deleted). */
    fun unregister(context: Context, downloadId: String) {
        val map = snapshot(context).filterValues { it != downloadId }
        persist(context, map)
        cache = map
    }

    /** Current snapshot of `manifestBase -> downloadId`, for the key factory. */
    fun currentBases(context: Context): Map<String, String> = snapshot(context)

    /**
     * Returns the stable download id for a segment URL, if a registered base is a
     * path-prefix of it. Longest match wins. Delegates to [StableCacheKeyCore].
     */
    fun downloadIdFor(context: Context, segmentUri: String): String? =
        StableCacheKeyCore.match(segmentUri, snapshot(context))?.second

    /** The registered base that is a strict path-prefix of [segmentUri], or null. */
    fun matchedBase(context: Context, segmentUri: String): String? =
        StableCacheKeyCore.match(segmentUri, snapshot(context))?.first

    // ── Internals ─────────────────────────────────────────────────────────

    private fun snapshot(context: Context): Map<String, String> {
        cache?.let { return it }
        val stored = runCatching {
            context.applicationContext
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(JSON_KEY, null)
        }.getOrNull()
        val map = if (stored.isNullOrBlank()) emptyMap() else runCatching {
            val o = JSONObject(stored)
            buildMap {
                o.keys().forEach { k -> o.optString(k).takeIf { it.isNotBlank() }?.let { put(k, it) } }
            }
        }.getOrDefault(emptyMap())
        cache = map
        return map
    }

    private fun persist(context: Context, map: Map<String, String>) {
        runCatching {
            val o = JSONObject()
            map.forEach { (k, v) -> o.put(k, v) }
            context.applicationContext
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(JSON_KEY, o.toString()).apply()
        }
    }

    /**
     * Normalizes a manifest URL into its directory (base) form shown to the
     * registry — the playlist filename removed. Uses [StableCacheKeyCore] so the
     * exact same rules the factory relies on are shared and unit-testable.
     */
    fun normalizeBase(url: String): String? =
        StableCacheKeyCore.baseOf(url).takeIf { it.isNotEmpty() }
}