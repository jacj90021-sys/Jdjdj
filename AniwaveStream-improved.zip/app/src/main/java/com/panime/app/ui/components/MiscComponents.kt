package com.panime.app.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.panime.app.data.model.Anime
import com.panime.app.data.model.DayAiring
import com.panime.app.data.model.NewReleaseEpisode
import com.panime.app.data.model.ScheduleDay
import com.panime.app.data.model.toUpcomingDisplay
import com.panime.app.ui.theme.AnivaveArt
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Cool
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Gold
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.InkBorder
import com.panime.app.ui.theme.OrangePrimary
import com.panime.app.ui.theme.Paper2
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.Purple
import com.panime.app.ui.theme.SharpCorner
import com.panime.app.ui.theme.UpcomingPurple
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.theme.TextOnDark
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary
import com.panime.app.ui.theme.Void

// ── Shared schedule-row geometry ──────────────────────────────────────────────
private val ROW_HEIGHT = 76.dp
private val COVER_SIZE = 54.dp
private val ROW_CORNER = 14.dp
private val ROW_PAD = 10.dp

// ── Shared hero/upcoming constants ────────────────────────────────────────────
private const val HERO_WINDOW = 8
private const val HERO_ROTATE_HOURS = 2L
private const val UPCOMING_WINDOW = 8
private const val UPCOMING_ROTATE_MINUTES = 30L

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AnimePosterCard(
    anime: Anime,
    onClick: () -> Unit,
    onLongPress: () -> Unit = {},
    modifier: Modifier = Modifier.width(120.dp),
    showScore: Boolean = true,
    watchedProgress: Int? = null,
    totalEpisodes: Int? = null,
    status: String? = null,
    showStatusBadge: Boolean = false
) {
    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val isPressed = interactionSource.collectIsPressedAsState()
    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }
    val alpha by animateFloatAsState(
        targetValue = if (appeared) 1f else 0f,
        animationSpec = tween(durationMillis = 350),
        label = "card-alpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (appeared) 1f else 0.92f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "card-scale"
    )
    Column(
        modifier
            .graphicsLayer { this.alpha = alpha; scaleX = scale; scaleY = scale }
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick,
                onLongClick = onLongPress
            )
    ) {

        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Hairline, RoundedCornerShape(14.dp))
        ) {
            AnivaveArt(
                anime = anime,
                modifier = Modifier.fillMaxSize(),
                showImage = true
            )
            if (showScore && anime.score != null) {
                Row(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = null,
                        tint = Gold,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(Modifier.width(2.dp))
                    Text(
                        String.format("%.1f", anime.score),
                        color = TextOnDark,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            if (showStatusBadge && !status.isNullOrBlank()) {
                val (bg, fg) = when (status.trim()) {
                    "Completed" -> Color(0xFF22C55E) to Color.Black
                    "Plan to Watch" -> OrangePrimary to Color.Black
                    "Paused" -> Color(0xFFEAB308) to Color.Black
                    "Dropped" -> Color(0xFFEF4444) to Color.White
                    "Watching" -> Color(0xFF3B82F6) to Color.White
                    "Rewatching" -> Color(0xFFA855F7) to Color.White
                    else -> SurfaceRaised to TextPrimary
                }
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(bg)
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = status.trim().uppercase(),
                        color = fg,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
            if (anime.posterUrl == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        anime.title,
                        color = TextOnDark,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
        watchedProgress?.let { progress ->
            val total = totalEpisodes ?: (anime.episodes ?: 0)
            if (total > 0) {
                val left = progress.coerceIn(0, total)
                Text(
                    text = "$left | $total",
                    color = TextSecondary,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                )
            }
        }
        Text(
            text = anime.title,
            color = TextSecondary,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun AnimeRow(
    items: List<Anime>,
    onAnimeClick: (Anime) -> Unit,
    contentPadding: PaddingValues = PaddingValues(start = 16.dp, end = 32.dp)
) {
    LazyRow(
        contentPadding = contentPadding,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items, key = { it.id }) { anime ->
            AnimePosterCard(anime = anime, onClick = { onAnimeClick(anime) })
        }
    }
}

@Composable
fun AnimeRankedCard(
    anime: Anime,
    rank: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.width(120.dp)
) {
    val rankColor = when {
        rank <= 3 -> Gold
        rank <= 10 -> Flame
        else -> TextOnDark
    }
    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }
    val alpha by animateFloatAsState(
        targetValue = if (appeared) 1f else 0f,
        animationSpec = tween(durationMillis = 350),
        label = "ranked-alpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (appeared) 1f else 0.92f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "ranked-scale"
    )
    Column(
        modifier
            .graphicsLayer { this.alpha = alpha; scaleX = scale; scaleY = scale }
            .clickable(onClick = onClick)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Hairline, RoundedCornerShape(14.dp))
        ) {
            AnivaveArt(anime = anime, modifier = Modifier.fillMaxSize(), showImage = true)
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .padding(top = 5.dp, start = 5.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            ) {
                Text(
                    "#$rank",
                    color = rankColor,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    letterSpacing = (-1).sp
                )
            }
            if (anime.score != null) {
                Row(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.Black.copy(alpha = 0.7f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Gold, modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(2.dp))
                    Text(String.format("%.1f", anime.score), color = TextOnDark, style = MaterialTheme.typography.labelSmall)
                }
            }
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.92f)),
                            startY = 0f, endY = 90f
                        )
                    )
                    .padding(start = 10.dp, end = 10.dp, bottom = 9.dp, top = 22.dp)
            ) {
                Text(
                    anime.title,
                    color = TextOnDark,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    lineHeight = 15.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun AnimeRankedRow(
    items: List<Anime>,
    onAnimeClick: (Anime) -> Unit,
    contentPadding: PaddingValues = PaddingValues(start = 16.dp, end = 32.dp)
) {
    LazyRow(
        contentPadding = contentPadding,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items, key = { it.id }) { anime ->
            val rank = items.indexOf(anime) + 1
            AnimeRankedCard(anime = anime, rank = rank, onClick = { onAnimeClick(anime) })
        }
    }
}

@Composable
fun ContinueCard(
    anime: Anime,
    episode: Int,
    progress: Float,
    onClick: () -> Unit,
    completedCount: Int = 0,
    totalEpisodes: Int = 0
) {
    val isCompleted = progress >= 0.9f
    val statusLabel = if (isCompleted) "E$episode · Completed" else "E$episode · Continue"
    val countLabel = if (totalEpisodes > 0 && completedCount > 0) "$completedCount/$totalEpisodes" else null
    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }
    val alpha by animateFloatAsState(
        targetValue = if (appeared) 1f else 0f,
        animationSpec = tween(durationMillis = 350),
        label = "continue-alpha"
    )
    val scale by animateFloatAsState(
        targetValue = if (appeared) 1f else 0.92f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "continue-scale"
    )
    Row(
        Modifier
            .graphicsLayer { this.alpha = alpha; scaleX = scale; scaleY = scale }
            .width(280.dp)
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, Hairline, RoundedCornerShape(14.dp))
            .background(SurfaceRaised)
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(width = 72.dp, height = 100.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Background)
        ) {
            AsyncImage(
                model = anime.posterUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Icon(
                if (isCompleted) Icons.Default.Check else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = if (isCompleted) Flame else Color.White,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(28.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                anime.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = TextPrimary,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    statusLabel,
                    color = if (isCompleted) Flame else TextMuted,
                    style = MaterialTheme.typography.bodySmall
                )
                if (countLabel != null) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        countLabel,
                        color = TextMuted,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0.05f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = if (isCompleted) Flame else OrangePrimary,
                trackColor = Paper2
            )
        }
    }
}

@Composable
fun HeroBanner(
    anime: Anime,
    onPlay: () -> Unit,
    onDetails: () -> Unit,
    pageCount: Int = 5,
    selectedPage: Int = 0
) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(460.dp)
    ) {
        AsyncImage(
            model = anime.bannerUrl ?: anime.posterUrl,
            contentDescription = anime.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color(0xFF121212))
                    )
                )
        )
        Box(
            Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .height(96.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF121212).copy(alpha = 0.85f), Color.Transparent)
                    )
                )
        )
        Row(
            Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                "ANIVAVE",
                color = OrangePrimary,
                fontWeight = FontWeight.Black,
                fontSize = 22.sp,
                letterSpacing = 2.sp
            )
        }
        Column(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, end = 16.dp, bottom = 20.dp)
        ) {
            Text(
                "FEATURED",
                color = OrangePrimary,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            Text(
                anime.title,
                style = MaterialTheme.typography.displayLarge.copy(fontSize = MaterialTheme.typography.displayLarge.fontSize * 0.7f),
                color = TextOnDark,
                fontWeight = FontWeight.Black,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(6.dp))
            val meta = listOfNotNull(
                anime.score?.let { "★ ${String.format("%.1f", it)}" },
                anime.year?.toString(),
                anime.type,
                anime.episodes?.let { "$it eps" }
            ).joinToString("  ·  ")
            Text(meta, color = TextOnDark.copy(alpha = 0.72f), style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                anime.synopsis,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                color = TextOnDark.copy(alpha = 0.72f),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryPillButton(
                    text = "Start Watching E1",
                    onClick = onPlay,
                    leadingIcon = Icons.Default.PlayArrow,
                    onMedia = true
                )
                SecondaryPillButton(text = "Details", onClick = onDetails, onMedia = true)
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(pageCount) { index ->
                    val selected = index == selectedPage
                    Box(
                        Modifier
                            .height(4.dp)
                            .width(if (selected) 22.dp else 10.dp)
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (selected) OrangePrimary else Color.White.copy(alpha = 0.35f)
                            )
                    )
                }
            }
        }
    }
}

@Composable
fun AnivaveHeroSlider(
    items: List<Anime>,
    onPlay: (Anime) -> Unit,
    onDetails: (Anime) -> Unit,
    onWatchlist: (Anime) -> Unit,
    myListIds: Set<Int> = emptySet()
) {
    if (items.isEmpty()) return

    var window by remember(items) {
        mutableStateOf(items.shuffled().take(HERO_WINDOW))
    }
    val pagerState = androidx.compose.foundation.pager.rememberPagerState(pageCount = { window.size })

    LaunchedEffect(items) {
        if (items.size <= HERO_WINDOW) return@LaunchedEffect
        while (true) {
            kotlinx.coroutines.delay(HERO_ROTATE_HOURS * 60 * 60 * 1000)
            window = items.shuffled().take(HERO_WINDOW)
            pagerState.scrollToPage(0)
        }
    }

    LaunchedEffect(window, pagerState) {
        if (window.size <= 1) return@LaunchedEffect
        while (true) {
            kotlinx.coroutines.delay(5000)
            if (!pagerState.isScrollInProgress) {
                val next = (pagerState.currentPage + 1) % window.size
                pagerState.animateScrollToPage(next)
            }
        }
    }

    Box(
        Modifier
            .fillMaxWidth()
            .height(440.dp)
            .border(1.dp, Hairline, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
    ) {
        androidx.compose.foundation.pager.HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val anime = window[page]
            val inList = anime.id in myListIds
            Box(Modifier.fillMaxSize()) {
                AnivaveArt(anime = anime, modifier = Modifier.fillMaxSize())
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF08080A).copy(alpha = 0.85f), Color.Transparent),
                            startY = 0f, endY = 240f
                        )
                    )
                )
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0xFF0D0D0D).copy(alpha = 0.9f)),
                            startY = 380f
                        )
                    )
                )
                Column(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 18.dp, end = 18.dp, bottom = 20.dp)
                ) {
                    Row(
                        Modifier
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.55f))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(Flame)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            anime.studios.firstOrNull() ?: "FEATURED",
                            color = TextOnDark,
                            fontFamily = com.panime.app.ui.theme.Inter,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        anime.title,
                        color = TextOnDark,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 26.sp,
                        lineHeight = 30.sp,
                        letterSpacing = 0.2.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        val score = anime.score
                        if (score != null) {
                            Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(14.dp), tint = Gold)
                            Spacer(Modifier.width(4.dp))
                            Text(
                                "%.1f".format(score),
                                color = Gold,
                                fontFamily = com.panime.app.ui.theme.Inter,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(
                            listOfNotNull(anime.year?.toString(), anime.type).joinToString(" · "),
                            color = TextOnDark.copy(alpha = 0.8f),
                            fontFamily = com.panime.app.ui.theme.Inter,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp,
                            style = androidx.compose.ui.text.TextStyle(
                                shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.8f), blurRadius = 6f)
                            )
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        PrimaryPillButton(
                            text = "Watch now",
                            onClick = { onPlay(anime) },
                            leadingIcon = Icons.Default.PlayArrow,
                            onMedia = true
                        )
                        SecondaryPillButton(
                            text = if (inList) "In list" else "Watchlist",
                            leadingIcon = if (inList) Icons.Default.Check else Icons.Default.Add,
                            onClick = { onWatchlist(anime) },
                            onMedia = true,
                            marked = inList
                        )
                    }
                }
            }
        }

        val scope = rememberCoroutineScope()
        Row(
            Modifier
                .align(Alignment.TopEnd)
                .padding(top = 18.dp, end = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            repeat(minOf(window.size, 5)) { i ->
                val active = i == pagerState.currentPage % 5
                Box(
                    Modifier
                        .height(6.dp)
                        .width(if (active) 18.dp else 6.dp)
                        .clip(CircleShape)
                        .background(if (active) Flame else Color.White.copy(alpha = 0.3f))
                        .clickable { scope.launch { pagerState.animateScrollToPage(i) } }
                )
            }
        }
    }
}

@Composable
fun AnivaveChipRow(
    categories: List<String>,
    selected: String?,
    onSelect: (String?) -> Unit
) {
    androidx.compose.foundation.lazy.LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            AnivaveChip("All", selected == null) { onSelect(null) }
        }
        items(categories, key = { it }) { cat ->
            AnivaveChip(cat, selected == cat) { onSelect(cat) }
        }
    }
}

@Composable
private fun AnivaveChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (active) Flame else SurfaceRaised)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            label,
            color = if (active) TextOnDark else TextPrimary,
            fontFamily = com.panime.app.ui.theme.Inter,
            fontWeight = FontWeight.Medium,
            fontSize = 13.sp
        )
    }
}

@Composable
fun AnivaveUpcomingRow(
    pool: List<Anime>,
    onItem: (Anime) -> Unit,
    modifier: Modifier = Modifier
) {
    if (pool.isEmpty()) return
    var window by remember(pool) {
        mutableStateOf(pool.shuffled().take(UPCOMING_WINDOW.coerceAtMost(pool.size)))
    }
    LaunchedEffect(pool) {
        if (pool.size <= UPCOMING_WINDOW) return@LaunchedEffect
        while (true) {
            delay(UPCOMING_ROTATE_MINUTES * 60 * 1000)
            val fresh = pool.filter { it.id !in window.map { w -> w.id }.toSet() }
                .shuffled()
                .take(UPCOMING_WINDOW)
            window = if (fresh.size >= UPCOMING_WINDOW) {
                fresh
            } else {
                pool.shuffled().take(UPCOMING_WINDOW)
            }
        }
    }
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(window, key = { it.id }) { anime ->
            AnivaveUpcomingCard(anime, { onItem(anime) })
        }
    }
}

@Composable
fun AnivaveUpcomingCard(
    anime: Anime,
    onItem: () -> Unit,
    modifier: Modifier = Modifier
) {
    var alertOn by remember { mutableStateOf(false) }
    val airingAt = anime.nextAiringAt ?: 0L
    val now0 = System.currentTimeMillis() / 1000L
    val tick = remember(airingAt) { mutableStateOf(now0) }
    LaunchedEffect(airingAt) {
        if (airingAt <= 0L) return@LaunchedEffect
        while (true) {
            tick.value = System.currentTimeMillis() / 1000L
            if (tick.value >= airingAt) break
            delay(1000L)
        }
    }
    val display = remember(anime, tick.value) { anime.toUpcomingDisplay(tick.value) }

    val kb = rememberInfiniteTransition()
    val kbScale by kb.animateFloat(
        initialValue = 1f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(11000, easing = LinearEasing), RepeatMode.Reverse)
    )
    val kbX by kb.animateFloat(
        initialValue = -8f, targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(11000, easing = LinearEasing), RepeatMode.Reverse)
    )
    val kbY by kb.animateFloat(
        initialValue = -6f, targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(11000, easing = LinearEasing), RepeatMode.Reverse)
    )
    Box(
        modifier
            .width(280.dp)
            .clip(RoundedCornerShape(18.dp))
    ) {
        AsyncImage(
            model = anime.bannerUrl ?: anime.posterUrl,
            contentDescription = anime.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .matchParentSize()
                .graphicsLayer {
                    scaleX = kbScale
                    scaleY = kbScale
                    translationX = kbX.dp.toPx()
                    translationY = kbY.dp.toPx()
                }
                .blur(0.6.dp)
                .clipToBounds()
        )
        Box(
            Modifier
                .matchParentSize()
                .background(Color.Black.copy(alpha = 0.45f))
        )
        Row(
            modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, Hairline, RoundedCornerShape(18.dp))
                .clickable { onItem() }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
        Box(
            Modifier
                .size(74.dp, 100.dp)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, Hairline, RoundedCornerShape(10.dp))
        ) {
            AnivaveArt(anime = anime, modifier = Modifier.fillMaxSize())
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Box(
                Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Purple)
                    .border(1.dp, Purple.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 1.dp)
            ) {
                Text(
                    display.badge,
                    color = Color.White,
                    fontFamily = PlexMono,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                anime.title,
                color = Color.White,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(shadow = Shadow(color = Color.Black, offset = Offset(0f, 0f), blurRadius = 10f))
            )
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (display.liveCountdown) {
                    Icon(
                        Icons.Default.Schedule,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.92f),
                        modifier = Modifier.size(11.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    display.meta,
                    color = Color.White.copy(alpha = 0.92f),
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(shadow = Shadow(color = Color.Black, offset = Offset(0f, 0f), blurRadius = 8f))
                )
            }
        }
        Box(
            Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .border(1.dp, Hairline, RoundedCornerShape(8.dp))
                .background(if (alertOn) Flame.copy(alpha = 0.15f) else SurfaceRaised)
                .clickable { alertOn = !alertOn },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.Notifications,
                contentDescription = "Alert",
                tint = if (alertOn) Flame else TextMuted,
                modifier = Modifier.size(16.dp)
            )
        }
        }
    }
}

@Composable
fun AnivaveNewReleasesGrid(
    items: List<NewReleaseEpisode>,
    onItem: (NewReleaseEpisode) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyRow(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(items, key = { it.anime.id to it.epNum }) { ep ->
            Column(
                Modifier
                    .width(220.dp)
                    .clickable { onItem(ep) }
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(124.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, Hairline, RoundedCornerShape(14.dp))
                ) {
                    AnivaveArt(anime = ep.anime, modifier = Modifier.fillMaxSize())
                    if (ep.duration.isNotBlank()) {
                        Box(
                            Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black.copy(alpha = 0.7f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(ep.duration, color = Cool, fontFamily = PlexMono, fontSize = 9.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                    if (ep.timeAgo.isNotBlank()) {
                        Box(
                            Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Flame)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(ep.timeAgo, color = Color.White, fontFamily = PlexMono, fontSize = 8.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Box(
                        Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth(ep.progress.coerceIn(0f, 1f))
                            .height(3.dp)
                            .background(Flame)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "${ep.epNum}: ${ep.epTitle}",
                    color = TextPrimary,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        ep.anime.title,
                        color = TextSecondary,
                        fontFamily = Bricolage,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "★ ${ep.anime.score ?: "—"}",
                        color = Flame,
                        fontFamily = PlexMono,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun AnivaveScheduleCard(
    activeDayIndex: Int,
    onDay: (Int) -> Unit,
    shows: List<DayAiring>,
    days: List<ScheduleDay> = emptyList(),
    onItem: (DayAiring) -> Unit = {},
    modifier: Modifier = Modifier,
    maxRows: Int = 4,
    loading: Boolean = false,
    error: String? = null,
    onRetry: (() -> Unit)? = null
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, Hairline, RoundedCornerShape(18.dp))
            .background(Surface)
            .padding(14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            days.forEachIndexed { idx, day ->
                val active = idx == activeDayIndex
                val pillBg = if (active) com.panime.app.ui.theme.Ink else com.panime.app.ui.theme.Paper2
                val labelColor = if (active) com.panime.app.ui.theme.Paper else TextMuted
                val dateColor = if (active) com.panime.app.ui.theme.Paper else TextPrimary
                Column(
                    Modifier
                        .weight(1f)
                        .border(InkBorder, Hairline, SharpCorner)
                        .background(pillBg, SharpCorner)
                        .clickable { onDay(idx) }
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        day.date.uppercase(),
                        color = labelColor,
                        fontFamily = PlexMono,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        day.wday.uppercase(),
                        color = dateColor,
                        fontFamily = Bricolage,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        when {
            loading && shows.isEmpty() -> ScheduleListShimmer(rows = maxRows.coerceIn(3, 6))
            error != null && shows.isEmpty() -> {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceRaised)
                        .padding(vertical = 20.dp, horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Schedule is catching up…",
                        color = TextPrimary,
                        fontFamily = Bricolage,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Live airings will appear in a moment.",
                        color = TextMuted,
                        fontFamily = PlexMono,
                        fontSize = 12.sp
                    )
                    if (onRetry != null) {
                        Spacer(Modifier.height(12.dp))
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Flame)
                                .clickable { onRetry() }
                                .padding(horizontal = 18.dp, vertical = 8.dp)
                        ) {
                            Text(
                                "Retry",
                                color = Void,
                                fontFamily = Bricolage,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
            shows.isEmpty() -> {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceRaised)
                        .padding(vertical = 22.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        days.getOrNull(activeDayIndex)
                            ?.let { "Nothing airing on ${it.date} (${it.wday})" }
                            ?: "Nothing airing this day",
                        color = TextMuted, fontFamily = PlexMono, fontSize = 12.sp
                    )
                }
            }
            else -> {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (loading) {
                        Text(
                            "Updating…",
                            color = TextMuted,
                            fontFamily = PlexMono,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                    shows.take(maxRows).forEach { s -> ScheduleRow(s) { onItem(s) } }
                }
            }
        }
    }
}

@Composable
private fun ScheduleListShimmer(rows: Int = 4) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        repeat(rows) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(ROW_HEIGHT)
                    .clip(RoundedCornerShape(ROW_CORNER))
                    .background(SurfaceRaised)
                    .padding(ROW_PAD),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ShimmerBox(
                    Modifier
                        .size(COVER_SIZE)
                        .clip(RoundedCornerShape(10.dp)),
                    RoundedCornerShape(10.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    ShimmerBox(Modifier.fillMaxWidth(0.35f).height(10.dp), RoundedCornerShape(4.dp))
                    Spacer(Modifier.height(8.dp))
                    ShimmerBox(Modifier.fillMaxWidth(0.7f).height(14.dp), RoundedCornerShape(4.dp))
                    Spacer(Modifier.height(6.dp))
                    ShimmerBox(Modifier.fillMaxWidth(0.45f).height(10.dp), RoundedCornerShape(4.dp))
                }
            }
        }
    }
}

@Composable
fun ScheduleRow(
    s: DayAiring,
    onItem: () -> Unit = {}
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(ROW_HEIGHT)
            .clip(RoundedCornerShape(ROW_CORNER))
            .background(SurfaceRaised)
            .clickable { onItem() }
            .padding(ROW_PAD),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!s.cover.isNullOrBlank()) {
            AsyncImage(
                model = s.cover,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alignment = s.posterFocal,
                modifier = Modifier
                    .size(COVER_SIZE)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(Modifier.width(12.dp))
        }

        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    s.time, color = Flame, fontFamily = PlexMono,
                    fontSize = 12.sp, fontWeight = FontWeight.Bold
                )
                // Live countdown (AniList airingAt) — just the timer, no label words.
                val nowSec = System.currentTimeMillis() / 1000L
                val dropsIn = if (s.airingAt > 0L) {
                    (s.airingAt - nowSec).coerceAtLeast(0L)
                } else 0L
                val cdState = remember(dropsIn) { mutableStateOf(dropsIn) }
                LaunchedEffect(s.airingAt) {
                    if (s.airingAt > 0L) {
                        while (true) {
                            val left = (s.airingAt - System.currentTimeMillis() / 1000L).coerceAtLeast(0L)
                            cdState.value = left
                            if (left <= 0L) break
                            delay(1000L)
                        }
                    }
                }
                val cd = cdState.value
                val (cdText, justDropped) = if (cd <= 0L) {
                    "LIVE NOW" to true
                } else {
                    val d = cd / 86400L
                    val h = (cd % 86400L) / 3600L
                    val m = (cd % 3600L) / 60L
                    (if (d > 0) "${d}d ${h}h ${m}m" else "${h}h ${m}m") to false
                }
                if (s.airingAt > 0L) {
                    Spacer(Modifier.width(8.dp))
                    // Countdown only (e.g. "5d 22h 14m") — blue for paper contrast.
                    // Air time (s.time, e.g. "13:00") stays Flame/red above.
                    Text(
                        cdText,
                        color = if (justDropped) Flame else UpcomingPurple,
                        fontFamily = PlexMono,
                        fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.height(3.dp))
            Text(
                s.title,
                color = TextPrimary, fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (s.episode > 0) {
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .background(Flame, RoundedCornerShape(8.dp))
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            ) {
                Text(
                    "EP ${s.episode}", color = Void, fontFamily = PlexMono,
                    fontSize = 10.sp, fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
