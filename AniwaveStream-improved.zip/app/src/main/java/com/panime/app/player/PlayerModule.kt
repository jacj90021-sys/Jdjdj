@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.panime.app.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.database.StandaloneDatabaseProvider
import com.panime.app.BuildConfig
import com.panime.app.data.api.AniwavesApi
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

/**
 * Phase 3 — Video streaming engine.
 *
 * Central place that owns:
 *  - Rule 9a: a tuned [DefaultLoadControl] that buffers aggressively ahead of
 *    playback so users don't see mid-stream buffering circles.
 *  - Rule 9b: a single process-wide [SimpleCache] with LRU eviction, wired into a
 *    [CacheDataSource.Factory] so rewinding/pausing reads from disk instead of
 *    re-fetching from the network.
 *  - Rule 12: Widevine DRM readiness via [MediaItem.DrmConfiguration] — see
 *    [buildMediaItem].
 */
object PlayerModule {

    /**
     * Pick the subtitle MIME type from the file extension. anizone serves .ass
     * (SSA/ASS) tracks; aniwaves/anidb use .srt/.vtt. ExoPlayer fails to render a
     * track if the MIME is wrong (e.g. parsing .ass as SUBRIP), so detect it.
     */
    private fun subtitleMime(url: String): String {
        val lower = url.lowercase()
        val ext = if (lower.contains("/api/proxy?")) {
            android.net.Uri.parse(url).getQueryParameter("url")?.let {
                it.lowercase().substringAfterLast('.')
            } ?: ""
        } else {
            lower.substringAfterLast('.')
        }
        return when {
            ext == "ass" || ext == "ssa" -> MimeTypes.TEXT_SSA
            ext == "vtt" -> MimeTypes.TEXT_VTT
            ext == "ttml" || ext == "xml" -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
    }

    // ---- Rule 9b: global LRU disk cache (max 256 MB) ------------------------
    private const val MAX_CACHE_BYTES = 256L * 1024 * 1024

    @Volatile
    private var cache: SimpleCache? = null

    fun getCache(context: Context): SimpleCache =
        cache ?: synchronized(this) {
            cache ?: runCatching {
                SimpleCache(
                    context.applicationContext.cacheDir.resolve("media_cache"),
                    LeastRecentlyUsedCacheEvictor(MAX_CACHE_BYTES),
                    StandaloneDatabaseProvider(context.applicationContext)
                )
            }.getOrElse { ex ->
                // A stale lock file or bad DB can throw here. Fall back to a
                // fresh, lock-free cache dir so playback can still start.
                SimpleCache(
                    context.applicationContext.cacheDir.resolve("media_cache_${System.currentTimeMillis()}"),
                    LeastRecentlyUsedCacheEvictor(MAX_CACHE_BYTES)
                ).also { if (BuildConfig.DEBUG) { android.util.Log.w("PlayerModule", "cache fallback: $ex") } }
            }.also { cache = it }
        }

    /** Upstream HTTP source with sane timeouts + cross-redirect support. */
    private fun httpDataSourceFactory() = DefaultHttpDataSource.Factory()
        .setUserAgent("AniwaveStream/1.0 (Android)")
        .setConnectTimeoutMs(30_000)
        .setReadTimeoutMs(30_000)
        .setAllowCrossProtocolRedirects(true)

    /** Cache-backed data source: disk first, network on miss (Rule 9b). */
    private fun cacheDataSourceFactory(context: Context): CacheDataSource.Factory {
        val upstream = DefaultDataSource.Factory(context.applicationContext, httpDataSourceFactory())
        return CacheDataSource.Factory()
            .setCache(getCache(context))
            .setUpstreamDataSourceFactory(upstream)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    /** Rule 9a: buffer generously ahead so playback rarely stalls. */
    private fun loadControl(): DefaultLoadControl =
        DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs = */ 30_000,
                /* maxBufferMs = */ 120_000,
                /* bufferForPlaybackMs = */ 2_500,
                /* bufferForPlaybackAfterRebufferMs = */ 5_000
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .setBackBuffer(/* backBufferDurationMs = */ 30_000, /* retainBackBufferFromKeyframe = */ true)
            .build()

    /**
     * Build an ExoPlayer wired with the tuned load control + cache-backed media
     * source factory, plus an explicit [DefaultTrackSelector] so the UI can pick
     * audio/subtitle tracks. Dual-audio (japanese/english DUB) plays natively
     * from the HLS audio renditions — no external FFmpeg extension required.
     */
    fun buildPlayer(context: Context): ExoPlayer {
        val appContext = context.applicationContext
        // NOTE: no disk cache. Caching HLS anime segments to disk caused
        // "playback hit a snag" (stale/corrupt cache entries reused forever).
        // Streams are one-time; play straight from HTTP.
        // DefaultDataSource routes http/https to the inner factory (identical
        // online behavior) and content:///file:// to local handlers — required
        // so offline downloads (SAF content:// uris) play in this same player.
        val mediaSourceFactory = DefaultMediaSourceFactory(
            DefaultDataSource.Factory(appContext, httpDataSourceFactory())
        )
        val trackSelector = DefaultTrackSelector(appContext)
        // Auto-enable subtitles on load: prefer English, fall back to any undetermined
        // text track. Without this, the MediaItem's SELECTION_FLAG_DEFAULT subtitles
        // stay OFF and the user must open the CC menu manually.
        trackSelector.setParameters(
            trackSelector.buildUponParameters()
                .setPreferredTextLanguage("en")
                .setSelectUndeterminedTextLanguage(true)
        )
        // Decoder fallback: when hardware MediaCodec rejects a format at init
        // (e.g. anizone's H.264 High 4:4:4 / 10-bit "avc1.6E00xx" encodes —
        // NO_EXCEEDS_CAPABILITIES), ExoPlayer falls back to the bundled FFmpeg
        // SOFTWARE decoders (nextlib). Hardware stays preferred; FFmpeg only
        // engages for formats no phone hardware-decodes. This mirrors how
        // anizone.to plays those streams in-browser.
        val renderersFactory = NextRenderersFactory(appContext)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
        return ExoPlayer.Builder(appContext, renderersFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl())
            .setMediaSourceFactory(mediaSourceFactory)
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
    }

    /**
     * Build a [MediaItem] for a stream URL resolved from the Aniwaves backend.
     *
     * PLAYBACK ROOT CAUSE FIX: the backend returns URLs of the form
     * `.../api/proxy?url=<cdn>...m3u8...` whose last path segment is `proxy`,
     * NOT a `.m3u8` file. ExoPlayer normally chooses the media-source type by
     * sniffing the URI extension (Util.inferContentType) BEFORE fetching the
     * playlist. With no `.m3u8` extension it infers CONTENT_TYPE_OTHER and throws
     * "Unsupported type" — so the video never plays ("it's not a video player").
     * Declaring the MIME type explicitly forces the HlsMediaSource to be used.
     */
    fun buildMediaItem(
        streamUrl: String,
        drmLicenseUrl: String? = null,
        drmHeaders: Map<String, String> = emptyMap(),
        subtitles: List<AniwavesApi.SubtitleTrack> = emptyList()
    ): MediaItem {
        val builder = MediaItem.Builder()
            .setUri(streamUrl)
            .setMimeType(MimeTypes.APPLICATION_M3U8)
        if (subtitles.isNotEmpty()) {
            builder.setSubtitleConfigurations(
                subtitles.map { s ->
                    MediaItem.SubtitleConfiguration.Builder(Uri.parse(s.url))
                        .setMimeType(subtitleMime(s.url))
                        .setLanguage(s.lang)
                        .setLabel(s.label)
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                }
            )
        }
        if (!drmLicenseUrl.isNullOrBlank()) {
            builder.setDrmConfiguration(
                MediaItem.DrmConfiguration.Builder(C.WIDEVINE_UUID)
                    .setLicenseUri(drmLicenseUrl)
                    .setLicenseRequestHeaders(drmHeaders)
                    .setMultiSession(true)
                    .build()
            )
        }
        return builder.build()
    }

    /**
     * BYFMS-only data source. BYFMS's CDN (owphbf24 / sprintcdn) blocks Cloudflare
     * Worker egress, so we can't proxy it through the backend. Instead we fetch the
     * RAW CDN url directly from the DEVICE. A phone's residential/mobile IP is not on
     * owphbf's datacenter blocklist (the Render backend's IP is, which is why the
     * proxy works but the Worker doesn't). We attach the exact Referer/Origin the CDN
     * expects. Native ExoPlayer ignores CORS, so this works where a browser wouldn't.
     */
    private fun byfmsHttpDataSourceFactory() = DefaultHttpDataSource.Factory()
        .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
        .setConnectTimeoutMs(30_000)
        .setReadTimeoutMs(30_000)
        .setAllowCrossProtocolRedirects(true)
        .setDefaultRequestProperties(
            mapOf(
                "Referer" to "https://aniwaves.ru/",
                "Origin" to "https://aniwaves.ru"
            )
        )

    /**
     * Build an HLS [MediaSource] that loads a BYFMS raw CDN m3u8 directly from the
     * device (no backend proxy). Falls back to [buildMediaItem] + proxied url if the
     * caller instead passes the proxied url here.
     *
     * NOTE: no `setAllowChunklessPreparation(true)` — these CDN master playlists
     * are VOD without duration info, so chunkless prep leaves the timeline
     * unestablished and resume/far seeks fail ("Playback hit a snag"). Load the
     * media playlist during prepare (the default) so duration/seek are reliable.
     */
    fun buildByfmsMediaSource(
        context: Context,
        rawCdnUrl: String,
        subtitles: List<AniwavesApi.SubtitleTrack> = emptyList(),
        referer: String? = null
    ): MediaSource {
        val refMap = if (referer.isNullOrBlank()) {
            mapOf(
                "Referer" to "https://aniwaves.ru/",
                "Origin" to "https://aniwaves.ru"
            )
        } else {
            val origin = referer.removeSuffix("/")
            mapOf("Referer" to referer, "Origin" to origin)
        }
        val upstream = DefaultDataSource.Factory(
            context.applicationContext,
            DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                .setConnectTimeoutMs(30_000)
                .setReadTimeoutMs(30_000)
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(refMap)
        )
        val item = MediaItem.Builder()
            .setUri(rawCdnUrl)
            .setMimeType(MimeTypes.APPLICATION_M3U8)
            .apply {
                if (subtitles.isNotEmpty()) {
                    setSubtitleConfigurations(
                        subtitles.map { s ->
                            MediaItem.SubtitleConfiguration.Builder(Uri.parse(s.url))
                                .setMimeType(subtitleMime(s.url))
                                .setLanguage(s.lang)
                                .setLabel(s.label)
                                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                                .build()
                        }
                    )
                }
            }
            .build()
        return HlsMediaSource.Factory(upstream).createMediaSource(item)
    }

    /**
     * anikage/anidap/anikoto/just4anime: HLS (vivibebe/megaplay/vidtube/echovideo/
     * playeng) or MP4 (vidcache) fetched DIRECTLY from the device with the CDN's
     * Referer. `format` selects Progressive vs HLS; null -> HLS.
     *
     * Same NO-chunkless-preparation rule as [buildByfmsMediaSource] — the on-device
     * VOD masters must establish a real timeline at prepare so the player can
     * resume from saved progress / seek without "Playback hit a snag".
     */
    fun buildAnikageMediaSource(
        context: Context,
        rawCdnUrl: String,
        format: String?,
        subtitles: List<AniwavesApi.SubtitleTrack> = emptyList(),
        referer: String? = null,
        xorKey: ByteArray? = null
    ): MediaSource {
        val refMap = if (referer.isNullOrBlank()) {
            mapOf(
                "Referer" to "https://aniwaves.ru/",
                "Origin" to "https://aniwaves.ru"
            )
        } else {
            mapOf("Referer" to referer, "Origin" to referer.removeSuffix("/"))
        }
        val userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        val dataSourceFactory: DataSource.Factory = FlixcloudDecryptingDataSource.Factory(
            xorKey = xorKey,
            userAgent = userAgent,
            defaultRequestProperties = refMap
        )
        val upstream = DefaultDataSource.Factory(context.applicationContext, dataSourceFactory)
        val item = MediaItem.Builder()
            .setUri(rawCdnUrl)
            .apply {
                if (subtitles.isNotEmpty()) {
                    setSubtitleConfigurations(
                        subtitles.map { s ->
                            MediaItem.SubtitleConfiguration.Builder(Uri.parse(s.url))
                                .setMimeType(subtitleMime(s.url))
                                .setLanguage(s.lang)
                                .setLabel(s.label)
                                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                                .build()
                        }
                    )
                }
            }
            .build()
        // NOTE: refactor between f36dd55 (working) and c8357ac wrapped EVERY
        // provider's subtitles in a hand-rolled MergingMediaSource. A load
        // error on the side-loaded track is FATAL in a merged source
        // (SingleSampleMediaPeriod returns DONT_RETRY_FATAL; the
        // setTreatLoadErrorsAsEndOfStream escape hatch did NOT bring playback
        // back) — which took down every provider that attached subtitles,
        // even though the video stream itself was fine. f36dd55 proved the
        // plain source plays for WAVE + Koto, so subs stay attached to the
        // MediaItem (rendered on DefaultMediaSourceFactory paths, e.g.
        // anizone) and are NOT side-loaded through a merged source here.
        return if (format == "mp4") {
            ProgressiveMediaSource.Factory(upstream).createMediaSource(item)
        } else {
            HlsMediaSource.Factory(upstream).createMediaSource(item)
        }
    }

    /** Release the shared cache (call on app teardown if ever needed). */
    fun releaseCache() {
        synchronized(this) {
            cache?.release()
            cache = null
        }
    }

    // ── Internal download system (Media3 DownloadManager) ───────────────────

    /** ONE database provider shared by cache + download index (SQLite locking). */
    @Volatile
    private var sharedDbProvider: StandaloneDatabaseProvider? = null

    fun sharedDatabaseProvider(context: Context): StandaloneDatabaseProvider =
        sharedDbProvider ?: synchronized(this) {
            sharedDbProvider ?: StandaloneDatabaseProvider(context.applicationContext)
                .also { sharedDbProvider = it }
        }

    /**
     * Persistent, NEVER-evicted cache for downloaded episodes. Lives in
     * filesDir (not cacheDir — the OS must not clear user downloads) and is
     * separate from the streaming cache above so its LRU can never delete a
     * completed episode.
     */
    @Volatile
    private var downloadCache: SimpleCache? = null

    fun getDownloadCache(context: Context): SimpleCache =
        downloadCache ?: synchronized(this) {
            downloadCache ?: runCatching {
                SimpleCache(
                    java.io.File(context.applicationContext.filesDir, "download_cache"),
                    androidx.media3.datasource.cache.NoOpCacheEvictor(),
                    sharedDatabaseProvider(context)
                )
            }.getOrElse {
                SimpleCache(
                    java.io.File(
                        context.applicationContext.filesDir,
                        "download_cache_${System.currentTimeMillis()}"
                    ),
                    androidx.media3.datasource.cache.NoOpCacheEvictor()
                )
            }.also { downloadCache = it }
        }

    /**
     * Cache key factory shared by the downloader AND offline playback.
     *
     * [com.panime.app.download.StableDownloadCacheKeyFactory] roots adaptive
     * (HLS/DASH) keys in the download's stable id, so a freshly-resolved stream
     * URL whose PATH changed still reuses the existing partial cache (resume,
     * not 0%). Unregistered URLs fall back to the historical query-stripped key.
     */
    val normalizeKeyFactory: androidx.media3.datasource.cache.CacheKeyFactory =
        com.panime.app.download.StableDownloadCacheKeyFactory

    /**
     * Full cache-wrapping factory used by BOTH the downloader (via
     * DefaultDownloaderFactory) and offline playback, guaranteeing identical
     * keys on both sides.
     *
     * Cache identity for adaptive (HLS/DASH) streams is rooted in the download's
     * stable id by [com.panime.app.download.StableDownloadCacheKeyFactory] — see
     * its doc for why that survives URL/path rotation on resume. Streaming of
     * non-downloaded URLs falls back to the historical query-stripped key.
     */
    fun downloadCacheDataSourceFactory(context: Context): CacheDataSource.Factory {
        com.panime.app.download.StableDownloadCacheKeyFactory.init(context)
        return CacheDataSource.Factory()
            .setCache(getDownloadCache(context))
            .setUpstreamDataSourceFactory(downloadUpstreamFactory(context))
            .setFlags(CacheDataSource.FLAG_BLOCK_ON_CACHE)
            .setCacheKeyFactory(normalizeKeyFactory)
    }

    /**
     * Upstream HTTP factory for downloads/offline playback that injects the
     * ACTIVE download's provider headers (Referer/Origin/…) into every request.
     */
    fun downloadUpstreamFactory(context: Context): DataSource.Factory =
        com.panime.app.download.HeaderedHttpDataSourceFactory(context.applicationContext)

    /**
     * Build a playable [MediaSource] for an internal (Media3-downloaded)
     * episode. Reads through the persistent download cache first; falls back
     * to the network (with provider headers) only for spans not yet cached,
     * which also lets PARTIAL downloads start playing immediately.
     *
     * Cache identity: adaptive (HLS/DASH) entries are keyed by query-stripped
     * URIs via [normalizeKeyFactory] — the SAME factory the downloader used,
     * so playback hits exactly what was downloaded. [customCacheKey] is only
     * applied for progressive media, where media3 supports it.
     */
    fun buildOfflineMediaSource(
        context: Context,
        streamUrl: String,
        mimeType: String?,
        customCacheKey: String,
        subtitles: List<AniwavesApi.SubtitleTrack> = emptyList(),
        xorKeyB64: String? = null
    ): MediaSource {
        val appContext = context.applicationContext
        val isProgressive = mimeType == MimeTypes.VIDEO_MP4

        val httpFactory: DataSource.Factory = runCatching {
            if (!xorKeyB64.isNullOrBlank()) {
                val key = android.util.Base64.decode(xorKeyB64, android.util.Base64.DEFAULT)
                com.panime.app.player.FlixcloudDecryptingDataSource.Factory(
                    xorKey = key,
                    userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    defaultRequestProperties = emptyMap()
                )
            } else {
                downloadUpstreamFactory(appContext)
            }
        }.getOrElse { downloadUpstreamFactory(appContext) }

        // Same key factory as the downloader → same cache entries.
        val baseFactory = downloadCacheDataSourceFactory(appContext)
        val cacheFactory =
            (if (!xorKeyB64.isNullOrBlank()) baseFactory.setUpstreamDataSourceFactory(httpFactory) else baseFactory)

        val item = MediaItem.Builder()
            .setUri(streamUrl)
            .apply { if (isProgressive) setCustomCacheKey(customCacheKey) }
            .apply { mimeType?.let { setMimeType(it) } }
            .apply {
                if (subtitles.isNotEmpty()) {
                    setSubtitleConfigurations(
                        subtitles.map { s ->
                            MediaItem.SubtitleConfiguration.Builder(Uri.parse(s.url))
                                .setMimeType(subtitleMime(s.url))
                                .setLanguage(s.lang)
                                .setLabel(s.label)
                                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                                .build()
                        }
                    )
                }
            }
            .build()
        return DefaultMediaSourceFactory(cacheFactory).createMediaSource(item)
    }
}
