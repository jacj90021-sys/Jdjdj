package com.panime.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.panime.app.data.model.Anime
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.ui.home.SeeAllKind
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SeeAllUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val items: List<Anime> = emptyList(),
    val currentPage: Int = 1,
    val lastPage: Int = 1
)

/**
 * Self-contained loader for the "See All" screen. Fetches one server page at a time
 * and uses AniList's pageInfo.lastPage for the real total page count.
 */
class SeeAllViewModel(private val repository: AnimeRepository) : ViewModel() {

    private val _state = MutableStateFlow(SeeAllUiState())
    val state: StateFlow<SeeAllUiState> = _state.asStateFlow()

    private var loadedKind: SeeAllKind? = null
    private var loadedProvider: String = ""

    /** Fetch a specific page (1-indexed) for the given kind. */
    fun loadPage(kind: SeeAllKind, page: Int) {
        loadedKind = kind
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            val perPage = 50
            val result = fetchPage(kind, page, perPage)
            result.onSuccess { (items, lastPage) ->
                _state.update {
                    it.copy(
                        loading = false,
                        error = null,
                        items = items,
                        currentPage = page,
                        lastPage = lastPage
                    )
                }
            }.onFailure { e ->
                _state.update {
                    it.copy(loading = false, error = e.message ?: "Failed to load")
                }
            }
        }
    }

    /** Convenience: load page 1 (used on first open). */
    fun load(kind: SeeAllKind, provider: String) {
        // Same kind + same provider already loaded (any page): keep the current
        // page instead of resetting to 1 — this effect re-runs every time the
        // user returns from a detail screen, and resetting would lose their place.
        // A provider switch must reload (the cached items belong to the old provider).
        if (loadedKind == kind && loadedProvider == provider && _state.value.items.isNotEmpty()) return
        loadedProvider = provider
        loadPage(kind, 1)
    }

    fun retry(kind: SeeAllKind, provider: String) {
        loadedKind = null
        load(kind, provider)
    }

    private suspend fun fetchPage(
        kind: SeeAllKind,
        page: Int,
        perPage: Int
    ): Result<Pair<List<Anime>, Int>> {
        return when (kind) {
            SeeAllKind.TOP_100 -> {
                // Top 100 is exactly 2 pages of 50 (score-desc). Cap UI pages at 2
                // regardless of AniList's fake lastPage=100 ceiling.
                repository.popularPage(page, perPage).map { pr ->
                    val items = if (page >= 2) pr.items.take(50) else pr.items
                    Pair(items, 2)
                }
            }
            SeeAllKind.SEASONAL -> repository.seasonalPage(page, perPage).map { Pair(it.items, it.lastPage) }
            SeeAllKind.TOP_RATED -> repository.popularPage(page, perPage).map { Pair(it.items, it.lastPage) }
            SeeAllKind.TRENDING -> repository.trendingPage(page, perPage).map { Pair(it.items, it.lastPage) }
            SeeAllKind.UPCOMING -> repository.upcomingPage(page, perPage).map { Pair(it.items, it.lastPage) }
            SeeAllKind.NEW_RELEASES -> {
                // Koto: real /latest-updated pagination. AniList: single flat window.
                repository.recentlyUpdatedPaged(page, perPage).map { Pair(it.items, it.lastPage) }
            }
            else -> Result.success(Pair(emptyList(), 1))
        }
    }

    companion object {
        fun factory(repo: AnimeRepository) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = SeeAllViewModel(repo) as T
        }
    }
}
