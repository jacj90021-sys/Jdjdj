package com.panime.app.data.provider

import android.content.Context
import android.util.Log
import com.panime.app.BuildConfig
import com.panime.app.data.provider.anidap.AnidapProvider
import com.panime.app.data.provider.anikage.AnikageProvider
import com.panime.app.data.provider.just4anime.Just4AnimeProvider
import com.panime.app.data.provider.anidb.AnidbProvider
import com.panime.app.data.provider.anikoto.AnikotoProvider
import com.panime.app.data.provider.aniwaves.AniwavesDirectProvider
import com.panime.app.data.provider.backend.AnizoneBackend
import com.panime.app.data.provider.animenosub.AnimenosubProvider
import com.panime.app.data.provider.moviebox.MovieboxProvider

/**
 * One-time registration of every provider + application of remote config.
 *
 * Registration order does not matter; [ProviderManager] sorts by priority at
 * resolve time. On-device providers and explicit backend providers are both
 * registered; the remote config controls enabled/priority/timeout/kill-switch.
 */
object ProviderInitializer {

    private var done = false

    fun init(context: Context) {
        if (done) return
        done = true

        // On-device providers (no backend).
        ProviderManager.register(AnidapProvider())
        ProviderManager.register(AnikageProvider())
        ProviderManager.register(Just4AnimeProvider())
        ProviderManager.register(AnidbProvider())
        ProviderManager.register(AnikotoProvider())
        ProviderManager.register(AniwavesDirectProvider())
        ProviderManager.register(AnizoneBackend())
        ProviderManager.register(AnimenosubProvider())
        ProviderManager.register(MovieboxProvider())

        // Apply remote (or safe default) configuration. The same config also
        // carries the remote ads kill-switch — pushed to AdManager BEFORE
        // AniwaveApp calls AdManager.init() (ProviderInitializer runs first),
        // so the SDK init + preloads already respect the remote settings.
        val cfg = RemoteConfigRepository.load(context)
        ProviderManager.applyConfig(cfg)
        com.panime.app.ad.AdManager.applyRemoteConfig(cfg)
        if (BuildConfig.DEBUG) {
            Log.d("ProviderInitializer", "providers registered + config applied (v${cfg.version})")
        }
    }
}
