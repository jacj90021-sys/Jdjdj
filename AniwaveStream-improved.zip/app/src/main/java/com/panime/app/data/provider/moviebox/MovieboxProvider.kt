package com.panime.app.data.provider.moviebox

import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider
import com.panime.app.data.provider.aniwaves.AniwavesScraper
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * On-device Moviebox provider (moviebox.ph / movieboxhd.net).
 *
 * VERIFIED live this session:
 *   search  -> POST h5-api.aoneroom.com/wefeed-h5api-bff/subject/search
 *              {keyword,page,perPage,subjectType} -> data.items[] + data.pager
 *              (REAL api — all results + pages; the old HTML scrape returned
 *              only the first page). Needs:
 *                1) X-Client-Token: "<epoch>,<md5(reversed epoch)>" (site JS)
 *                2) Authorization: Bearer <guest JWT> from the x-user RESPONSE
 *                   header of any API GET (subject/search-suggest/everyone-search)
 *              Without the JWT the API answers 400 "invalid token".
 *   streams -> h5-api.aoneroom.com/.../get-domain -> {domain}/.../subject/play
 *              -> data.streams[] direct MP4 urls (360p..1080p), all HTTP 200.
 *
 * Both flows work:
 *   - WRONG-TITLE PICKER ([resolveWithSlug]): picked "subjectId|detailPath"
 *     used directly, language variants as servers.
 *   - DEFAULT ([resolve]): AniList title -> moviebox search -> scored match.
 *     Singles (movie/OVA/special): word-points (+1 per matched word of the
 *     AniList names, +3/-2 release-year, min 4 to win) — verified on all 37
 *     One Piece franchise entries (33 exact / 4 honest no-match / 0 wrong).
 *     Series: season suffix + episode count + token overlap + sub/dub.
 */
class MovieboxProvider : StreamProvider, SearchableProvider {

    override val id = "moviebox"
    override val label = "MOVIE"
    override val backendRequired = false

    private companion object {
        const val DEFAULT_DOMAIN = "https://123movienow.cc"
        const val H5_API = "https://h5-api.aoneroom.com"
        const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
        // Show-level language list is identical for every episode — cache per
        // detailPath (30s TTL) so the per-episode chip fetches share one call.
        private val langCache = ConcurrentHashMap<String, Pair<Long, List<Pair<String, String>>>>()
        private const val LANG_CACHE_TTL_MS = 30_000L
        // Detail API (subject.dubs + seasons) — same per show, 30s TTL.
        private val detailCache = ConcurrentHashMap<String, Pair<Long, JSONObject>>()
        private const val DETAIL_CACHE_TTL_MS = 30_000L
        // Guest JWT from the API's x-user RESPONSE header — subject/search
        // rejects calls without it (400 "invalid token"). Cached app-wide;
        // invalidated on auth failure and re-bootstrapped lazily.
        @Volatile private var apiJwt: String? = null
        private val apiJwtLock = Any()
    }

    /** "<epochSeconds>,<md5(reversed epochSeconds)>" — exact site-JS replica. */
    private fun clientToken(): String {
        val e = System.currentTimeMillis() / 1000
        val digest = MessageDigest.getInstance("MD5")
            .digest(e.toString().reversed().toByteArray())
            .joinToString("") { "%02x".format(it) }
        return "$e,$digest"
    }

    private fun apiHeaders(jwt: String?): Map<String, String> = mapOf(
        "Accept" to "application/json",
        "Content-Type" to "application/json",
        "User-Agent" to UA,
        "X-Client-Info" to "{\"timezone\":\"Asia/Dhaka\"}",
        "Authorization" to (if (jwt.isNullOrBlank()) "" else "Bearer $jwt"),
        "X-Request-Lang" to "en",

        // NO X-Client-Token here — the site's own web app dropped it and the
        // API now REJECTS it on subject/search (400 "invalid token", verified
        // live 2026-09: with header = 400, without = 200/88 results). Every
        // endpoint works without it.
        "Referer" to "https://movieboxhd.net/"
    )

    /**
     * Guest JWT bootstrap: any API GET echoes an x-user response header
     * ({token: <jwt>}). everyone-search is the lightest. Verified live.
     */
    private fun fetchGuestJwt(): String? {
        val resp = ScraperEngine.fetchResponse(
            "$H5_API/wefeed-h5api-bff/subject/everyone-search",
            apiHeaders(null)
        ) ?: return null
        return resp.use { r ->
            if (!r.isSuccessful) null
            else r.header("x-user")?.let { xu ->
                runCatching { JSONObject(xu).optString("token") }
                    .getOrNull()?.takeIf { it.isNotBlank() }
            }
        }
    }

    private fun getJwt(): String? {
        apiJwt?.let { return it }
        synchronized(apiJwtLock) {
            apiJwt?.let { return it }
            apiJwt = fetchGuestJwt() ?: return null
            return apiJwt
        }
    }

    /**
     * Real search API: POST subject/search {keyword,page,perPage,subjectType}.
     * Returns (items, hasMore) or null. One retry with a fresh JWT on failure.
     */
    private suspend fun apiSearchData(keyword: String, page: Int, perPage: Int): Pair<JSONArray, Boolean>? {
        val body = JSONObject()
            .put("keyword", keyword)
            .put("page", page)
            .put("perPage", perPage)
            .put("subjectType", 0)
            .toString()
        fun post(jwt: String?): ScraperEngine.HttpResult? {
            return ScraperEngine.postJson(
                "$H5_API/wefeed-h5api-bff/subject/search",
                body,
                apiHeaders(jwt),
                timeoutMs = 20_000L
            )
        }
        var res = post(getJwt())
        if (res == null || res.code != 200) {
            synchronized(apiJwtLock) { apiJwt = null }
            res = post(getJwt())
        }
        val ok = res?.takeIf { it.code == 200 } ?: return null
        val data = runCatching { JSONObject(ok.body).optJSONObject("data") }.getOrNull()
            ?: return null
        val items = data.optJSONArray("items") ?: return null
        val hasMore = data.optJSONObject("pager")?.optBoolean("hasMore", false) ?: false
        return items to hasMore
    }

    /** Map API items to MovieEntry, deduped by (subjectId|title). */
    private suspend fun apiEntries(keyword: String, page: Int, perPage: Int = 28): Pair<List<MovieEntry>, Boolean>? {
        val (items, hasMore) = apiSearchData(keyword, page, perPage) ?: return null
        val out = ArrayList<MovieEntry>()
        val seen = HashSet<String>()
        for (i in 0 until items.length()) {
            val r = items.optJSONObject(i) ?: continue
            val subjectId = r.optString("subjectId")
            val detailPath = r.optString("detailPath")
            val title = r.optString("title")
            if (subjectId.isEmpty() || detailPath.isEmpty() || title.isEmpty()) continue
            if (!seen.add("$subjectId|$title")) continue
            out.add(
                MovieEntry(
                    title = title,
                    subjectId = subjectId,
                    detailPath = detailPath,
                    year = r.optString("releaseDate").take(4).toIntOrNull(),
                    subjectType = r.optInt("subjectType", 0),
                    coverUrl = r.optJSONObject("cover")?.optString("url")
                        ?.takeIf { it.isNotEmpty() && it != "null" },
                    genre = r.optString("genre")
                )
            )
        }
        return out to hasMore
    }

    // ===================== Search (wrong-title picker) =====================

    override suspend fun search(query: String): List<StreamProvider.SearchHit> {
        if (query.isBlank()) return emptyList()
        val entries = apiEntries(query.trim(), 1)?.first ?: return emptyList()
        return entries.filterNot { it.isAdultRow }.map {
            StreamProvider.SearchHit(
                title = it.title,
                slug = "${it.subjectId}|${it.detailPath}",
                posterUrl = it.coverUrl
            )
        }
    }

    /** Richer search entry for the default matcher (keeps year + type). */
    private data class MovieEntry(
        val title: String,
        val subjectId: String,
        val detailPath: String,
        val year: Int?,
        val subjectType: Int,
        val coverUrl: String?,
        val genre: String = ""
    ) {
        /** Porn rows come back with genre "Adult" (live-action) or "Erotic" —
         *  never show them. Hentai anime mislabeled as plain "Anime" is the
         *  wrong-title picker's job: it name-gates every row against the anime's
         *  real AniList names, so unrelated rows can never appear at all. */
        val isAdultRow: Boolean
            get() = genre.split(",").any {
                val g = it.trim()
                g.equals("Adult", ignoreCase = true) || g.equals("Erotic", ignoreCase = true)
            }
    }

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        if (query.isBlank() || page < 1) return PagedResult(emptyList(), 1)
        val (entries, hasMore) = apiEntries(query.trim(), page)
            ?: return PagedResult(emptyList(), page)
        val hits = entries.filterNot { it.isAdultRow }.map {
            StreamProvider.SearchHit(
                title = it.title,
                slug = "${it.subjectId}|${it.detailPath}",
                posterUrl = it.coverUrl
            )
        }
        return PagedResult(hits, if (hasMore) page + 1 else page)
    }

    // ===================== Play (picked slug path) =====================

    /** slug is the picker's "subjectId|detailPath" (optionally + "|se=N") entry. */
    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? {
        val parts = slug.split("|")
        val baseSubjectId = parts.getOrNull(0)?.takeIf { it.isNotBlank() } ?: return null
        val baseDetailPath = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: return null
        // Explicit season from the slug (picker picked ONE season / tapped a
        // season chip) beats the AniList season number — the pick IS the truth.
        val pickedSe = parts.getOrNull(2)
            ?.takeIf { it.startsWith("se=") }
            ?.substring(3)?.toIntOrNull()?.takeIf { it > 0 }

        // Combined entries ("S1-S6", one subject): map the GLOBAL episode number
        // to (se, ep) using the detail API's exact per-season ranges — their own
        // maxEp data, no guesses. Single-season entries pass through unchanged.
        var se = pickedSe ?: if (seasonNumber > 0) seasonNumber else 1
        var ep = if (episode > 0) episode else 1
        if (pickedSe == null) {
            runCatching {
                val seasons = seasonMapForSlug(slug)
                if (seasons.size > 1) {
                    var remaining = ep
                    var mapped = false
                    for ((s, maxEp) in seasons) {
                        if (remaining <= maxEp) {
                            se = s
                            ep = remaining
                            mapped = true
                            break
                        }
                        remaining -= maxEp
                    }
                    // Overflow past the last season: clamp to its final episode.
                    if (!mapped) {
                        se = seasons.last().first
                        ep = seasons.last().second
                    }
                } else if (seasons.size == 1 && seasons[0].first == 0) {
                    // MOVIE: the site renumbered films to {se:0, maxEp:0} and its
                    // play API only serves them at se=0&ep=0 (anything else ->
                    // hasResource=false). The picker still reports season 1 / ep 1
                    // for a film — translate to the site's movie slot here.
                    se = 0
                    ep = 0
                }
            }
        }

        // Language variants ("French dub", "Arabic sub", ...) are separate
        // subject entries. serverCode carries the variant's own
        // "subjectId|detailPath" when the user picked one from the server sheet
        // (same trick Zone uses: servers -> resolveOne(serverCode)).
        var subjectId = baseSubjectId
        var detailPath = baseDetailPath
        serverCode?.split("|")?.let { vp ->
            if (vp.size == 2 && vp[0].isNotBlank() && vp[1].isNotBlank()) {
                subjectId = vp[0]
                detailPath = vp[1]
            }
        }

        // Zone-style single server: the server sheet shows ONE "Movie" entry
        // (like Zone's "Zone"), never the language variants. Languages are
        // offered in the AUDIO sheet instead — PlayerScreen re-resolves with a
        // variant's own "subjectId|detailPath" as serverCode when one is picked
        // there (handled by the serverCode switch above).
        val servers = listOf("$baseSubjectId|$baseDetailPath" to "Movie")

        return play(subjectId, detailPath, se, ep, servers)
    }

    /**
     * Shared play chain: discover domain -> play API -> best MP4/HLS stream.
     * Used by BOTH [resolveWithSlug] (picked slug) and [resolve] (default).
     */
    private suspend fun play(
        subjectId: String,
        detailPath: String,
        se: Int,
        ep: Int,
        servers: List<Pair<String, String>>
    ): ResolveResult? {
        val domain = discoverDomain()
        // MOVIE safety net: the site serves films only at se=0&ep=0 (verified
        // live: any other combo -> hasResource=false) regardless of what the
        // AniList-based season/episode numbers say.
        val (playSe, playEp) = if (se == 0) 0 to 0 else se to ep
        val playUrl = "$domain/wefeed-h5api-bff/subject/play" +
            "?subjectId=$subjectId&se=$playSe&ep=$playEp&detailPath=$detailPath"

        val headers = mapOf(
            "Accept" to "application/json, text/plain, */*",
            "User-Agent" to UA,
            "X-Client-Info" to """{"timezone":"Asia/Dhaka"}""",
            "X-Forwarded-For" to "103.25.250.31",
            "Cookie" to "uuid=d8c3539e-2e46-4000-af20-7046a856e30a",
            "Referer" to "$domain/spa/videoPlayPage/movies/$detailPath",
            "Origin" to domain
        )
        val body = ScraperEngine.fetchText(playUrl, headers) ?: return null
        val json = runCatching { JSONObject(body) }.getOrNull() ?: return null
        val data = json.optJSONObject("data") ?: return null

        // Defensive: some play payloads may carry side-loaded subtitle tracks
        // (tracks[]/subtitles[] with {file|url,label}). Parse when present;
        // empty list is the normal case (subs ride INSIDE the HLS stream).
        val seenTracks = mutableSetOf<String>()
        val sideSubs = listOf("tracks", "subtitles").flatMap { key ->
            val arr = data.optJSONArray(key) ?: return@flatMap emptyList<AniwavesApi.SubtitleTrack>()
            (0 until arr.length()).mapNotNull { i ->
                val t = arr.optJSONObject(i) ?: return@mapNotNull null
                val url = t.optString("file").ifEmpty { t.optString("url") }
                if (url.isBlank()) return@mapNotNull null
                val label = t.optString("label").ifEmpty { t.optString("lang").ifEmpty { "Unknown" } }
                if (!seenTracks.add("$url|$label")) return@mapNotNull null
                AniwavesApi.SubtitleTrack(label.lowercase().replace(Regex("\\s+"), "-"), label, url)
            }
        }

        // Captions: moviebox keeps subtitles OUT of the play payload — they
        // live in a SEPARATE caption endpoint keyed by the STREAM id
        // (verified live on BoJack S1E1: data.captions[] -> 11 tracks, the
        // English .srt downloads clean). Zetflix's clone calls the same
        // endpoint; the response key is "captions" (their clone reads a stale
        // "subtitles" key). Empty result never blocks playback.
        val streamsArr = data.optJSONArray("streams")
        var capStreamId = ""
        var capBestRes = -1
        if (streamsArr != null) {
            for (i in 0 until streamsArr.length()) {
                val s = streamsArr.optJSONObject(i) ?: continue
                val sid = s.optString("id")
                val res = s.optString("resolutions").toIntOrNull() ?: 0
                if (sid.isNotEmpty() && res > capBestRes) {
                    capBestRes = res
                    capStreamId = sid
                }
            }
        }
        val captionSubs = fetchCaptions(subjectId, detailPath, capStreamId)
        val subs = captionSubs + sideSubs.filter { cs -> captionSubs.none { it.url == cs.url } }

        // HLS preferred when present (carries subtitles); else direct MP4 streams.
        val hls = data.optJSONArray("hls")
        if (hls != null && hls.length() > 0) {
            var hlsUrl: String? = null
            for (i in 0 until hls.length()) {
                val hObj = hls.optJSONObject(i) ?: continue
                hlsUrl = hObj.optString("url").takeIf { it.isNotEmpty() }
                if (hlsUrl != null) break
            }
            if (hlsUrl != null) {
                return ResolveResult(
                    source = id,
                    servers = servers,
                    url = hlsUrl,
                    rawUrl = hlsUrl,
                    // Trailing slash matters: player sends "Referer: <this>" and
                    // "Origin: <this minus slash>" — verified against the CDN.
                    referer = "$domain/",
                    format = "hls",
                    quality = null,
                    subtitles = subs,
                    notFound = false
                )
            }
        }

        val streams = data.optJSONArray("streams")
        if (streams == null || streams.length() == 0) return null

        data class StreamEntry(val url: String, val res: String)
        val entries = ArrayList<StreamEntry>()
        for (i in 0 until streams.length()) {
            val s = streams.optJSONObject(i) ?: continue
            val u = s.optString("url").takeIf { it.isNotEmpty() } ?: continue
            val raw = s.optString("resolutions").ifEmpty { "SD" }
            val res = if (raw.matches(Regex("""\d+"""))) "${raw}p" else raw
            entries.add(StreamEntry(u, res))
        }
        if (entries.isEmpty()) return null

        // Best quality by default (360p..1080p, highest wins).
        val pick = entries.maxByOrNull { it.res.removeSuffix("p").toIntOrNull() ?: 0 }?.url
            ?: entries.first().url
        val quality = entries.firstOrNull { it.url == pick }?.res

        return ResolveResult(
            source = id,
            servers = servers,
            url = pick,
            rawUrl = pick,
            referer = "$domain/",
            format = "mp4",
            quality = quality,
            subtitles = subs,
            notFound = false
        )
    }

    /**
     * Caption endpoint: GET subject/caption?subjectId=..&id=<streamId>&detailPath=..
     * -> data.captions[] = {lan, lanName, url(.srt), delay}. Any failure ->
     * empty list (never blocks playback).
     */
    private fun fetchCaptions(subjectId: String, detailPath: String, streamId: String): List<AniwavesApi.SubtitleTrack> {
        if (streamId.isBlank()) return emptyList()
        return runCatching {
            val headers = apiHeaders(getJwt()).toMutableMap()
            headers["Cookie"] = "uuid=d8c3539e-2e46-4000-af20-7046a856e30a"
            val body = ScraperEngine.fetchText(
                "$H5_API/wefeed-h5api-bff/subject/caption" +
                    "?subjectId=$subjectId&id=$streamId&detailPath=$detailPath",
                headers
            ) ?: return emptyList()
            val caps = runCatching {
                JSONObject(body).optJSONObject("data")?.optJSONArray("captions")
            }.getOrNull() ?: return emptyList()
            val seen = HashSet<String>()
            (0 until caps.length()).mapNotNull { i ->
                val c = caps.optJSONObject(i) ?: return@mapNotNull null
                val url = c.optString("url").takeIf { it.isNotEmpty() } ?: return@mapNotNull null
                if (!seen.add(url)) return@mapNotNull null
                val lan = c.optString("lan").ifEmpty { "unknown" }
                val name = c.optString("lanName").ifEmpty { lan }
                AniwavesApi.SubtitleTrack(lan, name, url)
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Zone-style single server entry ("Movie") — the server sheet must never
     * list languages (those live in the Audio sheet, same split as Zone).
     */
    suspend fun listServersFor(slug: String): List<Pair<String, String>> {
        val parts = slug.split("|")
        val baseId = parts.getOrNull(0)?.takeIf { it.isNotBlank() } ?: return emptyList()
        val basePath = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: return emptyList()
        return listOf("$baseId|$basePath" to "Movie")
    }

    /**
     * Language variants for the player's AUDIO sheet (zone-style): (variant
     * slug = "subjectId|detailPath", display name like "English dub"). The
     * first entry is the base subject itself — picking it re-resolves normally.
     */
    suspend fun listLanguagesFor(slug: String): List<Pair<String, String>> {
        val parts = slug.split("|")
        val baseId = parts.getOrNull(0)?.takeIf { it.isNotBlank() } ?: return emptyList()
        val basePath = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: return emptyList()
        val languages = fetchLanguages(basePath)
        if (languages.isEmpty()) return emptyList()
        return buildList {
            add("$baseId|$basePath" to (languages.firstOrNull { it.first == "$baseId|$basePath" }?.second ?: "Original Audio"))
            for ((lslug, lname) in languages) {
                if (lslug == "$baseId|$basePath") continue
                add(lslug to lname)
            }
        }
    }

    /**
     * Language variants from the detail API's subject.dubs array (each variant
     * has its own subjectId + detailPath). Returns ("subjectId|detailPath" to
     * lanName); empty on any failure. 30s cache — shared across episodes.
     */
    private suspend fun fetchLanguages(detailPath: String): List<Pair<String, String>> {
        langCache[detailPath]?.let { (at, list) ->
            if (System.currentTimeMillis() - at < LANG_CACHE_TTL_MS) return list
        }
        val data = fetchDetail(detailPath)
        val out = ArrayList<Pair<String, String>>()
        val dubs = data?.optJSONObject("subject")?.optJSONArray("dubs")
        if (dubs != null) {
            for (i in 0 until dubs.length()) {
                val d = dubs.optJSONObject(i) ?: continue
                val lanName = d.optString("lanName").ifEmpty { d.optString("name") }
                val dId = d.optString("subjectId").ifEmpty { d.optString("id") }
                val dPath = d.optString("detailPath").ifEmpty { d.optString("slug") }
                if (lanName.isNotBlank() && dId.isNotBlank() && dPath.isNotBlank()) {
                    out.add("$dId|$dPath" to lanName)
                }
            }
        }
        langCache[detailPath] = System.currentTimeMillis() to out
        return out
    }

    /**
     * Default flow: match an AniList anime to a moviebox entry, verified with
     * the signals the site exposes (verified live):
     *   - title keys from AniList (romaji/english/native/synonyms)
     *   - SINGLES (movie/OVA/special): word-points + release year (see below)
     *   - SERIES: season intent ("S1-S3" suffixes) — dominant signal
     *   - episode count (detail API seasons[].maxEp vs AniList total)
     *   - token overlap on the junk-stripped title
     *   - sub/dub: base entry for SUB, "[English]" variant for DUB
     * Junk filtered: "Trailer-" titles, AMV entries (subjectType 6), movies when
     * the anime is a series. The picked entry must cover the requested episode.
     * No synopsis matching (skipped per request).
     */
    override suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int,
        totalEpisodes: Int,
        year: Int?
    ): ResolveResult? {
        val detail = if (anilistId > 0) AniwavesScraper.anilistDetail(anilistId) else null
        val keys = buildList {
            title.trim().takeIf { it.isNotBlank() }?.let { add(it) }
            detail?.let { d ->
                listOfNotNull(d.romaji, d.english, d.native).forEach { if (it.isNotBlank()) add(it) }
                d.synonyms.forEach { if (it.isNotBlank()) add(it) }
            }
        }.distinct()
        val query = detail?.english?.takeIf { it.isNotBlank() } ?: keys.firstOrNull() ?: return null

        val isMovie = (totalEpisodes > 0 && totalEpisodes <= 1) || (detail?.episodes != null && detail.episodes <= 1)
        val keysNorm = keys.map(::normKey).filter { it.isNotBlank() }.distinct()
        val wantSeason = seasonNumber.coerceAtLeast(1)
        val expectedEps = totalEpisodes.takeIf { it > 0 } ?: detail?.episodes?.takeIf { it > 0 }
        val dub = type == "dub"

        // Adult-anime gate: AniList marks hentai with isAdult=true. The default
        // (auto-match) flow never plays adult content — the user picked this
        // anime from our app, which is anime-only. (Picker search separately
        // filters genre=Adult rows via isAdultRow.)
        if (detail?.isAdult == true) return null

        // Real search API (JWT-authed). Results are clean (no catalog noise),
        // but pagination matters for long titles — pull up to 3 pages and retry
        // with the next AniList title variant if nothing passes the token gate.
        suspend fun searchOnce(q: String): List<MovieEntry> {
            val all = ArrayList<MovieEntry>()
            var page = 1
            var hasMore = true
            while (page <= 3 && hasMore) {
                val pair = apiEntries(q, page) ?: break
                all += pair.first.filter { eligible(it, isMovie) }
                hasMore = pair.second
                page++
                if (all.isNotEmpty()) break  // first page is ranked best by the site
            }
            return all
        }
        var entries = searchOnce(query)
        if (entries.none { passesTokenGate(it, keysNorm) }) {
            for (alt in keys.drop(1).take(2)) {
                entries = searchOnce(alt)
                if (entries.any { passesTokenGate(it, keysNorm) }) break
            }
        }
        entries = entries.filter { passesTokenGate(it, keysNorm) }
        if (entries.isEmpty()) return null

        // ---- Single-release branch (movie/OVA/special: AniList episodes <= 1).
        // Word-points pick, verified live across all 37 One Piece franchise
        // entries: +1 point per matched word of any AniList key (missing words
        // like "adventure"/"story" just lose a point, they never disqualify),
        // +3 release-year within ±1 / -2 off. Need >= 1 matched word to enter
        // (kills catalog noise) and >= 4 points to win (every real match scores
        // 4+; 1-2 is coincidence — honest "no match" beats a wrong film). Top 2
        // candidates verified through the detail API like the series flow.
        if (isMovie) {
            val keyWords = keys.filter { it.lowercase().any { c -> c in 'a'..'z' || c in '0'..'9' } }
                .flatMap { titleWords(it) }.toSet()
            val aYear = detail?.year
            // EXACT-MATCH PRIORITY: a row containing EVERY word of the AniList
            // title jumps the queue (ranked first, probed first, wins over any
            // points total). Long titles let a wrong row pile up 4+ points from
            // filler words (the/of/season/...) — a full A-Z match must never
            // lose to that. Points only decide when no full match exists.
            val mainTitle = detail?.english?.takeIf { it.isNotBlank() } ?: keys.firstOrNull() ?: ""
            val mainWords = titleWords(mainTitle)
            fun fullMatch(t: String): Boolean {
                val rowWords = titleWords(t)
                return mainWords.isNotEmpty() && mainWords.all { it in rowWords }
            }
            val scored = entries.mapNotNull { e ->
                val (sc, matched) = wordPoints(e.title, keyWords, aYear, e.year)
                if (matched >= 1) e to sc else null
            }.sortedWith(
                compareByDescending<Pair<MovieEntry, Int>> { fullMatch(it.first.title) }
                    .thenByDescending { it.second }
                    // Equal-score full matches: [English] variant for DUB, base for SUB.
                    .thenByDescending { decompose(it.first.title).isEnglishDub == dub }
            )
            var best: Pair<MovieEntry, Int>? = null
            for ((entry, sc0) in scored.take(2)) {
                val data = fetchDetail(entry.detailPath) ?: continue
                val seasons = parseSeasons(data)
                if (seasons.isEmpty()) continue
                val dTitle = data.optJSONObject("subject")?.optString("title")
                    ?.takeIf { it.isNotBlank() } ?: entry.title
                val (sc1, _) = wordPoints(dTitle, keyWords, aYear, entry.year)
                val final = maxOf(sc0, sc1)
                if (final < 4) continue
                val se = seasons.firstOrNull { it.first == 1 }?.first ?: seasons.first().first
                val maxEp = seasons.firstOrNull { it.first == se }?.second ?: 0
                if (maxEp > 0 && episode > maxEp) continue
                if (best == null || final > best.second) best = entry to final
            }
            val (entry, _) = best ?: return null
            val data = fetchDetail(entry.detailPath) ?: return null
            // Zone-style single server — same as the pick path: the server
            // sheet shows ONE "Movie" chip; languages live in the AUDIO sheet
            // (PlayerScreen lists them via listLanguagesFor on this slug).
            val servers = listOf("${entry.subjectId}|${entry.detailPath}" to "Movie")
            val se = parseSeasons(data).firstOrNull { it.first == 1 }?.first
                ?: parseSeasons(data).first().first
            // Language variant picked in the Audio sheet (default mode):
            // serverCode carries the variant's own "subjectId|detailPath" —
            // switch the play target to that subject. Moviebox dubs mirror the
            // base entry's season/episode layout, so (se, ep) carries over.
            serverCode?.split("|")?.let { vp ->
                if (vp.size == 2 && vp[0].isNotBlank() && vp[1].isNotBlank() &&
                    (vp[0] != entry.subjectId || vp[1] != entry.detailPath)
                ) {
                    return play(vp[0], vp[1], se, episode, servers)
                }
            }
            return play(entry.subjectId, entry.detailPath, se, episode, servers)
        }

        // ---- Series flow (multi-episode, incl. combined "S1-S6" entries): unchanged.

        // Phase 1: score without the episode-count signal (no detail fetch).
        val ranked = entries.map { e -> e to score(e, keysNorm, wantSeason, dub) }
            .sortedByDescending { it.second }

        // Phase 2: probe the top candidates' detail API — adds the count signal
        // and verifies the requested season + episode actually exist.
        // NOTE: the search DISPLAY title is unreliable (same entry can show as
        // "BoJack Horseman S6" while its detail says "S1-S6") — the detail
        // subject's title is authoritative, so scoring restarts from it here.
        var best: Triple<MovieEntry, JSONObject, Int>? = null  // entry, data, score
        for ((entry, _) in ranked.take(6)) {
            val data = fetchDetail(entry.detailPath) ?: continue
            val seasons = parseSeasons(data)
            if (seasons.isEmpty()) continue
            val subject = data.optJSONObject("subject")
            val dTitle = subject?.optString("title")?.takeIf { it.isNotBlank() } ?: entry.title
            val d = decompose(dTitle)

            // Season coverage from the authoritative title + seasons array.
            val se = when {
                d.seasonRange != null && wantSeason in d.seasonRange -> wantSeason
                d.seasonRange == null && wantSeason == 1 ->
                    seasons.firstOrNull { it.first == wantSeason }?.first ?: seasons.first().first
                else -> seasons.firstOrNull { it.first == wantSeason }?.first
            } ?: continue
            val maxEp = seasons.firstOrNull { it.first == se }?.second ?: 0
            if (maxEp > 0 && episode > maxEp) continue

            val countScore = when {
                expectedEps == null || expectedEps <= 0 || maxEp <= 0 -> 0
                kotlin.math.abs(maxEp - expectedEps) <= 1 -> 2
                maxEp >= expectedEps && maxEp - expectedEps <= 16 -> 1
                else -> 0
            }
            val totalScore = scoreFromDetail(dTitle, keysNorm, wantSeason, dub) + countScore
            if (totalScore < bestAcceptable(ranked, countScore)) continue
            if (best == null || totalScore > best.third) {
                best = Triple(entry, data, totalScore)
            }
        }
        val (entry, data, _) = best ?: return null
        val se = parseSeasons(data).firstOrNull { it.first == wantSeason }?.first
            ?: if (wantSeason == 1) parseSeasons(data).first().first else return null
        // Zone-style single server (identical to the pick path + single branch).
        val servers = listOf("${entry.subjectId}|${entry.detailPath}" to "Movie")
        // Language variant picked in the Audio sheet (default mode): switch the
        // play target to the variant's own subject (same as the single branch).
        serverCode?.split("|")?.let { vp ->
            if (vp.size == 2 && vp[0].isNotBlank() && vp[1].isNotBlank() &&
                (vp[0] != entry.subjectId || vp[1] != entry.detailPath)
            ) {
                return play(vp[0], vp[1], se, episode, servers)
            }
        }
        return play(entry.subjectId, entry.detailPath, se, episode, servers)
    }

    /** Phase-2 score from the AUTHORITATIVE detail title (same weights as [score]).
     *  NO year signal: moviebox's single releaseDate is unreliable (same entry
     *  shows S1's year in search but S6's on its detail page, and vice versa). */
    private fun scoreFromDetail(
        detailTitle: String,
        keysNorm: List<String>,
        wantSeason: Int,
        dub: Boolean
    ): Int {
        val d = decompose(detailTitle)
        var s = 0
        val jac = bestTokenSim(normKey(d.base), keysNorm)
        s += when {
            jac >= 0.8 -> 3
            jac >= 0.5 -> 2
            jac >= 0.3 -> 1
            else -> 0
        }
        if (d.seasonRange != null) {
            if (wantSeason in d.seasonRange) s += 6 else s -= 3
        } else {
            if (wantSeason == 1) s += 6 else s -= 3
        }
        if (d.isEnglishDub) s += if (dub) 2 else -2
        return s
    }

    /** Catalog-noise gate: the junk-stripped title must share tokens with an
     *  AniList title key (a failed search returns the whole catalog — token
     *  overlap drops it out, same filter Koto applies to its search fallback). */
    private fun passesTokenGate(e: MovieEntry, keysNorm: List<String>): Boolean =
        bestTokenSim(normKey(decompose(e.title).base), keysNorm) >= 0.3

    /** Skip junk: trailers, AMVs (subjectType 6), and movies unless it's a movie. */
    private fun eligible(e: MovieEntry, isMovie: Boolean): Boolean {
        if (e.subjectType == 6) return false
        if (e.isAdultRow) return false
        if (e.title.trim().startsWith("Trailer-", ignoreCase = true)) return false
        if (!isMovie && e.subjectType == 1) return false
        return true
    }

    /** Phase-1 score: token overlap + season intent + dub preference. */
    private fun score(
        e: MovieEntry,
        keysNorm: List<String>,
        wantSeason: Int,
        dub: Boolean
    ): Int {
        var s = 0
        val d = decompose(e.title)
        val jac = bestTokenSim(normKey(d.base), keysNorm)
        s += when {
            jac >= 0.8 -> 3
            jac >= 0.5 -> 2
            jac >= 0.3 -> 1
            else -> 0
        }
        // Season intent — dominant (+6 / -3), like Wave/Koto.
        if (d.seasonRange != null) {
            if (wantSeason in d.seasonRange) s += 6 else s -= 3
        } else {
            if (wantSeason == 1) s += 6 else s -= 3
        }
        // Dub preference: base entry for SUB, "[English]" variant for DUB.
        if (d.isEnglishDub) s += if (dub) 2 else -2
        return s
    }

    /**
     * A picked candidate must at least match the second-best — avoids returning
     * a garbage entry when every candidate scores poorly. Best entry always
     * passes; a low-score entry only wins if the count signal rescues it.
     */
    private fun bestAcceptable(ranked: List<Pair<MovieEntry, Int>>, countScore: Int): Int {
        val best = ranked.maxOfOrNull { it.second } ?: 0
        if (countScore > 0) return best - 1
        return if (best >= 5) best - 1 else best
    }

    /** "Jujutsu Kaisen [English] S1-S3" -> base "Jujutsu Kaisen", range 1..3, dub. */
    private data class Decomposed(val base: String, val seasonRange: IntRange?, val isEnglishDub: Boolean)

    private fun decompose(rawTitle: String): Decomposed {
        var t = rawTitle.trim()
        val dub = t.contains("[English]", ignoreCase = true)
        t = t.replace(Regex("""\[[^\]]*\]"""), " ")  // drop [English]/[netflix]
        val range = Regex("""S(\d+)(?:-S?(\d+))?""", RegexOption.IGNORE_CASE).find(t)
        val seasonRange = range?.let { m ->
            val a = m.groupValues[1].toIntOrNull() ?: return@let null
            val b = m.groupValues[2].toIntOrNull() ?: a
            a..b.coerceAtLeast(a)
        }
        t = t.replace(Regex("""\s*S\d+(-S?\d+)?\s*$""", RegexOption.IGNORE_CASE), "")
        return Decomposed(t.trim(), seasonRange, dub)
    }

    private fun normKey(s: String): String =
        s.lowercase().replace(Regex("""[^a-z0-9]+"""), " ").trim()

    /** Lowercase word set of a title — the unit of the word-points match.
     *  Keys without any ASCII letter/digit (CJK-only) produce an empty set and
     *  can only ever ADD matches against latin rows, never create them. */
    private fun titleWords(s: String): Set<String> =
        Regex("[^a-z0-9]+").split(s.lowercase()).filter { it.isNotEmpty() }.toSet()

    /** Word-points: +1 per matched word of the AniList key set (filler words
     *  like "the"/"of" add to every row equally so they never twist the
     *  winner), +3 release-year within ±1 / -2 off. Returns (score, matched). */
    private fun wordPoints(rowTitle: String, keyWords: Set<String>, aYear: Int?, rowYear: Int?): Pair<Int, Int> {
        val matched = titleWords(rowTitle).count { it in keyWords }
        var sc = matched
        if (aYear != null && rowYear != null) sc += if (kotlin.math.abs(rowYear - aYear) <= 1) 3 else -2
        return sc to matched
    }

    private fun bestTokenSim(norm: String, keysNorm: List<String>): Double {
        if (norm.isBlank() || keysNorm.isEmpty()) return 0.0
        val a = norm.split(" ").filter { it.length > 1 }.toSet()
        if (a.isEmpty()) return 0.0
        var best = 0.0
        for (k in keysNorm) {
            val b = k.split(" ").filter { it.length > 1 }.toSet()
            if (b.isEmpty()) continue
            val inter = a.intersect(b).size.toDouble()
            val jac = inter / (a.size + b.size - inter).coerceAtLeast(1.0)
            if (jac > best) best = jac
        }
        return best
    }

    /** Language servers (base + variants) from the detail API's subject.dubs. */
    private fun serversFor(data: JSONObject, entry: MovieEntry): List<Pair<String, String>> {
        val dubs = ArrayList<Pair<String, String>>()
        val arr = data.optJSONObject("subject")?.optJSONArray("dubs") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val d = arr.optJSONObject(i) ?: continue
            val lanName = d.optString("lanName")
            val dId = d.optString("subjectId")
            val dPath = d.optString("detailPath")
            if (lanName.isNotBlank() && dId.isNotBlank() && dPath.isNotBlank()) {
                dubs.add("$dId|$dPath" to lanName)
            }
        }
        return buildList {
            add("${entry.subjectId}|${entry.detailPath}" to (dubs.firstOrNull { it.first == "${entry.subjectId}|${entry.detailPath}" }?.second ?: "English"))
            for ((lslug, lname) in dubs) {
                if (lslug == "${entry.subjectId}|${entry.detailPath}") continue
                add(lslug to lname)
            }
        }
    }

    /** Detail API data (cached 30s): subject (dubs) + resource.seasons. */
    private suspend fun fetchDetail(detailPath: String): JSONObject? {
        detailCache[detailPath]?.let { (at, obj) ->
            if (System.currentTimeMillis() - at < DETAIL_CACHE_TTL_MS) return obj
        }
        val body = ScraperEngine.fetchText(
            "$H5_API/wefeed-h5api-bff/detail?detailPath=$detailPath",
            mapOf(
                "Accept" to "application/json, text/plain, */*",
                "User-Agent" to UA,
                "X-Client-Info" to """{"timezone":"Asia/Dhaka"}""",
                "X-Source" to "h5",
                "X-Request-Lang" to "en",
                "X-Forwarded-For" to "103.25.250.31",
                "Cookie" to "uuid=d8c3539e-2e46-4000-af20-7046a856e30a",
                "Origin" to "https://netfilm.world",
                "Referer" to "https://netfilm.world/spa/videoPlayPage/movies/$detailPath"
            )
        ) ?: return null
        val data = runCatching { JSONObject(body).optJSONObject("data") }.getOrNull() ?: return null
        detailCache[detailPath] = System.currentTimeMillis() to data
        return data
    }

    /** (se, maxEp) pairs from the detail API's resource.seasons. */
    private fun parseSeasons(data: JSONObject): List<Pair<Int, Int>> {
        val arr = data.optJSONObject("resource")?.optJSONArray("seasons") ?: return emptyList()
        val out = ArrayList<Pair<Int, Int>>()
        for (i in 0 until arr.length()) {
            val s = arr.optJSONObject(i) ?: continue
            val se = s.optInt("se", -1)
            val maxEp = s.optInt("maxEp", 0)
            // Series: {se:N, maxEp:M}. MOVIES: the site renumbered them to
            // {se:0, maxEp:0} (verified live 2026-09) and their play API only
            // answers hasResource=true for se=0&ep=0 — so keep se=0 entries,
            // they are real "season 0 / 1 film" rows, not garbage.
            if (se >= 0) out.add(se to maxEp)
        }
        return out
    }

    /**
     * Total episode count for a picked slug. The slug may carry an explicit
     * "|se=N" season marker (encoded by the picker when the user picked ONE
     * season, or tapped a season chip of a combined entry) — then the count is
     * THAT season's maxEp. Without it the count is summed across ALL seasons
     * of the entry ("BoJack Horseman S1-S6" -> 12+17+13+13+10+13). Wired into
     * DownloadHelper.sourceEpisodeCount like the other providers' count helpers
     * so a wrong-title pick replaces the AniList episode cards with the picked
     * entry's real range instead of keeping AniList's count.
     */
    suspend fun episodeCountForSlug(slug: String): Int {
        val parts = slug.split("|")
        val detailPath = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: return 0
        val pickedSe = parts.getOrNull(2)
            ?.takeIf { it.startsWith("se=") }
            ?.substring(3)?.toIntOrNull()?.takeIf { it > 0 }
        val data = fetchDetail(detailPath) ?: return 0
        val seasons = parseSeasons(data)
        if (seasons.isEmpty()) return 0
        if (pickedSe != null) return seasons.firstOrNull { it.first == pickedSe }?.second ?: 0
        return seasons.sumOf { it.second }
    }

    /**
     * (se, maxEp) map for a picked slug, from the detail API — used by
     * DetailScreen to render season chips + per-season episode blocks for
     * combined entries ("Hunter x Hunter S1-S6": one row, six seasons).
     */
    suspend fun seasonMapForSlug(slug: String): List<Pair<Int, Int>> {
        val detailPath = slug.split("|").getOrNull(1)?.takeIf { it.isNotBlank() } ?: return emptyList()
        val data = fetchDetail(detailPath) ?: return emptyList()
        return parseSeasons(data)
    }

    private suspend fun discoverDomain(): String {
        val body = ScraperEngine.fetchText(
            "$H5_API/wefeed-h5api-bff/media-player/get-domain",
            mapOf("User-Agent" to UA, "X-Client-Type" to "h5")
        ) ?: return DEFAULT_DOMAIN
        val d = runCatching { JSONObject(body).optString("data") }.getOrNull()
            ?.takeIf { it.isNotBlank() } ?: return DEFAULT_DOMAIN
        return d.trimEnd('/')
    }
}