package com.panime.app.download

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject

/**
 * Port of Dantotsu's DownloadsManager, minimal form: a JSON registry of
 * downloaded episodes in SharedPreferences + SAF helpers rooted at the
 * user-picked download folder (tree Uri persisted with read/write grant).
 */
class DownloadsManager(private val context: Context) {

    data class DownloadedType(
        val title: String,
        val episode: String,
        val posterUrl: String? = null,
        val quality: String? = null,
        val anilistId: Int = 0
    ) {
        /** Stable identity that matches the sanitized on-disk folder names.
         *  Titles differing only in stripped characters ("Naruto: X" vs
         *  "Naruto X") resolve to the SAME key/folder, so they must also
         *  count as the same registry entry — otherwise the downloads list
         *  renders duplicate LazyColumn keys and crashes. */
        fun key(): String = "${sanitize(title)}/${sanitize(episode)}"
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences("downloads", Context.MODE_PRIVATE)

    // ── Registry ─────────────────────────────────────────────────────────────

    fun getDownloadsList(): List<DownloadedType> {
        val arr = runCatching { JSONArray(prefs.getString(KEY_LIST, "[]")) }.getOrDefault(JSONArray())
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            DownloadedType(
                o.optString("title"),
                o.optString("episode"),
                o.optString("posterUrl").ifBlank { null },
                o.optString("quality").ifBlank { null },
                o.optInt("anilistId", 0)
            )
        }.distinctBy { it.key() }
    }

    fun queryDownload(title: String, episode: String): Boolean {
        val key = DownloadedType(title, episode).key()
        return getDownloadsList().any { it.key() == key }
    }

    fun addDownload(
        title: String,
        episode: String,
        posterUrl: String? = null,
        quality: String? = null,
        anilistId: Int = 0
    ) {
        if (queryDownload(title, episode)) return
        val list = getDownloadsList().toMutableList()
        list.add(DownloadedType(title, episode, posterUrl, quality, anilistId))
        save(list)
    }

    fun removeDownload(title: String, episode: String) {
        val key = DownloadedType(title, episode).key()
        save(getDownloadsList().filterNot { it.key() == key })
    }

    private fun save(list: List<DownloadedType>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("title", it.title)
                    .put("episode", it.episode)
                    .put("posterUrl", it.posterUrl ?: "")
                    .put("quality", it.quality ?: "")
                    .put("anilistId", it.anilistId)
            )
        }
        prefs.edit().putString(KEY_LIST, arr.toString()).apply()
    }

    // ── Download location (SAF tree) ─────────────────────────────────────────

    fun setDownloadLocation(uri: Uri) {
        prefs.edit().putString(KEY_TREE, uri.toString()).apply()
    }

    fun getDownloadLocation(): Uri? =
        prefs.getString(KEY_TREE, null)?.let { runCatching { Uri.parse(it) }.getOrNull() }

    /** Root folder as DocumentFile, or null when no folder was picked.
     *  A revoked/deleted SAF grant must return null — never throw — because
     *  this runs on the My List → Downloads screen. */
    fun rootDir(): DocumentFile? {
        val uri = getDownloadLocation() ?: return null
        return runCatching {
            DocumentFile.fromTreeUri(context, uri)?.takeIf { it.isDirectory }
        }.getOrNull()
    }

    /**
     * "<root>/<title>/<episode>" — mirrors Dantotsu's getSubDirectory.
     * When [episode] is null only the title level is returned/created.
     * Any SAF failure (revoked grant, dead document) yields null.
     */
    fun subDir(title: String, episode: String?, create: Boolean): DocumentFile? =
        runCatching {
            var dir = rootDir() ?: return@runCatching null
            val safeTitle = sanitize(title)
            dir = (dir.findFile(safeTitle) ?: if (create) dir.createDirectory(safeTitle) else null)
                ?: return@runCatching null
            if (episode != null) {
                val safeEp = sanitize(episode)
                dir = (dir.findFile(safeEp) ?: if (create) dir.createDirectory(safeEp) else null)
                    ?: return@runCatching null
            }
            dir
        }.getOrNull()

    companion object {
        private const val KEY_LIST = "downloads_keys"
        private const val KEY_TREE = "download_tree_uri"

        fun sanitize(name: String): String =
            name.replace(Regex("[^a-zA-Z0-9-_. ]"), "").trim().take(120).ifBlank { "Unknown" }
    }
}
