package com.panime.app.data.provider

import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.model.PagedResult

/**
 * Common contract for every stream provider.
 *
 * The player only has: a title (String), an AniList numeric id (Int), the episode
 * number, and the audio type. Each provider knows how to map those to its own
 * source-site flow. Implementations must be fully self-contained: an on-device
 * provider calls its source site directly; the AniWaves backend provider calls
 * the deployed scraper. No provider may use another provider's backend as a
 * fallback (that would hide whether the on-device path actually works).
 *
 * All methods return null on failure (never throw to the UI). The ProviderManager
 * layer adds retry/timeout/fallback around these.
 */
interface StreamProvider {

    /** Stable id used for sourceMode selection, remote config, and logging. */
    val id: String

    /** Human label shown in the source chooser. */
    val label: String

    /** True if this provider requires a server-side backend (AniWaves). */
    val backendRequired: Boolean

    /**
     * Resolve the full flow for an episode.
     * @param title            anime title (from the player)
     * @param anilistId       AniList numeric id (0 if unknown)
     * @param episode         episode number
     * @param type            "sub" | "dub"
     * @param serverCode      optional specific server/quality selection
     * @param totalEpisodes   AniList total episode count (for season disambiguation)
     * @param year            AniList season year (for season disambiguation)
     * @return ResolveResult, or null if resolution failed
     */
    suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String? = null,
        seasonNumber: Int = 1,
        totalEpisodes: Int = 0,
        year: Int? = null
    ): ResolveResult?

    /**
     * Resolve using a known source-site slug (e.g. anikoto.cz `/watch/<slug>`)
     * instead of deriving it from the title/id. Default falls back to [resolve];
     * slug-capable providers override this to skip their title->slug lookup.
     */
    suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String? = null,
        seasonNumber: Int = 1
    ): ResolveResult? = resolve("", 0, episode, type, serverCode, seasonNumber)

    /** Cheap liveness/health probe. Default: a no-op success (override per provider). */
    suspend fun probeHealth(): Boolean = true

    /** Search result with title, slug, and optional poster image. [totalEpisodes]
     *  is the source's own episode count when the search response carries it
     *  (used by the wrong-title pick so the count is the picked entry's, with
     *  zero re-search / title matching). */
    data class SearchHit(
        val title: String,
        val slug: String,
        val posterUrl: String? = null,
        val totalEpisodes: Int? = null
    )

    /**
     * Search this provider for anime by query.
     * Returns list of [SearchHit] results.
     * Default returns empty — providers override if they support search.
     */
    suspend fun search(query: String): List<SearchHit> = emptyList()

    /**
     * One page of search results with the source's own last-page number, so the
     * UI can paginate manually. Default: whole [search] result as a single page.
     */
    suspend fun searchPage(query: String, page: Int): PagedResult<SearchHit> =
        PagedResult(if (page == 1) search(query) else emptyList(), 1)
}

/**
 * Capability marker: a provider that supports user-facing search.
 * Only these appear as chips in the wrong-title picker — sources without
 * real search support can never show up as dead options.
 */
interface SearchableProvider {
    suspend fun search(query: String): List<StreamProvider.SearchHit>
    suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit>
}
