package com.panime.app.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panime.app.R
import com.panime.app.player.SelectableTrack
import com.panime.app.player.TrackSelectionUiState
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary

@Composable
internal fun SettingsSheet(
    speed: Float,
    resizeMode: Int,
    currentType: String,
    trackState: TrackSelectionUiState,
    offline: Boolean = false,
    onSpeed: () -> Unit,
    onQuality: () -> Unit,
    onSubs: () -> Unit,
    onAudio: () -> Unit,
    onResizeCycle: () -> Unit,
    onType: (String) -> Unit,
    onDismiss: () -> Unit
) {
    SheetScaffold(title = stringResource(R.string.settings), onDismiss = onDismiss) {
        SettingsRow(
            stringResource(R.string.playback_speed),
            "${speed}x",
            onSpeed
        )
        if (!offline) {
            SettingsRow(
                stringResource(R.string.quality),
                if (trackState.isAutoVideo) stringResource(R.string.auto) else {
                    trackState.videoTracks.firstOrNull { it.isSelected }?.label
                        ?: stringResource(R.string.auto)
                },
                onQuality
            )
            SettingsRow(
                stringResource(R.string.subtitles),
                trackState.subtitleTracks.firstOrNull { it.isSelected }?.label
                    ?: stringResource(R.string.subtitles_off),
                onSubs
            )
            SettingsRow(stringResource(R.string.audio_tracks), currentType.uppercase(), onAudio)
        }
        SettingsRow(
            stringResource(R.string.aspect_ratio),
            when (resizeMode) {
                0 -> stringResource(R.string.fit)
                1 -> stringResource(R.string.zoom)
                else -> stringResource(R.string.fill)
            },
            onResizeCycle
        )
    }
}

@Composable
internal fun SettingsRow(title: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            color = TextPrimary,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge
        )
        Text(value, color = Flame, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
internal fun SubtitleSheet(
    state: TrackSelectionUiState,
    onSelect: (SelectableTrack) -> Unit,
    onSubtitlesOff: () -> Unit,
    onDismiss: () -> Unit
) {
    SheetScaffold(title = stringResource(R.string.subtitles), onDismiss = onDismiss) {
        TrackRow(stringResource(R.string.subtitles_off), !state.subtitleTracks.any { it.isSelected }, onSubtitlesOff)
        if (state.hasSubtitleOptions) {
            state.subtitleTracks.forEach { track ->
                TrackRow(track.label, track.isSelected) { onSelect(track) }
            }
        } else {
            Text(
                stringResource(R.string.no_subtitle_tracks),
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
internal fun AudioSheet(
    state: TrackSelectionUiState,
    currentType: String,
    // Zone/Moviebox style: real language variants ("English dub", "Arabic
    // sub", …) replace the generic sub/dub pill when the source provides them
    // (code = variant slug, name = display label). Empty = classic behavior.
    languageVariants: List<Pair<String, String>> = emptyList(),
    languageLoading: Boolean = false,
    currentLanguageCode: String? = null,
    onLanguageSelect: (String) -> Unit = {},
    onTypeChange: (String) -> Unit,
    onSelect: (SelectableTrack) -> Unit,
    onDismiss: () -> Unit
) {
    SheetScaffold(title = stringResource(R.string.audio_and_subtitles), onDismiss = onDismiss) {
        if (languageVariants.isNotEmpty() || languageLoading) {
            Text(
                "Languages",
                color = TextSecondary,
                style = MaterialTheme.typography.labelMedium
            )
            Spacer(Modifier.height(4.dp))
            if (languageLoading) {
                Text(
                    "Loading…",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                languageVariants.forEach { (code, name) ->
                    TrackRow(name, code == currentLanguageCode) { onLanguageSelect(code) }
                }
            }
            Spacer(Modifier.height(16.dp))
        } else {
            Text(
                stringResource(R.string.stream_type),
                color = TextSecondary,
                style = MaterialTheme.typography.labelMedium
            )
            Spacer(Modifier.height(8.dp))
            SubDubPill(currentType = currentType, onToggle = {
                onTypeChange(if (currentType == "sub") "dub" else "sub")
            })
            Spacer(Modifier.height(16.dp))
        }
        Text(
            stringResource(R.string.audio_tracks),
            color = TextSecondary,
            style = MaterialTheme.typography.labelMedium
        )
        Spacer(Modifier.height(4.dp))
        if (state.hasAudioOptions) {
            state.audioTracks.forEach { track ->
                TrackRow(track.label, track.isSelected) { onSelect(track) }
            }
        } else {
            Text(
                stringResource(R.string.no_audio_tracks),
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
internal fun QualitySheet(
    state: TrackSelectionUiState,
    onAuto: () -> Unit,
    onSelect: (SelectableTrack) -> Unit,
    onDismiss: () -> Unit
) {
    SheetScaffold(title = stringResource(R.string.quality), onDismiss = onDismiss) {
        TrackRow(stringResource(R.string.auto), state.isAutoVideo, onAuto)
        if (state.videoTracks.isNotEmpty()) {
            state.videoTracks.forEach { track ->
                TrackRow(track.label, !state.isAutoVideo && track.isSelected) { onSelect(track) }
            }
        } else {
            Text(
                stringResource(R.string.quality_adaptive_only),
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
internal fun SpeedSheet(
    speeds: List<Float>,
    current: Float,
    onSelect: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    SheetScaffold(title = stringResource(R.string.playback_speed), onDismiss = onDismiss) {
        speeds.forEach { s ->
            val label = if (s == 1f) "1x · ${stringResource(R.string.normal)}" else "${s}x"
            TrackRow(label, s == current) { onSelect(s) }
        }
    }
}

@Composable
internal fun EpisodeSheet(
    current: Int,
    total: Int,
    onSelect: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val ranges = remember(total) {
        if (total <= 50) emptyList()
        else buildList {
            var start = 1
            while (start <= total) {
                val end = minOf(start + 49, total)
                add(start to end)
                start = end + 1
            }
        }
    }
    var selectedRangeStart by remember { mutableIntStateOf(((current - 1) / 50) * 50 + 1) }

    SheetScaffold(title = stringResource(R.string.episodes), onDismiss = onDismiss) {
        if (ranges.isNotEmpty()) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                items(ranges.size) { index ->
                    val (s, e) = ranges[index]
                    val active = s == selectedRangeStart
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (active) Flame else Color.Black.copy(alpha = 0.40f))
                            .border(
                                1.dp,
                                if (active) Flame else Color.White.copy(alpha = 0.40f),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedRangeStart = s }
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "${s}\u2013${e}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        val from = if (ranges.isEmpty()) 1 else selectedRangeStart
        val to = if (ranges.isEmpty()) total else ranges.firstOrNull { it.first == selectedRangeStart }?.second ?: total
        val eps = (from..to).toList()

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 56.dp),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = if (ranges.isEmpty()) 360.dp else 300.dp),
            contentPadding = PaddingValues(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(eps) { ep ->
                val selected = ep == current
                Box(
                    Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) Flame else Color.Black.copy(alpha = 0.45f))
                        .border(
                            1.dp,
                            if (selected) Flame else Color.White.copy(alpha = 0.22f),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelect(ep) }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        ep.toString(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
internal fun SubDubPill(currentType: String, onToggle: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.45f))
            .border(1.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .clickable(onClick = onToggle)
            .padding(2.dp)
    ) {
        PillSegment("SUB", currentType != "dub")
        PillSegment("DUB", currentType == "dub")
    }
}

@Composable
internal fun PillSegment(text: String, active: Boolean) {
    Box(
        Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (active) Flame else Color.Transparent)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall
        )
    }
}

@Composable
internal fun ServerSheet(
    servers: List<Pair<String, String>>,
    selectedId: String?,
    selectedName: String?,
    sourceMode: String,
    lockedSource: String? = null,
    onSourceChange: (String) -> Unit,
    onSelect: (id: String, name: String) -> Unit,
    onDismiss: () -> Unit,
    serverQualities: Map<String, String> = emptyMap()
) {
    SheetScaffold(title = stringResource(R.string.switch_server), onDismiss = onDismiss) {
        if (lockedSource == null) {
            Text(
                "SOURCE",
                color = TextSecondary,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            val modes = listOf("aniwaves" to "WAVE", "anidb" to "DB", "anizone" to "ZONE", "anikage" to "KAGE", "just4anime" to "JUST", "anidap" to "DAP", "anikoto" to "KOTO", "animenosub" to "NOSUB", "moviebox" to "MOVIE")
            // Horizontally scrollable so all 8 source chips stay reachable on
            // narrow phones (a plain Row clipped the last few off-screen).
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 14.dp)
            ) {
                items(modes) { (key, label) ->
                    val active = sourceMode == key
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (active) Color(0xFFE02424) else Color.Black.copy(alpha = 0.45f))
                            .border(
                                1.dp,
                                if (active) Color(0xFFE02424) else Color.White.copy(alpha = 0.40f),
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { onSourceChange(key) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            label,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
        if (servers.isEmpty()) {
            Text(
                stringResource(R.string.no_servers),
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            servers.forEach { (id, name) ->
                val selected = id == selectedId ||
                    (selectedId == null && name.equals(selectedName, true))
                val qualityBadge = serverQualities[id]
                val label = if (qualityBadge != null) "$name ($qualityBadge)" else name
                TrackRow(label, selected) { onSelect(id, name) }
            }
        }
    }
}

@Composable
internal fun SheetScaffold(
    title: String,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            ),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.72f)
                .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .background(SurfaceRaised)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .navigationBarsPadding()
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .width(40.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Hairline.copy(alpha = 0.35f))
            )
            Spacer(Modifier.height(14.dp))
            Text(
                title,
                color = TextPrimary,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Column(
                Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
            ) {
                content()
            }
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier
                    .align(Alignment.End)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onDismiss)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    stringResource(R.string.close),
                    color = Flame,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
internal fun TrackRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .background(if (selected) Flame.copy(alpha = 0.12f) else Color.Transparent)
            .padding(horizontal = 10.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = if (selected) Flame else TextPrimary,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.bodyLarge
        )
        if (selected) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = Flame)
        }
    }
}
