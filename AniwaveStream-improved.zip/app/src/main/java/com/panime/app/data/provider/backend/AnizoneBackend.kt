package com.panime.app.data.provider.backend

import com.panime.app.data.api.AnizoneApi
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider
import com.panime.app.data.provider.aniwaves.AniwavesScraper

/**
 * AniZone provider — uses on-device AnizoneApi scraper (no backend required).
 */
class AnizoneBackend : StreamProvider, SearchableProvider {
    override val id = "anizone"
    override val label = "ZONE"
    override val backendRequired = false

    // ===================== Wrong-title support (additive) =====================

    override suspend fun search(query: String): List<StreamProvider.SearchHit> =
        searchPage(query, 1).items

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        // anizone embeds a single batch (~24 max) in its search page — no page
        // navigation exists, so page > 1 is always empty.
        if (query.isBlank() || page > 1) return PagedResult(emptyList(), 1)
        val items = AnizoneApi.searchAnime(query.trim())
        return PagedResult(
            items.map {
                StreamProvider.SearchHit(title = it.title, slug = it.slug, posterUrl = it.coverUrl)
            },
            lastPage = 1
        )
    }

    /**
     * Wrong-title resolution: [slug] is the user's picked anizone slug, used
     * DIRECTLY — resolveSlug's auto-matching is never consulted.
     */
    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? {
        val servers = AnizoneApi.servers(slug, episode)
        val full = (if (!serverCode.isNullOrBlank()) AnizoneApi.resolveOne(slug, episode, serverCode)
        else AnizoneApi.resolveFull(slug, episode)) ?: return null
        val url = full.proxiedM3u8 ?: return null
        return ResolveResult(
            source = id, servers = servers, url = url, rawUrl = full.rawM3u8,
            isByfms = false, subtitles = full.subtitles, notFound = false
        )
    }

    override suspend fun resolve(
        title: String, anilistId: Int, episode: Int, type: String, serverCode: String?,
        seasonNumber: Int, totalEpisodes: Int, year: Int?
    ): ResolveResult? {
        val titles = buildTitleCandidates(title, anilistId, seasonNumber)
        val slug = AnizoneApi.resolveSlug(title, totalEpisodes, seasonNumber, year, titles)
            ?: return null
        val servers = AnizoneApi.servers(slug, episode)
        val full = (if (!serverCode.isNullOrBlank()) AnizoneApi.resolveOne(slug, episode, serverCode)
        else AnizoneApi.resolveFull(slug, episode)) ?: return null
        val url = full.proxiedM3u8 ?: return null
        return ResolveResult(
            source = id, servers = servers, url = url, rawUrl = full.rawM3u8,
            isByfms = false, subtitles = full.subtitles, notFound = false
        )
    }

    private fun buildTitleCandidates(title: String, anilistId: Int, seasonNumber: Int = 1): List<String> {
        val out = linkedSetOf<String>()
        out.add(title)
        for (c in candidateTitles(title)) out.add(c)
        val detail = AniwavesScraper.anilistDetail(anilistId)
        if (detail != null) {
            for (v in listOfNotNull(detail.romaji, detail.english, detail.native) + detail.synonyms) {
                if (v.isNullOrBlank()) continue
                if (seasonNumber > 1 && !v.contains(Regex("season|part|\\bII\\b|\\b${seasonNumber}\\b", RegexOption.IGNORE_CASE))) continue
                out.add(v)
            }
        }
        return out.toList()
    }

    private fun candidateTitles(t: String): List<String> {
        val base = t.trim()
        if (base.isBlank()) return listOf(t)
        val core = base.split(Regex("""\s*[:：-]\s*""")).first().trim()
        return if (core.equals(base, ignoreCase = true) || core.length < 4) listOf(base)
        else listOf(base, core)
    }
}
