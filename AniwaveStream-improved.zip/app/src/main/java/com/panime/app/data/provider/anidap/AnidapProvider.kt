package com.panime.app.data.provider.anidap

import com.panime.app.data.api.AnidapApi
import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider
import com.panime.app.util.Obf
import com.panime.app.util.jsonArrayOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/**
 * On-device AniDap provider.
 *
 * Ports the resolution flow directly from the AniDap source sites — no backend
 * (the previous AnidapApi already did this; this adapter wraps that exact logic
 * behind the StreamProvider contract). Flow:
 *   1) anidap.lol/api/anime/<anilistId> -> slug
 *   2) chad.anidap.lol/rest/api/servers?id=<slug>&epNum=<ep> -> providers
 *   3) chad.anidap.lol/rest/api/sources?id=<slug>&epNum=<ep>&type=&providerId= -> m3u8 + referer
 *
 * The m3u8 is a DIRECT HLS url (playeng.animeapps.top) — fetched by the device
 * with the returned Referer. No proxy, no worker, no backend.
 */
class AnidapProvider : StreamProvider, SearchableProvider {

    override val id = "anidap"
    override val label = "DAP"
    override val backendRequired = false

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val ANIDAP = Obf.s("Mi4uKilgdXU7NDM+Oyp0NjU2")
    private val CHAD = Obf.s("Mi4uKilgdXU5Mjs+dDs0Mz47KnQ2NTY=")
    private val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

    private fun headers(referer: String = "$ANIDAP/home") =
        ScraperEngine.defaultHeaders(referer = referer) +
            ("User-Agent" to MOBILE_UA) +
            ("Accept" to "application/json")

    override suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int,
        totalEpisodes: Int,
        year: Int?
    ): ResolveResult? {
        val slug = resolveSlug(anilistId) ?: return null
        val pool = serverPool(slug, episode, type) ?: return null
        val (m3u8, referer, subs) = resolveFromPool(slug, episode, type, serverCode, pool) ?: return null
        val servers = pool.mapNotNull { s ->
            val code = s["id"] ?: return@mapNotNull null
            code to AnidapApi.serverDisplayName(code)
        }
        return ResolveResult(
            source = id, servers = servers, url = m3u8, rawUrl = m3u8,
            referer = referer, format = "hls", subtitles = subs
        )
    }

    private fun resolveSlug(anilistId: Int): String? {
        val txt = ScraperEngine.fetchText(
            "$ANIDAP/api/anime/$anilistId", headers = headers(), useCache = true
        ) ?: return null
        val root = json.parseToJsonElement(txt).jsonObject
        val ok = root["success"]?.jsonPrimitive?.content == "true"
        if (!ok) return null
        return root["data"]?.jsonObject?.get("id")?.jsonPrimitive?.content
    }

    private fun serverPool(slug: String, episode: Int, type: String): List<Map<String, String>>? {
        val txt = ScraperEngine.fetchText(
            "$CHAD/rest/api/servers?id=$slug&epNum=$episode", headers = headers()
        ) ?: return null
        val root = json.parseToJsonElement(txt).jsonObject
        val arr = if (type == "dub")
            root["dubProviders"].jsonArrayOrNull ?: root["subProviders"].jsonArrayOrNull
        else root["subProviders"].jsonArrayOrNull
        val listed = arr?.mapNotNull { it.jsonObject.toSimpleMap() } ?: return null
        // anidap's site injects its own "adp" provider that chad never returns.
        return if (listed.any { it["id"] == AnidapApi.ADP_ID }) listed
        else listOf(mapOf("id" to AnidapApi.ADP_ID)) + listed
    }

    private fun resolveProvider(
        slug: String, episode: Int, type: String, pid: String
    ): Triple<String, String, List<AniwavesApi.SubtitleTrack>>? {
        val txt = ScraperEngine.fetchText(
            "$CHAD/rest/api/sources?id=$slug&epNum=$episode&type=$type&providerId=$pid",
            headers = headers()
        ) ?: return null
        val root = json.parseToJsonElement(txt).jsonObject
        val srcList = root["sources"].jsonArrayOrNull ?: return null
        val first = srcList.firstOrNull()?.jsonObject ?: return null
        val m3u8 = first["url"]?.jsonPrimitive?.content ?: return null
        val referer = root["headers"]?.jsonObject?.get("Referer")?.jsonPrimitive?.content
            ?: run {
                val u = java.net.URI(m3u8)
                "${u.scheme}://${u.host}/"
            }
        // Subtitle tracks ride on the same response:
        // tracks:[{id,url,label,kind:"captions",default}] (beep) — or null
        // (yuki/neko/sora). Old code kept only the m3u8 and dropped them.
        val seen = mutableSetOf<String>()
        val subs = root["tracks"].jsonArrayOrNull?.mapNotNull { el ->
            runCatching {
                val t = el.jsonObject
                val kind = t["kind"]?.jsonPrimitive?.content ?: "captions"
                if (kind == "thumbnails" || kind == "preview") return@runCatching null
                val url = t["url"]?.jsonPrimitive?.content
                    ?: t["file"]?.jsonPrimitive?.content ?: ""
                if (url.isBlank()) return@runCatching null
                val label = t["label"]?.jsonPrimitive?.content ?: "Unknown"
                if (!seen.add("$url|$label")) return@runCatching null
                AniwavesApi.SubtitleTrack(label.lowercase().replace(Regex("\\s+"), "-"), label, url)
            }.getOrNull()
        } ?: emptyList()
        // Health-check the playlist: chad returns a URL even when the upstream
        // player is dead (neko's B2 worker 500s "b2_authorize_account failed:
        // account_trouble" while the API still answers). Without this the pool
        // walk never triggers and the episode shows a player error. A dead or
        // non-m3u8 body counts as a failed provider → caller tries the next one.
        val playlist = runCatching {
            ScraperEngine.fetchText(
                m3u8,
                headers = ScraperEngine.defaultHeaders(referer = referer),
                useCache = false
            )
        }.getOrNull()
        if (playlist.isNullOrBlank() || !playlist.contains("#EXTM3U")) return null
        return Triple(m3u8, referer, subs)
    }

    private fun JsonObject.toSimpleMap(): Map<String, String> {
        val out = mutableMapOf<String, String>()
        for (k in keys) {
            val v = this[k]?.jsonPrimitive?.content ?: continue
            out[k] = v
        }
        return out
    }

    // ===================== Wrong-title support (additive) =====================
    // Separate code path from the default anilist-id resolution above:
    //   - searchPage: /api/anime/search?q=&page= (JSON, paginated)
    //   - resolveWithSlug: the picked result's own anidap id is used DIRECTLY
    //     for servers/sources — resolveSlug(anilistId) is never consulted.
    // The default resolve() flow above is untouched.

    override suspend fun search(query: String): List<StreamProvider.SearchHit> =
        searchPage(query, 1).items

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        if (query.isBlank()) return PagedResult(emptyList(), 1)
        val q = java.net.URLEncoder.encode(query.trim(), "UTF-8")
        val txt = ScraperEngine.fetchText(
            "$ANIDAP/api/anime/search?q=$q&page=$page",
            headers = headers(referer = "$ANIDAP/search?q=$q"),
            useCache = false
        ) ?: return PagedResult(emptyList(), page.coerceAtLeast(1))
        val root = runCatching { json.parseToJsonElement(txt).jsonObject }
            .getOrNull() ?: return PagedResult(emptyList(), page.coerceAtLeast(1))
        if (root["success"]?.jsonPrimitive?.content != "true") {
            return PagedResult(emptyList(), page.coerceAtLeast(1))
        }
        val hits = root["results"].jsonArrayOrNull?.mapNotNull { el ->
            val o = el.jsonObject
            val aid = o["id"]?.jsonPrimitive?.content ?: return@mapNotNull null
            val t = o["title"]?.jsonObject
            val name = t?.get("userPreferred")?.jsonPrimitive?.content
                ?: t?.get("english")?.jsonPrimitive?.content
                ?: t?.get("romaji")?.jsonPrimitive?.content
                ?: return@mapNotNull null
            StreamProvider.SearchHit(
                title = name,
                slug = aid,
                posterUrl = o["image"]?.jsonPrimitive?.content
            )
        } ?: emptyList()
        // The API only exposes hasNextPage — expose exactly one more page while true.
        val hasNext = root["hasNextPage"]?.jsonPrimitive?.content == "true"
        return PagedResult(hits, if (hasNext) page + 1 else page)
    }

    /**
     * Wrong-title resolution: [slug] is anidap's SEARCH id from a pick. It is
     * converted to the chad slug first, then used directly — the default
     * anilist-id auto-match is never consulted.
     */
    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? {
        val chadSlug = AnidapApi.chadSlugByPick(slug) ?: return null
        val pool = serverPool(chadSlug, episode, type) ?: return null
        // Must use chadSlug here too — the search-pick id is NOT valid against
        // /rest/api/sources and silently returns no playable stream.
        val (m3u8, referer, subs) = resolveFromPool(chadSlug, episode, type, serverCode, pool) ?: return null
        val servers = pool.mapNotNull { s ->
            val code = s["id"] ?: return@mapNotNull null
            code to AnidapApi.serverDisplayName(code)
        }
        return ResolveResult(
            source = id, servers = servers, url = m3u8, rawUrl = m3u8,
            referer = referer, format = "hls", subtitles = subs
        )
    }

    /**
     * Try the chosen (or default) provider first, then walk the rest of the
     * pool — one dead provider must never leave the episode unplayable.
     */
    private fun resolveFromPool(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        pool: List<Map<String, String>>
    ): Triple<String, String, List<AniwavesApi.SubtitleTrack>>? {
        val pid = serverCode
            ?: pool.firstOrNull { it["default"] == "true" }?.get("id")
            ?: pool.firstOrNull()?.get("id")
            ?: return null
        for (p in listOf(pid) + pool.mapNotNull { it["id"] }.filter { it != pid }) {
            val r = resolveProvider(slug, episode, type, p) ?: continue
            return r
        }
        return null
    }
}
