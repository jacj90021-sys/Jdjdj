package com.panime.app.data.provider

import android.content.Context
import com.panime.app.util.Obf
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.concurrent.atomic.AtomicReference

private val Context.ds by preferencesDataStore("provider_config")

/**
 * Loads the remote provider configuration.
 *
 * Safety guarantees (per spec):
 *  - If the config server is unreachable, use the last-known-good config (cached
 *    in DataStore) or the bundled default — never break all providers.
 *  - The remote payload is validated by [RemoteConfigParser.safeMerge] (version/
 *    engine checks) before it is accepted; an incompatible payload is rejected
 *    and we roll back to the previous good config.
 *  - The config only carries declarative values (endpoints/headers/referer/
 *    priority/enabled/timeout/version). It never delivers executable code.
 */
object RemoteConfigRepository {

    private const val TAG = "RemoteConfig"
    // Served from the PUBLIC releases repo so any device can fetch it without
    // auth (raw.githubusercontent 404s on private repos). Edit
    // ajoynul832-source/panime/provider_config.json to control providers + ads
    // remotely — takes effect on the next app launch.
    private val CONFIG_URL = Obf.s("Mi4uKilgdXUoOy10PTMuMi84Lyk/KDk1NC4/NC50OTU3dTswNSM0LzZiaWh3KTUvKDk/dSo7NDM3P3U3OzM0dSooNSwzPj8oBTk1NDwzPXQwKTU0")

    private val KEY_LAST_GOOD = stringPreferencesKey("last_good_config")

    private val cached = AtomicReference<RemoteProviderConfig>(RemoteProviderConfig.DEFAULT)

    /** Fetch + validate the remote config. Falls back safely on any failure. */
    fun load(context: Context): RemoteProviderConfig {
        // 1) Try remote.
        val remote = runCatching {
            val txt = ScraperEngine.fetchText(CONFIG_URL, timeoutMs = 15_000, maxRetries = 2)
            txt?.let { RemoteConfigParser.parse(it) }
        }.getOrNull()

        val merged = RemoteConfigParser.safeMerge(remote)

        // 2) Persist if remote gave us something valid + newer.
        if (remote != null && remote.version >= cached.get().version) {
            runBlocking { persist(context, remote) }
            cached.set(merged)
            return merged
        }

        // 3) Remote failed/unavailable: use cached last-good from DataStore.
        val stored = runBlocking { loadStored(context) }
        if (stored != null) {
            cached.set(stored)
            return stored
        }

        // 4) Nothing cached: bundled default.
        cached.set(RemoteProviderConfig.DEFAULT)
        return RemoteProviderConfig.DEFAULT
    }

    /** Toggle a provider's enabled flag locally (kill-switch without APK). */
    fun setEnabled(context: Context, id: String, enabled: Boolean) {
        val current = cached.get().copy(
            providers = cached.get().providers.map {
                if (it.id == id) it.copy(enabled = enabled) else it
            }
        )
        cached.set(current)
        runBlocking { persist(context, current) }
    }

    private suspend fun persist(context: Context, cfg: RemoteProviderConfig) {
        runCatching {
            context.ds.edit { it[KEY_LAST_GOOD] = Json.encodeToString(RemoteProviderConfig.serializer(), cfg) }
        }
    }

    private suspend fun loadStored(context: Context): RemoteProviderConfig? {
        return runCatching {
            val raw = context.ds.data.first()[KEY_LAST_GOOD] ?: return null
            RemoteConfigParser.parse(raw)
        }.getOrNull()
    }
}
