package com.panime.app.update

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import com.panime.app.BuildConfig
import com.panime.app.data.provider.ScraperEngine
import java.io.File
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

// ---- GitHub release payloads ----
@Serializable
private data class GhAsset(
    val name: String = "",
    val size: Long = 0L,
    val browser_download_url: String = ""
)

@Serializable
private data class GhRelease(
    val tag_name: String = "",
    val body: String? = null,
    val html_url: String? = null,
    val draft: Boolean = false,
    val prerelease: Boolean = false,
    val assets: List<GhAsset> = emptyList()
)

data class UpdateInfo(
    val version: String,            // display, e.g. "2.2.0" (no leading v)
    val displayTag: String,         // original tag, e.g. "v2.2.0"
    val sizeLabel: String,          // "Size: 18.4 MB"
    val changelog: List<String>,
    val apkUrl: String,
    val assetSize: Long = 0L
)

object GitHubUpdater {
    // Public releases repo on a separate account — the main repo stays private.
    private const val RELEASES_URL =
        "https://api.github.com/repos/ajoynul832-source/panime/releases?per_page=20"
    private const val MIME_APK = "application/vnd.android.package-archive"
    private const val FILE_NAME = "aniwavestream-update.apk"
    private val JSON = Json { ignoreUnknownKeys = true }

    // ---- Update discovery ----

    // Atom feed + latest-download redirect live on plain github.com (no API rate
    // limits), so they keep working even when api.github.com is throttled/blocked.
    private const val RELEASES_ATOM_URL =
        "https://github.com/ajoynul832-source/panime/releases.atom"
    private const val LATEST_DOWNLOAD_BASE =
        "https://github.com/ajoynul832-source/panime/releases/latest/download/"

    suspend fun checkForUpdate(): UpdateInfo? = withContext(Dispatchers.IO) {
        // Compiled out in store builds (-PstoreBuild=true for Amazon/Play): the
        // store owns updates, and Amazon re-signs with its own key, so a GitHub
        // APK can't install over the store build anyway (signature mismatch).
        if (!BuildConfig.UPDATER_ENABLED) return@withContext null

        // Updates come ONLY from the public GitHub releases repo — no Firebase
        // Remote Config override. (RC `latest_version`/`apk_url` used to take
        // precedence and could pin the app to a stale version, blocking GitHub
        // releases from ever being seen; that override is gone.)
        fromApi() ?: fromAtom()
    }

    /** Primary path: GitHub REST API (gives per-ABI assets + exact changelog). */
    private suspend fun fromApi(): UpdateInfo? {
        val raw = ScraperEngine.fetchText(
            RELEASES_URL,
            headers = mapOf(
                "Accept" to "application/vnd.github+json",
                "User-Agent" to "AniwaveStream/${BuildConfig.VERSION_NAME}",
                "X-GitHub-Api-Version" to "2022-11-28"
            ),
            timeoutMs = 10_000L,
            maxRetries = 1
        ) ?: return null

        // Only trust releases whose tag is a real version (v1.2.3). The repo also
        // holds legacy auto-builds tagged apk-<sha> that ship app-debug.apk files —
        // installing one of those shows "-debug" and old UI, so they must never win.
        @Suppress("UNCHECKED_CAST")
        val rels = runCatching { JSON.decodeFromString<List<GhRelease>>(raw) }.getOrNull()
            ?: return null
        val rel = rels.asSequence()
            .filter { !it.draft && !it.prerelease }
            .filter { stripTag(it.tag_name).matches(Regex("\\d+(\\.\\d+)*")) }
            .maxWithOrNull { a, b -> versionCmp(stripTag(a.tag_name), stripTag(b.tag_name)) }
            ?: return null

        val tag = rel.tag_name.trim().ifBlank { return null }
        val strippedCandidate = stripTag(tag)
        if (!isNewer(strippedCandidate, stripTag(BuildConfig.VERSION_NAME))) return null

        val asset = pickAsset(rel.assets) ?: return null
        val sizeLabel = if (asset.size > 0L) {
            String.format(Locale.ENGLISH, "Size: %.1f MB", asset.size / 1024f / 1024f)
        } else "Size: —"

        return UpdateInfo(
            version = strippedCandidate,
            displayTag = tag,
            sizeLabel = sizeLabel,
            changelog = changelogLines(rel.body),
            apkUrl = asset.browser_download_url,
            assetSize = asset.size
        )
    }

    /**
     * Fallback path: parse the releases Atom feed (a plain github.com page, no
     * API rate limits). Gives the latest version + changelog; the APK comes from
     * the stable "latest download" redirect which never needs the API.
     */
    private suspend fun fromAtom(): UpdateInfo? {
        val xml = ScraperEngine.fetchText(
            RELEASES_ATOM_URL,
            headers = mapOf(
                "Accept" to "application/atom+xml, application/xml, text/xml, */*",
                "User-Agent" to "AniwaveStream/${BuildConfig.VERSION_NAME}"
            ),
            timeoutMs = 10_000L,
            maxRetries = 2
        ) ?: return null

        val entry = Regex("<entry>(.*?)</entry>", RegexOption.DOT_MATCHES_ALL)
            .find(xml)?.groupValues?.get(1) ?: return null
        // id looks like "tag:github.com,2008:Repository/1345355564/v1.0.18".
        val tag = Regex("/v(\\d+(?:\\.\\d+)+)").find(entry)?.groupValues?.get(1)
            ?.let { "v$it" } ?: return null
        val strippedCandidate = stripTag(tag)
        if (!isNewer(strippedCandidate, stripTag(BuildConfig.VERSION_NAME))) return null

        val body = Regex("<content[^>]*>(.*?)</content>", RegexOption.DOT_MATCHES_ALL)
            .find(entry)?.groupValues?.get(1)
            ?.replace("&lt;", "<")?.replace("&gt;", ">")?.replace("&amp;", "&") // unescape FIRST
            ?.replace(Regex("<[^>]+>"), "")                                        // then strip tags
            ?.trim()

        return UpdateInfo(
            version = strippedCandidate,
            displayTag = tag,
            sizeLabel = "Size: —",
            changelog = changelogLines(body),
            apkUrl = LATEST_DOWNLOAD_BASE + fallbackAssetName(),
            assetSize = 0L
        )
    }

    /** Deterministic per-ABI asset name for the latest-download redirect. */
    private fun fallbackAssetName(): String {
        val abi = Build.SUPPORTED_ABIS.firstOrNull()?.lowercase(Locale.ENGLISH).orEmpty()
        return when {
            abi.contains("arm64") -> "panime-arm64-v8a.apk"
            abi.contains("armeabi") || abi.contains("arm") -> "panime-armeabi-v7a.apk"
            abi.contains("x86_64") -> "panime-x86_64.apk"
            abi.contains("x86") -> "panime-x86.apk"
            else -> "panime-universal.apk"
        }
    }

    // ---- semver compare (strip 'v', drop '-flavor' suffix, numeric dot compare) ----
    internal fun stripTag(tag: String): String =
        tag.trim()
            .removePrefix("v").removePrefix("V")
            .substringBefore('-')
            .trim()

    internal fun isNewer(candidate: String, current: String): Boolean {
        val cand = candidate.split('.').map { it.toIntOrNull() ?: 0 }
        val curr = current.split('.').map { it.toIntOrNull() ?: 0 }
        val n = maxOf(cand.size, curr.size)
        for (i in 0 until n) {
            val c = cand.getOrElse(i) { 0 }
            val o = curr.getOrElse(i) { 0 }
            if (c != o) return c > o
        }
        return false // equal
    }

    // Component-wise semver compare: >0 if a newer, <0 if b newer, 0 if equal.
    private fun versionCmp(a: String, b: String): Int {
        val pa = a.split('.').map { it.toIntOrNull() ?: 0 }
        val pb = b.split('.').map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(pa.size, pb.size)) {
            val x = pa.getOrElse(i) { 0 }
            val y = pb.getOrElse(i) { 0 }
            if (x != y) return if (x > y) 1 else -1
        }
        return 0
    }

    // Choose the APK asset that matches the device ABI. Falls back to
    // universal and then any .apk.
    private fun pickAsset(assets: List<GhAsset>): GhAsset? {
        if (assets.isEmpty()) return null
        val lowerNames = assets.map { it.name.lowercase(Locale.ENGLISH) to it }
        for (abi in Build.SUPPORTED_ABIS) {
            val hit = lowerNames.firstOrNull { (n, _) -> n.contains(abi) }
            if (hit != null) return hit.second
        }
        lowerNames.firstOrNull { (n, _) -> n.contains("universal") || n.contains("-all-") }
            ?.let { return it.second }
        assets.firstOrNull { it.name.endsWith(".apk", true) }?.let { return it }
        return assets.first()
    }

    internal fun changelogLines(body: String?): List<String> {
        if (body.isNullOrBlank()) return listOf("Bug fixes & performance updates")
        val lines = body.lines()
            .map { it.trim().removePrefix("#").removePrefix("-").removePrefix("*").removePrefix("•").trim() }
            .filter { it.isNotBlank() && it.length > 2 }
        return (if (lines.isEmpty()) listOf("Bug fixes & performance updates") else lines).take(6)
    }

    // ---- DownloadManager helpers ----
    fun destFile(context: Context): File {
        val dir = File(context.getExternalFilesDir(null) ?: context.filesDir, "updates")
        dir.mkdirs()
        return File(dir, FILE_NAME)
    }

    fun enqueue(context: Context, url: String, title: String = "AniwaveStream update"): Long {
        val file = destFile(context)
        // Remove any stale file so DM doesn't append "-1".
        runCatching { if (file.exists()) file.delete() }
        val req = DownloadManager.Request(Uri.parse(url)).apply {
            setTitle(title)
            setDescription("Downloading update")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationUri(Uri.fromFile(file))
            setMimeType(MIME_APK)
            addRequestHeader("Accept", "application/octet-stream")
            setAllowedOverMetered(true)
            setAllowedOverRoaming(true)
        }
        val dm = context.getSystemService(DownloadManager::class.java) ?: return -1L
        return runCatching { dm.enqueue(req) }.getOrDefault(-1L)
    }

    sealed interface Progress {
        data class Running(val fraction: Float) : Progress
        data object Done : Progress
        data object Failed : Progress
    }

    fun progress(context: Context, id: Long): Progress {
        val dm = context.getSystemService(DownloadManager::class.java) ?: return Progress.Failed
        dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
            if (!c.moveToFirst()) return Progress.Failed
            val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            return when (status) {
                DownloadManager.STATUS_SUCCESSFUL -> Progress.Done
                DownloadManager.STATUS_FAILED -> Progress.Failed
                else -> {
                    val soFar = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                    val frac = if (total > 0) (soFar.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
                    Progress.Running(frac)
                }
            }
        }
        return Progress.Failed
    }

    // ---- Installer ----
    fun launchInstall(context: Context, file: File): Boolean {
        return runCatching {
            // O+ requires user to have allowed "install unknown apps" for this package.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !context.packageManager.canRequestPackageInstalls()
            ) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                Toast.makeText(
                    context,
                    "Enable \"Allow from this source\", then tap Install again.",
                    Toast.LENGTH_LONG
                ).show()
                return false
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val view = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, MIME_APK)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(view)
            true
        }.onFailure { e ->
            Toast.makeText(context, "Couldn't open installer: ${e.message}", Toast.LENGTH_LONG).show()
        }.getOrDefault(false)
    }
}
