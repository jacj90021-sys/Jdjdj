package com.panime.app.data.provider

import android.util.Log
import com.panime.app.BuildConfig
import com.panime.app.data.network.HttpClient
import okhttp3.MediaType.Companion.toMediaType
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import okhttp3.FormBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap

/**
 * Shared HTTP engine for on-device providers.
 *
 * - Single OkHttpClient with sane timeouts (default 60s; providers may override).
 * - Transparent http->https normalization (Render cold-start returns http:// that
 *   ExoPlayer cannot follow).
 * - Small in-memory cache (best-effort, short TTL) to avoid re-hitting source sites
 *   for identical requests during retries.
 * - Retry with exponential backoff for transient failures (502/503/timeouts).
 */
object ScraperEngine {

    private const val TAG = "ScraperEngine"

    /** Simple HTTP result carrying status code + body (POST endpoints that need
     *  non-2xx handling, e.g. BYFMS 428 captcha_required). */
    data class HttpResult(val code: Int, val body: String)

    val client = HttpClient.shared.newBuilder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    private val cache = ConcurrentHashMap<String, Pair<Long, String>>()
    private const val CACHE_TTL_MS = 30_000L

    private val DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    fun defaultHeaders(referer: String? = null, origin: String? = null): Map<String, String> {
        val h = mutableMapOf(
            "User-Agent" to DESKTOP_UA,
            "Accept" to "application/json, text/plain, */*",
            "Accept-Language" to "en-US,en;q=0.9"
        )
        if (!referer.isNullOrBlank()) h["Referer"] = referer
        if (!origin.isNullOrBlank()) h["Origin"] = origin
        return h
    }

    /** Normalize http:// -> https:// (Render cold-start emits http URLs). */
    fun https(url: String): String =
        if (url.startsWith("http://", ignoreCase = true)) "https://" + url.substring(7) else url

    private fun cached(key: String): String? {
        val v = cache[key] ?: return null
        if (System.currentTimeMillis() - v.first > CACHE_TTL_MS) { cache.remove(key); return null }
        return v.second
    }

    private fun put(key: String, value: String) {
        cache[key] = System.currentTimeMillis() to value
    }

    /**
     * Fetch a URL as text with retry/backoff. Returns null on persistent failure.
     * Transient errors (HTTP 502/503, timeouts, connection resets) are retried.
     */
    fun fetchText(
        url: String,
        headers: Map<String, String> = emptyMap(),
        timeoutMs: Long = 60_000L,
        useCache: Boolean = false,
        maxRetries: Int = 3
    ): String? {
        val key = "$url|${headers.hashCode()}"
        if (useCache) cached(key)?.let { return it }

        var lastErr: String? = null
        repeat(maxRetries) { attempt ->
            try {
                val req = Request.Builder()
                    .url(https(url))
                    .apply { headers.forEach { (k, v) -> header(k, v) } }
                    .build()
                val callClient = if (timeoutMs != 60_000L) {
                    client.newBuilder()
                        .connectTimeout(timeoutMs, TimeUnit.MILLISECONDS)
                        .readTimeout(timeoutMs, TimeUnit.MILLISECONDS)
                        .build()
                } else client
                callClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string().orEmpty()
                        if (useCache && body.isNotBlank()) put(key, body)
                        return body
                    }
                    // Retry only on transient server errors.
                    if (resp.code in 500..599) {
                        lastErr = "HTTP ${resp.code}"
                    } else {
                        // Non-transient (4xx) — don't retry.
                        lastErr = "HTTP ${resp.code}"
                        return null
                    }
                }
            } catch (e: Exception) {
                lastErr = e.message ?: "io-error"
                // connection/timeout errors are transient -> retry with backoff
            }
            if (attempt < maxRetries - 1) {
                try { runBlocking { delay(500L * (attempt + 1)) } } catch (_: InterruptedException) {}
            }
        }
        if (BuildConfig.DEBUG) {
            Log.w(TAG, "fetchText failed after retries: $url -> $lastErr")
        }
        return null
    }

    /** Fetch a URL and return the raw Response (for header/stream inspection). */
    fun fetchResponse(url: String, headers: Map<String, String> = emptyMap()): Response? {
        return try {
            val req = Request.Builder().url(https(url))
                .apply { headers.forEach { (k, v) -> header(k, v) } }.build()
            client.newCall(req).execute()
        } catch (e: Exception) {
            Log.w(TAG, "fetchResponse failed: $url -> ${e.message}")
            null
        }
    }

    /**
     * POST a JSON body and return the raw status code + body (no auto-retry —
     * callers decide on 4xx/428). Used by BYFMS's challenge/attest/captcha/
     * verify/playback endpoints.
     */
    fun postJson(
        url: String,
        body: String,
        headers: Map<String, String> = emptyMap(),
        timeoutMs: Long = 15_000L
    ): HttpResult? {
        return try {
            val req = Request.Builder()
                .url(https(url))
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            val callClient = if (timeoutMs != 15_000L) {
                client.newBuilder()
                    .connectTimeout(timeoutMs, TimeUnit.MILLISECONDS)
                    .readTimeout(timeoutMs, TimeUnit.MILLISECONDS)
                    .build()
            } else client
            callClient.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                HttpResult(resp.code, text)
            }
        } catch (e: Exception) {
            Log.w(TAG, "postJson failed: $url -> ${e.message}")
            null
        }
    }

    /** POST a URL-encoded form body (e.g. aniwaves typeahead) and return the body
     *  text, or null on failure. Retries transient 5xx once with backoff. */
    fun postForm(
        url: String,
        form: Map<String, String>,
        headers: Map<String, String> = emptyMap(),
        timeoutMs: Long = 10_000L
    ): String? {
        val bodyBuilder = FormBody.Builder()
        form.forEach { (k, v) -> bodyBuilder.add(k, v) }
        val body = bodyBuilder.build()
        var lastErr: String? = null
        repeat(2) { attempt ->
            try {
                val req = Request.Builder()
                    .url(https(url))
                    .apply { headers.forEach { (k, v) -> header(k, v) } }
                    .post(body)
                    .build()
                val callClient = if (timeoutMs != 10_000L) {
                    client.newBuilder()
                        .connectTimeout(timeoutMs, TimeUnit.MILLISECONDS)
                        .readTimeout(timeoutMs, TimeUnit.MILLISECONDS)
                        .build()
                } else client
                callClient.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) return resp.body?.string().orEmpty()
                    if (resp.code in 500..599) {
                        lastErr = "HTTP ${resp.code}"
                    } else {
                        lastErr = "HTTP ${resp.code}"
                        return null
                    }
                }
            } catch (e: Exception) {
                lastErr = e.message ?: "io-error"
            }
            if (attempt < 1) {
                try { runBlocking { delay(500L * (attempt + 1)) } } catch (_: InterruptedException) {}
            }
        }
        if (BuildConfig.DEBUG) {
            Log.w(TAG, "postForm failed after retries: $url -> $lastErr")
        }
        return null
    }
}
