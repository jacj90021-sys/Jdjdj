package com.panime.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.panime.app.ui.theme.Background

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    HomeShimmer(modifier.fillMaxSize().background(Background))
}
