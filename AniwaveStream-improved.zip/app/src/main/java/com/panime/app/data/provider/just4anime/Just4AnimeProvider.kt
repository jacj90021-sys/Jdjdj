package com.panime.app.data.provider.just4anime

import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider
import com.panime.app.util.Obf
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.URLEncoder

/**
 * On-device Just4Anime provider — DEVICE-RESOLVABLE SERVERS ONLY.
 *
 * The server list is NOT hardcoded. It mirrors the just4anime watch page exactly:
 * the site asks its backend for the servers available for an anime via
 *   GET /api/v1/meta/availability/{animeId}
 * (the site's own getServerAvailability call) and renders tabs per type
 * (SUB / H-SUB / DUB / EMBED). We call the same endpoint and show only the rows
 * the site actually reports for this anime + audio type — so any anime or episode
 * shows exactly what the site has, nothing more.
 *
 * Streaming:
 *   jin / sai / mai / echo / sen  -> sources[] carries a ready-to-play PROXIED
 *                                     m3u8 (cors.just4anime.online/proxy/...) — use
 *                                     it directly, no browser/node needed.
 *   kai / zeke                    -> pull literal m3u8 from the embed iframe page
 *                                    (regex on HTML).
 *   ryuk                          -> resolve ourselves from animegg.org (regex).
 *
 * No backend required; sai/mai that previously needed node (otakuhg eval packer)
 * now play directly because the site itself serves them proxied.
 */
class Just4AnimeProvider : StreamProvider, SearchableProvider {

    override val id = "just4anime"
    override val label = "JUST"
    override val backendRequired = false

    /**
     * Codes the just4anime site hides from its own server list (mirrors the site's
     * EXCLUDED_SERVERS constant: kaa=KAA, pahe=animepahe, uta). Never offered.
     */
    private val EXCLUDED_SERVERS = setOf("kaa", "pahe", "uta")

    /** Fallback probe set when the site's availability API is unreachable. */
    private val CANDIDATE_SERVERS = setOf("kai", "zeke", "jin", "ryuk", "sai", "mai", "echo", "sen")

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val API = Obf.s("Mi4uKilgdXU7KjN0MC8pLm47NDM3P3Q1NDYzND91Oyoz")

    private fun headers(referer: String? = null, ajax: Boolean = false) =
        ScraperEngine.defaultHeaders(referer = referer) +
            (if (ajax) "X-Requested-With" to "XMLHttpRequest" else "Accept" to "text/html,*/*")

    override suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int,
        totalEpisodes: Int,
        year: Int?
    ): ResolveResult? {
        val servers = listServers(anilistId, episode, type)
        if (servers.isEmpty()) return null
        // Row ids are "server|type" (e.g. "kai|hsub") — split and resolve the exact
        // type on-device so the user's picked row (sub or hsub) plays correctly.
        val (url, referer, format, subs) = resolveFromServers(anilistId, episode, type, serverCode, servers, title)
            ?: return null
        return ResolveResult(
            source = id,
            servers = servers,
            url = url, rawUrl = url,
            referer = referer,
            format = format,
            subtitles = subs,
            notFound = false
        )
    }

    /** Direct in-app server list for the player's server sheet (no backend). */
    suspend fun listServersFor(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String
    ): List<Pair<String, String>> = listServers(anilistId, episode, type)

    private fun listServers(anilistId: Int, episode: Int, type: String): List<Pair<String, String>> {
        // DYNAMIC + matches the site: the watch page's server list comes from the
        // availability endpoint, grouped by type. In SUB mode the site shows BOTH
        // the SUB and H-SUB server tabs (separate server entries, not a type
        // toggle), so list one row per server x type. In DUB mode only DUB.
        val avail = fetchAvailability(anilistId)
        if (avail != null) {
            val out = mutableListOf<Pair<String, String>>()
            val wanted = if (type == "dub") listOf("dub") else listOf("sub", "h-sub")
            for (t in wanted) {
                for ((code, name) in avail[t].orEmpty()) {
                    val rowType = if (t == "h-sub") "hsub" else t
                    val label = if (t == "h-sub") "$name · HSUB" else name
                    out.add("$code|$rowType" to label)
                }
            }
            return out
        }
        // Fallback (availability unreachable): probe candidate servers directly so
        // the sheet still lists something. Only servers that actually return a real
        // stream for this episode are kept — no hardcoded rows.
        return probeServers(anilistId, episode, type)
    }

    /**
     * Site's own source of truth: which servers exist for an anime, by type.
     * Returns type -> ordered (code, displayName) list, or null if unreachable.
     */
    private fun fetchAvailability(anilistId: Int): Map<String, List<Pair<String, String>>>? {
        // Flat form (primary): data.servers[] = [{code, displayName, types:[...]}]
        runCatching {
            val txt = ScraperEngine.fetchText(
                "$API/v1/meta/availability/$anilistId/servers", headers(ajax = true), useCache = true
            ) ?: return@runCatching null
            val root = json.parseToJsonElement(txt).jsonObject
            val data = root["data"]?.jsonObject ?: return@runCatching null
            val servers = data["servers"]?.jsonArray ?: return@runCatching null
            val byType = mutableMapOf<String, MutableList<Pair<String, String>>>()
            for (s in servers) {
                val o = s.jsonObject
                val code = o["code"]?.jsonPrimitive?.content ?: continue
                if (code in EXCLUDED_SERVERS) continue
                val name = o["displayName"]?.jsonPrimitive?.content ?: code
                val types = o["types"]?.jsonArray?.mapNotNull { it.jsonPrimitive.content } ?: emptyList()
                for (t in types) byType.getOrPut(t) { mutableListOf() }.add(code to name)
            }
            if (byType.isNotEmpty()) return@runCatching byType
            null
        }.getOrNull()?.let { return it }

        // Grouped form (fallback): data.<type>.providers[] = [{code, displayName}]
        return runCatching {
            val txt = ScraperEngine.fetchText(
                "$API/v1/meta/availability/$anilistId", headers(ajax = true), useCache = true
            ) ?: return@runCatching null
            val root = json.parseToJsonElement(txt).jsonObject
            val data = root["data"]?.jsonObject ?: return@runCatching null
            val byType = mutableMapOf<String, List<Pair<String, String>>>()
            for (t in listOf("h-sub", "sub", "dub", "embed")) {
                val providers = data[t]?.jsonObject?.get("providers")?.jsonArray ?: continue
                val list = providers.mapNotNull { e ->
                    val o = e.jsonObject
                    val code = o["code"]?.jsonPrimitive?.content ?: return@mapNotNull null
                    if (code in EXCLUDED_SERVERS) return@mapNotNull null
                    val name = o["displayName"]?.jsonPrimitive?.content ?: code
                    code to name
                }
                if (list.isNotEmpty()) byType[t] = list
            }
            byType.takeIf { it.isNotEmpty() }
        }.getOrNull()
    }

    private fun probeServers(anilistId: Int, episode: Int, type: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        val probeTypes = if (type == "dub") listOf("dub") else listOf("sub", "hsub")
        for (srv in CANDIDATE_SERVERS) {
            for (t in probeTypes) {
                val ok = runCatching {
                    val data = apiSources(anilistId, episode, srv, t)
                    // Must actually carry a stream for this ep. The API response
                    // ALWAYS includes an `episode` metadata object even when there
                    // is no stream, so require a real iframe or sources entry.
                    data != null && (
                        data["iframe"]?.jsonArray?.isNotEmpty() == true ||
                        data["sources"]?.jsonArray?.isNotEmpty() == true
                    )
                }.getOrDefault(false)
                if (ok) {
                    val label = if (t == "hsub") "${srv.uppercase()} · HSUB" else srv.uppercase()
                    out.add("$srv|$t" to label)
                }
            }
        }
        return out
    }

    /** Parse the sources payload's `subtitles` array
     *  ([{url, lang:"English"}, …] — verified live on sai/mai/kai/zeke; empty
     *  for ryuk). Same payload the stream already comes from. */
    private fun subsOf(data: JsonObject): List<AniwavesApi.SubtitleTrack> {
        val seen = mutableSetOf<String>()
        return data["subtitles"]?.jsonArray?.mapNotNull { el ->
            runCatching {
                val t = el.jsonObject
                val url = t["url"]?.jsonPrimitive?.content
                    ?: t["file"]?.jsonPrimitive?.content ?: ""
                if (url.isBlank()) return@runCatching null
                val lang = t["lang"]?.jsonPrimitive?.content
                    ?: t["label"]?.jsonPrimitive?.content ?: "Unknown"
                if (!seen.add("$url|$lang")) return@runCatching null
                AniwavesApi.SubtitleTrack(lang.lowercase().replace(Regex("\\s+"), "-"), lang, url)
            }.getOrNull()
        } ?: emptyList()
    }

    private fun apiSources(anilistId: Int, episode: Int, server: String, typ: String): JsonObject? {
        val url = "$API/v1/meta/sources/$anilistId?provider=$server&num=$episode&type=$typ"
        val txt = ScraperEngine.fetchText(url, headers(ajax = true), useCache = true)
        val root = txt?.let { runCatching { json.parseToJsonElement(it).jsonObject }.getOrNull() }
        if (root?.get("success")?.jsonPrimitive?.content != "true") return null
        return root["data"]?.jsonObject
    }

    private fun resolveServer(
        anilistId: Int, episode: Int, server: String, typ: String, title: String
    ): Resolved? {
        val data = apiSources(anilistId, episode, server, typ) ?: return null
        val subs = subsOf(data)
        when (server) {
            "kai", "zeke" -> {
                val iframes = data["iframe"]?.jsonArray ?: return null
                val iframeUrl = iframes.firstOrNull()?.jsonObject
                    ?.get("url")?.jsonPrimitive?.content ?: return null
                return embedM3u8(iframeUrl)?.let { Resolved(it.first, it.second, it.third, subs) }
            }
            "ryuk" -> {
                val j4slug = data["episode"]?.jsonObject?.get("id")?.jsonPrimitive?.content
                return ryukReal(anilistId, episode, j4slug, title, typ)?.let { Resolved(it.first, it.second, it.third, emptyList()) }
            }
            // jin / sai / mai / echo / sen (+ any new server the site adds):
            // sources[] carries a ready-to-play PROXIED url — use it as-is.
            else -> {
                val srcs = data["sources"]?.jsonArray ?: return null
                val s = srcs.firstOrNull()?.jsonObject ?: return null
                val url = s["url"]?.jsonPrimitive?.content ?: return null
                val hdrs = s["headers"]?.jsonObject
                val ref = hdrs?.get("referer")?.jsonPrimitive?.content
                    ?: hdrs?.get("Referer")?.jsonPrimitive?.content
                val isM = (s["isM3U8"]?.jsonPrimitive?.content == "true") || url.endsWith(".m3u8")
                return Resolved(url, ref ?: "", if (isM) "hls" else "mp4", subs)
            }
        }
    }

    /** Stream + parsed subtitles from one server resolution. */
    private data class Resolved(
        val url: String,
        val referer: String,
        val format: String,
        val subs: List<AniwavesApi.SubtitleTrack>
    )

    private fun embedM3u8(iframeUrl: String): Triple<String, String, String>? {
        val page = ScraperEngine.fetchText(iframeUrl, headers(referer = iframeUrl)) ?: return null
        val m = Regex("(https?://[^\\s\"']+?\\.m3u8[^\\s\"']*)").find(page)?.value ?: return null
        val head = ScraperEngine.fetchText(m, headers(referer = iframeUrl)) ?: return null
        if (!head.trim().startsWith("#EXTM3U")) return null
        val host = Regex("https?://([^/]+)").find(iframeUrl)?.groupValues?.getOrNull(1)
        return Triple(m, "https://$host", "hls")
    }

    private fun ryukReal(
        anilistId: Int, episode: Int, just4Slug: String?, title: String, typ: String
    ): Triple<String, String, String>? {
        val referer = Obf.s("Mi4uKilgdXU7NDM3Pz09dDUoPXU=")
        val want = mapOf("sub" to "subbed", "dub" to "dubbed", "raw" to "raw", "hsub" to "subbed")[typ] ?: "subbed"
        val candidates = mutableListOf<String>()
        if (!just4Slug.isNullOrBlank()) {
            val base = just4Slug.split(Regex("(?:-episode-|/ep)"))[0]
                .trim('-', '$').trim()
            if (base.isNotBlank() && "your-name" !in base && "kimi-no-na-wa" !in base) candidates += base
        }
        val tslug = title.lowercase().replace(Regex("[^a-z0-9\\s-]"), "")
            .replace(Regex("\\s+"), "-").trim()
        if (tslug.isNotBlank()) candidates += listOf("$tslug-tv", tslug, "$tslug-dub")
        for (slug in candidates.distinct()) {
            val page = ScraperEngine.fetchText(
                Obf.s("Mi4uKilgdXUtLS10OzQzNz89PXQ1KD11") + "$slug-episode-$episode", headers(referer = referer)
            ) ?: continue
            val mirrors = Regex("data-id=['\"](\\d+)['\"]\\s+data-mirror=['\"][^'\"]*['\"]\\s+data-version=['\"]([^'\"]+)['\"]")
                .findAll(page).map { it.groupValues[1] to it.groupValues[2] }.toList()
            val chosen = mirrors.firstOrNull { it.second == want }?.first
                ?: mirrors.firstOrNull()?.first ?: continue
            val emb = ScraperEngine.fetchText(
                Obf.s("Mi4uKilgdXUtLS10OzQzNz89PXQ1KD11") + "embed/$chosen", headers(referer = referer)
            ) ?: continue
            val mp = Regex("/play/(\\d+)/video\\.mp4\\?for=(\\d+)").find(emb) ?: continue
            val url = Obf.s("Mi4uKilgdXUtLS10OzQzNz89PXQ1KD11KjY7I3U=") + "${mp.groupValues[1]}/video.mp4?for=${mp.groupValues[2]}"
            return Triple(url, referer, "mp4")
        }
        return null
    }

    // ===================== Wrong-title support (additive) =====================
    // The picker searches the site's own /api/advanced-search route (the same
    // call /browse makes) and stores the AniList id (string) as the slug — the
    // key listServers() already uses. The default resolve() flow is untouched.

    override suspend fun search(query: String): List<StreamProvider.SearchHit> =
        searchPage(query, 1).items

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        if (query.isBlank()) return PagedResult(emptyList(), 1)
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        val txt = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXUwLykubjs0Mzc/dDU0NjM0P3U7KjN1Oz4sOzQ5Pz53KT87KDkyZSsvPygjZw==") + "$q&page=$page",
            headers(referer = Obf.s("Mi4uKilgdXUwLykubjs0Mzc/dDU0NjM0P3U4KDUtKT8="))
        ) ?: return PagedResult(emptyList(), 1)
        val root = runCatching { json.parseToJsonElement(txt).jsonObject }.getOrNull()
            ?: return PagedResult(emptyList(), 1)
        val data = root["data"]?.jsonObject ?: root
        val items = data["results"]?.jsonArray ?: return PagedResult(emptyList(), 1)
        val hits = items.mapNotNull { el ->
            val o = el.jsonObject
            // The picker slug is the AniList id string — exactly what listServers() takes.
            val id = o["id"]?.jsonPrimitive?.content ?: return@mapNotNull null
            val t = o["title"]?.jsonObject
            val title = t?.get("romaji")?.jsonPrimitive?.content
                ?: t?.get("english")?.jsonPrimitive?.content
                ?: t?.get("userPreferred")?.jsonPrimitive?.content
                ?: return@mapNotNull null
            // `image` is the POSTER (portrait); `cover` is the banner (landscape).
            // The picker grid is portrait — show the poster itself, not the banner.
            val poster = o["image"]?.jsonPrimitive?.content ?: o["cover"]?.jsonPrimitive?.content
            // Carry the source's OWN count through the pick — the picked entry's
            // totalEpisodes is the truth, no re-search or title matching later.
            val total = o["totalEpisodes"]?.jsonPrimitive?.content?.toIntOrNull()
                ?: o["currentEpisodeCount"]?.jsonPrimitive?.content?.toIntOrNull()
            StreamProvider.SearchHit(title = title, slug = id, posterUrl = poster, totalEpisodes = total)
        }
        val lastPage = data["totalPages"]?.jsonPrimitive?.content?.toIntOrNull() ?: 1
        return PagedResult(items = hits, lastPage = lastPage)
    }

    /** Wrong-title resolution: [slug] is the picked AniList id string, used
     *  DIRECTLY — no title guessing, no cross-series fallback. */
    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? {
        val anilistId = slug.toIntOrNull() ?: return null
        val servers = listServers(anilistId, episode, type)
        if (servers.isEmpty()) return null
        val (url, referer, format, subs) = resolveFromServers(anilistId, episode, type, serverCode, servers, slug)
            ?: return null
        return ResolveResult(
            source = id,
            servers = servers,
            url = url, rawUrl = url,
            referer = referer,
            format = format,
            subtitles = subs,
            notFound = false
        )
    }

    /**
     * Try the chosen (or first) server first, then walk the rest of the list —
     * one dead server must never leave the episode unplayable. Row ids are
     * "server|type" (e.g. "kai|hsub"); each is split and resolved on-device so
     * the user's picked row (sub or hsub) plays correctly.
     */
    private fun resolveFromServers(
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        servers: List<Pair<String, String>>,
        label: String
    ): Resolved? {
        val firstChoice = serverCode?.takeIf { it.isNotBlank() }
            ?: servers.firstOrNull()?.first
            ?: return null
        for (chosen in listOf(firstChoice) + servers.map { it.first }.filter { it != firstChoice }) {
            val (srv, typ) = if (chosen.contains("|")) {
                val i = chosen.indexOf("|")
                chosen.substring(0, i) to chosen.substring(i + 1)
            } else chosen to type
            val r = resolveServer(anilistId, episode, srv, typ, label) ?: continue
            return r
        }
        return null
    }

    /** Episode count for a picked AniList id (string), from the search result's
     *  totalEpisodes field. 0 = unknown — caller keeps AniList originals.
     *
     *  MUST search by TITLE, not by id: advanced-search treats a numeric query
     *  as a title (query=21 -> "Eyeshield 21" first, not the id 21 anime), so
     *  searching by id returns the WRONG series' count. The picked title ranks
     *  the right series; the id then pins the exact entry. */
    fun episodeCountForPick(anilistId: String, title: String): Int {
        val id = anilistId.toIntOrNull() ?: return 0
        if (title.isBlank()) return 0
        val q = URLEncoder.encode(title.trim(), "UTF-8")
        val txt = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXUwLykubjs0Mzc/dDU0NjM0P3U7KjN1Oz4sOzQ5Pz53KT87KDkyZSsvPygjZw==") + "$q&page=1",
            headers(referer = Obf.s("Mi4uKilgdXUwLykubjs0Mzc/dDU0NjM0P3U4KDUtKT8="))
        ) ?: return 0
        val root = runCatching { json.parseToJsonElement(txt).jsonObject }.getOrNull() ?: return 0
        val data = root["data"]?.jsonObject ?: root
        val items = data["results"]?.jsonArray ?: return 0
        for (i in 0 until items.size) {
            val o = items.optJSONObjectSafe(i) ?: continue
            if (o["id"]?.jsonPrimitive?.content == anilistId) {
                return o["totalEpisodes"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
            }
        }
        return 0
    }

    /**
     * Real per-episode audio blocks — the truth, never inferred. just4anime's
     * availability API reports each server's `types` (sub / h-sub / dub / embed);
     * the union across servers is what the series offers. h-sub -> HSUB chip.
     */
    fun audioBlocksFor(anilistId: Int): List<String> {
        val txt = ScraperEngine.fetchText(
            "$API/v1/meta/availability/$anilistId/servers", headers(ajax = true), useCache = true
        ) ?: return emptyList()
        val root = runCatching { json.parseToJsonElement(txt).jsonObject }.getOrNull() ?: return emptyList()
        val data = root["data"]?.jsonObject ?: root
        val out = LinkedHashSet<String>()
        for (el in data["servers"]?.jsonArray ?: emptyList()) {
            val o = el.jsonObject
            val code = o["code"]?.jsonPrimitive?.content ?: continue
            if (code in EXCLUDED_SERVERS) continue
            for (t in o["types"]?.jsonArray ?: emptyList()) {
                val typ = t.jsonPrimitive.content
                when (typ) {
                    "sub" -> out.add("sub")
                    "h-sub" -> out.add("hsub")
                    "dub" -> out.add("dub")
                }
            }
        }
        return out.toList()
    }

    private fun JsonArray.optJSONObjectSafe(i: Int): JsonObject? =
        runCatching { this[i].jsonObject }.getOrNull()
}
