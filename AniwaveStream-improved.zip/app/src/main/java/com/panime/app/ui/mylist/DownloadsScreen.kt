package com.panime.app.ui.mylist

import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import com.panime.app.download.AnimeDownloaderService
import com.panime.app.download.DownloadState
import com.panime.app.download.DownloadsManager
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.SharpCorner
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.theme.TextPrimary

private fun fmtBytes(b: Long): String = when {
    b >= 1_000_000_000L -> "%.1f GB".format(b / 1_000_000_000f)
    b >= 1_000_000L -> "%.1f MB".format(b / 1_000_000f)
    b > 0 -> "%.0f KB".format(b / 1_000f)
    else -> ""
}

@Composable
fun DownloadsScreen(
    onPlayOffline: (anilistId: Int, episode: Int, uri: String, title: String) -> Unit = { _, _, _, _ -> },
    onPlayDownloaded: (anilistId: Int, episode: Int, downloadId: String, title: String) -> Unit = { _, _, _, _ -> }
) {
    val context = LocalContext.current
    val manager = remember { DownloadsManager(context) }
    var entries by remember { mutableStateOf(manager.getDownloadsList()) }
    var hasFolder by remember { mutableStateOf(manager.getDownloadLocation() != null) }
    var folderName by remember { mutableStateOf<String?>(null) }
    var freeSpace by remember { mutableStateOf<String?>(null) }
    val active by DownloadState.entries.collectAsState()
    val pausedTasks by DownloadState.pausedTasks.collectAsState()
    var confirmCancel by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf<DownloadsManager.DownloadedType?>(null) }
    var confirmCancelInternal by remember { mutableStateOf<com.panime.app.download.DownloadCenter.Row?>(null) }
    var confirmDeleteInternal by remember { mutableStateOf<com.panime.app.download.DownloadCenter.Row?>(null) }

    // Self-contained Media3 downloads (no addon APK involved).
    val internal by remember {
        com.panime.app.download.DownloadCenter.observe(context, kotlinx.coroutines.Dispatchers.Default)
    }.collectAsState(initial = emptyList())

    fun refresh() {
        entries = manager.getDownloadsList()
        hasFolder = manager.getDownloadLocation() != null
        folderName = manager.rootDir()?.name
        // Free space of the picked storage (exact for primary storage trees).
        freeSpace = runCatching {
            val uri = manager.getDownloadLocation() ?: return@runCatching null
            if (!Uri.decode(uri.toString()).contains("primary:")) return@runCatching null
            "%.1f GB free".format(
                StatFs(Environment.getExternalStorageDirectory().path).availableBytes / 1_000_000_000f
            )
        }.getOrNull()
    }

    LaunchedEffect(Unit) {
        // Boot the Media3 download engine so queued items resume draining
        // even if the process was killed while a transfer was active.
        com.panime.app.download.DownloadCenter.ensureStarted(context)
        // Rehydrate a queue snapshot left by a previous crash/process death
        // and (from this foreground screen) resume draining it.
        val hadPending = AnimeDownloaderService.restorePending(context)
        refresh()
        if (hadPending) AnimeDownloaderService.resumePending(context)
    }

    // When a download finishes (done flag flips), re-read the saved registry so
    // the completed card appears without leaving the screen.
    val doneNames = active.values.filter { it.done }.map { it.name }.toSet()
    LaunchedEffect(doneNames) {
        if (doneNames.isNotEmpty()) refresh()
    }

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            manager.setDownloadLocation(uri)
            refresh()
        }
    }

    Box(Modifier.fillMaxSize().background(Background)) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(4.dp))

        // ── Storage header bar ────────────────────────────────────────────────
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .border(2.dp, Hairline, RoundedCornerShape(10.dp))
                .background(SurfaceRaised)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    (folderName ?: "NO FOLDER CHOSEN").uppercase(),
                    color = TextMuted,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 1.sp
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    freeSpace ?: "",
                    color = TextPrimary,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            Row(
                Modifier
                    .clip(SharpCorner)
                    .border(2.dp, Hairline, SharpCorner)
                    .background(Surface)
                    .clickable { folderPicker.launch(null) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    Icons.Default.Refresh,
                    contentDescription = null,
                    tint = TextPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    if (hasFolder) "SWITCH" else "CHOOSE",
                    color = TextPrimary,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        Spacer(Modifier.height(16.dp))

        val activeEntries = active.values.filterNot { it.done }.sortedBy { it.name }
            .distinctBy { it.name }
        // distinctBy guards the LazyColumn keys: legacy registries could hold
        // entries whose stripped titles collide ("Naruto: X" vs "Naruto X")
        // — duplicate keys used to crash this whole screen on open.
        val completedEntries = remember(entries) { entries.distinctBy { it.key() } }
        val internalActive = internal.filter { it.stateLabel != "COMPLETED" }
        val internalDone = internal.filter { it.stateLabel == "COMPLETED" }
            .sortedByDescending { it.completedAtMs }
        val showEmpty = !hasFolder && completedEntries.isEmpty() &&
            activeEntries.isEmpty() && internal.isEmpty()

        if (!showEmpty) {
            LazyColumn(
                Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // ── Internal (Media3) active downloads ────────────────────────
                items(internalActive, key = { "int-" + it.id }) { row ->
                    InternalDownloadRow(
                        row = row,
                        onPauseResume = {
                            if (row.stateLabel == "PAUSED") {
                                com.panime.app.download.DownloadCenter.resume(context, row.id)
                            } else {
                                com.panime.app.download.DownloadCenter.pause(context, row.id)
                            }
                        },
                        onCancel = { confirmCancelInternal = row },
                        onRetry = { com.panime.app.download.DownloadCenter.retryNow(context, row.id) }
                    )
                }

                // ── Active downloads (legacy addon queue, your HTML card) ─────
                items(activeEntries, key = { "active-" + it.name }) { e ->
                    val title = e.name.substringBefore(" - Episode ")
                    val epNum = e.name.substringAfter("Episode ", "").ifBlank { "?" }
                    val rowPaused = e.name in pausedTasks
                    val mbLine = when {
                        e.bytes > 0 && e.percent >= 5 ->
                            "${fmtBytes(e.bytes)} / ${fmtBytes(e.bytes * 100L / e.percent)}"
                        e.bytes > 0 -> fmtBytes(e.bytes)
                        else -> ""
                    }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(2.dp, Hairline, RoundedCornerShape(12.dp))
                            .background(SurfaceRaised)
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(width = 90.dp, height = 60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(2.dp, Hairline, RoundedCornerShape(8.dp))
                                    .background(Color.Black)
                            ) {
                                e.posterUrl?.let {
                                    AsyncImage(
                                        it,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                e.quality?.let { q ->
                                    Text(
                                        q.uppercase(),
                                        color = Color.White,
                                        fontFamily = PlexMono,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.sp,
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Color.Black.copy(alpha = 0.85f))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    title,
                                    color = TextPrimary,
                                    fontFamily = Bricolage,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    lineHeight = 17.sp
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    "Episode $epNum",
                                    color = Flame,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                if (mbLine.isNotBlank()) {
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        mbLine,
                                        color = TextMuted,
                                        fontFamily = PlexMono,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(
                                    if (rowPaused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause,
                                    contentDescription = if (rowPaused) "Resume" else "Pause",
                                    tint = TextPrimary,
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable { DownloadState.toggleTaskPause(e.name) }
                                )
                                Icon(
                                    Icons.Outlined.Delete,
                                    contentDescription = "Cancel download",
                                    tint = TextPrimary,
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clickable { confirmCancel = e.name }
                                )
                            }
                        }

                        if (e.error != null) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                e.error.take(90),
                                color = Flame,
                                fontFamily = PlexMono,
                                fontSize = 10.sp
                            )
                        } else {
                            Spacer(Modifier.height(6.dp))
                            // dashed top border of your progress-section
                            val dashColor = Hairline.copy(alpha = 0.45f)
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .drawBehind {
                                        drawLine(
                                            dashColor,
                                            Offset(0f, size.height / 2),
                                            Offset(size.width, size.height / 2),
                                            strokeWidth = 2f,
                                            pathEffect = PathEffect.dashPathEffect(
                                                floatArrayOf(12f, 10f)
                                            )
                                        )
                                    }
                            )
                            Spacer(Modifier.height(3.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    when {
                                        rowPaused -> "PAUSED"
                                        e.error != null -> "FAILED"
                                        else -> "DOWNLOADING" + (e.server?.let { " • $it" } ?: "")
                                    },
                                    color = if (rowPaused || e.error != null) TextMuted else Flame,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                                Text(
                                    "${e.percent}%",
                                    color = Flame,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(Modifier.height(3.dp))
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .border(2.dp, Hairline, RoundedCornerShape(4.dp))
                                    .background(Background)
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(e.percent / 100f)
                                        .height(8.dp)
                                        .background(Flame)
                                )
                            }
                        }
                    }
                }

                // ── Internal (Media3) completed downloads ──────────────────────
                items(internalDone, key = { "intdone-" + it.id }) { row ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(2.dp, Hairline, RoundedCornerShape(12.dp))
                            .background(SurfaceRaised)
                            .clickable {
                                onPlayDownloaded(
                                    row.animeId, row.episodeNumber, row.id, row.title
                                )
                            }
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(width = 90.dp, height = 60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(2.dp, Hairline, RoundedCornerShape(8.dp))
                                    .background(Color.Black)
                            ) {
                                row.posterUrl?.let {
                                    AsyncImage(
                                        it,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                row.quality?.let { q ->
                                    Text(
                                        q.uppercase(),
                                        color = Color.White,
                                        fontFamily = PlexMono,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.sp,
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Color.Black.copy(alpha = 0.85f))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    row.title,
                                    color = TextPrimary,
                                    fontFamily = Bricolage,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    lineHeight = 17.sp
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    row.episodeLabel,
                                    color = Flame,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    buildString {
                                        if (row.contentLength > 0) append(fmtBytes(row.contentLength))
                                        else if (row.bytesDownloaded > 0) append(fmtBytes(row.bytesDownloaded))
                                        row.serverLabel?.let { if (isNotBlank()) append("  ·  $it") }
                                    },
                                    color = TextMuted,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp
                                )
                            }
                            Icon(
                                Icons.Outlined.Delete,
                                contentDescription = "Delete",
                                tint = TextPrimary,
                                modifier = Modifier
                                    .size(20.dp)
                                    .clickable { confirmDeleteInternal = row }
                            )
                        }
                    }
                }

                // ── Completed downloads (legacy addon, your HTML completed card)
                items(completedEntries, key = { it.key() }) { entry ->
                    var found by remember(entry.key()) {
                        mutableStateOf<Pair<DocumentFile, Long>?>(null)
                    }
                    LaunchedEffect(entry.key()) {
                        // SAF queries can throw (revoked grant / dead tree) —
                        // an uncaught throw here crashes the whole app.
                        found = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                            runCatching {
                                val dir: DocumentFile? =
                                    manager.subDir(entry.title, entry.episode, create = false)
                                dir?.listFiles()?.firstOrNull { df: DocumentFile ->
                                    df.name?.endsWith(".mkv") == true ||
                                        df.name?.endsWith(".mp4") == true
                                }?.let { it to it.length() }
                            }.getOrNull()
                        }
                    }
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(2.dp, Hairline, RoundedCornerShape(12.dp))
                            .background(SurfaceRaised)
                            .clickable(enabled = found != null) {
                                found?.let { (file, _) ->
                                    val epNum = entry.episode
                                        .substringAfter("Episode ", "").trim().toIntOrNull() ?: 1
                                    onPlayOffline(entry.anilistId, epNum, file.uri.toString(), entry.title)
                                }
                            }
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(width = 90.dp, height = 60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(2.dp, Hairline, RoundedCornerShape(8.dp))
                                    .background(Color.Black)
                            ) {
                                entry.posterUrl?.let {
                                    AsyncImage(
                                        it,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                entry.quality?.let { q ->
                                    Text(
                                        q.uppercase(),
                                        color = Color.White,
                                        fontFamily = PlexMono,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.sp,
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Color.Black.copy(alpha = 0.85f))
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    entry.title,
                                    color = TextPrimary,
                                    fontFamily = Bricolage,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    lineHeight = 17.sp
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    entry.episode,
                                    color = Flame,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    found?.let { fmtBytes(it.second) }
                                        ?: if (hasFolder) "file missing" else "",
                                    color = TextMuted,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 10.sp
                                )
                            }
                            Icon(
                                Icons.Outlined.Delete,
                                contentDescription = "Delete",
                                tint = TextPrimary,
                                modifier = Modifier
                                    .size(20.dp)
                                    .clickable { confirmDelete = entry }
                            )
                        }
                    }
                }
            }
        } else {
            // Empty state (only when no folder is chosen)
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Choose a download folder",
                    color = TextPrimary,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "Select where your episodes will be saved",
                    color = TextMuted,
                    fontFamily = PlexMono,
                    fontSize = 12.sp
                )
            }
        }
    }

        confirmCancelInternal?.let { row ->
            ConfirmDialog(
                title = "Cancel download?",
                sub = "${row.title} — ${row.episodeLabel}",
                confirmLabel = "CANCEL",
                onConfirm = {
                    com.panime.app.download.DownloadCenter.remove(context, row.id)
                    confirmCancelInternal = null
                },
                onDismiss = { confirmCancelInternal = null }
            )
        }

        confirmDeleteInternal?.let { row ->
            ConfirmDialog(
                title = "Delete ${row.episodeLabel}?",
                sub = row.title,
                confirmLabel = "DELETE",
                onConfirm = {
                    com.panime.app.download.DownloadCenter.remove(context, row.id)
                    confirmDeleteInternal = null
                },
                onDismiss = { confirmDeleteInternal = null }
            )
        }

        confirmCancel?.let { name ->
            ConfirmDialog(
                title = "Cancel download?",
                sub = name,
                confirmLabel = "CANCEL",
                onConfirm = {
                    context.sendBroadcast(
                        Intent("com.panime.app.action.CANCEL_DOWNLOAD").putExtra("task_name", name)
                    )
                    DownloadState.clear(name)
                    confirmCancel = null
                },
                onDismiss = { confirmCancel = null }
            )
        }

        confirmDelete?.let { entry ->
            ConfirmDialog(
                title = "Delete ${entry.episode}?",
                sub = entry.title,
                confirmLabel = "DELETE",
                onConfirm = {
                    runCatching {
                        val dir: DocumentFile? =
                            manager.subDir(entry.title, entry.episode, create = false)
                        dir?.listFiles()?.forEach { it.delete() }
                        dir?.delete()
                    }
                    manager.removeDownload(entry.title, entry.episode)
                    refresh()
                    confirmDelete = null
                },
                onDismiss = { confirmDelete = null }
            )
        }
    }
}

/**
 * One active/failed/paused Media3 download. Real pause/resume — the engine
 * keeps partial segments, resume continues from where it stopped.
 */
@Composable
private fun InternalDownloadRow(
    row: com.panime.app.download.DownloadCenter.Row,
    onPauseResume: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(2.dp, Hairline, RoundedCornerShape(12.dp))
            .background(SurfaceRaised)
            .padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(width = 90.dp, height = 60.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(2.dp, Hairline, RoundedCornerShape(8.dp))
                    .background(Color.Black)
            ) {
                row.posterUrl?.let {
                    AsyncImage(
                        it,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                row.quality?.let { q ->
                    Text(
                        q.uppercase(),
                        color = Color.White,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 8.sp,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(4.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color.Black.copy(alpha = 0.85f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    row.title,
                    color = TextPrimary,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    lineHeight = 17.sp
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    row.episodeLabel,
                    color = Flame,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                if (row.bytesDownloaded > 0) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        fmtBytes(row.bytesDownloaded),
                        color = TextMuted,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 10.sp
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (row.stateLabel == "FAILED") {
                    Icon(
                        Icons.Default.Refresh,
                        contentDescription = "Retry",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp).clickable(onClick = onRetry)
                    )
                } else {
                    Icon(
                        if (row.stateLabel == "PAUSED") Icons.Outlined.PlayArrow else Icons.Outlined.Pause,
                        contentDescription = if (row.stateLabel == "PAUSED") "Resume" else "Pause",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp).clickable(onClick = onPauseResume)
                    )
                }
                Icon(
                    Icons.Outlined.Delete,
                    contentDescription = "Cancel download",
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp).clickable(onClick = onCancel)
                )
            }
        }

        if (row.lastError != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                row.lastError.take(90),
                color = Flame,
                fontFamily = PlexMono,
                fontSize = 10.sp
            )
        } else {
            Spacer(Modifier.height(6.dp))
            val dashColor = Hairline.copy(alpha = 0.45f)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .drawBehind {
                        drawLine(
                            dashColor,
                            Offset(0f, size.height / 2),
                            Offset(size.width, size.height / 2),
                            strokeWidth = 2f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))
                        )
                    }
            )
            Spacer(Modifier.height(3.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val statusColor =
                    if (row.stateLabel in listOf("FAILED", "PAUSED", "WAITING_NETWORK")) TextMuted else Flame
                Text(
                    when (row.stateLabel) {
                        "DOWNLOADING" -> "DOWNLOADING" +
                            (row.serverLabel?.let { " • $it" } ?: "")
                        else -> row.stateLabel
                    },
                    color = statusColor,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                Text(
                    "${row.percent.toInt()}%",
                    color = Flame,
                    fontFamily = PlexMono,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
            Spacer(Modifier.height(3.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .border(2.dp, Hairline, RoundedCornerShape(4.dp))
                    .background(Background)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(row.percent / 100f)
                        .height(8.dp)
                        .background(Flame)
                )
            }
        }
    }
}

@Composable
private fun ConfirmDialog(
    title: String,
    sub: String,
    confirmLabel: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Background.copy(alpha = 0.65f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(2.dp, Hairline, RoundedCornerShape(12.dp))
                .background(SurfaceRaised)
                .clickable { }
                .padding(16.dp)
        ) {
            Text(
                title,
                color = TextPrimary,
                fontFamily = Bricolage,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(Modifier.height(4.dp))
            Text(
                sub,
                color = TextMuted,
                fontFamily = PlexMono,
                fontSize = 11.sp
            )
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(SharpCorner)
                        .border(2.dp, Hairline, SharpCorner)
                        .background(Surface)
                        .clickable(onClick = onDismiss)
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "KEEP IT",
                        color = TextMuted,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(SharpCorner)
                        .background(Flame)
                        .clickable(onClick = onConfirm)
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        confirmLabel,
                        color = Background,
                        fontFamily = PlexMono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}
