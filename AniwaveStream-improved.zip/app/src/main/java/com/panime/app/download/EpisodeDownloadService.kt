package com.panime.app.download

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.scheduler.PlatformScheduler
import androidx.media3.exoplayer.scheduler.Requirements
import androidx.media3.exoplayer.scheduler.Scheduler
import com.panime.app.MainActivity
import com.panime.app.player.PlayerModule
import kotlinx.coroutines.DelicateCoroutinesApi
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Self-contained Media3 download engine. Replaces the external Dantotsu FFmpeg
 * addon: segments are fetched by [DownloadManager] through the header-injecting
 * upstream factory, stored in a persistent never-evicted cache, and played back
 * offline by [PlayerModule.buildOfflineMediaSource].
 *
 * Reliability model (replaces the old 10-minute stall watchdog):
 *  - Segment-level retries inside Media3 (minRetryCount).
 *  - Download-level supervised retries with backoff for transient errors.
 *  - Expired-URL recovery: 401/403/404/410 triggers the provider resolver for
 *    a FRESH url while keeping id + customCacheKey (cached segments survive).
 *  - Network loss handled natively via [Requirements] — tasks wait and auto
 *    resume when connectivity returns ("Waiting for network" in the UI).
 *
 * REAL pause: DownloadManager.setStopReason stops the transfer mid-flight and
 * retains all partial spans; resume clears the stop reason and continues.
 */
@UnstableApi
class EpisodeDownloadService : DownloadService(
    FOREGROUND_NOTIFICATION_ID,
    /* foregroundNotificationUpdateIntervalMs = */ 1000,
    CHANNEL_ID,
    /* channelNameResourceId = */ android.R.string.dialog_alert_title,
    /* channelDescriptionResourceId = */ android.R.string.dialog_alert_title
) {

    override fun getDownloadManager(): DownloadManager = provideManager(this)

    override fun getScheduler(): Scheduler? =
        PlatformScheduler(this, JOB_ID)

    override fun getForegroundNotification(
        downloads: MutableList<Download>,
        notMetRequirements: Int
    ): Notification {
        val contentIntent = runCatching {
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }.getOrNull()
        return DownloadNotificationHelper(this, CHANNEL_ID).buildProgressNotification(
            this,
            android.R.drawable.stat_sys_download,
            contentIntent,
            null, // default "Downloading" message
            downloads,
            notMetRequirements
        )
    }

    companion object {
        const val CHANNEL_ID = "episode_downloads"
        const val FOREGROUND_NOTIFICATION_ID = 4301
        private const val JOB_ID = 4302

        /** User-initiated pause stop reason (app-specific, non-zero). */
        const val STOP_REASON_USER_PAUSE = 1

        @Volatile
        private var manager: DownloadManager? = null

        private val retryExecutor: ScheduledExecutorService =
            Executors.newSingleThreadScheduledExecutor { r ->
                Thread(r, "dl-retry-supervisor").apply { isDaemon = true }
            }

        private val ioExecutor = Executors.newSingleThreadExecutor { r ->
            Thread(r, "dl-subs").apply { isDaemon = true }
        }

        private val http = OkHttpClient.Builder()
            .connectTimeout(java.time.Duration.ofSeconds(20))
            .readTimeout(java.time.Duration.ofSeconds(30))
            .build()

        // ── Manager singleton ────────────────────────────────────────────

        @Synchronized
        private fun provideManager(context: Context): DownloadManager {
            manager?.let { return it }
            val appContext = context.applicationContext
            // Custom downloader factory: media3's default one builds its own
            // CacheDataSource WITHOUT our query-stripping key factory, which
            // offline playback relies on for cache identity (HLS/DASH).
            val downloaderFactory = androidx.media3.exoplayer.offline.DefaultDownloaderFactory(
                PlayerModule.downloadCacheDataSourceFactory(appContext),
                Runnable::run
            )
            val mgr = DownloadManager(
                appContext,
                androidx.media3.exoplayer.offline.DefaultDownloadIndex(
                    PlayerModule.sharedDatabaseProvider(appContext)
                ),
                downloaderFactory
            ).apply {
                maxParallelDownloads = 1 // required by the header registry's active-id model
                minRetryCount = 3
                requirements = Requirements(Requirements.NETWORK) // any connection is fine
                addListener(supervisorListener(appContext))
            }
            manager = mgr
            return mgr
        }

        fun currentManager(): DownloadManager? = manager

        /** Used by UI to enumerate without starting the service. */
        fun ensureStarted(context: Context) {
            provideManager(context.applicationContext)
        }

        private fun supervisorListener(appContext: Context) = object : DownloadManager.Listener {
            override fun onDownloadChanged(dm: DownloadManager, download: Download, e: Exception?) {
                val id = download.request.id
                when (download.state) {
                    Download.STATE_DOWNLOADING -> {
                        DownloadHeaderRegistry.activeId = id
                        // Recovered and transferring again: drop the stale
                        // refresh/retry line so the UI shows real progress.
                        EpisodeDownloadStore.setLastError(appContext, id, null)
                    }

                    Download.STATE_FAILED -> onFailed(appContext, download, e)

                    Download.STATE_COMPLETED -> {
                        clearRetryCounters(appContext, id)
                        EpisodeDownloadStore.setCompletedAt(appContext, id)
                        EpisodeDownloadStore.setLastError(appContext, id, null)
                        fetchSubtitlesAsync(appContext, download.request)
                    }
                }
            }
        }

        // ── Failure handling / expired-URL recovery ──────────────────────

        private fun onFailed(context: Context, download: Download, e: Exception?) {
            val id = download.request.id
            val c = counters(context, id)
            val decision = DownloadRetryPolicy.decide(e, c.transientFailures, c.refreshAttempts)
            when (decision.kind) {
                DownloadRetryPolicy.Kind.RETRY_SAME_URL -> {
                    bumpTransient(context, id)
                    EpisodeDownloadStore.setLastError(context, id, "Retrying (${e?.message?.take(90)})")
                    retryExecutor.schedule({
                        runCatching { sendAddDownload(context, EpisodeDownloadService::class.java, download.request, false) }
                    }, decision.delayMs, TimeUnit.MILLISECONDS)
                }

                DownloadRetryPolicy.Kind.REFRESH_URL -> {
                    EpisodeDownloadStore.setLastError(context, id, "Stream link expired — refreshing…")
                    retryExecutor.execute {
                        val meta = EpisodeDownloadMeta.decode(readStoredData(context, id))
                        var refreshed: DownloadRequest? = null
                        var refreshedUrl: String? = null
                        var freshHeaders: Map<String, String>? = null
                        if (meta != null) {
                            runCatching {
                                val fresh = kotlinx.coroutines.runBlocking {
                                    com.panime.app.download.DownloadHelper.resolveFreshStream(meta)
                                }
                                if (!fresh?.url.isNullOrBlank()) {
                                    refreshedUrl = fresh!!.url
                                    freshHeaders = com.panime.app.download.DownloadHelper.headersFor(fresh)
                                    refreshed = meta.copy(
                                        streamUrl = refreshedUrl!!,
                                        headers = freshHeaders ?: emptyMap()
                                    ).toDownloadRequest()
                                }
                            }
                        }
                        if (refreshed != null) {
                            bumpRefresh(context, id)
                            // Re-assert the stable cache identity with the NEW manifest
                            // URL (whose path may have rotated) so segments still
                            // resolve to the same episode cache namespace — resume, not
                            // restart. Must run BEFORE enqueuing the refreshed request.
                            refreshedUrl?.takeIf { it.isNotBlank() }
                                ?.let { DownloadCacheRegistry.register(context, it, id) }
                            // Use the FRESH resolution's headers: a refreshed URL may
                            // come from a different server/CDN whose Referer differs
                            // from the expired one — keeping the stale headers would
                            // 403 again and loop until GIVE_UP.
                            DownloadHeaderRegistry.put(
                                context, id,
                                freshHeaders ?: meta?.headers ?: emptyMap()
                            )
                            DownloadHeaderRegistry.activeId = id
                            sendAddDownload(context, EpisodeDownloadService::class.java, refreshed!!, false)
                        } else if (c.refreshAttempts + 1 >= DownloadRetryPolicy.MAX_REFRESH_ATTEMPTS ||
                            meta == null
                        ) {
                            EpisodeDownloadStore.setLastError(
                                context, id,
                                "Failed: ${e?.message ?: "stream unavailable"}"
                            )
                        } else {
                            // Resolver temporarily down — retry same url later.
                            bumpTransient(context, id)
                            retryExecutor.schedule({
                                runCatching {
                                    sendAddDownload(context, EpisodeDownloadService::class.java, download.request, false)
                                }
                            }, 60_000L, TimeUnit.MILLISECONDS)
                        }
                    }
                }

                DownloadRetryPolicy.Kind.GIVE_UP -> {
                    EpisodeDownloadStore.setLastError(
                        context, id,
                        e?.message ?: "Download failed"
                    )
                }
            }
        }

        // ── Retry counters (persisted so process death doesn't reset caps) ──

        private const val RETRY_PREFS = "dl_retry"

        data class Counters(val transientFailures: Int, val refreshAttempts: Int)

        private fun counters(context: Context, id: String): Counters = runCatching {
            val o = JSONObject(
                context.getSharedPreferences(RETRY_PREFS, Context.MODE_PRIVATE)
                    .getString(id, "{}") ?: "{}"
            )
            Counters(o.optInt("t", 0), o.optInt("r", 0))
        }.getOrDefault(Counters(0, 0))

        private fun bumpTransient(context: Context, id: String) = runCatching {
            val p = context.getSharedPreferences(RETRY_PREFS, Context.MODE_PRIVATE)
            val c = counters(context, id)
            p.edit().putString(id, JSONObject().put("t", c.transientFailures + 1).put("r", c.refreshAttempts).toString()).apply()
        }

        private fun bumpRefresh(context: Context, id: String) = runCatching {
            val p = context.getSharedPreferences(RETRY_PREFS, Context.MODE_PRIVATE)
            val c = counters(context, id)
            p.edit().putString(id, JSONObject().put("t", 0).put("r", c.refreshAttempts + 1).toString()).apply()
        }

        private fun clearRetryCounters(context: Context, id: String) {
            context.getSharedPreferences(RETRY_PREFS, Context.MODE_PRIVATE).edit().remove(id).apply()
        }

        fun retryCounters(context: Context, id: String): Counters = counters(context, id)

        /** Raw request.data bytes straight from Media3's persistent index. */
        fun readStoredData(context: Context, id: String): ByteArray? = try {
            provideManager(context).downloadIndex.getDownload(id)?.request?.data
        } catch (_: Exception) {
            null
        }

        // ── Subtitle sidecars (soft subs preserved without MKV muxing) ───

        @OptIn(DelicateCoroutinesApi::class)
        private fun fetchSubtitlesAsync(context: Context, request: DownloadRequest) {
            val meta = EpisodeDownloadMeta.decode(request.data) ?: return
            if (meta.subtitles.isEmpty()) return
            ioExecutor.execute {
                val dir = File(File(context.filesDir, "download_subs"), meta.id).apply { mkdirs() }
                val saved = JSONArray()
                meta.subtitles.forEachIndexed { i, (lang, label, url) ->
                    val ext = when {
                        url.substringBefore('?').endsWith(".ass") -> "ass"
                        url.substringBefore('?').endsWith(".ssa") -> "ass"
                        url.substringBefore('?').endsWith(".vtt") -> "vtt"
                        else -> "srt"
                    }
                    val out = File(dir, "${i}_${label.replace(Regex("[^A-Za-z0-9]+"), "_")}.$ext")
                    runCatching {
                        val req = Request.Builder().url(url).apply {
                            meta.headers.forEach { (k, v) -> header(k, v) }
                        }.build()
                        http.newCall(req).execute().use { resp ->
                            if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
                            out.writeBytes(resp.body?.bytes() ?: ByteArray(0))
                        }
                        saved.put(
                            JSONObject()
                                .put("path", out.absolutePath)
                                .put("label", label)
                                .put("lang", lang)
                                .put("ext", ext)
                        )
                    }.onFailure {
                        // A missing sidecar never blocks playback (documented limitation).
                        android.util.Log.w("EpisodeDlService", "subtitle fetch failed: ${it.message}")
                    }
                }
                if (saved.length() > 0) {
                    context.getSharedPreferences("dl_subs", Context.MODE_PRIVATE)
                        .edit().putString(meta.id, saved.toString()).apply()
                }
            }
        }

        /** Local subtitle files recorded for a finished download (may be empty). */
        fun localSubtitles(context: Context, id: String): List<File> = runCatching {
            val arr = JSONArray(
                context.getSharedPreferences("dl_subs", Context.MODE_PRIVATE)
                    .getString(id, "[]") ?: "[]"
            )
            (0 until arr.length()).mapNotNull { i ->
                arr.optJSONObject(i)?.optString("path")?.let(::File)?.takeIf { it.exists() }
            }
        }.getOrDefault(emptyList())

        /**
         * Subtitle tracks ready for offline playback — original lang/label,
         * backed by local sidecar files (no network needed).
         */
        fun localSubtitleTracks(
            context: Context,
            id: String
        ): List<com.panime.app.data.api.AniwavesApi.SubtitleTrack> = runCatching {
            val arr = JSONArray(
                context.getSharedPreferences("dl_subs", Context.MODE_PRIVATE)
                    .getString(id, "[]") ?: "[]"
            )
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val f = o.optString("path").let(::File).takeIf { it.exists() && it.length() > 0 }
                    ?: return@mapNotNull null
                com.panime.app.data.api.AniwavesApi.SubtitleTrack(
                    lang = o.optString("lang", "eng"),
                    label = o.optString("label", "Subtitle ${i + 1}"),
                    url = f.absolutePath
                )
            }
        }.getOrDefault(emptyList())

        fun deleteSubtitles(context: Context, id: String) {
            runCatching {
                File(context.filesDir, "download_subs/$id").deleteRecursively()
                context.getSharedPreferences("dl_subs", Context.MODE_PRIVATE).edit().remove(id).apply()
            }
        }
    }
}
