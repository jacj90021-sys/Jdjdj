package com.panime.app.download

import android.content.Context
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import org.json.JSONObject

/**
 * Media3's DownloadRequest carries NO per-request HTTP headers, but our
 * providers REQUIRE them (Referer / Origin / UA per CDN). This registry keeps
 * id -> headers (persisted) and marks the ACTIVE download so the upstream data
 * source can inject the right headers on every request.
 *
 * Safe under DownloadManager's maxParallelDownloads = 1 (enforced in the
 * service); with parallelism >1 headers could cross-apply.
 */
object DownloadHeaderRegistry {

    private const val PREFS = "dl_headers"
    private const val KEY_MAP = "headers_by_id"

    /** Id of the download whose requests are currently in flight. */
    @Volatile
    var activeId: String? = null

    fun put(context: Context, id: String, headers: Map<String, String>) {
        runCatching {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val map = JSONObject(p.getString(KEY_MAP, "{}") ?: "{}")
            map.put(id, JSONObject().apply { headers.forEach { (k, v) -> put(k, v) } })
            p.edit().putString(KEY_MAP, map.toString()).apply()
        }
    }

    fun get(context: Context, id: String?): Map<String, String> {
        if (id == null) return emptyMap()
        return runCatching {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val map = JSONObject(p.getString(KEY_MAP, "{}") ?: "{}")
            val o = map.optJSONObject(id) ?: return emptyMap()
            buildMap { o.keys().forEach { k -> put(k, o.optString(k)) } }
        }.getOrDefault(emptyMap())
    }

    fun remove(context: Context, id: String) {
        runCatching {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val map = JSONObject(p.getString(KEY_MAP, "{}") ?: "{}")
            map.remove(id)
            p.edit().putString(KEY_MAP, map.toString()).apply()
        }
    }
}

/**
 * Upstream factory for the download cache AND offline playback. Every opened
 * connection gets the active download's provider headers (Referer/Origin/UA).
 */
class HeaderedHttpDataSourceFactory(
    private val context: Context,
    private val userAgent: String = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
) : DataSource.Factory {

    private val innerFactory = DefaultHttpDataSource.Factory()
        .setUserAgent(userAgent)
        .setConnectTimeoutMs(30_000)
        .setReadTimeoutMs(30_000)
        .setAllowCrossProtocolRedirects(true)

    override fun createDataSource(): DataSource =
        HeaderedDataSource(context, innerFactory.createDataSource())

    private class HeaderedDataSource(
        private val context: Context,
        private val upstream: DefaultHttpDataSource
    ) : BaseDataSource(true) {

        override fun open(dataSpec: DataSpec): Long {
            // Inject AFTER clearing: instance is fresh from the factory each
            // transfer, but be explicit so stale provider headers never leak.
            upstream.clearAllRequestProperties()
            // Route headers by the REQUEST's own URL, not a global "active" id:
            // every download's manifest + segments fall under ITS registered
            // base, so each episode gets its own provider headers. This is
            // immune to the races that caused 403 -> "stream link expired —
            // refreshing": a leftover/stale download auto-resumed by Media3 (or
            // a just-enqueued second download) used to flip the single activeId
            // and poison the in-flight episode's Referer.
            val id =
                DownloadCacheRegistry.downloadIdFor(context, dataSpec.uri?.toString() ?: "")
                    ?: DownloadHeaderRegistry.activeId // fallback: unregistered streams
            DownloadHeaderRegistry.get(context, id).forEach { (k, v) ->
                if (!k.equals("User-Agent", true)) upstream.setRequestProperty(k, v)
            }
            return upstream.open(dataSpec)
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int =
            upstream.read(buffer, offset, length)

        override fun close() = try {
            upstream.close()
        } catch (_: Exception) {
        }

        override fun getUri(): android.net.Uri? = upstream.uri
    }
}
