package com.panime.app.data.api

import android.util.Log
import com.panime.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import com.panime.app.data.network.HttpClient
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * MyAnimeList REST API client (https://api.myanimelist.net/v2).
 *
 * Mirrors the AniList integration: list read + write, plus id mapping between
 * AniList media ids (the app's internal list key) and MAL anime ids.
 *
 * Auth note: MAL is a PUBLIC client (no client_secret). The app uses the
 * auth-code + PKCE (plain) flow implemented in OAuthContracts/AniwaveAuthActivity.
 * Every call below takes an explicit bearer [accessToken]; token refresh is
 * handled by SecureTokenStore.validAccessToken.
 */
object MalApi {
    private const val BASE = "https://api.myanimelist.net/v2"
    private const val TAG = "MalApi"

    /**
     * AniList gated the GraphQL API to browser-origin requests during their
     * stability issues (403 "temporarily disabled" otherwise). The MAL id-mapping
     * calls below hit graphql.anilist.co, so they need the same browser disguise:
     * real UA + Origin/Referer from the anilist.co website.
     */
    private fun Request.Builder.browserDisguise(): Request.Builder = apply {
        header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36")
        header("Origin", "https://anilist.co")
        header("Referer", "https://anilist.co/")
    }

    private val client = HttpClient.shared.newBuilder()
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("Accept", "application/json")
                .build()
            chain.proceed(req)
        }
        .build()

    /** Normalized MAL list entry. [malId] is MAL's anime id; [anilistId] is resolved lazily. */
    data class MalListEntry(
        val malId: Int,
        val status: String,        // app status label ("Watching", "Completed", ...)
        val progress: Int,         // episodes watched
        val score: Double?         // 0-10 (null = unrated)
    )

    /** Map MAL status enum -> app status label used by List Editor + filters. */
    fun malStatusToApp(status: String): String = when (status) {
        "watching" -> "Watching"
        "completed" -> "Completed"
        "on_hold" -> "Paused"
        "plan_to_watch" -> "Plan to Watch"
        "dropped" -> "Dropped"
        else -> "Plan to Watch"
    }

    /** Reverse map: app status label -> MAL status enum value. */
    fun appStatusToMal(status: String): String = when (status) {
        "Watching" -> "watching"
        "Completed" -> "completed"
        "Paused" -> "on_hold"
        "Plan to Watch" -> "plan_to_watch"
        "Rewatching" -> "watching"   // MAL has no separate "rewatching" enum; treat as watching
        "Dropped" -> "dropped"
        else -> "plan_to_watch"
    }

    /**
     * Fetch the connected user's full anime list (ALL statuses), paging until
     * exhausted. Requires a valid bearer token.
     * @return list of [MalListEntry] (MAL-id based; resolve to AniList ids via [resolveMalToAnilist]).
     */
    suspend fun fetchUserList(accessToken: String): List<MalListEntry> = withContext(Dispatchers.IO) {
        val out = mutableListOf<MalListEntry>()
        var offset = 0
        val limit = 100
        while (true) {
            val url = "$BASE/users/@me/animelist" +
                "?fields=list_status{status,score,num_episodes_watched}" +
                "&limit=$limit&offset=$offset&nsfw=1"
            val req = Request.Builder().url(url)
                .get()
                .header("Authorization", "Bearer $accessToken")
                .build()
            val text = client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    Log.e(TAG, "fetchUserList HTTP ${resp.code}: ${body.take(400)}")
                    throw RuntimeException("MAL list HTTP ${resp.code}: ${body.take(300)}")
                }
                body
            }
            val root = JSONObject(text)
            val arr = root.optJSONArray("data") ?: break
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) {
                val node = arr.optJSONObject(i)?.optJSONObject("node") ?: continue
                val malId = node.optInt("id", 0)
                if (malId <= 0) continue
                val ls = arr.optJSONObject(i)?.optJSONObject("list_status")
                val status = ls?.optString("status").orEmpty()
                val progress = ls?.optInt("num_episodes_watched", 0) ?: 0
                val rawScore = ls?.optDouble("score", 0.0) ?: 0.0
                val score = if (rawScore > 0.0) rawScore else null
                out += MalListEntry(
                    malId = malId,
                    status = malStatusToApp(status),
                    progress = progress,
                    score = score
                )
            }
            // MAL paging: if we got fewer than `limit`, we're done.
            if (arr.length() < limit) break
            offset += limit
        }
        out
    }

    /**
     * Update a single anime's list entry on MAL (status / progress / score).
     * Uses the MAL anime id — callers must resolve the app's AniList id to a MAL id
     * first (see [resolveAnilistToMal]).
     *
     * @return true if MAL accepted the update.
     * @throws RuntimeException if MAL returns a non-2xx or an error body.
     */
    suspend fun updateListStatus(
        accessToken: String,
        malId: Int,
        status: String,
        progress: Int,
        score: Double?
    ): Boolean = withContext(Dispatchers.IO) {
        if (malId <= 0) return@withContext false
        val form = FormBody.Builder()
            .add("status", appStatusToMal(status))
            .add("num_watched_episodes", progress.toString())
        // MAL score is 0-10 (integers or .0-.5 allowed). Only send when set, like Dantotsu.
        score?.let { form.add("score", "%.1f".format(it)) }
        val req = Request.Builder()
            .url("$BASE/anime/$malId/my_list_status")
            .put(form.build())
            .header("Authorization", "Bearer $accessToken")
            .header("Content-Type", "application/x-www-form-urlencoded")
            .build()
        client.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                Log.e(TAG, "updateListStatus HTTP ${resp.code} for #$malId: ${body.take(400)}")
                throw RuntimeException("MAL update HTTP ${resp.code}: ${body.take(300)}")
            }
            true
        }
    }

    /**
     * Resolve MANY MAL anime ids -> AniList media ids in ONE batched GraphQL request
     * (AniList allows multiple `Media(idMal: X)` fields in a single query). This is
     * far faster than calling [resolveMalToAnilist] once per id (which froze the UI
     * on connect for large lists). Returns a map keyed by MAL id.
     *
     * @param malIds MAL anime ids (duplicates/<=0 are ignored)
     * @param chunk size per request (AniList safely handles ~50)
     */
    suspend fun resolveMalToAnilistBatch(malIds: List<Int>, chunk: Int = 50): Map<Int, Int> = withContext(Dispatchers.IO) {
        val out = mutableMapOf<Int, Int>()
        val unique = malIds.filter { it > 0 }.distinct()
        if (unique.isEmpty()) return@withContext out
        unique.chunked(chunk).forEach { batch ->
            try {
                // Build a query with one `m0: Media(idMal: ID0){id}` ... `mN: Media(idMal: IDN){id}`
                val fields = batch.mapIndexed { i, id ->
                    "m$i: Media(idMal: $id, type: ANIME) { id idMal }"
                }.joinToString("\n")
                val q = "query Batch {\n$fields\n}"
                val payload = JSONObject().put("query", q).toString()
                val req = Request.Builder()
                    .url("https://graphql.anilist.co")
                    .post(payload.toRequestBody("application/json".toMediaType()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .browserDisguise()
                    .build()
                client.newCall(req).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        if (BuildConfig.DEBUG) {
                            Log.w(TAG, "resolveMalToAnilistBatch HTTP ${resp.code}: ${body.take(200)}")
                        }
                        return@use
                    }
                    val data = JSONObject(body).optJSONObject("data") ?: return@use
                    for (i in batch.indices) {
                        val node = data.optJSONObject("m$i") ?: continue
                        val anilistId = node.optInt("id", 0)
                        val malId = node.optInt("idMal", 0)
                        if (anilistId > 0 && malId > 0) out[malId] = anilistId
                    }
                }
            } catch (e: Throwable) {
                Log.w(TAG, "resolveMalToAnilistBatch failed for chunk: ${e.message}")
            }
        }
        out
    }

    /**
     * Resolve a single MAL anime id -> AniList media id via AniList's `Media(idMal: X)`
     * query. Returns null if no mapping exists (anime not on AniList — extremely rare).
     * Prefer [resolveMalToAnilistBatch] for many ids (one request instead of N).
     */
    suspend fun resolveMalToAnilist(malId: Int): Int? = withContext(Dispatchers.IO) {
        if (malId <= 0) return@withContext null
        try {
            val q = """query Resolve(${"$"}id: Int) { Media(idMal: ${"$"}id, type: ANIME) { id } }"""
            val vars = JSONObject().put("id", malId).toString()
            val req = Request.Builder()
                .url("https://graphql.anilist.co")
                .post(
                    JSONObject().put("query", q).put("variables", JSONObject(vars))
                        .toString().toRequestBody("application/json".toMediaType())
                )
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .browserDisguise()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    if (BuildConfig.DEBUG) {
                        Log.w(TAG, "resolveMalToAnilist HTTP ${resp.code} for #$malId: ${body.take(200)}")
                    }
                    return@withContext null
                }
                JSONObject(body).optJSONObject("data")
                    ?.optJSONObject("Media")
                    ?.optInt("id", 0)
                    ?.takeIf { it > 0 }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "resolveMalToAnilist failed for #$malId: ${e.message}")
            null
        }
    }

    /**
     * Resolve an AniList media id -> MAL anime id via AniList's `Media(id: X)` query
     * (reads the `idMal` field). Returns null if the anime has no MAL mapping.
     */
    suspend fun resolveAnilistToMal(anilistId: Int): Int? = withContext(Dispatchers.IO) {
        if (anilistId <= 0) return@withContext null
        try {
            val q = """query Resolve(${"$"}id: Int) { Media(id: ${"$"}id, type: ANIME) { idMal } }"""
            val vars = JSONObject().put("id", anilistId).toString()
            val req = Request.Builder()
                .url("https://graphql.anilist.co")
                .post(
                    JSONObject().put("query", q).put("variables", JSONObject(vars))
                        .toString().toRequestBody("application/json".toMediaType())
                )
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .browserDisguise()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    if (BuildConfig.DEBUG) {
                        Log.w(TAG, "resolveAnilistToMal HTTP ${resp.code} for #$anilistId: ${body.take(200)}")
                    }
                    return@withContext null
                }
                JSONObject(body).optJSONObject("data")
                    ?.optJSONObject("Media")
                    ?.optInt("idMal", 0)
                    ?.takeIf { it > 0 }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "resolveAnilistToMal failed for #$anilistId: ${e.message}")
            null
        }
    }
}
