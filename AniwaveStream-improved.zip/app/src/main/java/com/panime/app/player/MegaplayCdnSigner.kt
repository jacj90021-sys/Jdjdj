package com.panime.app.player

import java.net.URLEncoder
import java.util.Base64
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Mirrors megaplay's `e1-player.min.js` CDN token signing so the app can play
 * streams the site now serves behind a signed-URL gate.
 *
 * The master playlist URL always contains a path key of the form
 * `/{32hex}/{32hex}/`. The player builds a token as
 *
 *     msg = String(currentUnixSeconds + 90) + "|" + pathKey   // pathKey is lowercased
 *     sig = HMAC_SHA256(key = "MpCdnT0k3n!9f2K#xQ7vL5mR8wN1pY4s", msg)
 *     token = base64url(msg) + "." + base64url(sig)
 *
 * and appends it as `?token=...` (or `&token=...`) to the URL.
 *
 * A URL that already carries a token, or whose path has no 32-hex key, is
 * returned unchanged (the site skips signing for both).
 */
object MegaplayCdnSigner {

    private const val TOKEN_KEY = "MpCdnT0k3n!9f2K#xQ7vL5mR8wN1pY4s"
    private const val TOKEN_TTL_SECONDS = 90L

    private val PATH_KEY_RE = Regex("/([a-f0-9]{32})/([a-f0-9]{32})/", RegexOption.IGNORE_CASE)
    private val HAS_TOKEN_RE = Regex("[?&]token=")

    fun signed(rawUrl: String): String {
        if (HAS_TOKEN_RE.containsMatchIn(rawUrl)) return rawUrl
        val keyMatch = PATH_KEY_RE.find(rawUrl) ?: return rawUrl
        val pathKey = keyMatch.groupValues[1].lowercase() + "/" + keyMatch.groupValues[2].lowercase()
        val unix = System.currentTimeMillis() / 1000 + TOKEN_TTL_SECONDS
        val msg = "$unix|$pathKey"
        val msgBytes = msg.toByteArray(Charsets.UTF_8)

        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(TOKEN_KEY.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val sigBytes = mac.doFinal(msgBytes)

        val encoder = Base64.getUrlEncoder().withoutPadding()
        val token = encoder.encodeToString(msgBytes) + "." + encoder.encodeToString(sigBytes)
        val sep = if (rawUrl.contains('?')) "&" else "?"
        return rawUrl + sep + "token=" + URLEncoder.encode(token, Charsets.UTF_8.name())
    }
}