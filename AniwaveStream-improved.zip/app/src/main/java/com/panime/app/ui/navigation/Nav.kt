package com.panime.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.data.repository.UserLibraryStore
import com.panime.app.ui.browse.BrowseScreen
import com.panime.app.ui.detail.DetailScreen
import com.panime.app.ui.home.HomeScreen
import com.panime.app.ui.home.SeeAllKind
import com.panime.app.ui.home.SeeAllScreen
import com.panime.app.ui.home.WeeklyScheduleScreen
import com.panime.app.ui.mylist.MyListScreen
import com.panime.app.ui.player.PlayerScreen
import com.panime.app.ui.profile.ProfileScreen
import com.panime.app.ui.search.SearchScreen
import com.panime.app.ui.theme.AniwaveColors
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.HalftoneTexture
import com.panime.app.ui.theme.OrangePrimary
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.TextMuted
import com.panime.app.viewmodel.HomeViewModel
import com.panime.app.viewmodel.LibraryViewModel
import com.panime.app.viewmodel.SeeAllViewModel

sealed class Route(val path: String) {
    data object Home : Route("home")
    data object Browse : Route("browse")
    data object Search : Route("search")
    data object MyList : Route("mylist")
    data object Profile : Route("profile")
    data object Detail : Route("detail/{id}") {
        fun create(id: Int) = "detail/$id"
    }
    data object Player : Route("player/{id}/{ep}?offline={offline}&uri={uri}&title={title}&dl={dl}") {
        fun create(id: Int, ep: Int) = "player/$id/$ep"
        fun createOffline(id: Int, ep: Int, uri: String, title: String): String =
            "player/$id/$ep?offline=1&uri=${android.net.Uri.encode(uri)}" +
                "&title=${android.net.Uri.encode(title)}"
        fun createDownloaded(id: Int, ep: Int, downloadId: String): String =
            "player/$id/$ep?dl=${android.net.Uri.encode(downloadId)}"
    }
    data object SeeAll : Route("seeall/{kind}") {
        fun create(kind: String) = "seeall/$kind"
    }
    data object WeeklySchedule : Route("weekly")
}

private data class Tab(
    val route: String,
    val label: String,
    val selected: ImageVector,
    val unselected: ImageVector
)

private val tabs = listOf(
    Tab(Route.Home.path, "Home", Icons.Filled.Home, Icons.Outlined.Home),
    Tab(Route.Browse.path, "Browse", Icons.Filled.GridView, Icons.Outlined.GridView),
    Tab(Route.Search.path, "Search", Icons.Filled.Search, Icons.Outlined.Search),
    Tab(Route.MyList.path, "My List", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary),
    Tab(Route.Profile.path, "Profile", Icons.Filled.Person, Icons.Outlined.Person)
)

// Tab switch transitions: quick fade-only so the outgoing tab never lingers
// or slides over the incoming one (the default nav crossfade overlaps both
// screens during the switch — the "previous tab still visible" bug). Pure
// fades keep each tab opaque and house the switch cleanly.
private val tabsEnter: AnimatedContentTransitionScope<NavBackStackEntry>.() -> EnterTransition = {
    fadeIn(animationSpec = tween(200))
}
private val tabsExit: AnimatedContentTransitionScope<NavBackStackEntry>.() -> ExitTransition = {
    fadeOut(animationSpec = tween(180))
}

/**
 * Reddit-style hide/show for the shared bottom tab, driven by the scrolling
 * feeds of the Home / Browse / Search / My List tabs (Profile stays static).
 * translationY only (never GONE): 0 = visible, height = hidden.
 *
 * Compose nested-scroll: swipe up / deeper into the feed → dy < 0 → hide
 * (increase translationY). Swipe down / toward the top → dy > 0 → show.
 */
private class HomeFeedBarControl(
    private val scope: CoroutineScope,
    private val heightPx: () -> Float,
    private val thresholdPx: Float
) {
    val offset = Animatable(0f)
    private var hideAccum = 0f

    /**
     * Restore the bar to fully visible. Must be called from a coroutine (e.g.
     * directly inside a LaunchedEffect) so the stop/snap run deterministically
     * — never through an extra scope.launch hop that could race a scroll event.
     */
    suspend fun snapVisible() {
        offset.stop()
        offset.snapTo(0f)
        hideAccum = 0f
    }

    private fun follow(targetRaw: Float) {
        val h = heightPx()
        if (h <= 0f) return
        val target = targetRaw.coerceIn(0f, h)
        if (target == offset.value) return
        scope.launch {
            offset.stop()
            offset.snapTo(target)
        }
    }

    private fun animateTo(targetRaw: Float) {
        val h = heightPx()
        if (h <= 0f) return
        val target = targetRaw.coerceIn(0f, h)
        if (target == offset.value) return
        scope.launch {
            offset.stop()
            offset.animateTo(target, tween(220, easing = FastOutSlowInEasing))
        }
    }

    val connection = object : NestedScrollConnection {
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
            val h = heightPx()
            if (h <= 0f) return Offset.Zero
            val dy = available.y
            if (dy == 0f) return Offset.Zero
            // offset -= dy: deeper (dy<0) hides; toward top (dy>0) shows.
            if (dy > 0f) {
                hideAccum = 0f
                follow(offset.value - dy)
                return Offset.Zero
            }
            if (offset.value == 0f && !offset.isRunning) {
                hideAccum -= dy
                if (hideAccum < thresholdPx) return Offset.Zero
            } else {
                hideAccum = thresholdPx
            }
            follow(offset.value - dy)
            return Offset.Zero
        }

        override fun onPostScroll(
            consumed: Offset,
            available: Offset,
            source: NestedScrollSource
        ): Offset {
            // Unconsumed downward overscroll at the top of the feed → bar visible.
            if (available.y > 0f && offset.value != 0f) animateTo(0f)
            return Offset.Zero
        }

        override suspend fun onPreFling(available: Velocity): Velocity {
            val h = heightPx()
            if (h <= 0f) return Velocity.Zero
            val v = available.y
            val settled = when {
                v < -500f -> h
                v > 500f -> 0f
                else -> if (offset.value > h / 2f) h else 0f
            }
            animateTo(settled)
            return Velocity.Zero
        }
    }
}

@Composable
fun AniwaveNavHost(
    repository: AnimeRepository,
    library: UserLibraryStore
) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    val showBar = tabs.any { it.route == current }
    // Route pattern is "player/{id}/{ep}" while the back-stack route string may be
    // either the pattern or a concrete "player/123/4" depending on Nav version.
    val isPlayer = current?.startsWith("player") == true

    val homeVm: HomeViewModel = viewModel(
        factory = HomeViewModel.factory(repository, library)
    )
    val libraryVm: LibraryViewModel = viewModel(
        factory = LibraryViewModel.factory(
            repository,
            library,
            (LocalContext.current.applicationContext as com.panime.app.AniwaveApp).tokenStore
        )
    )

    // Analytics — one screen_view per route change (Crashlytics auto-logs)
    val analyticsCtx = LocalContext.current
    LaunchedEffect(current) {
        runCatching {
            val fa = com.google.firebase.analytics.FirebaseAnalytics.getInstance(analyticsCtx)
            val bundle = android.os.Bundle().apply { putString(com.google.firebase.analytics.FirebaseAnalytics.Param.SCREEN_NAME, current ?: Route.Home.path) }
            fa.logEvent(com.google.firebase.analytics.FirebaseAnalytics.Event.SCREEN_VIEW, bundle)
        }
    }

    fun openDetail(id: Int) = nav.navigate(Route.Detail.create(id))
    fun openPlayer(id: Int, ep: Int) = nav.navigate(Route.Player.create(id, ep))

    // ONE overlay bar. Hide/show is driven by HomeFeedBarControl attached to
    // the Home / Browse / Search / My List destinations. Profile never moves it.
    val density = LocalDensity.current
    val barScope = rememberCoroutineScope()
    var barHeightPx by remember { mutableFloatStateOf(0f) }
    val homeBar = remember {
        HomeFeedBarControl(
            scope = barScope,
            heightPx = { barHeightPx },
            thresholdPx = with(density) { 12.dp.toPx() }
        )
    }
    // Every time we land on a tab (or the bar's visibility changes), the bar
    // MUST start fully visible. Keying on (current, showBar) and snapping
    // directly guarantees a hidden offset from a previous tab can never carry
    // over — e.g. Profile, which must always show the bar.
    LaunchedEffect(current, showBar) {
        if (showBar) homeBar.snapVisible()
    }

    Box(Modifier.fillMaxSize()) {
    Scaffold(
        // Player must sit on black — paper/Background is off-white and peeks as a
        // white edge during episode transitions if the container stays light.
        containerColor = if (isPlayer) Color.Black else Background
    ) { padding ->
        // Single NavHost. Chrome screens get paper + halftone; player gets solid
        // black so episode swaps never flash the off-white paper on left/edges.
        // Auto-hide tabs (Home/Browse/Search/My List): only the system inset —
        // content flows under the overlay so hide is pure translation. Other
        // chrome screens: reserve the measured bar height (64dp row + system
        // inset already included) so content is not covered.
        val layoutDir = LocalLayoutDirection.current
        val bottomInsetDp =
            (WindowInsets.navigationBars.getBottom(density) / density.density).dp
        // Tabs with the Home-style auto-hide bar: content flows under the overlay
        // so hide/show is pure translation. Profile keeps the bar pinned (static).
        val barHides = current in setOf(
            Route.Home.path,
            Route.Browse.path,
            Route.Search.path,
            Route.MyList.path
        )
        val contentBottomPad = when {
            isPlayer -> 0.dp
            barHides -> bottomInsetDp
            showBar && barHeightPx > 0f -> (barHeightPx / density.density).dp
            showBar -> 64.dp + bottomInsetDp
            else -> bottomInsetDp
        }
        Box(
            Modifier
                .fillMaxSize()
                .padding(
                    top = padding.calculateTopPadding(),
                    bottom = contentBottomPad,
                    start = padding.calculateLeftPadding(layoutDir),
                    end = padding.calculateRightPadding(layoutDir)
                )
                .background(if (isPlayer) Color.Black else Background)
        ) {
            if (!isPlayer) {
                HalftoneTexture(
                    modifier = Modifier.align(Alignment.TopEnd),
                    size = 260.dp,
                    opacity = if (AniwaveColors.isDark) 0.08f else 0.13f
                )
            }
            NavHost(
                navController = nav,
                startDestination = Route.Home.path,
                modifier = Modifier.fillMaxWidth()
            ) {
                composable(
                    Route.Home.path,
                    enterTransition = tabsEnter,
                    exitTransition = tabsExit,
                    popEnterTransition = tabsEnter,
                    popExitTransition = tabsExit
                ) {
                    Box(Modifier.nestedScroll(homeBar.connection)) {
                        HomeScreen(
                            viewModel = homeVm,
                            onAnimeClick = { openDetail(it.id) },
                            onPlay = { openPlayer(it.id, 1) },
                            onContinue = { anime, ep -> openPlayer(anime.id, ep) },
                            onViewAll = { kind -> nav.navigate(Route.SeeAll.create(kind.name)) },
                            onViewSchedule = { nav.navigate(Route.WeeklySchedule.path) },
                            library = library
                        )
                    }
                }
                composable(
                    Route.SeeAll.path,
                    arguments = listOf(navArgument("kind") { type = NavType.StringType })
                ) { entry ->
                    val kindName = entry.arguments?.getString("kind") ?: SeeAllKind.TRENDING.name
                    val kind = SeeAllKind.entries.firstOrNull { it.name == kindName } ?: SeeAllKind.TRENDING
                    val seeAllVm: SeeAllViewModel = viewModel(factory = SeeAllViewModel.factory(repository))
                    val apiProvider by library.apiProvider.collectAsStateWithLifecycle("anilist")
                    SeeAllScreen(
                        kind = kind,
                        viewModel = seeAllVm,
                        homeViewModel = homeVm,
                        apiProvider = apiProvider,
                        onAnimeClick = { openDetail(it.id) },
                        onBack = { nav.popBackStack() }
                    )
                }
                composable(Route.WeeklySchedule.path) {
                    WeeklyScheduleScreen(
                        repository = repository,
                        onAnimeClick = { openDetail(it.id) },
                        onBack = { nav.popBackStack() }
                    )
                }
                composable(
                    Route.Browse.path,
                    enterTransition = tabsEnter,
                    exitTransition = tabsExit,
                    popEnterTransition = tabsEnter,
                    popExitTransition = tabsExit
                ) {
                    Box(Modifier.nestedScroll(homeBar.connection)) {
                        BrowseScreen(
                            repository = repository,
                            library = library,
                            onAnimeClick = { openDetail(it.id) }
                        )
                    }
                }
                composable(
                    Route.Search.path,
                    enterTransition = tabsEnter,
                    exitTransition = tabsExit,
                    popEnterTransition = tabsEnter,
                    popExitTransition = tabsExit
                ) {
                    Box(Modifier.nestedScroll(homeBar.connection)) {
                        SearchScreen(
                            repository = repository,
                            library = library,
                            onAnimeClick = { openDetail(it.id) }
                        )
                    }
                }
                composable(
                    Route.MyList.path,
                    enterTransition = tabsEnter,
                    exitTransition = tabsExit,
                    popEnterTransition = tabsEnter,
                    popExitTransition = tabsExit
                ) {
                    Box(Modifier.nestedScroll(homeBar.connection)) {
                        MyListScreen(
                            viewModel = libraryVm,
                            onAnimeClick = { openDetail(it.id) },
                            onPlayOffline = { id, ep, uri, title ->
                                nav.navigate(Route.Player.createOffline(id, ep, uri, title))
                            },
                            onPlayDownloaded = { id, ep, dlId, _ ->
                                nav.navigate(Route.Player.createDownloaded(id, ep, dlId))
                            }
                        )
                    }
                }
                composable(
                    Route.Profile.path,
                    enterTransition = tabsEnter,
                    exitTransition = tabsExit,
                    popEnterTransition = tabsEnter,
                    popExitTransition = tabsExit
                ) {
                    ProfileScreen(
                        library = library,
                        onBack = { nav.popBackStack() },
                        onSignedOut = {
                            nav.popBackStack()
                        }
                    )
                }
                composable(
                    Route.Detail.path,
                    arguments = listOf(navArgument("id") { type = NavType.IntType })
                ) { entry ->
                    val id = entry.arguments?.getInt("id") ?: return@composable
                    DetailScreen(
                        animeId = id,
                        repository = repository,
                        library = library,
                        onBack = { nav.popBackStack() },
                        onPlay = { ep -> openPlayer(id, ep) },
                        onRelated = { openDetail(it) }
                    )
                }
                composable(
                    Route.Player.path,
                    arguments = listOf(
                        navArgument("id") { type = NavType.IntType },
                        navArgument("ep") { type = NavType.IntType },
                        navArgument("offline") { type = NavType.StringType; defaultValue = "" },
                        navArgument("uri") { type = NavType.StringType; defaultValue = "" },
                        navArgument("title") { type = NavType.StringType; defaultValue = "" },
                        navArgument("dl") { type = NavType.StringType; defaultValue = "" }
                    )
                ) { entry ->
                    val id = entry.arguments?.getInt("id") ?: return@composable
                    val ep = (entry.arguments?.getInt("ep") ?: 1).coerceAtLeast(1)
                    val offUri = entry.arguments?.getString("uri")
                        ?.takeIf { entry.arguments?.getString("offline") == "1" && it.isNotBlank() }
                    val playerActivity = androidx.compose.ui.platform.LocalContext.current as? android.app.Activity
                    PlayerScreen(
                        animeId = id,
                        episode = ep,
                        repository = repository,
                        library = library,
                        onBack = {
                            if (playerActivity != null && com.panime.app.ad.AdManager.showInterstitial(playerActivity) { nav.popBackStack() }) {
                                // interstitial shown — nav.popBackStack() is in the dismiss callback
                            } else {
                                nav.popBackStack()
                            }
                        },
                        offlineUri = offUri,
                        offlineTitle = entry.arguments?.getString("title"),
                        downloadId = entry.arguments?.getString("dl")?.takeIf { it.isNotBlank() },
                        onEpisodeChange = { next ->
                            nav.navigate(Route.Player.create(id, next)) {
                                popUpTo(Route.Player.create(id, ep)) { inclusive = true }
                            }
                        }
                    )
                }
            }
        }
        }

        if (showBar) {
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .onSizeChanged { barHeightPx = it.height.toFloat() }
                    // Profile pins the bar: force it fully visible regardless of any
                    // leftover hidden offset from a scrolled-down feed tab (race-proof
                    // vs the LaunchedEffect snap — no blank paper gap on Profile).
                    .graphicsLayer {
                        translationY =
                            if (current == Route.Profile.path) 0f else homeBar.offset.value
                    }
                    .background(Surface)
                    .border(2.dp, Hairline, RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp))
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .height(64.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    tabs.forEach { tab ->
                        val selected = current == tab.route
                        val tint = if (selected) OrangePrimary else TextMuted
                        Column(
                            Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable {
                                    nav.navigate(tab.route) {
                                        popUpTo(nav.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                if (selected) tab.selected else tab.unselected,
                                contentDescription = tab.label,
                                tint = tint,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                tab.label,
                                color = tint,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
