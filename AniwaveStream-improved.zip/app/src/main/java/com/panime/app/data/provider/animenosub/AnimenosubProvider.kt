package com.panime.app.data.provider.animenosub

import android.util.Log
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider

/**
 * On-device animenosub.to provider.
 *
 * All three servers are resolvable via HTTP:
 *   Moon  -> bysesayeveum.com (AES-256-GCM decrypt)
 *   Omega -> vidmoly.biz (JWPlayer, plain m3u8)
 *   Nova  -> nova.upn.one (AES-128-CBC decrypt + CDN m3u8)
 */
class AnimenosubProvider : StreamProvider, SearchableProvider {

    override val id = "animenosub"
    override val label = "NOSUB"
    override val backendRequired = false

    // ===================== Wrong-title support (additive) =====================
    // The picker shows EVERY search result — no titleToSlug guessing or
    // best-matching on this path. The user's clicked series slug is used
    // DIRECTLY. The default resolve() flow below is untouched.

    override suspend fun search(query: String): List<StreamProvider.SearchHit> =
        searchPage(query, 1).items

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        // WordPress ?s= search renders one result page; no pagination parsed.
        if (query.isBlank() || page > 1) return PagedResult(emptyList(), 1)
        val cards = AnimenosubApi.searchCards(query.trim())
        return PagedResult(
            cards.map {
                StreamProvider.SearchHit(title = it.title, slug = it.slug, posterUrl = it.posterUrl)
            },
            lastPage = 1
        )
    }

    /**
     * Wrong-title resolution: [slug] is the user's picked series slug, used
     * DIRECTLY — no title guessing, no cross-series fallback. Only the site's
     * own alternate URL spelling for the SAME series is also tried (newest DUB
     * releases of split series are linked as "<sub>-episode-N-english-dub").
     */
    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? {
        // Exact slug from the series page's own episode links first (handles
        // every spelling the site uses: zero-padded, -bd/-uncensored/
        // -english-dub at the end…), then the reconstructed candidates.
        val allServers = buildList {
            AnimenosubApi.listEpisodes(slug).firstOrNull { it.first == episode }
                ?.second?.let { add(it) }
            addAll(AnimenosubApi.epSlugs(slug, episode, type = null))
        }.distinct().firstNotNullOfOrNull { eps ->
            AnimenosubApi.serversFromSlug(eps, expectedEpisode = episode)
                .takeIf { s ->
                    s.isNotEmpty() &&
                        // Movie fallback is a single page with no numbered
                        // episode marker; its mirror labels may also omit
                        // SUB/DUB prefixes, so preserve those real servers.
                        (episode == 1 && eps == slug || AnimenosubApi.hasAudio(s, type))
                }
        } ?: return null
        return pickAndResolve(allServers, episode, type, serverCode, slug)
    }

    override suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int,
        totalEpisodes: Int,
        year: Int?
    ): ResolveResult? {
        val allServers = AnimenosubApi.servers(title, episode, type, totalEpisodes, seasonNumber, year)
        if (allServers.isEmpty()) {
            Log.w(TAG, "No servers found for '$title' ep $episode")
            return null
        }
        return pickAndResolve(allServers, episode, type, serverCode, title)
    }

    /**
     * Shared server-filtering + resolution chain used by BOTH the default flow
     * and the wrong-title flow. Logic identical to the original inline code.
     */
    private fun pickAndResolve(
        allServers: List<Pair<String, String>>,
        episode: Int,
        type: String,
        serverCode: String?,
        label: String
    ): ResolveResult? {

        // Only keep resolvable servers (Moon, Omega, Nova)
        val resolvable = allServers.filter { (label, _) ->
            val low = label.lowercase()
            "moon" in low || "omega" in low || "nova" in low
        }
        if (resolvable.isEmpty()) {
            Log.w(TAG, "No resolvable servers (Moon/Omega/Nova) for '$label' ep $episode — servers: ${allServers.map { it.first }}")
            return null
        }

        // Filter by audio type: SUB mode shows SUB + RAW together, DUB mode shows only DUB
        val typeFiltered = if (type == "dub") {
            resolvable.filter { it.first.lowercase().startsWith("dub") }
        } else {
            resolvable.filter {
                val low = it.first.lowercase()
                low.startsWith("sub") || low.startsWith("raw")
            }
        }
        if (typeFiltered.isEmpty()) return null

        // If user picked a specific server, try that first.
        // Match by label ("DUB - Moon") OR by embed URL (for preloadServers
        // callers that swap to (embedUrl, label) convention).
        val ordered = if (serverCode != null) {
            val picked = typeFiltered.firstOrNull { it.first == serverCode || it.second == serverCode }
            if (picked != null) listOf(picked) + typeFiltered.filter { it.first != serverCode && it.second != serverCode }
            else typeFiltered
        } else typeFiltered

        // Try each resolvable server until one works
        for ((srvLabel, embedUrl) in ordered) {
            val stream = try {
                AnimenosubApi.resolve(srvLabel, embedUrl)
            } catch (e: Exception) {
                Log.e(TAG, "Exception resolving $srvLabel: ${e.message}")
                null
            }
            if (stream != null) {
                Log.i(TAG, "Resolved '$label' ep $episode via $srvLabel → ${stream.url.take(80)}")
                // Pairs are (label, embedUrl) from serversFromSlug. Use the full
                // label as server id (so it matches in pickAndResolve) and a
                // clean display name ("Moon"/"Omega"/"Nova").
                val servers = typeFiltered.map { (label, embedUrl) -> label to mirrorLabel(label) }
                return ResolveResult(
                    source = id,
                    servers = servers,
                    url = stream.url,
                    rawUrl = stream.url,
                    referer = stream.referer,
                    format = "hls",
                    subtitles = stream.subtitles
                )
            }
            Log.w(TAG, "Failed to resolve $srvLabel for '$label' ep $episode")
        }

        Log.w(TAG, "All resolvable servers failed for '$label' ep $episode")
        return null
    }

    private fun mirrorLabel(raw: String): String {
        // Labels are "SUB - Moon" / "DUB - Omega" / "RAW - Nova" (older eps
        // may drop the prefix, e.g. "FileMoon"). The mirror name is the part
        // AFTER " - " — matching the whole label handles both formats.
        val low = raw.lowercase()
        return when {
            low.contains("moon") -> "Moon"
            low.contains("omega") -> "Omega"
            low.contains("nova") -> "Nova"
            else -> raw.substringAfter(" - ").trim().ifBlank { raw.trim().ifBlank { "Server" } }
        }
    }

    companion object {
        private const val TAG = "AnimenosubProvider"
    }
}
