package com.panime.app.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.panime.app.BuildConfig
import com.panime.app.data.api.AniListApi
import com.panime.app.data.api.MalApi
import com.panime.app.data.auth.SecureTokenStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

private val Context.dataStore by preferencesDataStore("aniwave_library")

/**
 * One DataStore for all local, per-device user data:
 *  - My List (saved anime ids)
 *  - per-show resume progress (id -> episode, fraction)
 *  - watch history log (used by the profile stats + weekly activity chart)
 *  - profile + playback preferences (display name, member-since, toggles, default audio)
 *
 * No account/backend exists — everything here is local-only.
 */
class UserLibraryStore(private val context: Context) {
    private val myListKey = stringSetPreferencesKey("my_list_ids")
    private val progressKey = stringSetPreferencesKey("progress") // "id:ep:fraction"
    private val historyKey = stringSetPreferencesKey("watch_history") // "id:ep:watchedAtMs:durationSec:fraction"
    private val listMetaKey = stringSetPreferencesKey("list_meta") // "id:status:progress:score"
    // IDs that came FROM the connected AniList account. On disconnect we drop only
    // these so guest (local-only) titles the user added beforehand survive.
    private val anilistImportedKey = stringSetPreferencesKey("anilist_imported_ids")
    // Same, for MyAnimeList. (Stored as AniList ids after MAL id -> AniList id resolution.)
    private val malImportedKey = stringSetPreferencesKey("mal_imported_ids")
    // PKCE code_verifier stashed between launching the browser and the redirect
    // callback. Persisted (not in-memory) so it survives an activity/process
    // restart while the browser auth is in flight. Keyed by service name.
    private val pendingOAuthKey = stringPreferencesKey("pending_oauth_verifier")

    private val displayNameKey = stringPreferencesKey("display_name")
    private val memberSinceKey = longPreferencesKey("member_since")
    private val skipIntroKey = booleanPreferencesKey("skip_intro")
    private val skipOutroKey = booleanPreferencesKey("skip_outro")
    private val autoplayKey = booleanPreferencesKey("autoplay")
    private val darkThemeKey = booleanPreferencesKey("dark_theme")
    private val defaultAudioKey = stringPreferencesKey("default_audio")
    private val lastAudioTypeKey = stringPreferencesKey("last_audio_type")
    private val lastAudioLangKey = stringPreferencesKey("last_audio_lang")
    private val lastSelectedServerIdKey = stringPreferencesKey("last_selected_server")
    private val lastSourceModeKey = stringPreferencesKey("last_source_mode")
    private val anilistUserKey = stringPreferencesKey("anilist_user")
    private val malUserKey = stringPreferencesKey("mal_user")
    private val lastSyncAtKey = longPreferencesKey("last_list_sync_at")
    private val apiProviderKey = stringPreferencesKey("api_provider") // "anilist" | "koto" | "wave"
    // Wrong-title override: "sourceId:slug:title:timestampMs" keyed by animeId
    private val wrongTitleKey = stringSetPreferencesKey("wrong_title_overrides")
    // Update awareness — persisted so the app never forgets a downloaded-but-
    // not-installed update or claims "up to date" while one is pending.
    //   updatePendingTag    newest version we've told the user about (e.g. "v1.0.11")
    //   updateDownloadedTag version whose APK finished downloading (awaiting install)
    //   updatePromptCount   how many times the prompt has been shown for the pending tag
    private val updatePendingTagKey = stringPreferencesKey("update_pending_tag")
    private val updateDownloadedTagKey = stringPreferencesKey("update_downloaded_tag")
    private val updatePromptCountKey = intPreferencesKey("update_prompt_count")

    /** Newest update version we've surfaced to the user ("" = none pending). */
    val updatePendingTag: Flow<String> = context.dataStore.data.map { it[updatePendingTagKey].orEmpty() }
    /** Version whose APK already finished downloading and is waiting to be installed. */
    val updateDownloadedTag: Flow<String> = context.dataStore.data.map { it[updateDownloadedTagKey].orEmpty() }

    val myListIds: Flow<Set<Int>> = context.dataStore.data.map { prefs ->
        prefs[myListKey].orEmpty().mapNotNull { it.toIntOrNull() }.toSet()
    }

    /** animeId -> (episode, progress 0f..1f) */
    val progressMap: Flow<Map<Int, Pair<Int, Float>>> = context.dataStore.data.map { prefs ->
        prefs[progressKey].orEmpty().mapNotNull { entry ->
            val parts = entry.split(":")
            if (parts.size < 3) return@mapNotNull null
            val id = parts[0].toIntOrNull() ?: return@mapNotNull null
            val ep = parts[1].toIntOrNull() ?: return@mapNotNull null
            val frac = parts[2].toFloatOrNull() ?: return@mapNotNull null
            id to (ep to frac)
        }.toMap()
    }

    data class WatchEntry(
        val animeId: Int,
        val episode: Int,
        val watchedAtMs: Long,
        val durationSec: Int,
        val fraction: Float
    )

    /** Synchronous history read (for computing completed counts in the ViewModel). */
    suspend fun currentHistory(): List<WatchEntry> {
        return context.dataStore.data.first().let { prefs ->
            prefs[historyKey].orEmpty().mapNotNull { entry ->
                val p = entry.split(":")
                if (p.size < 5) return@mapNotNull null
                val id = p[0].toIntOrNull() ?: return@mapNotNull null
                val ep = p[1].toIntOrNull() ?: return@mapNotNull null
                val at = p[2].toLongOrNull() ?: return@mapNotNull null
                val dur = p[3].toIntOrNull() ?: return@mapNotNull null
                val frac = p[4].toFloatOrNull() ?: return@mapNotNull null
                WatchEntry(id, ep, at, dur, frac)
            }
        }
    }

    /** Newest-first watch log. */
    val history: Flow<List<WatchEntry>> = context.dataStore.data.map { prefs ->
        prefs[historyKey].orEmpty().mapNotNull { entry ->
            val p = entry.split(":")
            if (p.size < 5) return@mapNotNull null
            val id = p[0].toIntOrNull() ?: return@mapNotNull null
            val ep = p[1].toIntOrNull() ?: return@mapNotNull null
            val at = p[2].toLongOrNull() ?: return@mapNotNull null
            val dur = p[3].toIntOrNull() ?: return@mapNotNull null
            val frac = p[4].toFloatOrNull() ?: return@mapNotNull null
            WatchEntry(id, ep, at, dur, frac)
        }.sortedByDescending { it.watchedAtMs }
    }

    val displayName: Flow<String> = context.dataStore.data.map { it[displayNameKey].orEmpty() }
    val memberSince: Flow<Long> = context.dataStore.data.map { it[memberSinceKey] ?: 0L }
    val skipIntro: Flow<Boolean> = context.dataStore.data.map { it[skipIntroKey] ?: true }
    val skipOutro: Flow<Boolean> = context.dataStore.data.map { it[skipOutroKey] ?: true }
    val autoplay: Flow<Boolean> = context.dataStore.data.map { it[autoplayKey] ?: true }
    /** When true, app uses the dark palette; false keeps the original paper theme. */
    val darkTheme: Flow<Boolean> = context.dataStore.data.map { it[darkThemeKey] ?: false }
    val defaultAudio: Flow<String> = context.dataStore.data.map {
        it[defaultAudioKey].orEmpty().ifBlank { "Japanese" }
    }
    /** Last SUB/DUB choice made in the player (global, survives episode nav + app restart). */
    val lastAudioType: Flow<String> = context.dataStore.data.map { it[lastAudioTypeKey].orEmpty() }
    /** Last picked audio LANGUAGE tag (e.g. "eng"), from the player's audio menu.
     *  Blank/null = user never picked (or cleared by switching sub<->dub). */
    val lastAudioLang: Flow<String?> = context.dataStore.data.map { it[lastAudioLangKey]?.takeIf(String::isNotBlank) }
    /** Last selected server (global; persists across episode nav + app restart). */
    val lastSelectedServerId: Flow<String> = context.dataStore.data.map { it[lastSelectedServerIdKey].orEmpty() }
    /** Last source mode (global; persists across episode nav + app restart). */
    val lastSourceMode: Flow<String> = context.dataStore.data.map { it[lastSourceModeKey].orEmpty() }
    /** Connected AniList username (empty = not connected). */
    val anilistUser: Flow<String> = context.dataStore.data.map { it[anilistUserKey].orEmpty() }
    /** Connected MyAnimeList username (empty = not connected). */
    val malUser: Flow<String> = context.dataStore.data.map { it[malUserKey].orEmpty() }
    /** Epoch ms of last successful remote list sync (0 = never). */
    val lastSyncAt: Flow<Long> = context.dataStore.data.map { it[lastSyncAtKey] ?: 0L }
    /** Active discovery data source: "anilist" (default) or "koto". */
    val apiProvider: Flow<String> = context.dataStore.data.map { it[apiProviderKey].orEmpty().ifBlank { "anilist" } }

    data class ListMeta(
        val id: Int,
        val status: String,
        val progress: Int,
        val score: Double?,
        val totalEpisodes: Int = 0
    )

    val listMeta: Flow<List<ListMeta>> = context.dataStore.data.map { prefs ->
        prefs[listMetaKey].orEmpty().mapNotNull { entry ->
            val p = entry.split(":")
            if (p.size < 4) return@mapNotNull null
            val id = p[0].toIntOrNull() ?: return@mapNotNull null
            ListMeta(
                id = id,
                status = p.getOrNull(1).orEmpty(),
                progress = p.getOrNull(2)?.toIntOrNull() ?: 0,
                score = p.getOrNull(3)?.toDoubleOrNull(),
                totalEpisodes = p.getOrNull(4)?.toIntOrNull() ?: 0
            )
        }
    }

    suspend fun setListStatus(id: Int, status: String) {
        upsertMeta(id) { copy(status = status) }
    }

    suspend fun setListProgress(id: Int, progress: Int) {
        upsertMeta(id) { copy(progress = progress) }
    }

    suspend fun setListScore(id: Int, score: Double?) {
        upsertMeta(id) { copy(score = score) }
    }

    suspend fun setListTotalEpisodes(id: Int, total: Int) {
        upsertMeta(id) { copy(totalEpisodes = total) }
    }

    /**
     * Push a single anime entry to the connected AniList account so local edits
     * stay in sync with the user's AniList list (status / progress / score).
     * No-op when not connected. Never throws — failures are logged so a remote
     * error can never break the local save or the UI.
     * @return true if a push happened and succeeded (or nothing to do), false on error.
     */
    suspend fun pushToAniList(id: Int, status: String, progress: Int, score: Double?): Boolean {
        if (!isAniListConnected()) return true
        val token = getAniListToken() ?: return true
        return withContext(Dispatchers.IO) {
            try {
                AniListApi.saveMediaListEntry(token, id, status, progress, score)
                true
            } catch (e: Throwable) {
                android.util.Log.e("UserLibraryStore", "AniList push failed for #$id ($status/$progress/$score)", e)
                false
            }
        }
    }

    suspend fun upsertMeta(id: Int, block: ListMeta.() -> Unit) {
        context.dataStore.edit { prefs ->
            val currentSet = prefs[listMetaKey].orEmpty().toMutableSet()
            val parse = { entry: String ->
                val p = entry.split(":")
                if (p.size < 4) null else ListMeta(
                    id = p[0].toIntOrNull() ?: -1,
                    status = p.getOrNull(1).orEmpty(),
                    progress = p.getOrNull(2)?.toIntOrNull() ?: 0,
                    score = p.getOrNull(3)?.toDoubleOrNull(),
                    totalEpisodes = p.getOrNull(4)?.toIntOrNull() ?: 0
                )
            }
            val current = currentSet.mapNotNull(parse).firstOrNull { it.id == id }
            val updated = if (current == null) {
                ListMeta(id = id, status = "Plan to Watch", progress = 0, score = null).apply(block)
            } else {
                current.apply(block)
            }
            currentSet.removeAll { it.startsWith("${updated.id}:") }
            currentSet.add("${updated.id}:${updated.status}:${updated.progress}:${updated.score ?: ""}:${updated.totalEpisodes}")
            prefs[listMetaKey] = currentSet
        }
    }

    suspend fun saveListMeta(meta: ListMeta) {
        context.dataStore.edit { prefs ->
            val current = prefs[listMetaKey].orEmpty().toMutableSet()
            current.removeAll { it.startsWith("${meta.id}:") }
            current.add("${meta.id}:${meta.status}:${meta.progress}:${meta.score ?: ""}:${meta.totalEpisodes}")
            prefs[listMetaKey] = current
        }
    }

    suspend fun removeListMeta(id: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[listMetaKey].orEmpty().toMutableSet()
            current.removeAll { it.startsWith("$id:") }
            prefs[listMetaKey] = current
        }
    }

    /**
     * True toggle: first tap adds (In List + check), second tap removes (back to
     * Watchlist / My List). UI re-reads [myListIds] so the button state flips immediately.
     */
    suspend fun toggleMyList(id: Int) {
        var wasAdded = false
        context.dataStore.edit { prefs ->
            val current = prefs[myListKey].orEmpty().toMutableSet()
            val key = id.toString()
            if (current.contains(key)) {
                // Second tap — leave the list (back to not-added state).
                current.remove(key)
                val meta = prefs[listMetaKey].orEmpty().toMutableSet()
                meta.removeAll { it.startsWith("$id:") }
                prefs[listMetaKey] = meta
            } else {
                // First tap — add + Plan to Watch meta.
                current.add(key)
                wasAdded = true
                val parse = { entry: String ->
                    val p = entry.split(":")
                    if (p.size < 4) null else ListMeta(
                        id = p[0].toIntOrNull() ?: -1,
                        status = p.getOrNull(1).orEmpty(),
                        progress = p.getOrNull(2)?.toIntOrNull() ?: 0,
                        score = p.getOrNull(3)?.toDoubleOrNull()
                    )
                }
                val existing = prefs[listMetaKey].orEmpty()
                    .mapNotNull(parse)
                    .firstOrNull { m -> m.id == id }
                if (existing == null) {
                    prefs[listMetaKey] = prefs[listMetaKey].orEmpty()
                        .toMutableSet()
                        .plus("${id}:Plan to Watch:0:")
                } else if (existing.status != "Plan to Watch") {
                    prefs[listMetaKey] = prefs[listMetaKey].orEmpty()
                        .toMutableSet()
                        .filterNot { it.startsWith("${id}:") }
                        .toMutableSet()
                        .plus("${id}:Plan to Watch:${existing.progress}:${existing.score ?: ""}")
                }
            }
            prefs[myListKey] = current
        }
        // Newly added → mirror Plan to Watch on AniList when connected.
        // Removed: local list drives the button; AniList entry is left alone so a
        // remote delete never blocks the local un-save.
        if (wasAdded) pushToAniList(id, "Plan to Watch", 0, null)
    }

    suspend fun removeFromList(id: Int) {
        context.dataStore.edit { prefs ->
            val current = prefs[myListKey].orEmpty().toMutableSet()
            current.remove(id.toString())
            prefs[myListKey] = current
        }
        removeListMeta(id)
        context.dataStore.edit { prefs ->
            val current = prefs[progressKey].orEmpty().toMutableSet()
            current.removeAll { it.startsWith("$id:") }
            prefs[progressKey] = current
        }
    }

    /** Union remote ids into My List without removing local-only titles. */
    suspend fun mergeMyListIds(ids: Collection<Int>) {
        if (ids.isEmpty()) return
        context.dataStore.edit { prefs ->
            val current = prefs[myListKey].orEmpty().toMutableSet()
            ids.forEach { if (it > 0) current.add(it.toString()) }
            prefs[myListKey] = current
        }
    }

    /**
     * Import the connected AniList account's full anime list into My List.
     * Merges IDs into my_list_ids and writes status/progress/score as list_meta,
     * preserving any local-only titles. Returns the number of entries imported.
     */
    suspend fun importAniListList(entries: List<com.panime.app.data.api.AniListApi.AniListMediaListEntry>): Int {
        if (entries.isEmpty()) return 0
        context.dataStore.edit { prefs ->
            // add ids to My List
            val ids = prefs[myListKey].orEmpty().toMutableSet()
            val imported = prefs[anilistImportedKey].orEmpty().toMutableSet()
            entries.forEach { if (it.id > 0) { ids.add(it.id.toString()); imported.add(it.id.toString()) } }
            prefs[myListKey] = ids
            prefs[anilistImportedKey] = imported
            // merge statuses into list_meta
            val meta = prefs[listMetaKey].orEmpty().toMutableSet()
            entries.forEach { e ->
                if (e.id <= 0) return@forEach
                val appStatus = com.panime.app.data.api.AniListApi.anilistStatusToApp(e.status)
                val existing = meta.firstOrNull { m -> m.startsWith("${e.id}:") }
                val prog: Int
                val sc: Double?
                if (existing != null) {
                    val p = existing.split(":")
                    prog = p.getOrNull(2)?.toIntOrNull() ?: 0
                    sc = p.getOrNull(3)?.toDoubleOrNull()
                } else {
                    prog = 0
                    sc = null
                }
                // remote wins for status; keep local progress/score if remote is empty
                val newStatus = appStatus.ifBlank { "Plan to Watch" }
                val newProgress = if (e.progress > 0) e.progress else prog
                val newScore = e.score ?: sc
                meta.removeAll { it.startsWith("${e.id}:") }
                meta.add("${e.id}:$newStatus:$newProgress:${newScore ?: ""}")
            }
            prefs[listMetaKey] = meta
        }
        return entries.size
    }

    /** Return the connected AniList bearer token, or null if not connected. */
    suspend fun getAniListToken(): String? = withContext(Dispatchers.IO) {
        SecureTokenStore(context).validAccessToken("anilist")
    }

    /**
     * Remove only the anime that were imported FROM AniList (so guest/local-only
     * titles the user added before connecting survive the disconnect).
     * Called on disconnect so the synced anime disappear from My List (they're the
     * remote account's list, not local-only titles).
     */
    suspend fun clearAniListImported() = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            val imported = prefs[anilistImportedKey].orEmpty()
            if (imported.isEmpty()) {
                prefs.remove(lastSyncAtKey)
                return@edit
            }
            // Drop imported ids from My List membership.
            val ids = prefs[myListKey].orEmpty().toMutableSet()
            ids.removeAll(imported)
            prefs[myListKey] = ids
            // Drop only the imported entries' meta; keep guest meta intact.
            val meta = prefs[listMetaKey].orEmpty().toMutableSet()
            meta.removeAll { entry -> imported.any { entry.startsWith("$it:") } }
            prefs[listMetaKey] = meta
            prefs.remove(anilistImportedKey)
            prefs.remove(lastSyncAtKey)
        }
    }

    suspend fun setLastSyncAt(epochMs: Long) {
        context.dataStore.edit { it[lastSyncAtKey] = epochMs }
    }

    /** True if the user has connected an AniList account (valid stored token). */
    suspend fun isAniListConnected(): Boolean = withContext(Dispatchers.IO) {
        SecureTokenStore(context).hasToken("anilist")
    }

    /**
     * Pull the connected AniList account's full anime list into My List.
     * No-op if not connected. Returns the number of entries imported.
     */
    suspend fun syncAniListOnLoad(): Int = withContext(Dispatchers.IO) {
        val store = SecureTokenStore(context)
        val token = store.validAccessToken("anilist") ?: return@withContext 0
        try {
            // IMPORTANT: fetchViewerMediaList() does a blocking network call, so it
            // MUST run off the main thread. The tab-load trigger (LaunchedEffect) is
            // on Dispatchers.Main, and a network call there throws
            // NetworkOnMainThreadException — which used to be swallowed here and
            // returned 0 ("0 sync" bug).
            val entries = AniListApi.fetchViewerMediaList(token)
            val imported = importAniListList(entries)
            setLastSyncAt(System.currentTimeMillis())
            imported
        } catch (e: Throwable) {
            android.util.Log.e("UserLibraryStore", "AniList sync failed: ${e.message}", e)
            0
        }
    }

    // ---- MyAnimeList (MAL) integration ----

    // ---- PKCE verifier persistence (survives browser round-trip / process restart) ----

    /** Persist the PKCE code_verifier for an in-flight OAuth attempt. */
    suspend fun putPendingVerifier(service: String, verifier: String) {
        context.dataStore.edit { it[pendingOAuthKey] = "$service:$verifier" }
    }

    /** Consume the PKCE code_verifier for [service]; returns "" if missing/expired. */
    suspend fun takePendingVerifier(service: String): String {
        val stored = context.dataStore.data.first()[pendingOAuthKey].orEmpty()
        val (svc, verifier) = stored.split(":", limit = 2).let { it.getOrNull(0) to it.getOrNull(1) }
        if (svc != service || verifier.isNullOrBlank()) return ""
        context.dataStore.edit { it.remove(pendingOAuthKey) }
        return verifier
    }

    /** Return the connected MAL bearer token, or null if not connected. */
    suspend fun getMalToken(): String? = withContext(Dispatchers.IO) {
        SecureTokenStore(context).validAccessToken("mal")
    }

    /** True if the user has connected a MAL account (valid stored token). */
    suspend fun isMalConnected(): Boolean = withContext(Dispatchers.IO) {
        SecureTokenStore(context).hasToken("mal")
    }

    /**
     * Import the connected MAL account's full anime list into My List.
     * MAL entries are keyed by MAL id; we resolve each to the app's AniList id so
     * MAL and AniList share one unified My List. Titles with no MAL->AniList mapping
     * are skipped (cannot be displayed/cross-referenced in the app otherwise).
     * Returns the number of entries successfully imported.
     */
    suspend fun importMalList(entries: List<com.panime.app.data.api.MalApi.MalListEntry>): Int = withContext(Dispatchers.IO) {
        if (entries.isEmpty()) return@withContext 0
        // Batch-resolve MAL ids -> AniList ids in ONE (or few) GraphQL requests instead
        // of one network call per anime. The previous per-id loop froze the UI on
        // connect for large lists (Bug 3).
        val mapping = MalApi.resolveMalToAnilistBatch(entries.map { it.malId })
        val resolved = entries.mapNotNull { e -> mapping[e.malId]?.let { anilistId -> anilistId to e } }
        if (resolved.isEmpty()) return@withContext 0
        context.dataStore.edit { prefs ->
            val ids = prefs[myListKey].orEmpty().toMutableSet()
            val imported = prefs[malImportedKey].orEmpty().toMutableSet()
            resolved.forEach { (anilistId, _) ->
                ids.add(anilistId.toString())
                imported.add(anilistId.toString())
            }
            prefs[myListKey] = ids
            prefs[malImportedKey] = imported
            val meta = prefs[listMetaKey].orEmpty().toMutableSet()
            resolved.forEach { (anilistId, e) ->
                val existing = meta.firstOrNull { it.startsWith("$anilistId:") }
                val prog: Int
                val sc: Double?
                if (existing != null) {
                    val p = existing.split(":")
                    prog = p.getOrNull(2)?.toIntOrNull() ?: 0
                    sc = p.getOrNull(3)?.toDoubleOrNull()
                } else {
                    prog = 0; sc = null
                }
                val newStatus = e.status.ifBlank { "Plan to Watch" }
                val newProgress = if (e.progress > 0) e.progress else prog
                val newScore = e.score ?: sc
                meta.removeAll { it.startsWith("$anilistId:") }
                meta.add("$anilistId:$newStatus:$newProgress:${newScore ?: ""}")
            }
            prefs[listMetaKey] = meta
        }
        resolved.size
    }

    /**
     * Pull the connected MAL account's full anime list into My List.
     * No-op if not connected. Returns the number of entries imported.
     */
    suspend fun syncMalOnLoad(): Int = withContext(Dispatchers.IO) {
        val store = SecureTokenStore(context)
        val token = store.validAccessToken("mal") ?: return@withContext 0
        try {
            val entries = MalApi.fetchUserList(token)
            val imported = importMalList(entries)
            setLastSyncAt(System.currentTimeMillis())
            imported
        } catch (e: Throwable) {
            android.util.Log.e("UserLibraryStore", "MAL sync failed: ${e.message}", e)
            0
        }
    }

    /**
     * Push a single anime's status/progress/score to the connected MAL account.
     * Resolves the app's AniList id -> MAL id, then PUTs my_list_status.
     * No-op (returns true) when not connected. Never throws — failures are logged so a
     * remote error can never break the local save or the UI.
     * @return true if a push happened and succeeded (or nothing to do), false on error.
     */
    suspend fun pushToMal(id: Int, status: String, progress: Int, score: Double?): Boolean {
        if (!isMalConnected()) return true
        val token = getMalToken() ?: return true
        return withContext(Dispatchers.IO) {
            try {
                val malId = MalApi.resolveAnilistToMal(id)
                if (malId == null) {
                    if (BuildConfig.DEBUG) {
                        android.util.Log.w("UserLibraryStore", "MAL push skipped for #$id: no MAL mapping")
                    }
                    return@withContext true // not an error — title simply isn't on MAL
                }
                MalApi.updateListStatus(token, malId, status, progress, score)
                true
            } catch (e: Throwable) {
                android.util.Log.e("UserLibraryStore", "MAL push failed for #$id ($status/$progress/$score)", e)
                false
            }
        }
    }

    /**
     * Remove only the anime that were imported FROM MAL (so guest/local-only titles
     * and AniList-imported titles survive the disconnect). Mirrors clearAniListImported.
     */
    suspend fun clearMalImported() = withContext(Dispatchers.IO) {
        context.dataStore.edit { prefs ->
            val imported = prefs[malImportedKey].orEmpty()
            if (imported.isEmpty()) return@edit
            val ids = prefs[myListKey].orEmpty().toMutableSet()
            ids.removeAll(imported)
            prefs[myListKey] = ids
            val meta = prefs[listMetaKey].orEmpty().toMutableSet()
            meta.removeAll { entry -> imported.any { entry.startsWith("$it:") } }
            prefs[listMetaKey] = meta
            prefs.remove(malImportedKey)
        }
    }

    /** Wipe all continue watching progress (Clear All button in See All). */
    suspend fun clearAllProgress() {
        context.dataStore.edit { prefs ->
            prefs.remove(progressKey)
            prefs.remove(historyKey)
        }
    }

    /** Remove progress for a single anime (long-press delete in See All). */
    suspend fun clearProgress(animeId: Int) {
        context.dataStore.edit { prefs ->
            val progress = prefs[progressKey].orEmpty().filterNot { it.startsWith("$animeId:") }.toSet()
            prefs[progressKey] = progress
            val history = prefs[historyKey].orEmpty().filterNot { it.startsWith("$animeId:") }.toSet()
            prefs[historyKey] = history
        }
    }

    suspend fun saveProgress(animeId: Int, episode: Int, fraction: Float) {
        context.dataStore.edit { prefs ->
            val current = prefs[progressKey].orEmpty()
                .filterNot { it.startsWith("$animeId:") }
                .toMutableSet()
            current.add("$animeId:$episode:${fraction.coerceIn(0f, 1f)}")
            prefs[progressKey] = current
        }
    }

    /** Append one watch session (called from the player on exit). */
    suspend fun recordWatchSession(animeId: Int, episode: Int, durationSec: Int, fraction: Float) {
        val at = System.currentTimeMillis()
        context.dataStore.edit { prefs ->
            val current = prefs[historyKey].orEmpty().toMutableSet()
            current.add("$animeId:$episode:$at:$durationSec:${fraction.coerceIn(0f, 1f)}")
            prefs[historyKey] = current
        }
    }

    suspend fun setDisplayName(name: String) {
        context.dataStore.edit { it[displayNameKey] = name.trim() }
    }

    suspend fun setMemberSince(epochMs: Long) {
        context.dataStore.edit { it[memberSinceKey] = epochMs }
    }

    suspend fun setSkipIntro(on: Boolean) {
        context.dataStore.edit { it[skipIntroKey] = on }
    }

    suspend fun setSkipOutro(on: Boolean) {
        context.dataStore.edit { it[skipOutroKey] = on }
    }

    suspend fun setAutoplay(on: Boolean) {
        context.dataStore.edit { it[autoplayKey] = on }
    }

    suspend fun setDarkTheme(on: Boolean) {
        context.dataStore.edit { it[darkThemeKey] = on }
    }

    suspend fun setDefaultAudio(lang: String) {
        context.dataStore.edit { it[defaultAudioKey] = lang }
    }

    suspend fun setLastAudioType(type: String) {
        context.dataStore.edit { it[lastAudioTypeKey] = type }
    }

    /** Persist the picked audio language (null clears it). */
    suspend fun setLastAudioLang(lang: String?) {
        context.dataStore.edit { prefs ->
            if (lang.isNullOrBlank()) prefs.remove(lastAudioLangKey)
            else prefs[lastAudioLangKey] = lang
        }
    }

    // ── Update awareness ───────────────────────────────────────────────────

    /**
     * Record that the update prompt was shown for [tag] and bump the reminder
     * count. Returns the new count (so the caller can display "Reminder #N").
     */
    suspend fun rememberUpdatePrompt(tag: String): Int {
        context.dataStore.edit { prefs ->
            prefs[updatePendingTagKey] = tag
            prefs[updatePromptCountKey] = (prefs[updatePromptCountKey] ?: 0) + 1
        }
        return context.dataStore.data.first()[updatePromptCountKey] ?: 0
    }

    /** Record that the APK for [tag] finished downloading but hasn't been installed. */
    suspend fun rememberUpdateDownloaded(tag: String) {
        context.dataStore.edit { prefs ->
            prefs[updatePendingTagKey] = tag
            prefs[updateDownloadedTagKey] = tag
        }
    }

    /** Forget update state once the installed version has caught up (or a reset). */
    suspend fun clearUpdateState() {
        context.dataStore.edit { prefs ->
            prefs.remove(updatePendingTagKey)
            prefs.remove(updateDownloadedTagKey)
            prefs.remove(updatePromptCountKey)
        }
    }

    suspend fun setLastSelectedServerId(serverId: String) {
        context.dataStore.edit { it[lastSelectedServerIdKey] = serverId }
    }

    suspend fun setLastSourceMode(mode: String) {
        context.dataStore.edit { it[lastSourceModeKey] = mode }
    }

    suspend fun setAniListUser(name: String) {
        context.dataStore.edit { it[anilistUserKey] = name }
    }

    suspend fun setMalUser(name: String) {
        context.dataStore.edit { it[malUserKey] = name }
    }

    /** Switch the global discovery data source ("anilist" | "koto" | "wave"). Legacy "mal"
     *  selections map to "koto" so they also behave as the no-data placeholder. */
    suspend fun setApiProvider(provider: String) {
        val p = when (provider) {
            "mal", "koto" -> "koto"
            "wave" -> "wave"
            else -> "anilist"
        }
        context.dataStore.edit { it[apiProviderKey] = p }
    }

    /** Link an account: store its username and update the profile display name. */
    suspend fun setAccount(service: String, name: String) {
        context.dataStore.edit {
            when (service) {
                "anilist" -> it[anilistUserKey] = name
                "mal" -> it[malUserKey] = name
            }
            if (it[displayNameKey].isNullOrBlank()) it[displayNameKey] = name
        }
    }

    suspend fun disconnectAniList() {
        context.dataStore.edit { it.remove(anilistUserKey) }
    }

    suspend fun disconnectMal() {
        context.dataStore.edit { it.remove(malUserKey) }
    }

    /** Disconnect by service. Caller must also clear SecureTokenStore. */
    suspend fun disconnectAccount(service: String) {
        when (service) {
            "anilist" -> disconnectAniList()
            "mal" -> disconnectMal()
        }
    }

    /** Seed member-since + default display name on first launch. */
    suspend fun ensureProfileInit() {
        context.dataStore.edit { prefs ->
            if ((prefs[memberSinceKey] ?: 0L) == 0L) {
                prefs[memberSinceKey] = System.currentTimeMillis()
            }
            if (prefs[displayNameKey].isNullOrBlank()) {
                prefs[displayNameKey] = ""
            }
        }
    }

    /**
     * Reset LOCAL data only — watch history, progress, and any guest/local-only
     * My List entries + display name/preferences. Intentionally does NOT touch
     * connected-account state (anilistUser/malUser) or the imported list entries,
     * so synced AniList/MAL data survives a local reset (Bug 5).
     */
    suspend fun clearLocalOnly() {
        context.dataStore.edit { prefs ->
            val anilistImported = prefs[anilistImportedKey].orEmpty()
            val malImported = prefs[malImportedKey].orEmpty()
            val synced = (anilistImported + malImported).toSet()
            // Drop only local (non-synced) My List ids; keep synced entries.
            val ids = prefs[myListKey].orEmpty().toMutableSet()
            ids.removeAll { it !in synced }
            prefs[myListKey] = ids
            // Drop meta that isn't for a synced id.
            val meta = prefs[listMetaKey].orEmpty().toMutableSet()
            meta.removeAll { entry -> synced.none { entry.startsWith("$it:") } }
            prefs[listMetaKey] = meta

            prefs.remove(historyKey)
            prefs.remove(progressKey)
            prefs.remove(memberSinceKey)
            prefs.remove(skipIntroKey)
            prefs.remove(skipOutroKey)
            prefs.remove(autoplayKey)
            prefs.remove(defaultAudioKey)
            prefs.remove(lastAudioTypeKey)
            prefs.remove(displayNameKey)
            // Wrong-title picks are local-only decisions — a full local reset
            // goes back to original AniList behavior (fresh 6h window too).
            prefs.remove(wrongTitleKey)
            // Keep anilistUserKey / malUserKey / *ImportedKey so synced accounts + lists persist.
        }
    }

    /** Wipe everything (used by the profile "Sign out" action). */
    suspend fun clearAll() {
        context.dataStore.edit { prefs ->
            prefs.remove(myListKey)
            prefs.remove(progressKey)
            prefs.remove(historyKey)
            prefs.remove(displayNameKey)
            prefs.remove(memberSinceKey)
            prefs.remove(skipIntroKey)
            prefs.remove(skipOutroKey)
            prefs.remove(autoplayKey)
            prefs.remove(defaultAudioKey)
            prefs.remove(lastAudioTypeKey)
            prefs.remove(anilistUserKey)
            prefs.remove(malUserKey)
            prefs.remove(lastSyncAtKey)
            // Encrypted OAuth tokens must be cleared via SecureTokenStore on sign-out.
        }
    }

    // ── Wrong-title override (6-hour expiry) ──────────────────────────────

    /** Picks stay fresh for 6 hours, then the app returns to plain AniList behavior. */
    private val OVERRIDE_FRESHNESS_MS = 6L * 60 * 60 * 1000

    data class WrongTitleOverride(
        val sourceId: String,
        val slug: String,
        val selectedTitle: String,
        val timestampMs: Long,
        /** The picked entry's OWN episode count (when the search carried it). */
        val totalEpisodes: Int? = null
    )

    /**
     * Line format: "<animeId>|<sourceId>:<slug>[:<count>]:<title>:<timestampMs>".
     * Titles routinely contain ':' (e.g. "One Piece: Film Red"), so the value
     * is parsed structurally: sourceId and slug never contain ':', the episode
     * count (new lines only) sits between slug and title as a pure number, and
     * the title is everything after it up to the LAST colon (the timestamp).
     * Old lines without the count parse unchanged.
     */
    private fun parseWrongTitleLine(line: String): Pair<Int, WrongTitleOverride>? {
        val parts = line.split("|", limit = 2)
        if (parts.size != 2) return null
        val id = parts[0].toIntOrNull() ?: return null
        val value = parts[1]
        val tsSep = value.lastIndexOf(':')
        if (tsSep <= 0) return null
        val ts = value.substring(tsSep + 1).toLongOrNull() ?: return null
        val head = value.substring(0, tsSep)
        val segs = head.split(':')
        if (segs.size < 3) return null
        val sourceId = segs[0]
        val slug = segs[1]
        // A numeric segment right after the slug (with more segments following)
        // is the stored episode count; titles are never a bare number there.
        val count = if (segs.size >= 4) segs[2].toIntOrNull() else null
        val title = if (count != null) {
            segs.drop(3).joinToString(":")
        } else {
            segs.drop(2).joinToString(":")
        }
        return id to WrongTitleOverride(sourceId, slug, title, ts, count)
    }

    private fun MutableMap<Int, WrongTitleOverride>.loadAll(prefs: androidx.datastore.preferences.core.Preferences) {
        prefs[wrongTitleKey]?.forEach { line ->
            parseWrongTitleLine(line)?.let { (id, ov) -> this[id] = ov }
        }
    }

    private fun Map<Int, WrongTitleOverride>.toLines(): Set<String> =
        map { (k, v) ->
            val mid = if (v.totalEpisodes != null && v.totalEpisodes > 0) {
                "${v.sourceId}:${v.slug}:${v.totalEpisodes}:${v.selectedTitle}"
            } else {
                "${v.sourceId}:${v.slug}:${v.selectedTitle}"
            }
            "$k|$mid:${v.timestampMs}"
        }.toSet()

    suspend fun saveWrongTitleOverride(
        animeId: Int,
        sourceId: String,
        slug: String,
        title: String,
        totalEpisodes: Int? = null
    ) {
        context.dataStore.edit { prefs ->
            val all = mutableMapOf<Int, WrongTitleOverride>().apply { loadAll(prefs) }
            all[animeId] = WrongTitleOverride(sourceId, slug, title, System.currentTimeMillis(), totalEpisodes)
            prefs[wrongTitleKey] = all.toLines()
        }
    }

    suspend fun getWrongTitleOverride(animeId: Int): WrongTitleOverride? {
        return withContext(Dispatchers.IO) {
            context.dataStore.data.first().let { prefs ->
                prefs[wrongTitleKey]?.firstOrNull { line ->
                    line.split("|").firstOrNull()?.toIntOrNull() == animeId
                }?.let { line ->
                    val (_, ov) = parseWrongTitleLine(line) ?: return@let null
                    if (System.currentTimeMillis() - ov.timestampMs > OVERRIDE_FRESHNESS_MS) null
                    else ov
                }
            }
        }
    }

    suspend fun clearWrongTitleOverride(animeId: Int) {
        context.dataStore.edit { prefs ->
            val all = mutableMapOf<Int, WrongTitleOverride>().apply { loadAll(prefs) }
            all.remove(animeId)
            prefs[wrongTitleKey] = all.toLines()
        }
    }
}
