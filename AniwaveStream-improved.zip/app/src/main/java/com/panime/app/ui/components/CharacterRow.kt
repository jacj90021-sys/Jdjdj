package com.panime.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.panime.app.data.model.Character
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary

/**
 * Anivave character row — circular gradient portraits with name (same art style).
 */
@Composable
fun CharacterRow(
    characters: List<Character>,
    onItem: (Character) -> Unit = {}
) {
    Column(Modifier.fillMaxWidth()) {
        SectionHeader("Key Characters")
        Spacer(Modifier.height(6.dp))
        if (characters.isEmpty()) {
            Text(
                "No character data.",
                color = TextSecondary,
                fontFamily = PlexMono,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(characters, key = { it.id }) { ch ->
                    Column(
                        Modifier
                            .width(86.dp)
                            .clickable { onItem(ch) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            Modifier
                                .size(86.dp)
                                .clip(CircleShape)
                                .border(2.dp, Flame.copy(alpha = 0.7f), CircleShape)
                        ) {
                            if (ch.imageUrl != null) {
                                AsyncImage(
                                    model = ch.imageUrl,
                                    contentDescription = ch.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(Modifier.fillMaxSize().background(SurfaceRaised))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            ch.name,
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = PlexMono,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        ch.role?.let {
                            Text(
                                it,
                                color = TextSecondary,
                                fontSize = 10.sp,
                                fontFamily = PlexMono,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
