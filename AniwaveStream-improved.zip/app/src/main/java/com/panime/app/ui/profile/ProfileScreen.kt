package com.panime.app.ui.profile

import com.panime.app.R
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.panime.app.AniwaveApp
import com.panime.app.AniwaveAuthActivity
import com.panime.app.BuildConfig
import com.panime.app.data.repository.UserLibraryStore
import com.panime.app.ui.theme.Anton
import com.panime.app.ui.theme.AniwaveColors
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.Ink
import com.panime.app.ui.theme.InkSoft
import com.panime.app.ui.theme.TextOnDark
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.JetBrainsMono
import com.panime.app.ui.theme.LiveGreen
import com.panime.app.ui.theme.Paper
import com.panime.app.ui.theme.PaperScreen
import com.panime.app.ui.theme.PaperWhite
import com.panime.app.ui.theme.Red
import com.panime.app.ui.theme.WorkSans
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.update.AppUpdateInfo
import com.panime.app.ui.update.AppUpdateOverlay
import com.panime.app.ui.update.checkForAppUpdate
import com.panime.app.ui.update.rememberUpdateFlow
import com.panime.app.update.GitHubUpdater
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * AnimeX paper profile — faithful Compose port of animex_prototype.html.
 * Notched-corner avatar (polygon clip), stamped account cards, numbered dossier
 * panels, ink-bordered groups with toggles. The app's real bottom navbar +
 * system status bar replace the HTML's decorative ones.
 */

// .avatar-frame clip-path polygon: (10% 0,100% 0,100% 90%,90% 100%,0 100%,0 10%)
val NotchedCornerShape = GenericShape { size, path ->
    val w = size.width
    val h = size.height
    val c = 0.1f
    with(path) {
        moveTo(w * c, 0f)
        lineTo(w, 0f)
        lineTo(w, h * (1f - c))
        lineTo(w * (1f - c), h)
        lineTo(0f, h)
        lineTo(0f, h * c)
        close()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    library: UserLibraryStore,
    onBack: () -> Unit,
    onSignedOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val app = context.applicationContext as AniwaveApp
    val tokens = app.tokenStore

    val history by library.history.collectAsStateWithLifecycle(emptyList())
    val anilistUser by library.anilistUser.collectAsStateWithLifecycle("")
    val malUser by library.malUser.collectAsStateWithLifecycle("")
    val skipIntro by library.skipIntro.collectAsStateWithLifecycle(true)
    val skipOutro by library.skipOutro.collectAsStateWithLifecycle(true)
    val autoplay by library.autoplay.collectAsStateWithLifecycle(true)
    val darkTheme by library.darkTheme.collectAsStateWithLifecycle(false)
    val defaultAudio by library.defaultAudio.collectAsStateWithLifecycle("Japanese")
    val apiProvider by library.apiProvider.collectAsStateWithLifecycle("anilist")
    val listMeta by library.listMeta.collectAsStateWithLifecycle(emptyList())
    var showAudioPicker by remember { mutableStateOf(false) }
    var showSignOut by remember { mutableStateOf(false) }
    var showSupport by remember { mutableStateOf(false) }

    // SETTINGS TAB — "Check for Updates" skips the prompt and launches the
    // modal directly in the DOWNLOADING state with the progress animation.
    val updateFlow = rememberUpdateFlow(library)
    var checkingUpdate by remember { mutableStateOf(false) }

    // setApi(provider): updates the GLOBAL backend data-source state. The repository
    // observes this via AniwaveApp and re-routes browse/search/detail to MAL or AniList.
    fun setApi(provider: String) {
        scope.launch { library.setApiProvider(provider) }
    }

    fun beginConnect(service: String) {
        AniwaveAuthActivity.startAuth(context as android.app.Activity, service)
    }

    fun disconnect(service: String) {
        scope.launch {
            tokens.clear(service)
            library.disconnectAccount(service)
            if (service == "anilist") {
                // Reset the profile display name (set to the AniList username on connect)
                // and drop every imported anime so My List reflects the disconnect.
                library.setDisplayName("")
                library.clearAniListImported()
            } else if (service == "mal") {
                // Drop only the MAL-imported anime; keep guest + AniList entries.
                // Clear the MAL username and reset the profile name to default when no
                // other account is connected (mirrors the AniList disconnect rule).
                library.clearMalImported()
                library.setMalUser("")
                if (library.anilistUser.first().isBlank()) {
                    library.setDisplayName("")
                }
            }
            Toast.makeText(context, "Disconnected $service", Toast.LENGTH_SHORT).show()
        }
    }

    fun openUrl(url: String) {
        val view = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        val chooser = Intent.createChooser(view, "Help & support")
        if (context !is android.app.Activity) {
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(chooser) }
            .recoverCatching {
                if (context !is android.app.Activity) {
                    view.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(view)
            }
            .onFailure {
                Toast.makeText(context, "Couldn't open Help & support", Toast.LENGTH_SHORT).show()
            }
    }

    // ---- Derived real stats from the watch-history log + list statuses ----
    // Card 1 — THIS WEEK: rolling 7-day watch time in hours. Only watch sessions
    // recorded within the last 7 days ({ timestamp, secondsWatched }) are summed.
    val nowMs = System.currentTimeMillis()
    val weekCutoffMs = nowMs - 7L * 24 * 60 * 60 * 1000
    val weeklySec = history
        .filter { it.watchedAtMs >= weekCutoffMs && it.watchedAtMs <= nowMs }
        .sumOf { it.durationSec }
    // Minutes under an hour ("45m"), hours with one decimal from 1h up ("1.5h").
    val weeklyTotalText = if (weeklySec < 3600) {
        "${(weeklySec / 60).coerceAtLeast(1)}m"
    } else {
        "%.1fh".format(Locale.ENGLISH, weeklySec / 3600f)
    }

    // Card 2 — EPISODES: unique episodes COMPLETED across all series
    // ({ animeId: [ep1, ep2, ...] }). An episode counts once per animeId when its
    // best recorded session reached the completion threshold (>= 90%).
    val episodesByAnime = history
        .filter { it.fraction >= 0.90f }
        .groupBy({ it.animeId }, { it.episode })
        .mapValues { (_, eps) -> eps.toSet() }
    val episodesWatched = episodesByAnime.values.sumOf { it.size }

    // Card 3 — COMPLETED: anime that are finished.
    // Counts from BOTH sources:
    //  1) Manually marked 'Completed' in the user's list
    //  2) Auto-detected from watch HISTORY (same source as Continue Watching):
    //     every anime you've ever watched counts, as long as history shows all
    //     its episodes at >= 90% and we know its total episode count.
    val manualCompleted = listMeta.filter { it.status == "Completed" }.map { it.id }.toSet()
    val totalByAnime = listMeta.associate { it.id to it.totalEpisodes }
    val autoCompleted = (episodesByAnime.keys + listMeta.map { it.id }.toSet())
        .filter { it !in manualCompleted }
        .filter { id ->
            val watched = episodesByAnime[id]?.size ?: 0
            val total = totalByAnime[id] ?: 0
            watched > 0 && total > 0 && watched >= total
        }
        .toSet()
    val animeCompleted = manualCompleted.size + autoCompleted.size

    // ---------- Identity / avatars (HTML rule) ----------
    // No account -> single GUEST avatar. One account -> that avatar only.
    // Both connected -> two side-by-side avatars (AniList left, MAL right).
    val showDual = anilistUser.isNotBlank() && malUser.isNotBlank()
    val singleService = when {
        anilistUser.isNotBlank() -> "anilist"
        malUser.isNotBlank() -> "mal"
        else -> ""
    }

    PaperScreen(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(18.dp))

            // ---- Guest: single avatar + big title (HTML: profile letter in avatar) ----
            if (anilistUser.isBlank() && malUser.isBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AvatarNotch("G")
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            "GUEST",
                            fontFamily = Anton,
                            fontSize = 28.sp,
                            lineHeight = 25.sp,
                            color = Ink
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "LOCAL PROFILE — NO ACCOUNT",
                            fontFamily = JetBrainsMono,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.W700,
                            color = InkSoft
                        )
                    }
                }
            } else {
                // ---- Linked: avatar shows the profile letter(s) per HTML ----
                when {
                    showDual -> {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            AvatarNotch("AL")
                            AvatarNotch("MAL")
                        }
                    }
                    singleService == "anilist" -> AvatarNotch("AL")
                    else -> AvatarNotch("MAL")
                }
            }

            Spacer(Modifier.height(14.dp))

            // ---------- Sync provider stamps (both always) ----------
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Stamp(
                    name = "AniList",
                    username = anilistUser,
                    modifier = Modifier.weight(1f)
                ) {
                    if (anilistUser.isNotBlank()) disconnect("anilist") else beginConnect("anilist")
                }
                Stamp(
                    name = "MyAnimeList",
                    username = malUser,
                    modifier = Modifier.weight(1f)
                ) {
                    if (malUser.isNotBlank()) disconnect("mal") else beginConnect("mal")
                }
            }

            Spacer(Modifier.height(16.dp))

            // ---------- Dossier panels ----------
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Panel(weeklyTotalText, "This week", Modifier.weight(1.3f))
                Panel(episodesWatched.toString(), "Episodes", Modifier.weight(1f))
                Panel(animeCompleted.toString(), "Completed", Modifier.weight(1f))
            }

            Spacer(Modifier.height(18.dp))

            // ---------- Playback ----------
            DossierHead("02", "Playback")
            Spacer(Modifier.height(7.dp))
            GroupCard {
                RowItem(
                    label = "Skip intro & outro",
                    toggle = skipIntro && skipOutro,
                    withTopBorder = false,
                    onToggle = { v -> scope.launch { library.setSkipIntro(v); library.setSkipOutro(v) } }
                )
                RowItem(
                    label = "Default audio",
                    value = "${defaultAudio.uppercase(Locale.ENGLISH)} ›"
                ) { showAudioPicker = true }
                RowItem(
                    label = "Autoplay next episode",
                    toggle = autoplay,
                    onToggle = { scope.launch { library.setAutoplay(it) } }
                )
            }

            Spacer(Modifier.height(18.dp))

            // ---------- App ----------
            DossierHead("03", "App")
            Spacer(Modifier.height(7.dp))
            GroupCard {
                RowItem(
                    label = "Import / Export",
                    withTopBorder = false
                ) { /* mockup — backup/restore flow to be wired later */ }
                RowItem(
                    label = "Theme",
                    value = if (darkTheme) "DARK" else "PAPER",
                    toggle = darkTheme,
                    onToggle = { v -> scope.launch { library.setDarkTheme(v) } }
                )
                // ---- API Provider segmented switch (ANILIST / KOTO) ----
                ApiProviderRow(
                    current = apiProvider,
                    onSelect = { setApi(it) }
                )
                RowItem(
                    label = "Check for updates",
                    // Always-visible circle: static (full ring) when idle, spins
                    // while a check is running — never a "›" chevron.
                    spinnerAlways = true,
                    loading = checkingUpdate
                ) {
                    if (checkingUpdate) return@RowItem
                    checkingUpdate = true
                    scope.launch {
                        try {
                            val appCtx = context.applicationContext
                            // Forget state once the installed version has caught up.
                            val pending = library.updatePendingTag.first()
                            if (pending.isNotBlank() && !GitHubUpdater.isNewer(
                                    GitHubUpdater.stripTag(pending),
                                    GitHubUpdater.stripTag(BuildConfig.VERSION_NAME)
                                )
                            ) {
                                library.clearUpdateState()
                            }
                            val upd = checkForAppUpdate()
                            if (upd != null) {
                                val apk = GitHubUpdater.destFile(appCtx)
                                if (library.updateDownloadedTag.first() == upd.version && apk.exists()) {
                                    // Already downloaded — offer Install, don't re-download.
                                    library.rememberUpdateDownloaded(upd.version)
                                    updateFlow.showReady(upd, apk)
                                } else {
                                    library.rememberUpdatePrompt(upd.version)
                                    updateFlow.showDownloading(upd)
                                }
                            } else {
                                // Never claim "up to date" while a download we
                                // started is still waiting to be installed.
                                val downloaded = library.updateDownloadedTag.first()
                                val apk = GitHubUpdater.destFile(appCtx)
                                if (downloaded.isNotBlank() && apk.exists() &&
                                    GitHubUpdater.isNewer(downloaded, GitHubUpdater.stripTag(BuildConfig.VERSION_NAME))
                                ) {
                                    updateFlow.showReady(
                                        AppUpdateInfo(
                                            version = downloaded,
                                            displayTag = downloaded,
                                            sizeLabel = "",
                                            changelog = listOf("Update downloaded — tap Install to finish."),
                                            apkUrl = ""
                                        ),
                                        apk
                                    )
                                } else if (pending.isNotBlank() &&
                                    GitHubUpdater.isNewer(pending, GitHubUpdater.stripTag(BuildConfig.VERSION_NAME))
                                ) {
                                    // We know an update exists but the live check
                                    // failed — say the truth instead of "latest".
                                    Toast.makeText(
                                        context,
                                        "Update available — check your connection and try again",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "You're on the latest version",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        } catch (_: Exception) {
                            Toast.makeText(
                                context,
                                "Couldn't check for updates",
                                Toast.LENGTH_SHORT
                            ).show()
                        } finally {
                            checkingUpdate = false
                        }
                    }
                }
                RowItem(
                    label = "Help & support",
                    value = "›"
                ) { showSupport = true }
            }

            Spacer(Modifier.height(18.dp))

            // ---------- Reset ----------
            Box(
                Modifier
                    .fillMaxWidth()
                    .border(2.dp, Red)
                    .clickable { showSignOut = true }
                    .padding(13.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "RESET LOCAL DATA",
                    fontFamily = JetBrainsMono,
                    fontWeight = FontWeight.W700,
                    fontSize = 11.5.sp,
                    color = Red
                )
            }

            Spacer(Modifier.height(28.dp))
        }
    }

    AppUpdateOverlay(updateFlow)

    // ---------- Help & support bottom sheet ----------
    if (showSupport) {
        ModalBottomSheet(
            onDismissRequest = { showSupport = false },
            containerColor = PaperWhite,
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            scrimColor = Color.Black.copy(alpha = 0.4f)
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .border(2.dp, Ink, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                    .padding(20.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "HELP & SUPPORT",
                        modifier = Modifier.weight(1f),
                        fontFamily = WorkSans,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 0.5.sp,
                        color = Ink
                    )
                    Box(
                        Modifier
                            .size(28.dp)
                            .border(1.5.dp, Ink, RoundedCornerShape(6.dp))
                            .clickable { showSupport = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "✕",
                            fontFamily = WorkSans,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = Ink
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                SupportCard(
                    title = "Telegram Channel",
                    subtext = "Announcements & Updates",
                    onClick = { openUrl("https://t.me/panimeonline") }
                )
                Spacer(Modifier.height(10.dp))
                SupportCard(
                    title = "Telegram Group",
                    subtext = "Community Chat & Support",
                    onClick = { openUrl("https://t.me/Panimediscussion") }
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    // ---------- Default audio picker ----------
    if (showAudioPicker) {
        AlertDialog(
            onDismissRequest = { showAudioPicker = false },
            confirmButton = {
                TextButton(onClick = { showAudioPicker = false }) {
                    Text("Done", color = Red)
                }
            },
            title = { Text("Default audio", color = Ink) },
            text = {
                Column {
                    listOf("Japanese", "English (Dub)", "Spanish", "Portuguese", "German").forEach { lang ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    scope.launch { library.setDefaultAudio(lang) }
                                    showAudioPicker = false
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                lang,
                                color = if (lang == defaultAudio) Red else Ink,
                                fontWeight = if (lang == defaultAudio) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        )
    }

    // ---------- Reset confirm ----------
    if (showSignOut) {
        AlertDialog(
            onDismissRequest = { showSignOut = false },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        library.clearLocalOnly()
                        showSignOut = false
                        Toast.makeText(context, "Local data reset", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Reset", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { showSignOut = false }) {
                    Text("Cancel", color = InkSoft)
                }
            },
            title = { Text("Reset local data?", color = Ink) },
            text = {
                Text(
                    "This clears your local watch history, progress, and preferences on this device. Your connected AniList / MyAnimeList accounts and their synced lists are kept.",
                    color = InkSoft
                )
            }
        )
    }
}

// ---------------------------------------------------------------------------
// AnimeX paper primitives
// ---------------------------------------------------------------------------

@Composable
private fun AvatarNotch(letters: String) {
    Box(
        Modifier
            .size(60.dp)
            .clip(NotchedCornerShape)
            .background(Ink),
        contentAlignment = Alignment.Center
    ) {
        Text(letters, fontFamily = Anton, fontSize = 22.sp, color = PaperWhite)
    }
}

@Composable
private fun Stamp(
    name: String,
    username: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val connected = username.isNotBlank()
    Column(
        modifier
            .background(SurfaceRaised)
            .border(2.dp, Ink)
            .clickable(onClick = onClick)
            .padding(11.dp, 11.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(name, fontFamily = Anton, fontSize = 14.sp, color = Ink)
            if (connected) {
                // No box/pill — just the word SYNC. Yellow in BOTH themes
                // (deep amber on the beige stamp, bright gold on dark) so it
                // always stays visible and reads as "connected".
                val syncYellow = if (AniwaveColors.isDark) Color(0xFFFFD24A) else Color(0xFFB8860B)
                Text(
                    "SYNC",
                    fontFamily = Anton,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp,
                    color = syncYellow
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        if (connected) {
            Text(
                "@$username",
                fontFamily = JetBrainsMono,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.W700,
                color = Ink
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "DISCONNECT",
                fontFamily = JetBrainsMono,
                fontSize = 8.5.sp,
                fontWeight = FontWeight.W700,
                textDecoration = TextDecoration.Underline,
                color = Red
            )
        } else {
            Spacer(Modifier.height(8.dp))
            Text(
                "CONNECT",
                fontFamily = JetBrainsMono,
                fontSize = 9.sp,
                fontWeight = FontWeight.W700,
                textDecoration = TextDecoration.Underline,
                color = Red
            )
        }
    }
}

@Composable
private fun Panel(
    num: String,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .background(PaperWhite)
            .border(2.dp, Ink)
            .padding(10.dp, 8.dp)
    ) {
        Column {
            Text(num, fontFamily = Anton, fontSize = 22.sp, color = Ink)
            Spacer(Modifier.height(3.dp))
            Text(
                label.uppercase(Locale.ENGLISH),
                fontFamily = JetBrainsMono,
                fontSize = 7.5.sp,
                color = InkSoft
            )
        }
    }
}

@Composable
private fun DossierHead(num: String, title: String) {
    Row(
        Modifier.padding(start = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Text(num, fontFamily = Anton, fontSize = 13.sp, color = Red)
        Text(
            title.uppercase(Locale.ENGLISH),
            fontFamily = JetBrainsMono,
            fontWeight = FontWeight.W700,
            fontSize = 9.5.sp,
            letterSpacing = 1.3.sp,
            color = Ink
        )
    }
}

@Composable
private fun GroupCard(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(PaperWhite)
            .border(2.dp, Ink)
    ) {
        content()
    }
}

@Composable
private fun RowItem(
    label: String,
    value: String? = null,
    toggle: Boolean? = null,
    loading: Boolean = false,
    spinnerAlways: Boolean = false,
    withTopBorder: Boolean = true,
    onToggle: ((Boolean) -> Unit)? = null,
    onClick: (() -> Unit)? = null
) {
    // Trailing lambdas bind to onClick (last param). Toggle rows must pass onToggle=
    // by name — otherwise a click row's lambda was swallowed as onToggle and the
    // row was not clickable because toggle was null.
    val handler: (() -> Unit)? = when {
        onClick != null -> onClick
        onToggle != null && toggle != null -> { { onToggle(!toggle) } }
        else -> null
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = handler != null) { handler?.invoke() }
    ) {
        if (withTopBorder) HorizontalDivider(thickness = 2.dp, color = Ink)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp, 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                label,
                Modifier.weight(1f),
                fontFamily = WorkSans,
                fontWeight = FontWeight.W600,
                fontSize = 12.5.sp,
                color = Ink
            )
            if (spinnerAlways || loading) {
                if (loading) {
                    // Spinning while a check is actually running.
                    androidx.compose.material3.CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp),
                        color = Red
                    )
                } else {
                    // Static full circle when idle — always visible, never "›".
                    androidx.compose.material3.CircularProgressIndicator(
                        progress = { 1f },
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp),
                        color = Red
                    )
                }
                if (value != null) Spacer(Modifier.width(8.dp))
            }
            if (value != null) {
                Text(
                    value,
                    fontFamily = JetBrainsMono,
                    fontWeight = FontWeight.W700,
                    fontSize = 10.sp,
                    color = Ink
                )
            }
            if (toggle != null) Toggle(on = toggle)
        }
    }
}

@Composable
private fun Toggle(on: Boolean) {
    Box(
        Modifier
            .size(34.dp, 18.dp)
            .background(if (on) Red else PaperWhite)
            .border(2.dp, Ink)
            .padding(1.dp),
        contentAlignment = if (on) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Box(
            Modifier
                .size(12.dp)
                .background(if (on) PaperWhite else Ink)
        )
    }
}

/**
 * Brutalist API Provider segmented switch — faithful Compose port of the requested
 * `.setting-row` / `.segmented-switch` toggle. Ink-bordered container; the active
 * provider button is filled Red. Calls [onSelect]("anilist" | "koto") on tap, which
 * writes the global data-source state via [setApi].
 */
@Composable
private fun ApiProviderRow(
    current: String,
    onSelect: (String) -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
    ) {
        HorizontalDivider(thickness = 2.dp, color = Ink)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(12.dp, 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "API Provider",
                Modifier.weight(1f),
                fontFamily = WorkSans,
                fontWeight = FontWeight.W600,
                fontSize = 12.5.sp,
                color = Ink
            )
            // segmented-switch
            Row(
                Modifier
                    .border(2.dp, Hairline)
                    .background(Hairline)
            ) {
                listOf("anilist" to "ANILIST", "koto" to "KOTO", "wave" to "WAVE").forEach { (key, label) ->
                    val active = current == key
                    Box(
                        Modifier
                            .clickable { onSelect(key) }
                            .background(if (active) Red else PaperWhite)
                            .padding(horizontal = 14.dp, vertical = 7.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            fontFamily = JetBrainsMono,
                            fontWeight = FontWeight.W700,
                            fontSize = 10.sp,
                            color = if (active) TextOnDark else TextPrimary
                        )
                    }
                }
            }
        }
    }
}

// ---------- Help & support: Telegram icon + card row ----------

/** Brutalist support card: hard 2dp shadow, 2dp Ink border, plane icon, arrow. */
@Composable
private fun SupportCard(
    title: String,
    subtext: String,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    Box {
        // Hard offset shadow (2dp solid; shrinks to 1dp while pressed — design).
        Box(
            Modifier
                .matchParentSize()
                .offset(if (pressed) 1.dp else 2.dp, if (pressed) 1.dp else 2.dp)
                .background(Ink, shape)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .background(SurfaceRaised, shape)
                .border(2.dp, Ink, shape)
                .clickable(interactionSource = interaction, indication = null) { onClick() }
                .padding(12.dp, 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = androidx.compose.ui.res.painterResource(R.drawable.ic_telegram),
                contentDescription = null,
                tint = Ink,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    fontFamily = WorkSans,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Ink
                )
                Text(
                    subtext,
                    fontFamily = WorkSans,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
            Text(
                "›",
                fontFamily = WorkSans,
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = Ink
            )
        }
    }
}
