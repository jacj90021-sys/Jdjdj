package com.panime.app.data.provider.aniwaves

import android.os.Build
import android.util.Base64
import android.util.Log
import com.panime.app.BuildConfig
import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.util.Obf
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Signature
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.time.Instant
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.jsoup.Jsoup
import java.net.URLEncoder

/**
 * On-device extractors ported from the Aniwavesapi backend providers
 * (echovideo.ts / vidplay.ts / megacloud.ts).
 *
 * Echovideo (aniwaves' primary CDN — its "Vidplay" and "MyCloud" rows both
 * resolve to play.echovideo.ru embeds) is a single plain getSources JSON call;
 * the m3u8 + .srt tracks it returns play directly from the device (verified:
 * HTTP 200 without even a Referer). Vidplay/Megacloud pipelines (RC4/futoken +
 * CryptoJS AES) are ported as defensive fallbacks for hosts aniwaves may serve
 * natively in the future. BYFMS (device attestation + custom PoW + AES-GCM) is
 * implemented on-device; DGHG (TLS impersonation) is never dispatched here.
 */
object AniwavesExtractor {

    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private val VIDPLAY_KEYS_URL =
        Obf.s("Mi4uKilgdXUoOy10PTMuMi84Lyk/KDk1NC4/NC50OTU3dTk1NCkvNz8udTk1NCkvNz8udC4pdTc7KS4/KHUpKDl1PyIuKDs5LjUoKXUsMz4qNjsjdC4p")
    private val VIDPLAY_FALLBACK_KEYS = listOf(listOf(8, 0), listOf(6, 2), listOf(1, 5))
    private val VIDPLAY_DECRYPT_KEYS = listOf(
        "9Y6I6HiQOqjDUlbAEWtFhg==", "WXrUARXb1aDLaZjI", "4wZuP5YkT1a4wZuP", "LXgbdW5rQ3VzdG9t"
    )

    private val MEGACLOUD_KEYS_URL = Obf.s("Mi4uKilgdXUoOy10PTMuMi84Lyk/KDk1NC4/NC50OTU3dS4yPzU0NiM3NXUxPyMpdTc7MzR1MT8j")
    private val MEGACLOUD_DECRYPT_KEYS = listOf("c1d17096f2ca11b7", "9Y6I6HiQOqjDUlbA", "koko")

    data class Stream(
        val m3u8: String,
        val subtitles: List<AniwavesApi.SubtitleTrack> = emptyList(),
        val intro: Pair<Int, Int>? = null,
        val outro: Pair<Int, Int>? = null,
        val referer: String = "",
        val format: String = "hls",
        /** Human-readable quality badge (e.g. "1080p", "720p", "480p" or "HD/SD/HQ"). */
        val quality: String? = null
    )

    /** Dispatch by embed host + server name, mirroring providers/index.ts. */
    fun extract(
        embedUrl: String,
        serverName: String = "",
        skipIntro: Pair<Int, Int>? = null,
        skipOutro: Pair<Int, Int>? = null
    ): Stream? {
        val host = runCatching { java.net.URI(embedUrl).host.lowercase() }.getOrNull() ?: ""
        val lowerName = serverName.lowercase()

        val attemptEcho = { extractEchovideo(embedUrl, skipIntro, skipOutro) }
        val attemptMega = { extractMegacloud(embedUrl) }
        val attemptVid = { extractVidplay(embedUrl) }

        // BYFMS and its mirrors (weneverbeenfree / wnbf / owphbf / animefever /
        // sprintcdn). Uses the server name first (reliable row signal), with a
        // host fallback for direct calls.
        if (lowerName.contains("byfms") || lowerName.contains("weneverbeenfree") ||
            lowerName.contains("owphbf") || lowerName.contains("animefever") ||
            host.contains("weneverbeenfree") || host.contains("wnbf") ||
            host.contains("owphbf") || host.contains("animefever") || host.contains("sprintcdn")
        ) return extractByfms(embedUrl)

        // Echovideo (aniwaves primary CDN).
        if (host.contains("echovideo") || host.contains("echo")) return attemptEcho()

        // MegaCloud / RapidCloud / RabbitStream.
        if (host.contains("megacloud") || host.contains("rapid-cloud") || host.contains("rabbitstream") ||
            lowerName.contains("megacloud") || lowerName.contains("rapidcloud") || lowerName.contains("rabbitstream")
        ) return attemptMega()

        // Vidplay and mirrors.
        if (host.contains("vidplay") || host.contains("vidcloud") || host.contains("mcloud") || host.contains("goload") ||
            lowerName.contains("vidplay") || lowerName.contains("vidcloud")
        ) return attemptVid()

        // Unknown host — heuristic fallback (backend parity).
        if (Regex("""/embed-\d+/[A-Za-z0-9_-]{20,}""").containsMatchIn(embedUrl)) {
            attemptEcho()?.let { return it }
        }
        if (Regex("""/e/[a-z0-9]{10,16}""").containsMatchIn(embedUrl)) {
            attemptMega()?.let { return it }
        }
        for (attempt in listOf(attemptEcho, attemptMega, attemptVid)) {
            attempt()?.let { return it }
        }
        return null
    }

    // ── Echovideo ──────────────────────────────────────────────────────────────

    private fun extractEchovideo(
        embedUrl: String,
        skipIntro: Pair<Int, Int>?,
        skipOutro: Pair<Int, Int>?
    ): Stream? {
        val urlObj = runCatching { java.net.URI(embedUrl) }.getOrNull() ?: return null
        val host = urlObj.host ?: return null
        val prefix = Regex("""^/embed-(\d+)/""").find(urlObj.path)?.let { "embed-${it.groupValues[1]}" } ?: "embed-1"
        val sourceId = urlObj.path.trimEnd('/').substringAfterLast('/')
        if (sourceId.isBlank() || sourceId.contains("/")) return null

        // Best-effort warm-up of the embed page (backend does this too).
        ScraperEngine.fetchText(
            embedUrl, mapOf("User-Agent" to UA, "Referer" to Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoL3U=")),
            timeoutMs = 5_000L, maxRetries = 1
        )

        val sourcesUrl = "https://$host/$prefix/getSources?id=${enc(sourceId)}"
        val txt = ScraperEngine.fetchText(
            sourcesUrl,
            mapOf(
                "User-Agent" to UA,
                "Accept" to "application/json, */*",
                "Referer" to embedUrl,
                "Origin" to "https://$host",
                "Sec-Fetch-Mode" to "cors",
                "Sec-Fetch-Dest" to "empty",
                "Sec-Fetch-Site" to "same-origin"
            ),
            timeoutMs = 10_000L, maxRetries = 1
        ) ?: return null
        val root = runCatching { json.parseToJsonElement(txt).jsonObject }.getOrNull() ?: return null

        val m3u8: String?
        var streamFormat = "hls"
        var qualityLabel: String? = null
        when (val s = root["sources"]) {
            is JsonPrimitive -> {
                m3u8 = s.content.takeIf { it.isNotBlank() }
                if (m3u8 != null) qualityLabel = "HLS"
            }
            is JsonArray -> {
                val files = s.mapNotNull { fileOf(it) }
                m3u8 = files.firstOrNull { it.contains(".m3u8", true) } ?: files.firstOrNull()
                m3u8?.let { url -> qualityLabel = if (url.contains(".m3u8", true)) "HLS" else "MP4" }
            }
            is JsonObject -> {
                // Quality-keyed format: {"HD":["url"],"SD":["url"],"HQ":["url"]}
                // Flatten all quality URLs and pick the best (first = HD).
                val qualityMap = linkedMapOf<String, MutableList<String>>()
                s.entries.forEach { (key, el) ->
                    val urls = mutableListOf<String>()
                    when (el) {
                        is JsonArray -> el.mapNotNullTo(urls) { v ->
                            when (v) {
                                is JsonPrimitive -> v.content.takeIf { it.isNotBlank() }
                                is JsonObject -> v["file"]?.jsonPrimitive?.content
                                    ?: v["url"]?.jsonPrimitive?.content
                                    ?: v["src"]?.jsonPrimitive?.content
                                else -> null
                            }
                        }
                        is JsonPrimitive -> el.content.takeIf { it.isNotBlank() }?.let { urls.add(it) }
                        is JsonObject -> (el["file"]?.jsonPrimitive?.content
                            ?: el["url"]?.jsonPrimitive?.content
                            ?: el["src"]?.jsonPrimitive?.content)?.let { urls.add(it) }
                    }
                    if (urls.isNotEmpty()) qualityMap[key] = urls
                }
                val firstEntry = qualityMap.entries.firstOrNull()
                m3u8 = firstEntry?.value?.firstOrNull()
                if (m3u8 != null && !m3u8.contains(".m3u8", true)) streamFormat = "mp4"
                qualityLabel = qualityMap.keys.joinToString(", ")
            }
            else -> m3u8 = null
        }
        if (m3u8.isNullOrBlank()) return null

        val subs = tracksToSubtitles(root["tracks"])
        val intro = skipObj(root["intro"]) ?: takeIfPair(skipIntro)
        val outro = skipObj(root["outro"]) ?: takeIfPair(skipOutro)
        return Stream(m3u8, subs, intro, outro,
            referer = Obf.s("Mi4uKilgdXUqNjsjdD85MjUsMz4/NXQoL3U="),
            format = streamFormat,
            quality = qualityLabel)
    }

    // ── Vidplay ────────────────────────────────────────────────────────────────

    private fun extractVidplay(embedUrl: String): Stream? {
        val urlObj = runCatching { java.net.URI(embedUrl) }.getOrNull() ?: return null
        val host = urlObj.host ?: return null

        val page = ScraperEngine.fetchText(
            embedUrl,
            mapOf("User-Agent" to UA, "Accept" to "text/html,*/*;q=0.8", "Referer" to Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoL3U=")),
            timeoutMs = 10_000L, maxRetries = 1
        )
        val scripts = runCatching {
            Jsoup.parse(page.orEmpty()).select("script:not([src])").joinToString("\n") { it.data() }
        }.getOrNull() ?: ""

        val idPatterns = listOf(
            Regex("""getSources\s*\(\s*\{[^}]*id\s*:\s*['"]([^'"]+)['"]"""),
            Regex("""var\s+id\s*=\s*['"]([^'"]+)['"]"""),
            Regex("""["']id["']\s*:\s*["']([^'"]+)["']"""),
            Regex("""\.getSources\s*\(\s*['"]([^'"]+)['"]""")
        )
        var rawId: String? = idPatterns.firstNotNullOfOrNull { it.find(scripts)?.groupValues?.get(1) }
        if (rawId == null) {
            rawId = urlObj.path.trimEnd('/').substringAfterLast('/').takeIf { it.isNotBlank() }
        }
        if (rawId.isNullOrBlank()) return null

        val pathPatterns = listOf(
            Regex("""getSources\s*\(\s*\{[^}]*url\s*:\s*['"]([^'"]+)['"]"""),
            Regex("""sourcesUrl\s*=\s*['"]([^'"]+)['"]"""),
            Regex("""["']sources["']\s*:\s*["']([^'"]+)["']""")
        )
        val sourcesPath: String? = pathPatterns.firstNotNullOfOrNull { it.find(scripts)?.groupValues?.get(1) }

        val keys = fetchVidplayKeys()
        val token = buildFutoken(keys, rawId)
        val encodedId = vrfEncrypt(rawId, keys) ?: return null
        val mediaInfoUrl = if (!sourcesPath.isNullOrBlank()) "https://$host$sourcesPath" else "https://$host/mediainfo/$encodedId"
        val query = "t=${enc(token)}" + if (urlObj.query?.contains("t=") == true) "&autoplay=1" else ""

        val txt = ScraperEngine.fetchText(
            "$mediaInfoUrl?$query",
            mapOf(
                "User-Agent" to UA,
                "Accept" to "*/*",
                "Referer" to embedUrl,
                "Origin" to "https://$host",
                "X-Requested-With" to "XMLHttpRequest"
            ),
            timeoutMs = 10_000L, maxRetries = 1
        ) ?: return null

        val sources = decryptResponse(txt, listOfNotNull(VIDPLAY_DECRYPT_KEYS, listOf(StreamCrypto.md5Hex(rawId))).flatten())
            ?: return null
        val parsed = sources.second
        return sourcesToStream(sources.first, parsed, "https://$host/")
    }

    private fun fetchVidplayKeys(): List<List<Int>> {
        val txt = ScraperEngine.fetchText(
            VIDPLAY_KEYS_URL, mapOf("User-Agent" to UA), timeoutMs = 8000L, maxRetries = 1
        )
        if (!txt.isNullOrBlank()) {
            val m = Regex("""const\s+keys\s*=\s*(\[\[.*?\]\])""", RegexOption.DOT_MATCHES_ALL).find(txt)
            if (m != null) {
                val parsed = runCatching {
                    json.parseToJsonElement(m.groupValues[1]).jsonArray
                        .mapNotNull { pair ->
                            runCatching { pair.jsonArray.mapNotNull { it.jsonPrimitive.content.toIntOrNull() } }.getOrNull()
                        }
                        .filter { it.size == 2 }
                }.getOrNull()
                if (!parsed.isNullOrEmpty()) return parsed
            }
        }
        return VIDPLAY_FALLBACK_KEYS
    }

    /** RC4 chain over the futoken key list, URL-encoded (backend vrfEncrypt). */
    private fun vrfEncrypt(id: String, keys: List<List<Int>>): String? {
        var result = id
        for (key in keys) {
            val k = key.firstOrNull() ?: continue
            result = StreamCrypto.rc4Encrypt(result, k) ?: return null
        }
        return URLEncoder.encode(result.replace("/", "_").replace("+", "-"), "UTF-8")
    }

    private fun buildFutoken(keys: List<List<Int>>, id: String): String {
        val parts = mutableListOf("k=" + keys.map { it.firstOrNull() ?: 0 }.joinToString(","))
        for (key in keys) {
            val start = key.getOrNull(0) ?: 0
            val offset = key.getOrNull(1) ?: 0
            val slice = if (start < id.length) {
                id.substring(start, minOf(start + offset, id.length))
            } else {
                start.toString()
            }
            parts.add(slice)
        }
        return parts.joinToString(",")
    }

    // ── MegaCloud ──────────────────────────────────────────────────────────────

    private fun extractMegacloud(embedUrl: String): Stream? {
        val urlObj = runCatching { java.net.URI(embedUrl) }.getOrNull() ?: return null
        val host = urlObj.host ?: return null
        val sourceId = urlObj.path.trimEnd('/').substringAfterLast('/')
        if (sourceId.isBlank() || sourceId.contains("/")) return null

        val page = ScraperEngine.fetchText(
            embedUrl, mapOf("User-Agent" to UA, "Referer" to Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoL3U=")),
            timeoutMs = 10_000L, maxRetries = 1
        )
        val scriptKey = page?.let { p ->
            runCatching { Jsoup.parse(p).select("script:not([src])").joinToString("\n") { it.data() } }
                .getOrNull()?.let { extractKeyFromScript(it) }
        }

        val endpoint = when {
            host.contains("rapid-cloud") -> "/embed-6/ajax/e-1/getSources"
            host.contains("rabbitstream") -> "/embed-4/ajax/e-1/getSources"
            else -> "/embed-2/ajax/e-1/getSources"
        }
        val txt = ScraperEngine.fetchText(
            "https://$host$endpoint?id=$sourceId",
            mapOf(
                "User-Agent" to UA,
                "Accept" to "*/*",
                "Referer" to embedUrl,
                "Origin" to "https://$host",
                "X-Requested-With" to "XMLHttpRequest"
            ),
            timeoutMs = 10_000L, maxRetries = 1
        ) ?: return null

        val sources = decryptResponse(txt, listOfNotNull(scriptKey, fetchMegacloudKey()).plus(MEGACLOUD_DECRYPT_KEYS))
            ?: return null
        return sourcesToStream(sources.first, sources.second, "https://$host/")
    }

    private fun extractKeyFromScript(scripts: String): String? {
        val patterns = listOf(
            Regex("""(?:var|let|const)\s+key\s*=\s*['"]([^'"]{8,})['"]"""),
            Regex("""key\s*:\s*['"]([^'"]{8,})['"]"""),
            Regex("""decryptionKey\s*[:=]\s*['"]([^'"]{8,})['"]"""),
            Regex("""k\s*=\s*['"]([^'"]{8,})['"]""")
        )
        return patterns.firstNotNullOfOrNull { it.find(scripts)?.groupValues?.get(1) }
    }

    private fun fetchMegacloudKey(): String? =
        ScraperEngine.fetchText(MEGACLOUD_KEYS_URL, mapOf("User-Agent" to UA), timeoutMs = 8000L, maxRetries = 1)
            ?.trim()?.takeIf { it.isNotBlank() }

    // ── BYFMS ──────────────────────────────────────────────────────────────────
    //
    // Ported from the site's live bundle (pow-DEJGtdh2.js) + backend
    // weneverbeenfree.ts. Flow:
    //   1. Attest the device: POST /api/videos/access/challenge -> {challenge_id,
    //      nonce}; sign the nonce with a fresh ECDSA P-256 key (DER -> raw r||s ->
    //      base64url), POST /api/videos/access/attest with the public JWK + client
    //      info -> {viewer_id, device_id, token, confidence, expires_at}.
    //   2. POST /api/videos/{id}/embed/captcha {fingerprint:{token}} ->
    //      {pow_nonce, pow_difficulty, pow_token}. NOTE: the response labels the
    //      algorithm "sha256-leading-zero-bits" but the real miner is the custom
    //      `gr` hash (verified byte-identical against the site's own bundle).
    //   3. Mine gr("pow_nonce:solution") with >= pow_difficulty leading zero bits.
    //   4. POST .../captcha/verify {pow_token, solution, fingerprint} ->
    //      {status:"ok", token}; retry up to 3x (site does the same).
    //   5. POST .../embed/playback {fingerprint} + X-Captcha-Token -> 428 if the
    //      captcha isn't cleared yet, else {playback:{algorithm:"AES-256-GCM", iv,
    //      payload, key_parts[], version}}; decrypt AES-GCM with the concatenated
    //      key_parts (version selects 2 of them: {n, 31-n}), parse the JSON for
    //      sources[] (m3u8) + tracks[] (subtitles).
    private val BYFMS_ORIGIN = Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoLw==")
    private val BYFMS_REFERER = Obf.s("Mi4uKilgdXU7NDMtOyw/KXQoL3U=")
    private const val BYFMS_MINE_TIMEOUT_MS = 20_000L

    private var byfmsKeyPair: KeyPair? = null
    private var byfmsViewerId: String? = null
    private var byfmsDeviceId: String? = null
    private var byfmsToken: String? = null
    private var byfmsTokenExpiry: Long = 0L

    private data class ByfmsFingerprint(val token: String, val expiresAtEpoch: Long)

    // ── PoW: the site's `gr` hash + miner ─────────────────────────────────────

    private fun byfmsRotl(t: UInt, e: Int): UInt = (t shl e) or (t shr (32 - e))
    private fun byfmsMul32(t: UInt, e: UInt): UInt = (t.toLong() * e.toLong()).toUInt()

    private fun byfmsYe(t: UIntArray) {
        t[0] += t[1]; t[3] = byfmsRotl(t[3] xor t[0], 16); t[2] += t[3]; t[1] = byfmsRotl(t[1] xor t[2], 12)
        t[0] += t[1]; t[3] = byfmsRotl(t[3] xor t[0], 8); t[2] += t[3]; t[1] = byfmsRotl(t[1] xor t[2], 7)
    }

    private fun byfmsGr(input: ByteArray): UIntArray {
        val t = UIntArray(4).also {
            it[0] = 1779033703u; it[1] = 3144134277u; it[2] = 1013904242u; it[3] = 2773480762u
        }
        for (i in input.indices) {
            t[0] = t[0] + (input[i].toInt() and 0xFF).toUInt()
            t[0] = byfmsRotl(t[0], 7)
            byfmsYe(t)
        }
        repeat(8) { byfmsYe(t) }
        val r = UIntArray(512)
        for (i in 0 until 512) { byfmsYe(t); r[i] = t[0] xor t[2] }
        repeat(2) { for (s in 0 until 512) {
            val a = r[s] and 511u
            var c = r[s] + r[a.toInt()]
            c = byfmsRotl(c, 13)
            c = c xor byfmsMul32(r[(s + 1) and 511], 2654435761u)
            r[s] = c
            t[0] = t[0] xor c
            byfmsYe(t)
        } }
        val out = UIntArray(8)
        for (i in 0 until 8) {
            byfmsYe(t)
            var s2 = t[0]
            val a = i * 64
            for (c in 0 until 64) {
                val d = r[a + c]
                s2 = s2 + d
                s2 = byfmsRotl(s2, 5)
                s2 = s2 xor byfmsMul32(d, 2246822519u)
            }
            out[i] = s2 xor t[2]
        }
        return out
    }

    /** Leading-zero-bit count of the 8-word digest (the PoW difficulty). */
    private fun byfmsLeadingZeros(t: UIntArray): Int {
        var e = 0
        for (n in t) {
            if (n == 0u) { e += 32; continue }
            return e + Integer.numberOfLeadingZeros(n.toInt())
        }
        return e
    }

    private fun byfmsMine(nonce: String, difficulty: Int, timeoutMs: Long): String? {
        val difficultySafe = if (difficulty < 1) 1 else difficulty
        val prefix = (nonce + ":").toByteArray(Charsets.UTF_8)
        val deadline = System.currentTimeMillis() + timeoutMs
        var s = 0L
        while (System.currentTimeMillis() < deadline) {
            val tail = s.toString().toByteArray(Charsets.UTF_8)
            val buf = ByteArray(prefix.size + tail.size)
            prefix.copyInto(buf, 0)
            tail.copyInto(buf, prefix.size)
            if (byfmsLeadingZeros(byfmsGr(buf)) >= difficultySafe) return s.toString()
            s++
        }
        return null
    }

    // ── Attestation (device identity + ECDSA P-256 signature) ─────────────────

    private fun byfmsHeaders(extra: Map<String, String> = emptyMap()): Map<String, String> = buildMap {
        putAll(extra)
        put("User-Agent", UA)
        put("Accept", "application/json, text/plain, */*")
        put("Content-Type", "application/json")
        put("Origin", BYFMS_ORIGIN)
        put("Referer", BYFMS_REFERER)
        put("X-Embed-Origin", BYFMS_ORIGIN)
        put("X-Embed-Referer", BYFMS_REFERER)
        put("X-Embed-Frame", BYFMS_REFERER)
    }

    private fun byfmsB64UrlEncode(bytes: ByteArray): String =
        Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)

    private fun byfmsB64UrlDecode(s: String): ByteArray? = runCatching {
        var padded = s.replace('-', '+').replace('_', '/')
        while (padded.length % 4 != 0) padded += "="
        Base64.decode(padded, Base64.DEFAULT)
    }.getOrNull()

    private fun byfmsStableHash(seed: String): String =
        byfmsB64UrlEncode(MessageDigest.getInstance("SHA-256").digest("aniwaves-byfms-$seed".toByteArray()))

    private fun byfmsRandomId(prefix: String): String {
        val bytes = ByteArray(16)
        java.security.SecureRandom().nextBytes(bytes)
        return prefix + byfmsB64UrlEncode(bytes)
    }

    private fun byfmsDerToRaw(sig: ByteArray): ByteArray? {
        if (sig.size < 8 || sig[0] != 0x30.toByte()) return null
        var i = 2
        fun readInt(): ByteArray? {
            if (i + 2 > sig.size) return null
            val len = sig[i + 1].toInt() and 0xFF
            i += 2
            if (i + len > sig.size) return null
            var start = i
            if (len > 0 && sig[i] == 0.toByte()) start++
            val srcLen = i + len - start
            val out = ByteArray(32)
            val copyLen = minOf(srcLen, 32)
            sig.copyInto(out, 32 - copyLen, start, start + copyLen)
            i += len
            return out
        }
        val r = readInt() ?: return null
        val s = readInt() ?: return null
        return r + s
    }

    private fun byfmsClientInfo(): JsonObject = buildJsonObject {
        put("user_agent", JsonPrimitive(UA))
        put("pixel_ratio", JsonPrimitive(2.0))
        put("screen_width", JsonPrimitive(1080))
        put("screen_height", JsonPrimitive(2400))
        put("color_depth", JsonPrimitive(24))
        put("languages", JsonArray(listOf(JsonPrimitive("en-US"), JsonPrimitive("en"))))
        put("timezone", JsonPrimitive(java.util.TimeZone.getDefault().id))
        put("hardware_concurrency", JsonPrimitive(Runtime.getRuntime().availableProcessors()))
        put("device_memory", JsonPrimitive(8))
        put("touch_points", JsonPrimitive(5))
        put("pointer_type", JsonPrimitive("coarse"))
        put("canvas_hash", JsonPrimitive(byfmsStableHash("canvas")))
        put("audio_hash", JsonPrimitive(byfmsStableHash("audio")))
        put("fonts_hash", JsonPrimitive(byfmsStableHash("fonts")))
        put("codecs_hash", JsonPrimitive(byfmsStableHash("codecs")))
        put("platform", JsonPrimitive("Android"))
        put("model", JsonPrimitive("${Build.MANUFACTURER} ${Build.MODEL}"))
        put("vendor", JsonPrimitive("Google Inc."))
        put("architecture", JsonPrimitive("arm64"))
        put("bitness", JsonPrimitive("64"))
        put("brand_full_versions", JsonArray(listOf(buildJsonObject {
            put("brand", JsonPrimitive("Chromium"))
            put("version", JsonPrimitive("126.0.6478.127"))
        })))
        put("extra", buildJsonObject {
            put("vendor", JsonPrimitive("Google Inc."))
            put("appVersion", JsonPrimitive("5.0 (Linux; Android) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"))
        })
    }

    private fun byfmsStorage(): JsonObject = buildJsonObject {
        put("cookie", JsonNull)
        put("local_storage", JsonNull)
        put("indexed_db", JsonNull)
        put("cache_storage", JsonNull)
    }

    private fun byfmsObtainFingerprint(host: String): ByfmsFingerprint? {
        val now = System.currentTimeMillis()
        val cachedToken = byfmsToken
        if (cachedToken != null && byfmsTokenExpiry > now + 30_000L) {
            return ByfmsFingerprint(cachedToken, byfmsTokenExpiry)
        }
        val keyPair = byfmsKeyPair ?: runCatching {
            KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1")) }
                .generateKeyPair()
        }.getOrNull() ?: return null
        byfmsKeyPair = keyPair
        val baseUrl = "https://$host"

        val challenge = ScraperEngine.postJson(
            "$baseUrl" + Obf.s("dTsqM3UsMz4/NSl1Ozk5PykpdTkyOzY2PzQ9Pw=="), "{}", byfmsHeaders()
        ) ?: return null
        val chObj = runCatching { json.parseToJsonElement(challenge.body).jsonObject }.getOrNull() ?: return null
        val nonce = chObj["nonce"]?.jsonPrimitive?.content ?: return null
        val challengeId = chObj["challenge_id"]?.jsonPrimitive?.content ?: return null

        val der = runCatching {
            val sig = Signature.getInstance("SHA256withECDSA")
            sig.initSign(keyPair.private)
            sig.update(nonce.toByteArray(Charsets.UTF_8))
            sig.sign()
        }.getOrNull() ?: return null
        val raw = byfmsDerToRaw(der) ?: return null

        val pub = keyPair.public as ECPublicKey
        fun coord(c: java.math.BigInteger): String {
            val b = c.toByteArray()
            val raw = if (b.size > 32) {
                b.copyOfRange(b.size - 32, b.size)
            } else {
                val out = ByteArray(32)
                b.copyInto(out, 32 - b.size)
                out
            }
            return byfmsB64UrlEncode(raw)
        }
        val jwk = buildJsonObject {
            put("kty", JsonPrimitive("EC"))
            put("crv", JsonPrimitive("P-256"))
            put("x", JsonPrimitive(coord(pub.w.affineX)))
            put("y", JsonPrimitive(coord(pub.w.affineY)))
        }
        if (byfmsViewerId == null) byfmsViewerId = byfmsRandomId("byfms-viewer-")
        if (byfmsDeviceId == null) byfmsDeviceId = byfmsRandomId("byfms-device-")
        val viewerId = byfmsViewerId ?: return null
        val deviceId = byfmsDeviceId ?: return null

        val body = buildJsonObject {
            put("viewer_id", JsonPrimitive(viewerId))
            put("device_id", JsonPrimitive(deviceId))
            put("challenge_id", JsonPrimitive(challengeId))
            put("nonce", JsonPrimitive(nonce))
            put("signature", JsonPrimitive(byfmsB64UrlEncode(raw)))
            put("public_key", jwk)
            put("client", byfmsClientInfo())
            put("storage", byfmsStorage())
            put("attributes", buildJsonObject { put("entropy", JsonPrimitive("high")) })
        }
        val attest = ScraperEngine.postJson(
            "$baseUrl" + Obf.s("dTsqM3UsMz4/NSl1Ozk5PykpdTsuLj8pLg=="), json.encodeToString(JsonObject.serializer(), body), byfmsHeaders()
        ) ?: return null
        val at = runCatching { json.parseToJsonElement(attest.body).jsonObject }.getOrNull() ?: return null
        val token = at["token"]?.jsonPrimitive?.content ?: return null
        val expiresMs = at["expires_at"]?.jsonPrimitive?.content
            ?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() }
            ?: (System.currentTimeMillis() + 5 * 60_000L)
        byfmsToken = token
        byfmsTokenExpiry = expiresMs
        return ByfmsFingerprint(token, expiresMs)
    }

    // ── Captcha → verify → playback → decrypt ────────────────────────────────

    /** Mine + verify one captcha round. Returns the usable captcha token on success. */
    private fun byfmsSolveCaptcha(
        host: String,
        videoId: String,
        captchaPath: String,
        verifyPath: String,
        fingerprint: JsonObject?
    ): String? {
        val capBody = buildJsonObject {
            fingerprint?.let { put("fingerprint", it) }
        }
        val cap = ScraperEngine.postJson(
            "https://$host$captchaPath",
            json.encodeToString(JsonObject.serializer(), capBody),
            byfmsHeaders()
        ) ?: return null
        if (cap.code != 200) return null
        val capObj = runCatching { json.parseToJsonElement(cap.body).jsonObject }.getOrNull() ?: return null
        val powNonce = capObj["pow_nonce"]?.jsonPrimitive?.content ?: return null
        val difficulty = capObj["pow_difficulty"]?.jsonPrimitive?.content?.toIntOrNull() ?: 16
        val powToken = capObj["pow_token"]?.jsonPrimitive?.content ?: return null
        val solution = byfmsMine(powNonce, difficulty, BYFMS_MINE_TIMEOUT_MS) ?: return null
        val verifyBody = buildJsonObject {
            put("pow_token", JsonPrimitive(powToken))
            put("solution", JsonPrimitive(solution))
            fingerprint?.let { put("fingerprint", it) }
        }
        val v = ScraperEngine.postJson(
            "https://$host$verifyPath",
            json.encodeToString(JsonObject.serializer(), verifyBody),
            byfmsHeaders()
        ) ?: return null
        val vObj = runCatching { json.parseToJsonElement(v.body).jsonObject }.getOrNull() ?: return null
        if (vObj["status"]?.jsonPrimitive?.content != "ok") return null
        return vObj["token"]?.jsonPrimitive?.content
    }

    private fun byfmsDecryptStream(playback: JsonObject): Stream? {
        val algo = playback["algorithm"]?.jsonPrimitive?.content ?: return null
        if (!algo.contains("AES", ignoreCase = true)) return null
        val iv = byfmsB64UrlDecode(playback["iv"]?.jsonPrimitive?.content ?: return null) ?: return null
        val payload = byfmsB64UrlDecode(playback["payload"]?.jsonPrimitive?.content ?: return null) ?: return null
        val parts = playback["key_parts"]?.jsonArray?.mapNotNull { it.jsonPrimitive.content } ?: return null
        val version = playback["version"]?.jsonPrimitive?.content
        val key = byfmsKeyBytes(byfmsSelectKeyParts(version, parts))
        if (key.isEmpty()) return null
        val plain = StreamCrypto.aesGcmDecrypt(key, iv, payload) ?: return null
        val root = runCatching { json.parseToJsonElement(String(plain, Charsets.UTF_8)).jsonObject }.getOrNull() ?: return null
        val files = (root["sources"]?.jsonArray ?: JsonArray(emptyList())).mapNotNull { fileOf(it) }
        val m3u8 = files.firstOrNull { it.contains(".m3u8", true) && it.contains("master") }
            ?: files.firstOrNull { it.contains(".m3u8", true) }
            ?: files.firstOrNull() ?: return null
        val fmt = if (m3u8.contains(".m3u8", true)) "hls" else "mp4"
        if (BuildConfig.DEBUG) {
            Log.i("AniwavesExtractor", "byfmsDecryptStream: fmt=$fmt url=${m3u8.take(80)}")
        }
        return Stream(
            m3u8,
            tracksToSubtitles(root["tracks"]),
            skipObj(root["intro"]),
            skipObj(root["outro"]),
            referer = BYFMS_REFERER,
            format = fmt,
            quality = "BYFMS"
        )
    }

    /** Version selects 2 of the key_parts by index {n, 31-n} (backend `ws`). */
    private fun byfmsSelectKeyParts(version: String?, parts: List<String>): List<String> {
        val n = version?.trim()?.toIntOrNull() ?: return parts
        if (n < 1 || n > 20) return parts
        val idx = listOf(n, 31 - n).filter { it in 1..parts.size }
        if (idx.isEmpty()) return parts
        val picked = idx.map { parts[it - 1] }.filter { it.isNotBlank() }
        return if (picked.isNotEmpty()) picked else parts
    }

    private fun byfmsKeyBytes(parts: List<String>): ByteArray {
        val decoded = parts.mapNotNull { byfmsB64UrlDecode(it) }
        var total = 0
        for (d in decoded) total += d.size
        val out = ByteArray(total)
        var pos = 0
        for (d in decoded) { d.copyInto(out, pos); pos += d.size }
        return out
    }

    private fun byfmsPlayback(host: String, videoId: String, captchaToken: String, fingerprint: JsonObject): Stream? {
        val body = buildJsonObject { put("fingerprint", fingerprint) }
        val hdrs = byfmsHeaders(mapOf("X-Captcha-Token" to captchaToken))
        val resp = ScraperEngine.postJson(
            "https://$host" + Obf.s("dTsqM3UsMz4/NSl1") + "$videoId/embed/playback",
            json.encodeToString(JsonObject.serializer(), body),
            hdrs
        ) ?: return null
        if (resp.code != 200) return null // 428 captcha_required — caller retries.
        val root = runCatching { json.parseToJsonElement(resp.body).jsonObject }.getOrNull() ?: return null
        return byfmsDecryptStream(root["playback"]?.jsonObject ?: return null)
    }

    private fun extractByfms(embedUrl: String): Stream? {
        val urlObj = runCatching { java.net.URI(embedUrl) }.getOrNull() ?: return null
        val host = urlObj.host?.lowercase() ?: return null
        val videoId = Regex("""/e/([A-Za-z0-9_-]+)""").find(urlObj.path)?.groupValues?.get(1)
            ?: urlObj.path.trimEnd('/').substringAfterLast('/').takeIf { it.isNotBlank() } ?: return null
        if (BuildConfig.DEBUG) {
            Log.i("AniwavesExtractor", "extractByfms: host=$host videoId=$videoId")
        }

        val fp = byfmsObtainFingerprint(host)
        if (fp == null) {
            if (BuildConfig.DEBUG) {
                Log.w("AniwavesExtractor", "extractByfms: attestation failed for $host")
            }
            return null
        }
        if (BuildConfig.DEBUG) {
            Log.i("AniwavesExtractor", "extractByfms: attestation OK, solving captcha...")
        }
        val fpJson = buildJsonObject { put("token", JsonPrimitive(fp.token)) }
        repeat(3) { attempt ->
            if (BuildConfig.DEBUG) {
                Log.i("AniwavesExtractor", "extractByfms: captcha attempt ${attempt + 1}/3")
            }
            byfmsSolveCaptcha(
                host, videoId,
                Obf.s("dTsqM3UsMz4/NSl1") + "$videoId/embed/captcha",
                Obf.s("dTsqM3UsMz4/NSl1") + "$videoId/embed/captcha/verify",
                fpJson
            )?.let { capToken ->
                if (BuildConfig.DEBUG) {
                    Log.i("AniwavesExtractor", "extractByfms: captcha solved, fetching playback...")
                }
                byfmsPlayback(host, videoId, capToken, fpJson)?.let { stream ->
                    if (BuildConfig.DEBUG) {
                        Log.i("AniwavesExtractor", "extractByfms: OK fmt=${stream.format} quality=${stream.quality}")
                    }
                    return stream
                } ?: run {
                    if (BuildConfig.DEBUG) {
                        Log.w("AniwavesExtractor", "extractByfms: playback/decrypt failed (attempt ${attempt + 1})")
                    }
                }
            } ?: run {
                if (BuildConfig.DEBUG) {
                    Log.w("AniwavesExtractor", "extractByfms: captcha solve failed (attempt ${attempt + 1})")
                }
            }
        }
        if (BuildConfig.DEBUG) {
            Log.w("AniwavesExtractor", "extractByfms: all 3 attempts failed for $host videoId=$videoId")
        }
        return null
    }

    // ── Shared response handling ───────────────────────────────────────────────

    /**
     * Decrypt/parse a sources response. Returns (sourcesArray, parsedRoot).
     * Handles: plain JSON, JSON whose `sources` is an encrypted base64 string
     * (CryptoJS passphrase via [StreamCrypto.opensslAesDecrypt], then raw-key
     * AES-ECB / AES-CBC fallbacks), and a raw non-JSON encrypted body.
     */
    private fun decryptResponse(txt: String, keys: List<String>): Pair<JsonArray, JsonObject>? {
        // Case 1: valid JSON envelope.
        val parsed = runCatching { json.parseToJsonElement(txt) }.getOrNull()
        if (parsed is JsonObject) {
            decryptSources(parsed, keys)?.let { return it to parsed }
            return null
        }
        if (parsed is JsonArray && parsed.isNotEmpty()) {
            return parsed to JsonObject(emptyMap())
        }
        // Case 2: raw encrypted body (backend wraps it as {encrypted:true,sources:<raw>}).
        val arr = decryptCiphertext(txt.trim(), keys, 0) ?: return null
        return arr to JsonObject(emptyMap())
    }

    private fun decryptSources(parsed: JsonObject, keys: List<String>): JsonArray? {
        val s = parsed["sources"]
        return when (s) {
            is JsonArray -> s.takeIf { it.isNotEmpty() }
            is JsonPrimitive -> decryptCiphertext(s.content, keys, 0)
            else -> null
        }
    }

    private fun decryptCiphertext(ct: String, keys: List<String>, depth: Int): JsonArray? {
        if (depth > 3 || ct.isBlank()) return null
        for (key in keys) {
            if (key.isBlank()) continue
            for (attempt in listOf(
                { StreamCrypto.opensslAesDecrypt(ct, key) },
                { StreamCrypto.aesEcbDecrypt(ct, key) },
                { StreamCrypto.aesCbcZeroIvDecrypt(ct, key) }
            )) {
                val dec = attempt() ?: continue
                when (val el = runCatching { json.parseToJsonElement(dec) }.getOrNull()) {
                    is JsonArray -> if (el.isNotEmpty()) return el
                    is JsonObject -> {
                        decryptSources(el, keys)?.let { return it }
                        el["sources"]?.let { inner ->
                            if (inner is JsonPrimitive) {
                                decryptCiphertext(inner.content, keys, depth + 1)?.let { return it }
                            }
                        }
                    }
                    else -> {}
                }
            }
        }
        return null
    }

    private fun sourcesToStream(sources: JsonArray, parsed: JsonObject, referer: String): Stream? {
        val files = sources.mapNotNull { fileOf(it) }
        val m3u8 = files.firstOrNull { it.contains(".m3u8", true) } ?: files.firstOrNull() ?: return null
        val subs = tracksToSubtitles(parsed["tracks"])
        val intro = skipObj(parsed["intro"])
        val outro = skipObj(parsed["outro"])
        val fmt = if (m3u8.contains(".m3u8", true)) "hls" else "mp4"
        val qual = if (fmt == "hls") "HLS" else "MP4"
        return Stream(m3u8, subs, intro, outro, referer, format = fmt, quality = qual)
    }

    private fun fileOf(el: JsonElement): String? = runCatching {
        val o = el.jsonObject
        o["file"]?.jsonPrimitive?.content ?: o["url"]?.jsonPrimitive?.content ?: o["src"]?.jsonPrimitive?.content
    }.getOrNull()?.takeIf { it.isNotBlank() }

    private fun tracksToSubtitles(el: JsonElement?): List<AniwavesApi.SubtitleTrack> {
        val arr = el as? JsonArray ?: return emptyList()
        // echovideo lists the same track 2-3x (ENG/FRE/SPA…). Dedupe by url+label,
        // keeping the first occurrence (the one marked default comes first).
        val seen = mutableSetOf<String>()
        return arr.mapNotNull { t ->
            runCatching {
                val o = t.jsonObject
                val kind = o["kind"]?.jsonPrimitive?.content ?: ""
                if (kind == "thumbnails" || kind == "preview") return@runCatching null
                val url = o["file"]?.jsonPrimitive?.content ?: o["src"]?.jsonPrimitive?.content ?: ""
                if (url.isBlank()) return@runCatching null
                val label = o["label"]?.jsonPrimitive?.content ?: "Unknown"
                if (!seen.add("$url|$label")) return@runCatching null
                val lang = label.lowercase().replace(Regex("\\s+"), "-")
                AniwavesApi.SubtitleTrack(lang, label, url)
            }.getOrNull()
        }
    }

    private fun skipObj(el: JsonElement?): Pair<Int, Int>? = runCatching {
        val o = el?.jsonObject ?: return@runCatching null
        val a = o["start"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
        val b = o["end"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
        (a to b).takeIf { it.first != 0 || it.second != 0 }
    }.getOrNull()

    private fun takeIfPair(p: Pair<Int, Int>?): Pair<Int, Int>? = p?.takeIf { it.first != 0 || it.second != 0 }
}
