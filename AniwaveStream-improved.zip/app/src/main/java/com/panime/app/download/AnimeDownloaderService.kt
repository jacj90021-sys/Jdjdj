package com.panime.app.download

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Port of Dantotsu's AnimeDownloaderService: a foreground service that drains a
 * task queue, hands each m3u8 to the FFmpeg download addon, reports progress in
 * the notification and writes a media.json sidecar next to the finished file.
 */
class AnimeDownloaderService : Service() {

    data class Task(
        val title: String,
        val episode: String,
        val videoUrl: String,
        val headers: Map<String, String>,
        val subtitles: List<Pair<String, String>> = emptyList(),
        val posterUrl: String? = null,
        val quality: String? = null,
        val serverLabel: String? = null,
        val anilistId: Int = 0
    ) {
        val taskName: String
            get() = "${DownloadsManager.sanitize(title)} - ${DownloadsManager.sanitize(episode)}"
    }

    private val ff by lazy { DownloadAddonLoader.get(this) }
    private lateinit var notificationManager: NotificationManagerCompat
    private lateinit var builder: NotificationCompat.Builder
    private val downloadsManager by lazy { DownloadsManager(this) }
    private var currentTask: Task? = null
    private var currentSession: Long = -1L

    /** Tasks the user explicitly cancelled — their catch-block must clear, not fail. */
    private val cancelledTasks =
        java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<String, Boolean>())

    private val cancelReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val name = i?.getStringExtra(EXTRA_TASK_NAME) ?: return
            cancelDownload(name)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        notificationManager = NotificationManagerCompat.from(this)
        builder = NotificationCompat.Builder(this, CHANNEL_ID).apply {
            setContentTitle("Anime Download")
            setSmallIcon(android.R.drawable.stat_sys_download)
            priority = NotificationCompat.PRIORITY_DEFAULT
            setOnlyAlertOnce(true)
            setProgress(100, 0, false)
            setOngoing(true)
        }
        // startForegroundService() contract: startForeground() MUST run within
        // ~5s even on the failure path — otherwise the OS kills the whole app
        // ("app closes itself" + in-RAM download queue wiped).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, builder.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, builder.build())
        }
        if (ff == null) {
            Toast.makeText(this, "Install the Dantotsu download addon first", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        ContextCompat.registerReceiver(
            this, cancelReceiver, IntentFilter(ACTION_CANCEL_DOWNLOAD),
            ContextCompat.RECEIVER_EXPORTED
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        // Keep queued tasks: the static queue survives and the next
        // startForegroundService (every enqueue issues one) drains it.
        runCatching { unregisterReceiver(cancelReceiver) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope.launch {
            // Single worker: extra start commands are no-ops while one drains.
            if (!workerActive.compareAndSet(false, true)) return@launch
            try {
                while (true) {
                    processQueue()
                    if (queue.isEmpty()) break
                }
            } finally {
                workerActive.set(false)
                persistQueue(this@AnimeDownloaderService)
            }
            withContext(Dispatchers.Main) { stopSelf() }
        }
        return START_NOT_STICKY
    }

    private suspend fun processQueue() {
        var notifiedPaused = false
        while (queue.isNotEmpty()) {
            // Per-task pause: individually-paused episodes are skipped; only
            // when EVERY queued task is paused does the worker idle.
            val task = pollNextPlayable()
            if (task == null) {
                if (!notifiedPaused) {
                    notifiedPaused = true
                    notifyText("Downloads paused")
                }
                delay(400)
                continue
            }
            notifiedPaused = false
            currentTask = task
            download(task)
            currentTask = null
            // The finished task was polled off the queue — snapshot the
            // remaining pending set so a crash never resurrects it.
            persistQueue(this@AnimeDownloaderService)
        }
    }

    /** Head-of-queue scan that defers paused tasks behind playable ones. */
    private fun pollNextPlayable(): Task? {
        repeat(queue.size) {
            val t = queue.poll() ?: return null
            if (t.taskName !in DownloadState.pausedTasks.value) return t
            queue.add(t)
        }
        return null
    }

    private fun notifyText(text: String, progress: Int? = null) {
        builder.setContentText(text)
        if (progress != null) builder.setProgress(100, progress.coerceIn(0, 100), false)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            == PackageManager.PERMISSION_GRANTED
        ) {
            notificationManager.notify(NOTIFICATION_ID, builder.build())
        }
    }

    private suspend fun download(task: Task) {
        val ff = ff ?: run {
            DownloadState.fail(task.taskName, "FFmpeg addon not loaded")
            return
        }
        try {
            withContext(Dispatchers.IO) {
                val episodeDir = downloadsManager.subDir(task.title, task.episode, create = true)
                    ?: throw Exception("No download folder chosen (My List > Downloads > CHOOSE)")
                // Never wipe a previous attempt's partial: SAF auto-uniquifies
                // the name ("… (1)", "… (2)") so every attempt coexists.
                val ext = runCatching { ff.getFileExtension() }.getOrDefault("mkv" to "video/x-matroska")
                val outputFile = episodeDir.createFile(ext.second, task.taskName)
                    ?: throw Exception("Failed to create output file")

                DownloadState.update(task.taskName, 0, task.posterUrl, task.quality, task.serverLabel)
                notifyText("Downloading ${task.taskName}", 0)

                var totalLength = 0.0
                val path = ff.setDownloadPath(this@AnimeDownloaderService, outputFile.uri)
                // A dead connection can hang the probe forever — cap it.
                try {
                    withTimeout(PROBE_TIMEOUT_MS) {
                        ff.executeFFProbe(
                            task.videoUrl,
                            task.headers + mapOf("User-Agent" to DEFAULT_UA)
                        ) { s -> s.toDoubleOrNull()?.let { totalLength = it } }
                    }
                } catch (e: TimeoutCancellationException) {
                    throw Exception("Stream info timed out — check your connection", e)
                }

                val headers = if (task.headers.any { it.key.equals("User-Agent", true) })
                    task.headers else task.headers + mapOf("User-Agent" to DEFAULT_UA)

                val latestStat = AtomicReference(0.0)
                val session = ff.executeFFMpeg(
                    task.videoUrl,
                    path,
                    headers,
                    task.subtitles,
                    emptyList()
                ) { seconds ->
                    latestStat.set(seconds)
                    if (seconds > 0 && totalLength > 0) {
                        val pct = ((seconds / 1000.0) / totalLength * 100).toInt()
                        val len = runCatching {
                            DocumentFile.fromSingleUri(this@AnimeDownloaderService, outputFile.uri)?.length() ?: 0L
                        }.getOrDefault(0L)
                        DownloadState.update(task.taskName, pct, bytes = len)
                        notifyText("Downloading ${task.taskName}", pct)
                    }
                }
                currentSession = session

                // Stall watchdog: when neither file size nor stream position
                // moves for STALL_TIMEOUT_MS, kill the session and fail —
                // otherwise a wedged FFmpeg state blocks the whole queue.
                var lastBytes = -1L
                var lastSeconds = -1.0
                var lastProgressMs = SystemClock.elapsedRealtime()
                while (ff.getState(session) != "COMPLETED") {
                    if (ff.getState(session) == "FAILED") throw Exception(ff.getStackTrace(session) ?: "FFmpeg failed")
                    val len = runCatching {
                        DocumentFile.fromSingleUri(this@AnimeDownloaderService, outputFile.uri)?.length() ?: 0L
                    }.getOrDefault(0L)
                    val secs = latestStat.get()
                    if (len != lastBytes || secs != lastSeconds) {
                        lastBytes = len
                        lastSeconds = secs
                        lastProgressMs = SystemClock.elapsedRealtime()
                    } else if (SystemClock.elapsedRealtime() - lastProgressMs > STALL_TIMEOUT_MS) {
                        runCatching { ff.cancelDownload(session) }
                        throw Exception("Download stalled — no progress for ${STALL_TIMEOUT_MS / 60000} min")
                    }
                    delay(2000)
                }
                if (ff.hadError(session)) throw Exception(ff.getStackTrace(session) ?: "FFmpeg error")

                saveMediaInfo(task, episodeDir)
                downloadsManager.addDownload(task.title, task.episode, task.posterUrl, task.quality, task.anilistId)
                DownloadState.complete(task.taskName)
                notifyText("${task.taskName} — completed", 100)
                builder.setProgress(0, 0, false)
            }
        } catch (e: Exception) {
            val wasCancelled = cancelledTasks.remove(task.taskName)
            if (wasCancelled || e.message?.contains("Coroutine was cancelled") == true) {
                // User-initiated cancel: the row was already cleared in the UI —
                // never resurrect it as a FAILED ghost.
                DownloadState.clear(task.taskName)
                notifyText("${task.taskName} — cancelled")
            } else {
                DownloadState.fail(task.taskName, e.message ?: "download failed")
                notifyText("${task.taskName} — failed: ${e.message?.take(80)}")
                Toast.makeText(this, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
            downloadsManager.removeDownload(task.title, task.episode)
        }
    }

    fun cancelDownload(taskName: String) {
        val ff = ff ?: return
        cancelledTasks.add(taskName)
        if (currentTask?.taskName == taskName && currentSession != -1L) {
            runCatching { ff.cancelDownload(currentSession) }
        }
        queue.removeAll { it.taskName == taskName }
        persistQueue(this)
    }

    /** media.json sidecar so an offline screen can list/play episodes later. */
    private fun saveMediaInfo(task: Task, dir: DocumentFile) {
        runCatching {
            dir.findFile("media.json")?.delete()
            val file = dir.createFile("application/json", "media.json") ?: return
            val json = JSONObject()
                .put("title", task.title)
                .put("episode", task.episode)
                .put("posterUrl", task.posterUrl ?: "")
                .put("file", "${task.taskName}")
            val subs = JSONArray()
            task.subtitles.forEach { subs.put(JSONObject().put("lang", it.first).put("url", it.second)) }
            json.put("subtitles", subs)
            contentResolver.openOutputStream(file.uri)?.use { it.write(json.toString().toByteArray()) }
        }
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Downloads", NotificationManager.IMPORTANCE_LOW)
                )
            }
        }
    }

    companion object {
        const val CHANNEL_ID = "download_progress"
        const val NOTIFICATION_ID = 4242
        const val ACTION_CANCEL_DOWNLOAD = "com.panime.app.action.CANCEL_DOWNLOAD"
        const val EXTRA_TASK_NAME = "task_name"
        private const val DEFAULT_UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
        private const val PROBE_TIMEOUT_MS = 120_000L
        private const val STALL_TIMEOUT_MS = 10 * 60_000L

        // Dantotsu-style singleton queue shared between UI and service.
        val queue = ConcurrentLinkedQueue<Task>()

        /** True while a processQueue loop is draining; guards single-worker. */
        private val workerActive = AtomicBoolean(false)

        // ── Queue persistence ────────────────────────────────────────────
        // The live queue is RAM-only: a crash or process death used to wipe
        // every queued episode ("download queue gone" bug). The snapshot in
        // prefs is rewritten after every queue change and rehydrated by
        // [restorePending] on app start / Downloads screen open.

        private const val QUEUE_PREFS = "download_queue"
        private const val QUEUE_KEY = "pending_tasks"

        fun enqueue(context: Context, task: Task) {
            if (queue.none { it.taskName == task.taskName }) {
                queue.offer(task)
                persistQueue(context)
            }
            // Always start: idempotent, and removes any stale "running" state.
            val intent = Intent(context, AnimeDownloaderService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        /** Snapshot the live queue to disk (never throws). */
        fun persistQueue(context: Context) {
            runCatching {
                val arr = JSONArray()
                queue.forEach { t -> arr.put(taskToJson(t)) }
                context.getSharedPreferences(QUEUE_PREFS, Context.MODE_PRIVATE)
                    .edit().putString(QUEUE_KEY, arr.toString()).apply()
            }
        }

        private fun taskToJson(t: Task): JSONObject {
            val headers = JSONObject()
            t.headers.forEach { (k, v) -> headers.put(k, v) }
            val subs = JSONArray()
            t.subtitles.forEach { (lang, url) ->
                subs.put(JSONObject().put("lang", lang).put("url", url))
            }
            return JSONObject()
                .put("title", t.title)
                .put("episode", t.episode)
                .put("videoUrl", t.videoUrl)
                .put("headers", headers)
                .put("subtitles", subs)
                .put("posterUrl", t.posterUrl ?: "")
                .put("quality", t.quality ?: "")
                .put("serverLabel", t.serverLabel ?: "")
                .put("anilistId", t.anilistId)
        }

        private fun taskFromJson(o: JSONObject): Task? = runCatching {
            val headers = buildMap {
                val h = o.optJSONObject("headers") ?: JSONObject()
                h.keys().forEach { k -> put(k, h.optString(k)) }
            }
            val subs = buildList {
                val s = o.optJSONArray("subtitles")
                for (i in 0 until (s?.length() ?: 0)) {
                    val so = s!!.optJSONObject(i) ?: continue
                    add(so.optString("lang") to so.optString("url"))
                }
            }
            Task(
                title = o.optString("title"),
                episode = o.optString("episode"),
                videoUrl = o.optString("videoUrl"),
                headers = headers,
                subtitles = subs,
                posterUrl = o.optString("posterUrl").ifBlank { null },
                quality = o.optString("quality").ifBlank { null },
                serverLabel = o.optString("serverLabel").ifBlank { null },
                anilistId = o.optInt("anilistId", 0)
            )
        }.getOrNull()

        /**
         * Rehydrates tasks persisted by [persistQueue] into the live queue and
         * re-seeds their progress rows so they show up as queued immediately.
         * Returns true when anything was restored; does NOT start the service
         * (background starts of a foreground service are restricted) — callers
         * in a foreground screen should kick it via [resumePending].
         */
        fun restorePending(context: Context): Boolean {
            val stored = context.getSharedPreferences(QUEUE_PREFS, Context.MODE_PRIVATE)
                .getString(QUEUE_KEY, null) ?: return false
            val arr = runCatching { JSONArray(stored) }.getOrNull() ?: return false
            var restoredAny = false
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val t = taskFromJson(o) ?: continue
                if (queue.any { it.taskName == t.taskName }) continue
                // Already-completed episodes must not resurrect from a stale
                // snapshot (completion may not have been persisted pre-crash).
                if (DownloadsManager(context).queryDownload(t.title, t.episode)) continue
                queue.offer(t)
                DownloadState.update(t.taskName, 0, t.posterUrl, t.quality, t.serverLabel)
                restoredAny = true
            }
            if (restoredAny) persistQueue(context)
            return restoredAny
        }

        /** Foreground-only helper: restarts the worker for restored tasks. */
        fun resumePending(context: Context) {
            if (queue.isEmpty()) return
            runCatching {
                val intent = Intent(context, AnimeDownloaderService::class.java)
                ContextCompat.startForegroundService(context, intent)
            }
        }
    }
}
