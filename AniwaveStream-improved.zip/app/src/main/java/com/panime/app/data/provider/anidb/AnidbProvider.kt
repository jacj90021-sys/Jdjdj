package com.panime.app.data.provider.anidb

import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.model.PagedResult
import com.panime.app.data.provider.ResolveResult
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.data.provider.SearchableProvider
import com.panime.app.data.provider.StreamProvider
import com.panime.app.util.Obf
import java.net.URLEncoder

/**
 * On-device AniDB provider (replaces the backend-only AnidbBackend).
 *
 * VERIFIED this session (live, plain requests, no curl_cffi / no impersonation):
 *   suggestions -> /api/frontend/anime/<id>/episodes -> /api/frontend/episode/<epId>/languages
 *   -> /embed/<embedId> -> hls.anidb.app/stream/.../master.m3u8 (HTTP 200)
 *
 * anidb.app's data endpoints are NOT behind an interactive Cloudflare challenge
 * from a normal TLS client — a plain OkHttp request clears them (confirmed). So
 * this is a normal HTTP provider, exactly like AniKage/Just4Anime: no WebView,
 * no TLS impersonation, no native libs. Heavy/fragile WebView approach dropped.
 *
 * Discovery chain (server-rendered + JSON APIs):
 *   1. GET /search/suggestions?q=<title>  -> HTML link /anime/<slug>-<id>
 *   2. GET /api/frontend/anime/<id>/episodes -> episode id for <episode>
 *   3. GET /api/frontend/episode/<epId>/languages -> embed_url (per lang)
 *   4. GET /embed/<embedId> -> HTML containing hls.anidb.app/.../master.m3u8
 *
 * The final m3u8 host (hls.anidb.app) is itself open.
 */
class AnidbProvider : StreamProvider, SearchableProvider {

    override val id = "anidb"
    override val label = "DB"
    override val backendRequired = false

    // ===================== Wrong-title support (additive) =====================
    // Uses the site's BROWSE page (/browse?q=&page=) — real pagination, full
    // cards. The user's pick ("<slug>-<id>") is used DIRECTLY; the default
    // resolve() suggestions flow above is never consulted on this path.

    override suspend fun search(query: String): List<StreamProvider.SearchHit> =
        searchPage(query, 1).items

    override suspend fun searchPage(query: String, page: Int): PagedResult<StreamProvider.SearchHit> {
        if (query.isBlank()) return PagedResult(emptyList(), 1)
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        val headers = ScraperEngine.defaultHeaders(referer = Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1"))
        val html = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1OCg1LSk/ZStn") + "$q&page=$page", headers
        ) ?: return PagedResult(emptyList(), page.coerceAtLeast(1))

        // Cards are server-rendered anchors:
        //   <a href="https://anidb.app/anime/<slug>-<id>" class="anime-card ..." title="Title">
        //     <img src="poster" ...>
        val hits = ArrayList<StreamProvider.SearchHit>()
        val marker = Obf.s("Zjt6Mig/PGd4Mi4uKilgdXU7NDM+OHQ7Kip1OzQzNz91")
        for (seg in html.split(marker).drop(1)) {
            val head = seg.take(1200)
            val m = Regex("""([a-z0-9\-]+)-(\d+)""").find(head) ?: continue
            val slugId = "${m.groupValues[1]}-${m.groupValues[2]}"
            val title = Regex("""title="([^"]*)"""").find(head)
                ?.groupValues?.get(1)
                ?: m.groupValues[1].replace('-', ' ')
            val poster = Regex("""<img src="([^"]+)"""").find(head)?.groupValues?.get(1)
                ?.takeIf { it.startsWith("http") }
            hits.add(
                StreamProvider.SearchHit(
                    title = title,
                    slug = slugId,
                    posterUrl = poster
                )
            )
        }
        // Pagination: anidb renders a "Page X of Y" indicator plus Prev/Next.
        // Next is a DISABLED <span> on the last page and Prev is the only href
        // there, so href-scanning alone collapses lastPage back to 1. Parse the
        // authoritative "of Y" number first, fall back to (and max with) hrefs.
        val ofY = Regex("""Page\s*<span[^>]*>\s*\d+\s*</span>\s*of\s*<span[^>]*>\s*(\d+)\s*</span>""")
            .find(html)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        val hrefMax = Regex("""[?&]page=(\d+)""").findAll(html)
            .mapNotNull { it.groupValues[1].toIntOrNull() }.maxOrNull() ?: 0
        val lastPage = maxOf(ofY, hrefMax, page).coerceAtLeast(1)
        return PagedResult(hits.distinctBy { it.slug }, lastPage)
    }

    /** Wrong-title resolution: [slug] is the picked "<slug>-<id>" entry. */
    override suspend fun resolveWithSlug(
        slug: String,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int
    ): ResolveResult? {
        val animeId = slug.substringAfterLast('-')
        if (animeId.toIntOrNull() == null) return null
        return resolveById(animeId, episode, type)
    }

    /**
     * Real per-episode language codes straight from anidb.app (ON-DEVICE, no
     * backend): episodes API -> /api/frontend/episode/<epId>/languages -> codes
     * (eng/jpn). Handles the cour/season numbering offset exactly like
     * [resolveById]. Returns emptyList on any failure.
     */
    fun languageCodesForEpisode(animeId: String, episode: Int): List<String> {
        val headers = ScraperEngine.defaultHeaders(referer = Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1"))
        val epsJson = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1OyozdTwoNTQuPzQ+dTs0Mzc/dQ==") + "$animeId/episodes", headers
        )?.let { runCatching { org.json.JSONObject(it) }.getOrNull() } ?: return emptyList()
        val eps = epsJson.optJSONArray("episodes") ?: return emptyList()
        if (eps.length() == 0) return emptyList()

        // Match by site number, honoring the continuous numbering offset.
        val firstNum = eps.optJSONObject(0)?.optInt("number", -1) ?: -1
        val offset = if (firstNum > 1) firstNum - 1 else 0
        val siteEp = episode + offset
        var epId: String? = null
        for (i in 0 until eps.length()) {
            val e = eps.optJSONObject(i) ?: continue
            if (e.optInt("number", -1) == siteEp) { epId = e.optString("id"); break }
        }
        if (epId.isNullOrBlank()) return emptyList()

        val langsJson = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1OyozdTwoNTQuPzQ+dT8qMyk1Pj91") + "$epId/languages", headers
        )?.let { runCatching { org.json.JSONObject(it) }.getOrNull() } ?: return emptyList()
        val langs = langsJson.optJSONArray("languages") ?: return emptyList()
        val codes = ArrayList<String>(langs.length())
        for (i in 0 until langs.length()) {
            val l = langs.optJSONObject(i) ?: continue
            l.optString("code").takeIf { it.isNotBlank() }?.let { codes.add(it) }
        }
        return codes
    }

    /** Episode count for a picked "<slug>-<id>" entry (episodes API array size). */
    fun episodeCountForPick(pick: String): Int {
        val id = pick.substringAfterLast('-')
        if (id.toIntOrNull() == null) return 0
        val headers = ScraperEngine.defaultHeaders(referer = Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1"))
        val json = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1OyozdTwoNTQuPzQ+dTs0Mzc/dQ==") + "$id/episodes", headers
        ) ?: return 0
        val eps = runCatching {
            org.json.JSONObject(json).optJSONArray("episodes")
        }.getOrNull() ?: return 0
        return eps.length()
    }

    /**
     * Resolve the best-matching anidb.app anime id for a title (on-device
     * suggestions search). anidb fragments a series into one entry per
     * cour/season; the app's title is the BASE title (AniList drops the season
     * from the title string), so " Season N" is appended for cours like
     * [resolve] does. Returns null when nothing matches.
     */
    fun animeIdFor(title: String, seasonNumber: Int): String? {
        val seasonQ = if (seasonNumber > 1) " Season $seasonNumber" else ""
        val q = URLEncoder.encode(title + seasonQ, "UTF-8")
        val headers = ScraperEngine.defaultHeaders(referer = Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1"))
        val sug = ScraperEngine.fetchText(Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1KT87KDkydSkvPT0/KS4zNTQpZStn") + "$q", headers)
            ?: return null
        val slugIds = Regex("""/anime/([a-z0-9\\-]+)-(\d+)""").findAll(sug)
            .map { it.groupValues[1] to it.groupValues[2] }.toList()
        return if (seasonNumber > 1) {
            slugIds.firstOrNull { s -> Regex("""season-$seasonNumber\b|season-$seasonNumber""").containsMatchIn(s.first) }?.second
                ?: slugIds.firstOrNull()?.second
        } else {
            slugIds.firstOrNull()?.second
        }
    }

    /**
     * Real per-episode (code, name) language entries straight from anidb.app's
     * languages API — the same data the old backend served as the download
     * sheet's server choices ("eng"→"English", "jpn"→"Japanese"). Handles the
     * cour/season numbering offset exactly like [resolveById]. Empty on failure.
     */
    fun languageEntriesForEpisode(animeId: String, episode: Int): List<Pair<String, String>> {
        val headers = ScraperEngine.defaultHeaders(referer = Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1"))
        val epsJson = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1OyozdTwoNTQuPzQ+dTs0Mzc/dQ==") + "$animeId/episodes", headers
        )?.let { runCatching { org.json.JSONObject(it) }.getOrNull() } ?: return emptyList()
        val eps = epsJson.optJSONArray("episodes") ?: return emptyList()
        if (eps.length() == 0) return emptyList()
        val firstNum = eps.optJSONObject(0)?.optInt("number", -1) ?: -1
        val offset = if (firstNum > 1) firstNum - 1 else 0
        val siteEp = episode + offset
        var epId: String? = null
        for (i in 0 until eps.length()) {
            val e = eps.optJSONObject(i) ?: continue
            if (e.optInt("number", -1) == siteEp) { epId = e.optString("id"); break }
        }
        if (epId.isNullOrBlank()) return emptyList()
        val langsJson = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1OyozdTwoNTQuPzQ+dT8qMyk1Pj91") + "$epId/languages", headers
        )?.let { runCatching { org.json.JSONObject(it) }.getOrNull() } ?: return emptyList()
        val langs = langsJson.optJSONArray("languages") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>(langs.length())
        for (i in 0 until langs.length()) {
            val l = langs.optJSONObject(i) ?: continue
            val code = l.optString("code").takeIf { it.isNotBlank() } ?: continue
            val name = l.optString("name").takeIf { it.isNotBlank() }
                ?: when (code.lowercase()) {
                    "eng" -> "English"
                    "jpn" -> "Japanese"
                    else -> code
                }
            out.add(code to name)
        }
        return out
    }

    override suspend fun resolve(
        title: String,
        anilistId: Int,
        episode: Int,
        type: String,
        serverCode: String?,
        seasonNumber: Int,
        totalEpisodes: Int,
        year: Int?
    ): ResolveResult? {
        // anidb fragments a series into one entry per cour/season. The app's title
        // is the BASE title (AniList drops the season from the title string), so we
        // must append the season to the query or anidb returns the base S1 entry and
        // we end up playing the wrong cour. anidb's search understands "Season N".
        val animeId = animeIdFor(title, seasonNumber) ?: return null
        return resolveById(animeId, episode, type)
    }

    /**
     * Shared resolution chain from a known anime id: episodes -> languages ->
     * embed -> m3u8. Used by BOTH the default flow (after suggestions search)
     * and the wrong-title flow (with the picked id). Logic identical to the
     * original inline implementation.
     */
    private fun resolveById(animeId: String, episode: Int, type: String): ResolveResult? {
        val headers = ScraperEngine.defaultHeaders(referer = Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1"))

        // 2. episodes
        val epsJson = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1OyozdTwoNTQuPzQ+dTs0Mzc/dQ==") + "$animeId/episodes", headers
        )?.let { runCatching { org.json.JSONObject(it) }.getOrNull() } ?: return null
        val eps = epsJson.optJSONArray("episodes") ?: return null
        if (eps.length() == 0) return null
        // Find the episode whose `number` matches. Do NOT silently fall back to
        // ep1 of the wrong cour — if it isn't here, return null so the player can
        // surface "episode not found" instead of playing the wrong anime.
        //
        // anidb numbers episodes as a continuous sequence across the parent series
        // (e.g. Bleach TYBW "The Calamity" starts at ep 41 because original Bleach
        // had 399 eps). Detect this offset: if the first episode's number > 1, the
        // app's episode N maps to site episode (N + offset).
        val firstNum = eps.optJSONObject(0)?.optInt("number", -1) ?: -1
        val offset = if (firstNum > 1) firstNum - 1 else 0
        val siteEp = episode + offset
        var epId: String? = null
        for (i in 0 until eps.length()) {
            val e = eps.optJSONObject(i) ?: continue
            if (e.optInt("number", -1) == siteEp) { epId = e.optString("id"); break }
        }
        if (epId.isNullOrBlank()) return null

        // 3. languages -> embed url
        val langsJson = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1OyozdTwoNTQuPzQ+dT8qMyk1Pj91") + "$epId/languages", headers
        )?.let { runCatching { org.json.JSONObject(it) }.getOrNull() } ?: return null
        val langs = langsJson.optJSONArray("languages") ?: return null
        if (langs.length() == 0) return null
        val want = if (type == "dub") "eng" else "jpn"
        var embedUrl: String? = null
        for (i in 0 until langs.length()) {
            val l = langs.optJSONObject(i) ?: continue
            if (l.optString("code") == want) { embedUrl = l.optString("embed_url"); break }
            if (embedUrl == null) embedUrl = l.optString("embed_url")
        }
        if (embedUrl.isNullOrBlank()) return null
        val embedId = embedUrl.trimEnd('/').substringAfterLast('/')

        // 4. embed page -> m3u8 (+ best-effort subtitle tracks from the page —
        // the embed stack is the same producer as wave's BYFMS, whose payload
        // carries a tracks[] array; parse defensively, empty when absent).
        val html = ScraperEngine.fetchText(Obf.s("Mi4uKilgdXU7NDM+OHQ7Kip1Pzc4Pz51") + "$embedId", headers)
            ?: return null
        val m = Regex(Obf.s("Mi4uKillYHV1MjYpBnQ7NDM+OAZ0OyoqdSkuKD87N3UBBAYpeH1mZAdxBnQ3aS9i")).find(html)
            ?: return null
        val m3u8 = m.value

        val seen = mutableSetOf<String>()
        val subs = Regex("\\\"file\\\"\\s*:\\s*\\\"([^\\\"]+\\.(?:vtt|srt))\\\"[^}]*?\\\"label\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"")
            .findAll(html)
            .mapNotNull { mm ->
                val url = mm.groupValues[1]
                val label = mm.groupValues[2]
                if (!seen.add("$url|$label")) return@mapNotNull null
                AniwavesApi.SubtitleTrack(label.lowercase().replace(Regex("\\s+"), "-"), label, url)
            }
            .toList()

        return ResolveResult(
            source = id,
            servers = listOf("anidb" to "AniDB"),
            url = m3u8,
            rawUrl = m3u8,
            referer = Obf.s("Mi4uKilgdXUyNil0OzQzPjh0OyoqdQ=="),
            format = "hls",
            subtitles = subs,
            notFound = false
        )
    }
}
