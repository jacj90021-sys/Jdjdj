package com.panime.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Looper
import android.util.Log
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.intercept.Interceptor
import coil.request.ImageResult
import com.google.firebase.FirebaseApp
import com.panime.app.data.auth.SecureTokenStore
import com.panime.app.data.provider.ProviderInitializer
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.data.repository.UserLibraryStore
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AniwaveApp : Application(), ImageLoaderFactory {
    lateinit var repository: AnimeRepository
        private set
    lateinit var library: UserLibraryStore
        private set
    lateinit var tokenStore: SecureTokenStore
        private set

    override fun onCreate() {
        super.onCreate()
        repository = AnimeRepository()
        library = UserLibraryStore(this)
        tokenStore = SecureTokenStore(this)
        ProviderInitializer.init(this)
        com.panime.app.ad.AdManager.init(this)

        // Rehydrate any download-queue snapshot from a previous crash/process
        // death so queued episodes reappear instead of silently vanishing.
        // The worker itself restarts on the next foreground visit or enqueue
        // (background FGS starts are restricted); see DownloadsScreen.
        com.panime.app.download.AnimeDownloaderService.restorePending(this)

        // Keep the repository's active data source in sync with the persisted
        // API Provider preference (ANILIST / KOTO). Drives every browse/search/detail call.
        ProcessLifecycleOwner.get().lifecycleScope.launch {
            library.apiProvider.collectLatest { repository.provider = it }
        }

        // Firebase: Crashlytics + Analytics + Messaging + Performance.
        // Guarded so the placeholder google-services.json never crashes the app;
        // with the real file it activates on first launch. Remote Config is NOT
        // used — the update check reads GitHub releases directly (see
        // GitHubUpdater), so a stale RC override can never block an update.
        runCatching {
            if (FirebaseApp.getApps(this).isEmpty()) FirebaseApp.initializeApp(this)
            // Default FCM channel — incoming pushes fall back here.
            runCatching {
                val nm = getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel("general") == null) {
                    nm.createNotificationChannel(
                        NotificationChannel("general", "General", NotificationManager.IMPORTANCE_DEFAULT)
                    )
                }
            }
        }.onFailure { Log.w("AniwaveApp", "Firebase init skipped: ${it.message}") }

        // Crash capture: save the stack trace to disk (shown with a COPY button
        // on next launch) AND keep the diagnostics logging below. The previous
        // handler force-restarted the launcher activity on ANY main-thread
        // throw — including transient player glitches — which made the app
        // appear to "close itself" / jump to home. That masking was removed;
        // crashes now behave normally, but are also recoverable for debugging.
        CrashReporter.install(this)
        com.panime.app.download.DownloadCenter.init(this)
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            android.util.Log.e("AniwaveApp", "Uncaught exception on ${thread.name}", throwable)
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    /**
     * Rule 8 — Advanced image caching polish.
     * A single global ImageLoader with crossfade enabled so grid/list scrolling
     * never shows sharp, jarring image snaps. Memory + disk caches keep massive
     * anime grids buttery on re-scroll.
     */
    override fun newImageLoader(): ImageLoader {
        // AniList's CDN (s4.anilist.co) can reject hotlinked posters without a
        // Referer. Add one via a Coil Interceptor (works on the base coil-compose
        // artifact; no coil-okhttp dependency required).
        val refererInterceptor = Interceptor { chain ->
            val data = chain.request.data.toString()
            val referer = when {
                data.contains("static.aniwaves.ru") -> "https://aniwaves.ru/"
                data.contains("anilist.co") -> "https://anilist.co/"
                else -> "https://anilist.co/"
            }
            val request = chain.request.newBuilder()
                .setHeader("Referer", referer)
                .setHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .build()
            chain.proceed(request)
        }
        return ImageLoader.Builder(this)
            .crossfade(220)
            .placeholder(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizePercent(0.03)
                    .build()
            }
            .respectCacheHeaders(false)
            .components { add(refererInterceptor) }
            .build()
    }
}
