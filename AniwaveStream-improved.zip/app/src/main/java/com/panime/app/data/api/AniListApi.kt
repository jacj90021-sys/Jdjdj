package com.panime.app.data.api

import kotlin.math.roundToInt
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import okhttp3.MediaType.Companion.toMediaType
import com.panime.app.data.network.HttpClient
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import android.util.Log
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import com.panime.app.BuildConfig
import com.panime.app.data.repository.RateLimitException
import org.json.JSONArray
import org.json.JSONObject

/**
 * Minimal AniList GraphQL client (https://graphql.anilist.co).
 *
 * No auth required for public media queries. We use a plain OkHttp POST (not
 * Retrofit) because GraphQL is a single endpoint with a JSON body — this keeps
 * the dependency surface small and reuses the same OkHttp/serialization stack
 * the app already ships.
 */
object AniListApi {
    private const val BASE = "https://graphql.anilist.co"

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    private val client = HttpClient.shared.newBuilder()
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                // AniList gated the GraphQL API to browser-origin requests during
                // their stability issues (403 "temporarily disabled" otherwise).
                // Send a browser disguise so the app keeps working: real UA +
                // Origin/Referer from the anilist.co website.
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36")
                .header("Origin", "https://anilist.co")
                .header("Referer", "https://anilist.co/")
                .build()
            chain.proceed(req)
        }
        .build()

    /** POST a GraphQL [query] with variables built via [buildVars]. */
    fun query(query: String, buildVars: VariableBuilder.() -> Unit = {}): String =
        query(query, null, buildVars)

    /**
     * Auth-aware POST. When [authToken] is non-null, sends `Authorization: Bearer`.
     * Required for viewer-scoped queries (e.g. the user's own media list).
     */
    fun query(query: String, authToken: String?, buildVars: VariableBuilder.() -> Unit = {}): String {
        val varsJson = buildJsonObject { VariableBuilder(this).apply(buildVars) }
        val body = buildJsonObject {
            put("query", JsonPrimitive(query))
            put("variables", varsJson)
        }
        val request = Request.Builder()
            .url(BASE)
            .post(json.encodeToString(JsonObject.serializer(), body).toRequestBody("application/json".toMediaType()))
            .apply { if (!authToken.isNullOrBlank()) header("Authorization", "Bearer $authToken") }
            .build()
        val maxAttempts = 4
        var attempt = 0
        while (true) {
            attempt++
            client.newCall(request).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                val code = resp.code
                if (resp.isSuccessful) return text
                if (BuildConfig.DEBUG) {
                    Log.w("AniListApi", "HTTP $code on attempt $attempt: ${text.take(200)}")
                }
                if (code == 429 && attempt < maxAttempts) {
                    val retryAfter = resp.headers["Retry-After"]?.toLongOrNull()
                    val waitMs = ((retryAfter ?: 0L) * 1000L).coerceAtLeast(attempt * 1500L).coerceAtMost(15000L)
                    if (BuildConfig.DEBUG) {
                        Log.w("AniListApi", "HTTP 429, backing off ${waitMs}ms (attempt $attempt/$maxAttempts)")
                    }
                    runBlocking { delay(waitMs) }
                    return@use
                }
                if (code == 429) throw RateLimitException("AniList HTTP 429 (attempt $attempt)")
                if (code >= 500 && attempt < maxAttempts) {
                    val retryAfter = resp.headers["Retry-After"]?.toLongOrNull()
                    val waitMs = ((retryAfter ?: 0L) * 1000L).coerceAtLeast(attempt * 1000L).coerceAtMost(8000L)
                    runBlocking { delay(waitMs) }
                    return@use
                }
                throw RuntimeException("AniList HTTP $code: ${text.take(200)}")
            }
        }
    }

    private val FETCH_VIEWER_ID_Q = """
        query { Viewer { id name } }
    """.trimIndent()

    private val FETCH_MEDIA_LIST_Q = """
        query FetchMediaList(${'$'}userId: Int, ${'$'}page: Int, ${'$'}perPage: Int) {
          Page(page: ${'$'}page, perPage: ${'$'}perPage) {
            pageInfo { hasNextPage }
            mediaList(userId: ${'$'}userId, type: ANIME, sort: UPDATED_TIME_DESC) {
              status
              progress
              score(format: POINT_10_DECIMAL)
              media { id title { romaji english } }
            }
          }
        }
    """.trimIndent()

    /** Resolve the connected viewer's AniList user id. Returns null if the token is invalid. */
    fun fetchViewerId(accessToken: String): Int? {
        val text = query(FETCH_VIEWER_ID_Q, accessToken)
        val root = JSONObject(text)
        if (root.has("errors")) {
            val err = root.optJSONArray("errors")?.optJSONObject(0)
            throw RuntimeException("AniList Viewer error: ${err?.optString("message") ?: text.take(200)}")
        }
        return root.optJSONObject("data")
            ?.optJSONObject("Viewer")
            ?.optInt("id", 0)
            ?.takeIf { it > 0 }
    }

    /**
     * Fetch every anime in the connected user's AniList media list (ALL statuses),
     * paging until exhausted. Requires the viewer's user id (resolved internally),
     * because AniList's Page.mediaList needs an explicit userId — querying without
     * it returns an empty list (the original "0 sync" bug).
     *
     * @param accessToken bearer token from the implicit OAuth flow
     * @param chunk pageSize (AniList caps at 50 per page)
     */
    fun fetchViewerMediaList(accessToken: String, chunk: Int = 50): List<AniListMediaListEntry> {
        val viewerId = fetchViewerId(accessToken)
            ?: throw RuntimeException("AniList: could not resolve Viewer id (token may be invalid)")
        val out = mutableListOf<AniListMediaListEntry>()
        var page = 1
        while (true) {
            val text = query(
                FETCH_MEDIA_LIST_Q,
                accessToken
            ) {
                int("userId", viewerId)
                int("page", page)
                int("perPage", chunk)
            }
            val root = JSONObject(text)
            if (root.has("errors")) {
                val err = root.optJSONArray("errors")?.optJSONObject(0)
                throw RuntimeException("AniList mediaList error: ${err?.optString("message") ?: text.take(200)}")
            }
            val data = root.optJSONObject("data") ?: break
            val pageObj = data.optJSONObject("Page") ?: break
            val arr = pageObj.optJSONArray("mediaList") ?: break
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) {
                val entry = arr.optJSONObject(i) ?: continue
                val media = entry.optJSONObject("media") ?: continue
                val id = media.optInt("id", 0)
                if (id <= 0) continue
                out += AniListMediaListEntry(
                    id = id,
                    status = entry.optString("status").orEmpty(),
                    progress = entry.optInt("progress", 0),
                    score = entry.optDouble("score", 0.0).takeIf { it > 0.0 }
                )
            }
            val hasNext = pageObj.optJSONObject("pageInfo")?.optBoolean("hasNextPage", false) ?: false
            if (!hasNext) break
            page++
        }
        return out
    }

    /** Normalized AniList media-list entry. */
    data class AniListMediaListEntry(
        val id: Int,
        val status: String,
        val progress: Int,
        val score: Double?
    )

    /** Map AniList media-list status -> app status label used by List Editor + filters. */
    fun anilistStatusToApp(status: String): String = when (status) {
        "CURRENT" -> "Watching"
        "COMPLETED" -> "Completed"
        "PAUSED" -> "Paused"
        "PLANNING" -> "Plan to Watch"
        "REPEATING" -> "Rewatching"
        "DROPPED" -> "Dropped"
        else -> "Plan to Watch"
    }

    /** Reverse map: app status label -> AniList MediaListStatus enum value. */
    fun appStatusToAnilist(status: String): String = when (status) {
        "Watching" -> "CURRENT"
        "Completed" -> "COMPLETED"
        "Paused" -> "PAUSED"
        "Plan to Watch" -> "PLANNING"
        "Rewatching" -> "REPEATING"
        "Dropped" -> "DROPPED"
        else -> "PLANNING"
    }

    private val SAVE_MEDIA_LIST_Q = """
        mutation SaveMediaListEntry(${'$'}mediaId: Int, ${'$'}status: MediaListStatus, ${'$'}progress: Int, ${'$'}scoreRaw: Int) {
          SaveMediaListEntry(mediaId: ${'$'}mediaId, status: ${'$'}status, progress: ${'$'}progress, scoreRaw: ${'$'}scoreRaw) {
            id
            status
            progress
            score(format: POINT_10_DECIMAL)
          }
        }
    """.trimIndent()

    /**
     * Push a single anime's list entry back to the connected AniList account
     * (status / progress / score). Mirrors Dantotsu's editList: AniList takes a
     * raw 0-100 score (scoreRaw), so a 0-10 app score is scaled by 10.
     *
     * @return true if AniList accepted the save, false if there was nothing to do.
     * @throws RuntimeException if AniList returns a GraphQL errors block.
     */
    fun saveMediaListEntry(
        accessToken: String,
        mediaId: Int,
        status: String,
        progress: Int,
        score: Double?
    ): Boolean {
        if (mediaId <= 0) return false
        val text = query(SAVE_MEDIA_LIST_Q, accessToken) {
            int("mediaId", mediaId)
            str("status", appStatusToAnilist(status))
            int("progress", progress)
            // App score is 0-10; AniList scoreRaw is 0-100. Dantotsu only sends
            // scoreRaw when a score is actually set — sending 0 forces a 0 score
            // on AniList even when the user left it blank, so omit it when null.
            score?.let { int("scoreRaw", (it * 10.0).roundToInt().coerceIn(0, 100)) }
        }
        val root = JSONObject(text)
        if (root.has("errors")) {
            val err = root.optJSONArray("errors")?.optJSONObject(0)
            throw RuntimeException("AniList save error: ${err?.optString("message") ?: text.take(200)}")
        }
        return root.optJSONObject("data")?.optJSONObject("SaveMediaListEntry") != null
    }

    /** Fluent builder for GraphQL variables backed by a kotlinx [buildJsonObject]. */
    class VariableBuilder(private val obj: kotlinx.serialization.json.JsonObjectBuilder) {
        fun int(key: String, value: Int) = obj.put(key, value)
        fun str(key: String, value: String) = obj.put(key, value)
        fun strOrNull(key: String, value: String?) = value?.let { obj.put(key, it) }
        fun intOrNull(key: String, value: Int?) = value?.let { obj.put(key, it) }
        fun float(key: String, value: Float) = obj.put(key, value)
        fun floatOrNull(key: String, value: Float?) = value?.let { obj.put(key, it) }
        fun list(key: String, values: List<String>) = obj.putJsonArray(key) {
            values.forEach { add(JsonPrimitive(it)) }
        }
        }
}
