package com.panime.app.ui.mylist

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import kotlin.math.roundToInt
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panime.app.R
import com.panime.app.data.model.Anime
import com.panime.app.ui.theme.Danger
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.Ink
import com.panime.app.ui.theme.InkFaint
import com.panime.app.ui.theme.InkSoft
import com.panime.app.ui.theme.Paper
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised

// ---- AnimeX typefaces ----
private val SpaceGrotesk = FontFamily(
    Font(R.font.anton, FontWeight.W400),
    Font(R.font.anton, FontWeight.W700)
)
private val JetBrains = FontFamily(
    Font(R.font.jetbrains_mono, FontWeight.W500),
    Font(R.font.jetbrains_mono, FontWeight.W600)
)
private val InterF = FontFamily(
    Font(R.font.inter, FontWeight.W400),
    Font(R.font.inter, FontWeight.W500),
    Font(R.font.inter, FontWeight.W600)
)

private val STATUSES = listOf(
    "Watching",
    "Completed",
    "Paused",
    "Plan to Watch",
    "Rewatching",
    "Dropped"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListEditorSheet(
    anime: Anime,
    initialStatus: String = "Plan to Watch",
    initialProgress: Int = 0,
    initialScore: Double? = null,
    onDismiss: () -> Unit,
    onSave: (status: String, progress: Int, score: Double?) -> Unit,
    onDelete: () -> Unit
) {
    var status by remember { mutableStateOf(initialStatus) }
    var progress by remember { mutableIntStateOf(initialProgress.coerceAtLeast(0)) }
    var score by remember { mutableFloatStateOf((initialScore ?: 0.0).toFloat()) }
    var scoreSet by remember { mutableStateOf(initialScore != null) }

    // Resolve theme colors once so nested non-@Composable blocks can reuse them.
    val SheetBg = Paper
    val SheetSurface = Surface
    val SheetSurface2 = SurfaceRaised
    val SheetLine = Hairline
    val Orange = Flame
    val OrangeDim = Flame.copy(alpha = 0.85f)
    val TextOn = Ink
    val TextDim = InkSoft
    val TextFaint = InkFaint

    val maxEp = anime.episodes ?: Int.MAX_VALUE
    val effectiveMax = if (maxEp == Int.MAX_VALUE) 1000 else maxEp
    val totalText = if (maxEp == Int.MAX_VALUE) "?" else "$maxEp"

    // episode-progress field uses TextFieldValue so we can control text + selection.
    // 'progress' (Int) is the source of truth for header/bar/save; 'progressText' mirrors it.
    // Mid-type we do NOT clamp — clamp only on blur or Save.
    var progressText by remember {
        mutableStateOf(TextFieldValue("${progress.coerceAtLeast(0)}", TextRange("$progress".length)))
    }

    fun commitProgressClamp() {
        val n = progressText.text.toIntOrNull()
        progress = if (n == null) progress.coerceIn(0, effectiveMax) else n.coerceIn(0, effectiveMax)
        progressText = progressText.copy(
            text = "$progress",
            selection = TextRange("$progress".length)
        )
    }

    val epFill = if (maxEp == Int.MAX_VALUE || maxEp <= 0) 0f else (progress.toFloat() / maxEp).coerceIn(0f, 1f)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SheetBg,
        contentColor = TextOn
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 22.dp, end = 22.dp, top = 10.dp, bottom = 22.dp)
        ) {
            // grabber
            Box(
                Modifier
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(TextFaint)
                    .align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(16.dp))

            // title
            Text(
                text = anime.title.ifBlank { "List Editor" },
                fontFamily = SpaceGrotesk,
                fontWeight = FontWeight.W700,
                fontSize = 19.sp,
                color = TextOn
            )
            Divider(Modifier.padding(vertical = 14.dp), color = SheetLine, thickness = 1.dp)

            // status chips — horizontal scroll, selected = solid orange
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                STATUSES.forEach { s ->
                    val selected = status == s
                    Box(
                        Modifier
                            .border(2.dp, if (selected) Orange else SheetLine)
                            .background(if (selected) Orange else SheetSurface)
                            .clickable { status = s }
                            .padding(horizontal = 16.dp, vertical = 9.dp)
                    ) {
                        Text(
                            text = s.uppercase(),
                            fontFamily = JetBrains,
                            fontWeight = FontWeight.W700,
                            fontSize = 11.5.sp,
                            color = if (selected) Color.White else TextOn
                        )
                    }
                }
            }

            Divider(Modifier.padding(vertical = 14.dp), color = SheetLine, thickness = 1.dp)

            // ---------- Progress (stepper, NOT a slider) ----------
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    "Progress",
                    fontFamily = SpaceGrotesk,
                    fontWeight = FontWeight.W600,
                    fontSize = 15.sp,
                    color = TextOn
                )
                Text(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(color = Orange, fontWeight = FontWeight.W600)) {
                            append("$progress")
                        }
                        withStyle(SpanStyle(color = TextDim)) {
                            append(" / $totalText")
                        }
                    },
                    fontFamily = JetBrains,
                    fontSize = 13.5.sp,
                    color = TextDim
                )
            }
            Spacer(Modifier.height(14.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // big minus
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(SheetSurface)
                        .border(1.dp, SheetLine, RoundedCornerShape(14.dp))
                        .clickable { progress = (progress - 1).coerceAtLeast(0); progressText = progressText.copy(text = "$progress", selection = TextRange("$progress".length)) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("–", fontFamily = InterF, fontWeight = FontWeight.W600, fontSize = 22.sp, color = Orange)
                }
                // editable number box
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SheetSurface)
                        .border(1.dp, OrangeDim, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    BasicTextField(
                        value = progressText,
                        onValueChange = { tv ->
                            // type freely; only keep digits; do NOT clamp mid-type
                            val cleaned = tv.text.filter { it.isDigit() }
                            progressText = tv.copy(text = cleaned)
                            // live-update the Int used by header + visual bar, but unclamped
                            cleaned.toIntOrNull()?.let { progress = it }
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontFamily = JetBrains,
                            fontWeight = FontWeight.W600,
                            fontSize = 18.sp,
                            color = TextOn,
                            textAlign = TextAlign.Center
                        ),
                        decorationBox = { inner -> Box(contentAlignment = Alignment.Center) { inner() } },
                        modifier = Modifier
                            .fillMaxWidth()
                            .onFocusChanged { fs: androidx.compose.ui.focus.FocusState ->
                                if (fs.isFocused) {
                                    // select the whole number so the next keystroke replaces it
                                    progressText = progressText.copy(selection = TextRange(0, progressText.text.length))
                                } else {
                                    // blur: clamp to [0, effectiveMax] and restore to last valid
                                    commitProgressClamp()
                                }
                            }
                    )
                }
                // big plus
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(SheetSurface)
                        .border(1.dp, SheetLine, RoundedCornerShape(14.dp))
                        .clickable { progress = (progress + 1).coerceAtMost(effectiveMax); progressText = progressText.copy(text = "$progress", selection = TextRange("$progress".length)) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("+", fontFamily = InterF, fontWeight = FontWeight.W600, fontSize = 22.sp, color = Orange)
                }
            }
            // slim visual-only progress bar
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(SheetSurface2)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(epFill)
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Orange)
                )
            }

            Spacer(Modifier.height(22.dp))

            // ---------- Score (draggable slider, shared-state bubble) ----------
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    "Score",
                    fontFamily = SpaceGrotesk,
                    fontWeight = FontWeight.W600,
                    fontSize = 15.sp,
                    color = TextOn
                )
                Text(
                    text = buildAnnotatedString {
                        if (scoreSet) {
                            withStyle(SpanStyle(color = Orange, fontWeight = FontWeight.W600)) {
                                append("%.1f".format(score))
                            }
                            withStyle(SpanStyle(color = TextDim)) {
                                append(" / 10")
                            }
                        } else {
                            withStyle(SpanStyle(color = TextDim)) {
                                append("— / 10")
                            }
                        }
                    },
                    fontFamily = JetBrains,
                    fontSize = 13.5.sp,
                    color = TextDim
                )
            }
            Spacer(Modifier.height(14.dp))

            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val density = LocalDensity.current
                val trackDp = maxWidth
                val frac = if (!scoreSet) 0f else (score / 10f).coerceIn(0f, 1f)
                var bubbleW by remember { mutableIntStateOf(0) }
                val bubbleUpPx = with(density) { (30.dp.value * density.density).roundToInt() }

                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    scoreSet = true
                                    val w = size.width.toFloat()
                                    score = ((offset.x.coerceIn(0f, w) / w) * 10f).coerceIn(0f, 10f)
                                },
                                onDrag = { change, _ ->
                                    scoreSet = true
                                    val w = size.width.toFloat()
                                    score = ((change.position.x.coerceIn(0f, w) / w) * 10f).coerceIn(0f, 10f)
                                    change.consume()
                                }
                            )
                        }
                ) {
                    // track (visual)
                    Box(
                        Modifier
                            .align(Alignment.Center)
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(SheetSurface2)
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(if (scoreSet) frac else 0f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(Orange)
                        )
                    }
                    // handle + bubble share the single `frac` so they can't desync
                    if (scoreSet) {
                        Box(
                            Modifier
                                .align(Alignment.CenterStart)
                                .offset(x = trackDp * frac - 8.dp)
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(Orange)
                                .border(3.dp, SheetBg, CircleShape)
                        )
                        Box(
                            Modifier
                                .align(Alignment.CenterStart)
                                .offset(x = trackDp * frac)
                        ) {
                            Box(
                                Modifier
                                    .offset { IntOffset(-(bubbleW / 2), -bubbleUpPx) }
                                    .background(SheetSurface2, RoundedCornerShape(7.dp))
                                    .border(1.dp, OrangeDim, RoundedCornerShape(7.dp))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                    .onSizeChanged { bubbleW = it.width }
                            ) {
                                Text(
                                    "%.1f".format(score),
                                    fontFamily = JetBrains,
                                    fontWeight = FontWeight.W600,
                                    fontSize = 11.5.sp,
                                    color = TextOn
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Divider(Modifier.padding(vertical = 14.dp), color = SheetLine, thickness = 1.dp)

            // ---------- Delete / Save ----------
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(SheetSurface)
                        .border(1.dp, Color(0x4DE8465A), RoundedCornerShape(14.dp))
                        .clickable { onDelete() }
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Delete", fontFamily = InterF, fontWeight = FontWeight.W600, fontSize = 14.sp, color = Danger)
                }
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Orange)
                        .border(1.dp, Orange, RoundedCornerShape(14.dp))
                        .clickable { commitProgressClamp(); onSave(status, progress, if (scoreSet) score.toDouble() else null) }
                        .padding(vertical = 13.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Save", fontFamily = InterF, fontWeight = FontWeight.W600, fontSize = 14.sp, color = Color.White)
                }
            }
        }
    }
}
