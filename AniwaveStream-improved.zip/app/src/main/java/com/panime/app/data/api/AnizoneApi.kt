package com.panime.app.data.api

import android.util.Log
import com.panime.app.util.Obf
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * On-device scraper for anizone.to — no backend required.
 *
 * anizone.to serves BARE DIRECT HLS m3u8 urls (vid-cdn.xyz / xin-cdn.xyz) with
 * NO token, NO encryption. We scrape the HTML directly from the device:
 *   1) Livewire /livewire/update (pages.anime-index component) → parse filtered
 *      items JSON → slug. The old /anime?search=<title> GET no longer filters.
 *   2) /anime/<slug>/<ep>   → parse vidstackPlayer JSON → direct m3u8 + subtitles
 *
 * The episode page embeds stream data in an Alpine x-data attribute:
 *   x-data="vidstackPlayer(JSON.parse('{\"src\":\"...master.m3u8\",\"subtitles\":[...]}'))"
 *
 * Any failure returns null — the caller shows a real error, never a demo video.
 */
object AnizoneApi {

    private val BASE = Obf.s("Mi4uKilgdXU7NDMgNTQ/dC41")
    private const val UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36")

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    // Session cookies + livewire state for search. anizone.to runs its search
    // through Livewire now: the front page search input binds to a
    // pages.anime-index component and the query is applied server-side via a
    // POST to /livewire/update. The plain /anime?search=<q> GET (which this file
    // used for years) is IGNORED by the server and always returns the same
    // default 24-item batch — that's why search results stopped filtering.
    private val cookies = ConcurrentHashMap<String, List<Cookie>>()
    private val cookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookieList: List<Cookie>) {
            cookies[url.host] = cookieList
        }
        override fun loadForRequest(url: HttpUrl): List<Cookie> =
            cookies[url.host].orEmpty()
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .cookieJar(cookieJar)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    // Livewire search state: the anime-index component snapshot + CSRF token,
    // bootstrapped once from /anime. Reused across searches; re-fetched on 419/expire.
    @Volatile private var lwSnapshot: String? = null
    @Volatile private var lwCsrf: String? = null

    // Slug cache: title key -> (timestamp, slug). 10 min TTL.
    private val slugCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private const val SLUG_CACHE_TTL_MS = 10 * 60_000L

    // Detail-page cache: slug -> (timestamp, html). 24h TTL (episode count never
    // changes). Episode pages are deliberately NOT cached — see isDetailPage().
    private val detailCache = ConcurrentHashMap<String, Pair<Long, String>>()
    private const val DETAIL_CACHE_TTL_MS = 24 * 60 * 60_000L

    fun warmUp() { /* no-op: direct scraping has no server to warm up */ }

    /**
     * True only for the bare detail page `/anime/<slug>` (exactly one path
     * segment, no query). Episode pages (`/anime/<slug>/<ep>`) are NOT detail
     * pages and must never be cached: their full HTML is ~0.5–1.5MB each and a
     * 24h unbounded cache of every episode on a long series (One Piece = 1170
     * episodes) poisons the heap and crashes with OutOfMemoryError on range
     * switches.
     */
    private fun isDetailPage(path: String): Boolean {
        if (!path.startsWith("/anime/")) return false
        if (path.contains("?")) return false
        val rest = path.removePrefix("/anime/")
        return rest.isNotEmpty() && !rest.contains('/')
    }

    private fun fetchPage(path: String): String {
        val url = if (path.startsWith("http")) path else "$BASE$path"
        // Cache detail pages only (24h) — episode count never changes.
        if (isDetailPage(path)) {
            detailCache[path]?.let { (ts, html) ->
                if (System.currentTimeMillis() - ts < DETAIL_CACHE_TTL_MS) return html
                detailCache.remove(path)
            }
        }
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", UA)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw RuntimeException("AnizoneApi HTTP ${resp.code}")
            val html = resp.body?.string().orEmpty()
            if (isDetailPage(path)) {
                detailCache[path] = System.currentTimeMillis() to html
            }
            return html
        }
    }

    /** Replace the HTML entities Livewire uses when embedding its snapshot in an attribute. */
    private fun unescapeHtml(s: String): String = s
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")

    /**
     * Bootstrap the Livewire session: fetch /anime once, grab the CSRF token
     * and the `pages.anime-index` component snapshot. Returns false on failure.
     */
    private fun ensureLivewireSession(): Boolean {
        if (lwSnapshot != null && lwCsrf != null) return true
        return try {
            val html = fetchPage("/anime")
            val csrf = Regex("""data-csrf="([^"]+)""").find(html)?.groupValues?.get(1)
            val snapshot = findAnimeIndexSnapshot(html)
            if (csrf.isNullOrBlank() || snapshot == null) {
                Log.w("AnizoneApi", "livewire session bootstrap failed")
                false
            } else {
                lwCsrf = csrf; lwSnapshot = snapshot
                true
            }
        } catch (e: Exception) {
            Log.w("AnizoneApi", "livewire bootstrap failed: ${e.message}")
            false
        }
    }

    /**
     * Pull the exact JSON string for the `pages.anime-index` Livewire component
     * (memo.name == "pages.anime-index") from a page's markup. The page embeds
     * several components (navbar, etc.); we need the one that owns the search
     * results grid.
     */
    private fun findAnimeIndexSnapshot(html: String): String? {
        // snapshots are JSON nested in an attribute; capture with balanced-ish
        // regex on the HTML-entity-escaped payload.
        val re = Regex("""wire:snapshot=\"((?:[^\"\\]|\\.)*?)\"""")
        for (m in re.findAll(html)) {
            val decoded = unescapeHtml(m.groupValues[1])
            if (decoded.contains("pages.anime-index")) return decoded
        }
        return null
    }

    /**
     * Run a Livewire search for [query] and return the filtered item JSON
     * objects (each has slug/main_title/cover). Returns emptyList on any failure.
     */
    private fun livewireSearchItems(query: String): List<JsonObject> {
        if (!ensureLivewireSession()) return emptyList()
        // Retry once if Livewire returns 419 (session/CSRF expired): reseed the
        // session, then fall through and POST again with the fresh state.
        repeat(2) { attempt ->
            val snapshot = lwSnapshot ?: return emptyList()
            val csrf = lwCsrf ?: return emptyList()
            val payload = buildJsonObject {
                put("_token", JsonPrimitive(csrf))
                put("components", buildJsonArray {
                    add(buildJsonObject {
                        put("snapshot", JsonPrimitive(snapshot))
                        put("updates", buildJsonObject { put("search", JsonPrimitive(query)) })
                        put("calls", buildJsonArray { })
                    })
                })
            }
            try {
                val req = Request.Builder()
                    .url("$BASE/livewire/update")
                    .header("User-Agent", UA)
                    .header("Accept", "*/*")
                    .header("Content-Type", "application/json")
                    .header("X-Livewire", "true")
                    .header("Referer", "$BASE/anime")
                    .header("X-CSRF-TOKEN", csrf)
                    .post(payload.toString().toRequestBody(jsonMedia))
                    .build()
                var expired = false
                client.newCall(req).execute().use { resp ->
                    if (resp.code == 419) { expired = true; return@use }
                    if (!resp.isSuccessful) return@use
                    val body = resp.body?.string().orEmpty()
                    val root = try { json.parseToJsonElement(body).jsonObject } catch (e: Exception) {
                        null
                    }
                    val effectsHtml = root?.get("components")?.jsonArray
                        ?.firstOrNull()?.jsonObject
                        ?.get("effects")?.jsonObject
                        ?.get("html")?.jsonPrimitive?.content
                    if (effectsHtml != null) return parseSearchItems(effectsHtml)
                }
                if (expired && attempt < 1) {
                    lwCsrf = null; lwSnapshot = null
                    if (ensureLivewireSession()) return@repeat
                }
                return emptyList()
            } catch (e: Exception) {
                Log.w("AnizoneApi", "livewireSearch failed: ${e.message}")
            }
        }
        return emptyList()
    }

    /** Decode unicode_escape and unescape forward-slashes in JSON strings from HTML. */
    private fun decodeJsonString(raw: String): String {
        return try {
            val sb = StringBuilder()
            var i = 0
            while (i < raw.length) {
                if (raw[i] == '\\' && i + 1 < raw.length) {
                    when (raw[i + 1]) {
                        'u' -> {
                            if (i + 5 < raw.length) {
                                val hex = raw.substring(i + 2, i + 6)
                                sb.appendCodePoint(Integer.parseInt(hex, 16))
                                i += 6
                            } else { sb.append(raw[i]); i++ }
                        }
                        'n' -> { sb.append('\n'); i += 2 }
                        't' -> { sb.append('\t'); i += 2 }
                        'r' -> { sb.append('\r'); i += 2 }
                        '\\' -> { sb.append('\\'); i += 2 }
                        '"' -> { sb.append('"'); i += 2 }
                        '\'' -> { sb.append('\''); i += 2 }
                        '/' -> { sb.append('/'); i += 2 }
                        '0' -> { sb.append('\u0000'); i += 2 }
                        else -> { sb.append(raw[i]); i++ }
                    }
                } else {
                    sb.append(raw[i]); i++
                }
            }
            sb.toString()
        } catch (_: Exception) { raw }
    }

    /**
     * Extract the "items" JSON array from the anime index page HTML.
     * The page embeds: items: JSON.parse('[{...},{...}]')
     */
    private fun parseSearchItems(html: String): List<JsonObject> {
        val items = mutableListOf<JsonObject>()
        val regex = Regex(Obf.s("My4/NylgBilwEAkVFAZ0KjsoKT8Gcn1ydHFlc30Gcw=="))
        for (match in regex.findAll(html)) {
            val raw = match.groupValues[1]
            val decoded = decodeJsonString(raw)
            try {
                val arr = json.parseToJsonElement(decoded).jsonArray
                for (el in arr) items.add(el.jsonObject)
            } catch (e: Exception) {
                Log.w("AnizoneApi", "Failed to parse items JSON: ${e.message}")
            }
        }
        return items
    }

    private data class ScoredMatch(val slug: String, val score: Int)
    private data class ItemInfo(val mainTitle: String, val slug: String,
                                val normMain: String, val cleanMain: String, val itemSeason: Int,
                                val aliasNorms: Set<String>, val aliasCleans: Set<String>)

    /**
     * Find the best-matching slug for a title from the search results.
     * Matches against main_title and title_list aliases.
     * If expectedEpisodes is provided, verifies the slug's episode count.
     * If seasonNumber > 1, prefers entries whose title contains a season indicator.
     *
     * Strategy: prefer EXACT match on original titles (no cleanup).
     * Only use cleanTitle matching as a fallback when original matching finds nothing.
     */
    private fun bestMatch(items: List<JsonObject>, titles: List<String>, expectedEpisodes: Int? = null, seasonNumber: Int = 1, expectedYear: Int? = null): String? {
        val infos = buildItemInfos(items)
        if (infos.isEmpty()) return null

        // PASS 1: Score using ORIGINAL titles (no cleanup) — the old behavior
        // that worked for most anime. Season markers are preserved so S1/S2/S3 differ.
        val scored1 = scoreItems(infos, titles, seasonNumber, useClean = false)
        if (scored1.isNotEmpty()) {
            for (match in scored1) {
                if (verifyEpisodes(match.slug, expectedEpisodes, expectedYear)) return match.slug
            }
        }

        // PASS 2: Fallback — use cleanTitle matching for edge cases like "(Sub)/(Dub)"
        val scored2 = scoreItems(infos, titles, seasonNumber, useClean = true)
        val seen = scored1.map { it.slug }.toSet()
        val combined = scored1.toMutableList()
        for (m in scored2) {
            if (m.slug !in seen) combined.add(m)
        }
        if (combined.isNotEmpty()) {
            for (match in combined) {
                if (verifyEpisodes(match.slug, expectedEpisodes, expectedYear)) return match.slug
            }
        }

        return combined.firstOrNull()?.slug
    }

    private fun buildItemInfos(items: List<JsonObject>): List<ItemInfo> {
        val infos = mutableListOf<ItemInfo>()
        for (item in items) {
            val mainTitle = item["main_title"]?.jsonPrimitive?.content?.trim('"') ?: continue
            val slug = item["slug"]?.jsonPrimitive?.content ?: continue
            val normMain = normalize(mainTitle)
            val cleanMain = cleanTitle(mainTitle)
            val itemSeason = extractSeason(mainTitle)
            val aliasNorms = mutableSetOf<String>()
            val aliasCleans = mutableSetOf<String>()
            val titleList = item["title_list"]?.jsonObject
            if (titleList != null) {
                for ((_, v) in titleList) {
                    val alias = v.jsonPrimitive.content.trim('"')
                    aliasNorms.add(normalize(alias))
                    aliasCleans.add(normalize(cleanTitle(alias)))
                }
            }
            infos.add(ItemInfo(mainTitle, slug, normMain, cleanMain, itemSeason, aliasNorms, aliasCleans))
        }
        return infos
    }

    private fun scoreItems(infos: List<ItemInfo>, titles: List<String>, seasonNumber: Int, useClean: Boolean): List<ScoredMatch> {
        val scored = mutableListOf<ScoredMatch>()

        for (info in infos) {
            var score = 0

            for (title in titles) {
                val normTarget = normalize(title)
                val cleanTarget = cleanTitle(title)

                if (useClean) {
                    // Clean matching: compare cleaned versions
                    if (info.cleanMain == cleanTarget) score += 8
                    if (info.aliasCleans.any { it == cleanTarget }) score += 8
                    val lcs = longestCommonSubstring(cleanTarget, info.cleanMain)
                    val minLen = cleanTarget.length.coerceAtMost(info.cleanMain.length)
                    if (minLen > 0 && lcs >= (minLen * 0.6).toInt().coerceAtLeast(5)) score += 2
                } else {
                    // Original matching: compare raw normalized titles
                    if (info.normMain == normTarget) score += 10
                    if (info.aliasNorms.any { it == normTarget }) score += 10
                    val lcs = longestCommonSubstring(normTarget, info.normMain)
                    val minLen = normTarget.length.coerceAtMost(info.normMain.length)
                    if (minLen > 0 && lcs >= (minLen * 0.6).toInt().coerceAtLeast(5)) score += 3
                    if (normTarget.length >= 4 && info.normMain.contains(normTarget)) score += 5
                    if (normTarget.length >= 4 && normTarget.contains(info.normMain)) score += 5
                }
            }

            // Season scoring (only in original pass)
            if (!useClean && seasonNumber > 1) {
                if (info.itemSeason == seasonNumber) score += 10
                else score -= 20
                val allItemTitles = mutableListOf(info.cleanMain)
                for (ac in info.aliasCleans) allItemTitles.add(ac)
                for (alias in allItemTitles) {
                    if (looksLikeSeasonN(alias.lowercase(), seasonNumber)) {
                        score += 6
                        break
                    }
                }
            }

            if (score > 0) scored.add(ScoredMatch(info.slug, score))
        }

        scored.sortByDescending { it.score }
        return scored
    }

    /** Detect if a title string looks like it refers to a specific season number. */
    private fun looksLikeSeasonN(title: String, season: Int): Boolean {
        val patterns = listOf(
            Regex("""season\s*$season"""),
            Regex("""${season}(?:st|nd|rd|th)\s*season"""),
            Regex("""\bs$season\b"""),
            Regex("""${season}(?:st|nd|rd|th)\b"""),
            Regex("""part\s*$season""")
        )
        return patterns.any { it.containsMatchIn(title) }
    }

    private fun normalize(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    /** Clean a title for search: strip audio tags, season markers, special chars. */
    private fun cleanTitle(title: String): String {
        var t = title
        t = t.replace(Regex("""\s*\(Sub\)""", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("""\s*\(Dub\)""", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("""\s*\(Uncensored\)""", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("""\s*\(Raw\)""", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("""\s*Season\s*\d+""", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("""\s*Part\s*\d+""", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("""\s*\d+(?:st|nd|rd|th)\s*Season""", RegexOption.IGNORE_CASE), "")
        t = t.replace(Regex("""\s*\b(?:II|III|IV|V)\b"""), "")
        t = t.replace(Regex("""[^\w\s]"""), " ")
        t = t.trim().replace(Regex("""\s+"""), " ")
        return t
    }

    /** Extract season number from a title string. */
    private fun extractSeason(title: String): Int {
        val t = title.trim()
        Regex("""Season\s*(\d+)""", RegexOption.IGNORE_CASE).find(t)?.let { return it.groupValues[1].toIntOrNull() ?: 1 }
        Regex("""Part\s*(\d+)""", RegexOption.IGNORE_CASE).find(t)?.let { return it.groupValues[1].toIntOrNull() ?: 1 }
        Regex("""(\d+)(?:st|nd|rd|th)\s*Season""", RegexOption.IGNORE_CASE).find(t)?.let { return it.groupValues[1].toIntOrNull() ?: 1 }
        Regex("""\b(II|III|IV|V)\s*$""").find(t.uppercase())?.let {
            return when (it.groupValues[1]) { "II" -> 2; "III" -> 3; "IV" -> 4; "V" -> 5; else -> 1 }
        }
        return 1
    }

    /**
     * Verify that a slug's episode count AND year match the expected values from AniList.
     * Fetches the detail page and parses both from the HTML.
     */
    private fun verifyEpisodes(slug: String, expectedEpisodes: Int?, expectedYear: Int?): Boolean {
        if (expectedEpisodes == null && expectedYear == null) return true
        return try {
            val html = fetchPage("/anime/$slug")
            // Check episode count
            if (expectedEpisodes != null) {
                val epMatch = Regex("""(\d+)\s*[Ee]pisodes?""").find(html)
                if (epMatch != null) {
                    val actualEpisodes = epMatch.groupValues[1].toIntOrNull()
                    if (actualEpisodes != null && actualEpisodes != expectedEpisodes) {
                        Log.d("AnizoneApi", "Episode count mismatch for $slug: $actualEpisodes vs expected $expectedEpisodes")
                        return false
                    }
                }
            }
            // Check year — anizone uses <span class="inline-block">YYYY</span>
            if (expectedYear != null) {
                val yearMatch = Regex("""<span[^>]*>\s*$expectedYear\s*</span>""").find(html)
                    ?: Regex("""\b$expectedYear\b""").find(html)
                if (yearMatch == null) {
                    Log.d("AnizoneApi", "Year $expectedYear not found on page for $slug")
                    return false
                }
            }
            true
        } catch (e: Exception) {
            Log.w("AnizoneApi", "verifyEpisodes failed: ${e.message}")
            true // Can't verify, assume match
        }
    }

    private fun longestCommonSubstring(a: String, b: String): Int {
        if (a.isEmpty() || b.isEmpty()) return 0
        var prev = IntArray(b.length + 1)
        var best = 0
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            for (j in 1..b.length) {
                if (a[i - 1] == b[j - 1]) {
                    cur[j] = prev[j - 1] + 1
                    if (cur[j] > best) best = cur[j]
                }
            }
            prev = cur
        }
        return best
    }

    /** Search anizone by title, return the best-matching slug (or null).
     *  @param titles        list of title variants to try (romaji, english, native, synonyms).
     *  @param totalEpisodes AniList total episode count for disambiguation.
     *  @param seasonNumber  AniList season number for season-aware matching.
     *  @param year          AniList season year for year verification. */
    fun resolveSlug(title: String, totalEpisodes: Int? = null, seasonNumber: Int = 1, year: Int? = null, titles: List<String> = emptyList()): String? {
        val q = title.trim()
        if (q.isBlank()) return null
        // Check slug cache
        val cacheKey = "$q|${totalEpisodes ?: 0}|$seasonNumber|${year ?: 0}".lowercase()
        slugCache[cacheKey]?.let { (ts, slug) ->
            if (System.currentTimeMillis() - ts < SLUG_CACHE_TTL_MS) return slug
            slugCache.remove(cacheKey)
        }
        val src = if (titles.isNotEmpty()) titles else listOf(q)

        // PASS 1: Search with ORIGINAL titles — preserves season markers (S2, Part 2, etc.)
        val originalItems = linkedSetOf<JsonObject>()
        for (t in src) {
            try {
                originalItems.addAll(livewireSearchItems(t))
            } catch (e: Exception) {
                Log.w("AnizoneApi", "Search failed for '$t': ${e.message}")
            }
        }
        if (originalItems.isNotEmpty()) {
            val slug = bestMatch(originalItems.toList(), src, totalEpisodes, seasonNumber, year)
            if (slug != null) {
                slugCache[cacheKey] = System.currentTimeMillis() to slug
                return slug
            }
        }

        // PASS 2: Fallback — search with cleaned titles for edge cases like "(Sub)/(Dub)"
        val cleanedTitles = linkedSetOf<String>()
        for (t in src) {
            val cleaned = cleanTitle(t)
            if (cleaned.isNotBlank() && cleaned != t) cleanedTitles.add(cleaned)
        }
        if (cleanedTitles.isNotEmpty()) {
            val cleanedItems = linkedSetOf<JsonObject>()
            for (t in cleanedTitles) {
                try {
                    cleanedItems.addAll(livewireSearchItems(t))
                } catch (e: Exception) {
                    Log.w("AnizoneApi", "Search failed for cleaned '$t': ${e.message}")
                }
            }
            if (cleanedItems.isNotEmpty()) {
                val allItems = (originalItems + cleanedItems).toList()
                val allTitles = (src + cleanedTitles).toList()
                val slug = bestMatch(allItems, allTitles, totalEpisodes, seasonNumber, year)
                if (slug != null) {
                    slugCache[cacheKey] = System.currentTimeMillis() to slug
                    return slug
                }
            }
        }

        Log.w("AnizoneApi", "No search results for '$q'")
        return null
    }

    /**
     * AniZone currently exposes one direct source in the episode page. The
     * label is shown to users in server lists — always the branded short
     * name "Zone", never the raw site name.
     * Audio languages remain independent and are intentionally not filtered here.
     */
    fun servers(slug: String, episode: Int): List<Pair<String, String>> {
        return resolveFull(slug, episode)?.serverCode
            ?.let { listOf(it to "Zone") }
            ?: emptyList()
    }

    /**
     * A resolved stream result. anizone m3u8 is already direct + playable, so
     * proxiedM3u8 == rawM3u8 == the vid-cdn.xyz url.
     */
    data class StreamResult(
        val proxiedM3u8: String?,
        val rawM3u8: String?,
        val isByfms: Boolean,
        val subtitles: List<AniwavesApi.SubtitleTrack>,
        val serverCode: String?
    )

    /**
     * Parse the vidstackPlayer JSON blob from an episode page.
     * Returns (m3u8, subtitles) or null on failure.
     */
    private fun parseEpisodePage(html: String): StreamResult? {
        // Match: vidstackPlayer(JSON.parse('...'))
        val regex = Regex(Obf.s("LDM+KS47OTEKNjsjPygGchAJFRQGdCo7KCk/BnJ9cnRxZXN9BnMGcw=="))
        val match = regex.find(html) ?: return null
        val raw = match.groupValues[1]
        val decoded = decodeJsonString(raw)
        val root = try {
            json.parseToJsonElement(decoded).jsonObject
        } catch (e: Exception) {
            Log.w("AnizoneApi", "Failed to parse vidstackPlayer JSON: ${e.message}")
            return null
        }
        val m3u8 = root["src"]?.jsonPrimitive?.content ?: return null
        val subs = (root["subtitles"]?.jsonArray ?: emptyList()).mapNotNull { el ->
            val o = el.jsonObject
            val url = o["file"]?.jsonPrimitive?.content ?: return@mapNotNull null
            val lang = o["language"]?.jsonPrimitive?.content ?: "unk"
            val label = o["title"]?.jsonPrimitive?.content ?: lang
            AniwavesApi.SubtitleTrack(lang = lang, label = label, url = url)
        }
        return StreamResult(
            proxiedM3u8 = m3u8,
            rawM3u8 = m3u8,
            isByfms = false,
            subtitles = subs,
            serverCode = "default"
        )
    }

    /**
     * Real AUDIO languages for an episode — the truth, never inferred. anizone
     * lists the dubbed/original audio languages as badges in the page's
     * "Audio:" section (flag icon + name, e.g. "Japanese", "English",
     * "Spanish (Latin American)"...). The page ALSO has a "Softsub:" section
     * (subtitle languages, e.g. Hindi on shows that are only subbed) — those
     * are NOT audio availability and are never mixed in.
     */
    fun audioLanguages(slug: String, episode: Int): List<String> {
        return try {
            val html = fetchPage("/anime/$slug/$episode")
            // Scope to the "Audio:" section only — everything from its label
            // up to the "Softsub:" label (or the end of the page if absent).
            val audioSection = Regex(""">Audio:</div>.*?(?:>Softsub:</div>|$)""", RegexOption.DOT_MATCHES_ALL)
                .find(html)?.value ?: html
            // Badge: <span class="fi fi-xx"></span> <lang name> inside a span
            // with bg-slate-900/50. The flag span is required (other bg-slate
            // badges like "v2"/"DVD"/"24:37" carry no flag); the name itself
            // may contain spaces/parens (e.g. "Spanish (Latin American)"), so
            // capture anything up to the closing tag and trim.
            Regex("""bg-slate-900/50">\s*(?:<!--.*?-->)?\s*<span class="fi fi-[a-z-]+"></span>\s*(?:<!--.*?-->)?\s*([^<]{2,40}?)\s*</span>""")
                .findAll(audioSection)
                .mapNotNull { m ->
                    val name = m.groupValues[1].trim()
                    name.takeIf { it.isNotEmpty() && it.length <= 40 }
                }
                .distinct()
                .toList()
        } catch (e: Exception) {
            Log.w("AnizoneApi", "audioLanguages failed: ${e.message}")
            emptyList()
        }
    }

    /** Resolve the full sources payload for an episode. */
    fun resolveFull(slug: String, episode: Int): StreamResult? {
        return try {
            val html = fetchPage("/anime/$slug/$episode")
            parseEpisodePage(html)
        } catch (e: Exception) {
            Log.e("AnizoneApi", "resolveFull failed: ${e.message}")
            null
        }
    }

    /** Resolve a specific server code to a StreamResult, or null. anizone has only one server. */
    fun resolveOne(slug: String, episode: Int, serverCode: String): StreamResult? {
        return resolveFull(slug, episode)
    }

    /** Legacy single-url resolve (first available server). */
    fun streamUrl(slug: String, episode: Int): String? = resolveFull(slug, episode)?.proxiedM3u8

    // ===================== Wrong-title support (additive) =====================
    // The picker shows EVERY search result — no bestMatch/auto-matching on this
    // path. The user's clicked slug is then used directly everywhere. The
    // default flow above (resolveSlug/bestMatch) is untouched.

    data class SearchItem(val slug: String, val title: String, val coverUrl: String?)

    /** Raw search results for the wrong-title picker. */
    fun searchAnime(query: String): List<SearchItem> {
        return try {
            livewireSearchItems(query.trim()).mapNotNull { o ->
                val slug = o["slug"]?.jsonPrimitive?.content ?: return@mapNotNull null
                val title = o["main_title"]?.jsonPrimitive?.content ?: return@mapNotNull null
                SearchItem(slug, title, o["cover"]?.jsonPrimitive?.content)
            }
        } catch (e: Exception) {
            Log.w("AnizoneApi", "searchAnime failed: ${e.message}")
            emptyList()
        }
    }

    /** Episode count for a picked slug, parsed from its detail page ("N Episodes"). */
    fun episodeCountBySlug(slug: String): Int {
        return try {
            Regex("""(\d+)\s*[Ee]pisodes?""").find(fetchPage("/anime/$slug"))
                ?.groupValues?.get(1)?.toIntOrNull() ?: 0
        } catch (e: Exception) {
            Log.w("AnizoneApi", "episodeCountBySlug failed: ${e.message}")
            0
        }
    }
}
