package com.panime.app.ui.search

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.panime.app.data.model.Anime
import com.panime.app.data.repository.AnimeRepository
import com.panime.app.data.repository.UserLibraryStore
import com.panime.app.ui.components.EpisodeListShimmer
import com.panime.app.ui.home.PaginationBar
import com.panime.app.ui.theme.Background
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.Ink
import com.panime.app.ui.theme.OrangePrimary
import com.panime.app.ui.theme.PaperWhite
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary
import com.panime.app.ui.theme.Void
import kotlinx.coroutines.delay

private val TYPE_FILTERS = listOf("All", "TV", "Movie", "OVA", "ONA", "Special", "Music")

private fun serializeAnimeList(list: List<Anime>): String = list.joinToString("\u001D") { a ->
    listOf(
        a.id, a.title, a.synopsis, a.posterUrl ?: "", a.bannerUrl ?: "",
        a.score?.toString() ?: "", a.episodes?.toString() ?: "",
        a.nextEpisode?.toString() ?: "", a.nextAiringAt?.toString() ?: "",
        a.year?.toString() ?: "", a.season ?: "", a.seasonNumber.toString(),
        a.startYear?.toString() ?: "", a.startMonth?.toString() ?: "", a.startDay?.toString() ?: "",
        a.type ?: "", a.status ?: "", a.rating ?: "",
        a.genres.joinToString("\u001F"),
        a.studios.joinToString("\u001F"),
        a.countryOfOrigin ?: "", a.isAdult?.toString() ?: "", a.kotoSlug ?: ""
    ).joinToString("\u001E")
}

private fun deserializeAnimeList(s: String): List<Anime> {
    if (s.isBlank()) return emptyList()
    return s.split("\u001D").map { row ->
        val f = row.split("\u001E")
        Anime(
            id = f[0].toInt(), title = f[1], synopsis = f[2],
            posterUrl = f[3].ifBlank { null }, bannerUrl = f[4].ifBlank { null },
            score = f[5].toDoubleOrNull(), episodes = f[6].toIntOrNull(),
            nextEpisode = f[7].toIntOrNull(), nextAiringAt = f[8].toLongOrNull(),
            year = f[9].toIntOrNull(), season = f[10].ifBlank { null },
            seasonNumber = f[11].toInt(),
            startYear = f[12].toIntOrNull(), startMonth = f[13].toIntOrNull(), startDay = f[14].toIntOrNull(),
            type = f[15].ifBlank { null }, status = f[16].ifBlank { null }, rating = f[17].ifBlank { null },
            genres = f[18].split("\u001F").filter(String::isNotEmpty),
            studios = f[19].split("\u001F").filter(String::isNotEmpty),
            countryOfOrigin = f[20].ifBlank { null }, isAdult = f[21].toBooleanStrictOrNull(), kotoSlug = f[22].ifBlank { null }
        )
    }
}

@Composable
fun SearchScreen(
    repository: AnimeRepository,
    library: UserLibraryStore,
    onAnimeClick: (Anime) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var loading by rememberSaveable { mutableStateOf(false) }
    var resultsJson by rememberSaveable { mutableStateOf("") }
    val results = remember(resultsJson) { deserializeAnimeList(resultsJson) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var typeFilter by rememberSaveable { mutableStateOf("All") }
    var lastFetchedKey by rememberSaveable { mutableStateOf("") }
    var currentPage by rememberSaveable { mutableIntStateOf(1) }
    var lastPage by rememberSaveable { mutableIntStateOf(1) }
    val gridState = rememberLazyGridState()
    val apiProvider by library.apiProvider.collectAsStateWithLifecycle("anilist")

    LaunchedEffect(query, currentPage, apiProvider) {
        if (query.isBlank()) {
            resultsJson = ""
            error = null
            loading = false
            lastFetchedKey = ""
            currentPage = 1
            lastPage = 1
            return@LaunchedEffect
        }
        // New query or provider switch -> restart at page 1.
        if (currentPage != 1 && lastFetchedKey.substringBefore('#') != "$apiProvider|$query") {
            currentPage = 1
            return@LaunchedEffect
        }
        // Provider switch: wipe results fetched by the previous provider so stale
        // titles never linger while the new provider re-searches.
        if (results.isNotEmpty() && lastFetchedKey.substringBefore('|') != apiProvider) {
            resultsJson = ""
        }
        val key = "$apiProvider|$query#$currentPage"
        if (key == lastFetchedKey && results.isNotEmpty()) return@LaunchedEffect
        delay(400)
        if (key == lastFetchedKey && results.isNotEmpty()) return@LaunchedEffect
        loading = true
        error = null
        repository.searchPaged(query, currentPage)
            .onSuccess { pr ->
                resultsJson = serializeAnimeList(pr.items)
                lastPage = pr.lastPage.coerceAtLeast(1)
                if (currentPage > lastPage) {
                    currentPage = lastPage
                    return@onSuccess
                }
                loading = false
                lastFetchedKey = key
            }
            .onFailure {
                error = it.message
                loading = false
            }
    }

    LaunchedEffect(currentPage) {
        gridState.scrollToItem(0)
    }

    val filtered = if (typeFilter == "All") results else results.filter {
        it.type?.equals(typeFilter, ignoreCase = true) == true
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Background)
            .padding(top = 12.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            placeholder = { Text("Search anime…") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = OrangePrimary) },
            singleLine = true,
            shape = RoundedCornerShape(0.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Ink,
                unfocusedBorderColor = Ink,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                cursorColor = OrangePrimary,
                focusedContainerColor = Surface,
                unfocusedContainerColor = Surface,
                focusedPlaceholderColor = TextMuted,
                unfocusedPlaceholderColor = TextMuted
            )
        )
        Spacer(Modifier.height(12.dp))

        // Type filter chips (single-select, horizontally scrollable).
        if (query.isNotBlank()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(TYPE_FILTERS) { type ->
                    val isSel = type == typeFilter
                    Box(
                        Modifier
                            .border(2.dp, if (isSel) Flame else Hairline)
                            .background(if (isSel) Flame else Surface)
                            .clickable { typeFilter = type }
                            .padding(horizontal = 16.dp, vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            type.uppercase(),
                            color = if (isSel) PaperWhite else TextPrimary,
                            fontFamily = PlexMono,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        when {
            loading -> EpisodeListShimmer(modifier = Modifier.fillMaxSize())
            query.isBlank() -> BoxHint("Find titles, genres vibes, or classics")
            error != null -> error?.let { BoxHint(it) }
            filtered.isEmpty() -> BoxHint(
                if (typeFilter == "All") "No results for “$query”" else "No $typeFilter results for “$query”"
            )
            else -> LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.id }) { anime ->
                    SearchCard(anime) { onAnimeClick(anime) }
                }
                if (lastPage > 1) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        PaginationBar(
                            page = currentPage,
                            pageCount = lastPage,
                            onPage = { p -> currentPage = p }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchCard(anime: Anime, onClick: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = anime.posterUrl,
            contentDescription = anime.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Hairline, RoundedCornerShape(14.dp))
        )
        Spacer(Modifier.height(8.dp))
        Text(
            anime.title,
            color = TextPrimary,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        val meta = listOfNotNull(
            anime.year?.toString(),
            anime.score?.let { "★ ${"%.1f".format(it)}" }
        ).joinToString(" · ")
        if (meta.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(
                meta,
                color = TextSecondary,
                fontFamily = PlexMono,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun BoxHint(text: String) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text, color = TextSecondary)
    }
}
