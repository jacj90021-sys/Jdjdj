package com.panime.app.download

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import ani.dantotsu.addons.download.DownloadAddonApiV2
import dalvik.system.PathClassLoader

/**
 * Loads Dantotsu's FFmpeg download addon (package "dantotsu.downloadAddon")
 * into this app — same mechanism as Dantotsu's AddonLoader, minimal form.
 * The addon APK is installed separately by the user; we only reflect into it.
 */
object DownloadAddonLoader {

    private const val TAG = "DownloadAddon"
    const val ADDON_PACKAGE = "dantotsu.downloadAddon"
    private const val ADDON_CLASS = "ani.dantotsu.downloadAddon.DownloadAddon"

    @Volatile
    private var cached: DownloadAddonApiV2? = null

    /** Cached addon instance, or null when the addon is not installed. */
    fun get(context: Context): DownloadAddonApiV2? {
        cached?.let { return it }
        return load(context)?.also { cached = it }
    }

    fun isInstalled(context: Context): Boolean = runCatching {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            context.packageManager.getInstalledPackages(
                PackageManager.PackageInfoFlags.of(0L)
            ).any { it.packageName == ADDON_PACKAGE }
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getInstalledPackages(0).any { it.packageName == ADDON_PACKAGE }
        }
    }.getOrDefault(false)

    private fun load(context: Context): DownloadAddonApiV2? = runCatching {
        val pm = context.packageManager
        val info = try {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                pm.getApplicationInfo(
                    ADDON_PACKAGE,
                    PackageManager.ApplicationInfoFlags.of(PackageManager.GET_META_DATA.toLong())
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(ADDON_PACKAGE, PackageManager.GET_META_DATA)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            return null
        }
        val classLoader = PathClassLoader(info.sourceDir, info.nativeLibraryDir, context.classLoader)
        val cls = Class.forName(ADDON_CLASS, false, classLoader)
        val instance = cls.getDeclaredConstructor().newInstance()
        instance as? DownloadAddonApiV2
            ?: throw IllegalStateException("Addon class is not a DownloadAddonApiV2")
    }.onFailure {
        Log.w(TAG, "Failed to load download addon: ${it.message}")
    }.getOrNull()
}
