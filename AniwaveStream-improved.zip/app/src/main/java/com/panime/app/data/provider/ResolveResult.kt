package com.panime.app.data.provider

import com.panime.app.data.api.AniwavesApi

/**
 * Normalized stream result — the single shape every provider (on-device or backend)
 * must produce. Mirrors the fields the player already consumes via ResolvePack.
 */
data class ResolveResult(
    val source: String,                 // provider id, e.g. "anidap"
    val servers: List<Pair<String, String>>,
    val url: String?,                   // m3u8/mp4 the player loads
    val rawUrl: String? = null,         // raw CDN url (BYFMS direct fetch)
    val isByfms: Boolean = false,
    val referer: String? = null,        // Referer the device must send for the m3u8
    val format: String? = "hls",
    val quality: String? = null,        // quality badge, e.g. "1080p" or "HD, SD"
    val subtitles: List<AniwavesApi.SubtitleTrack> = emptyList(),
    val thumbnails: String? = null,
    val intro: Pair<Int, Int>? = null,
    val outro: Pair<Int, Int>? = null,
    val notFound: Boolean = false,
    val decryptKey: ByteArray? = null,  // XOR key for flixcloud.cc encrypted content
    val decryptIv: ByteArray? = null    // unused (kept for backward compat)
)

/**
 * Lightweight episode/server descriptors used by the provider contract so the
 * player can list + pick without re-resolving.
 */
data class ProviderEpisode(val number: Int, val id: String, val rawId: String? = null, val title: String? = null)
data class ProviderServer(val id: String, val name: String)
data class ProviderAnime(
    val id: String,
    val title: String,
    val poster: String? = null,
    val episodes: Int = 0
)
