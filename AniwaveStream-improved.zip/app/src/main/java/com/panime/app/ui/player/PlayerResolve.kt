package com.panime.app.ui.player

import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.api.AnizoneApi
import com.panime.app.data.api.AnidapApi
import com.panime.app.data.provider.animenosub.AnimenosubApi
import com.panime.app.data.provider.moviebox.MovieboxProvider
import com.panime.app.data.provider.ProviderInitializer
import com.panime.app.data.provider.ProviderManager
import com.panime.app.data.provider.anidb.AnidbProvider
import com.panime.app.data.provider.anikage.AnikageProvider
import com.panime.app.data.provider.anikoto.AnikotoProvider
import com.panime.app.data.provider.aniwaves.AniwavesDirectProvider
import com.panime.app.data.provider.just4anime.Just4AnimeProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.content.Context

internal data class ResolvePack(
    val slug: String?,
    val anidbId: String?,
    val source: String,
    val servers: List<Pair<String, String>>,
    val url: String?,
    val rawUrl: String?,
    val isByfms: Boolean,
    val serverName: String?,
    val subtitles: List<AniwavesApi.SubtitleTrack>,
    val referer: String? = null,
    val format: String? = null,
    val quality: String? = null,
    val intro: Pair<Int, Int>? = null,
    val outro: Pair<Int, Int>? = null,
    val decryptKey: ByteArray? = null,
    val decryptIv: ByteArray? = null
)

internal fun candidateTitles(t: String): List<String> {
    val base = t.trim()
    val core = base.split(Regex("""\s*[:：-]\s*""")).first().trim()
    return if (core.equals(base, ignoreCase = true)) listOf(base) else listOf(base, core)
}

internal suspend fun resolveHybrid(
    context: Context,
    sourceMode: String,
    title: String,
    animeId: Int,
    episode: Int,
    currentType: String,
    selectedServerId: String?,
    selectedServerName: String?,
    seasonNumber: Int,
    slugHint: String?,
    totalEpisodes: Int = 0,
    year: Int? = null
): ResolvePack? = withContext(Dispatchers.IO) {
    ProviderInitializer.init(context.applicationContext)
    // sourceMode is always one of the 8 provider ids here (set from
    // lastSourceMode / the koto-wave lock / a wrong-title pick), so resolve
    // directly on it — the old identity-mapping `when` was dead logic.
    val result = ProviderManager.resolveOn(
        sourceMode, title, animeId, episode, currentType, selectedServerId, seasonNumber,
        slugHint = slugHint,
        totalEpisodes = totalEpisodes, year = year
    )
    result?.let { r ->
        ResolvePack(
            // Moviebox: carry the matched entry's "subjectId|detailPath" so the
            // Audio sheet can list language variants even in DEFAULT mode (no
            // wrong-title pick). Other providers don't need it (null).
            slug = if (sourceMode == "moviebox") r.servers.firstOrNull()?.first else null,
            anidbId = null,
            source = r.source,
            servers = r.servers,
            url = r.url,
            rawUrl = r.rawUrl,
            isByfms = r.isByfms,
            serverName = selectedServerName,
            subtitles = r.subtitles,
            referer = r.referer,
            format = r.format,
            quality = r.quality,
            intro = r.intro,
            outro = r.outro,
            decryptKey = r.decryptKey,
            decryptIv = r.decryptIv
        )
    }
}

internal fun filterServersForAudio(
    servers: List<Pair<String, String>>,
    sourceMode: String,
    currentType: String
): List<Pair<String, String>> {
    if (sourceMode == "anidb") {
        val wantId = if (currentType == "dub") "eng" else "jpn"
        val wantName = if (currentType == "dub") "English" else "Japanese"
        val filtered = servers.filter { (id, name) ->
            id.equals(wantId, true) || name.equals(wantName, true)
        }
        return if (filtered.isEmpty()) servers else filtered
    }
    if (sourceMode == "anikoto") {
        val ok: (String) -> Boolean = if (currentType == "dub") {
            { id -> id.startsWith("dub:") }
        } else {
            { id -> id.startsWith("sub:") || id.startsWith("hsub:") }
        }
        val filtered = servers.filter { ok(it.first) }
        return if (filtered.isEmpty()) servers else filtered
    }
    if (sourceMode == "just4anime") {
        val filtered = servers.filter { (id, _) ->
            if (currentType == "dub") id.endsWith("|dub", true)
            else id.endsWith("|sub", true) || id.endsWith("|hsub", true)
        }
        return if (filtered.isEmpty()) servers else filtered
    }
    return servers
}

internal suspend fun preloadServers(
    mode: String,
    type: String,
    title: String,
    animeId: Int,
    episode: Int,
    kotoSlug: String?,
    seasonNumber: Int = 0,
    totalEpisodes: Int = 0,
    year: Int? = null
): List<Pair<String, String>> = withContext(Dispatchers.IO) {
    runCatching {
        when (mode) {
            "anidb" -> {
                // Direct on-device provider — no backend. Wrong-title pick: the
                // picked "<slug>-<id>" yields a single server entry; otherwise
                // resolve title -> id on-device, then show the REAL per-episode
                // language entries (Japanese/English) exactly like the old
                // backend used to return.
                val pickedId = kotoSlug?.takeIf { it.isNotBlank() }
                    ?.substringAfterLast('-')?.takeIf { it.toIntOrNull() != null }
                if (pickedId != null) listOf("anidb" to "AniDB")
                else {
                    val provider = AnidbProvider()
                    val id = provider.animeIdFor(title, seasonNumber)
                    if (id == null) emptyList()
                    else provider.languageEntriesForEpisode(id, episode)
                }
            }
            "anizone" -> {
                // Wrong-title pick: kotoSlug carries the user's selected AniZone
                // slug. Use it directly, just like the other providers.
                val slug = if (!kotoSlug.isNullOrBlank()) kotoSlug else {
                    AnizoneApi.warmUp()
                    AnizoneApi.resolveSlug(title, totalEpisodes, seasonNumber, year)?.takeIf { it.isNotBlank() }
                }
                if (slug == null) emptyList()
                else {
                    // Show the REAL audio languages (Japanese/English/…) as the
                    // download choices. AniZone's m3u8 carries every track, so
                    // downloading any entry yields the full multi-audio stream.
                    val langs = runCatching { AnizoneApi.audioLanguages(slug, episode) }
                        .getOrDefault(emptyList())
                    if (langs.isNotEmpty()) langs.map { it to it }
                    else AnizoneApi.servers(slug, episode)
                }
            }
            "anikage" -> {
                AnikageProvider().listServersFor(title, animeId, episode, type)
            }
            "just4anime" -> {
                Just4AnimeProvider().listServersFor(title, animeId, episode, type)
            }
            "anidap" -> {
                AnidapApi.warmUp()
                // Wrong-title pick: use it directly (converted to anidap's chad
                // slug). If the hint isn't a valid pick (e.g. a koto catalog
                // slug), fall back to the default anilist-id match.
                val picked = kotoSlug?.takeIf { it.isNotBlank() }
                    ?.let { AnidapApi.chadSlugByPick(it) }
                if (picked != null) AnidapApi.serversBySlug(picked, episode, type)
                else AnidapApi.servers(animeId, episode, type)
            }
            "anikoto" -> {
                kotoSlug?.takeIf { it.isNotBlank() }
                    ?.let { AnikotoProvider().listServersFor(it, episode, type) }
            }
            "aniwaves" -> {
                AniwavesDirectProvider().listServersFor(title, episode, type, seasonNumber, anilistId = 0, slugHint = kotoSlug)
            }
            "moviebox" -> {
                // Wrong-title pick only (default resolve is disabled). Zone-style
                // download choices: the REAL language variants ("Original Audio",
                // "English dub", "French dub", …) — each is its own subject, so
                // picking one downloads that language. Not the single "Movie"
                // entry (that split is player-server-sheet-only).
                val slug = kotoSlug?.takeIf { it.isNotBlank() }
                if (slug == null) emptyList()
                else MovieboxProvider().listLanguagesFor(slug)
                    .ifEmpty { MovieboxProvider().listServersFor(slug) }
            }
            "animenosub" -> {
                // Wrong-title pick: the picked series' slug is used DIRECTLY —
                // only its own alternate URL spellings (…-english-dub,
                // zero-padded episodes) are tried. Never fall back to a
                // site-wide title search from a pick: its loose "slug contains
                // title" matching can land on a DIFFERENT show/season and play
                // the wrong episode.
                if (!kotoSlug.isNullOrBlank()) {
                    // Exact episode slug from the series page first (handles
                    // movies/specials), then the reconstructed candidates.
                    val candidates = buildList {
                        AnimenosubApi.listEpisodes(kotoSlug).firstOrNull { it.first == episode }
                            ?.second?.let { add(it) }
                        addAll(AnimenosubApi.epSlugs(kotoSlug, episode, type))
                    }.distinct()
                    candidates.firstNotNullOfOrNull { s ->
                        AnimenosubApi.serversFromSlug(s, expectedEpisode = episode)
                            // DUB tab shows DUB servers only; SUB tab shows
                            // SUB/RAW. The movie fallback (single page with no
                            // SUB/DUB prefix) keeps its real servers.
                            .filter { (episode == 1 && s == kotoSlug) || AnimenosubApi.hasAudio(listOf(it), type) }
                            .takeIf { it.isNotEmpty() }
                    }
                        // serversFromSlug returns (label, embedUrl). Swap to
                        // (embedUrl, label) so the BatchServerSheet shows the
                        // human name ("Moon") not the raw embed URL.
                        ?.map { (label, url) -> url to label }
                        .orEmpty()
                } else {
                    AnimenosubApi.warmUp()
                    AnimenosubApi.servers(title, episode, type, totalEpisodes, seasonNumber, year)
                        .map { (label, url) -> url to label }
                }
            }
            // Unreachable for the 8 known sources; keep the direct provider so
            // nothing references the legacy backend client.
            else -> {
                AniwavesDirectProvider().listServersFor(title, episode, type, seasonNumber, anilistId = 0, slugHint = null)
            }
        }
    }.getOrNull().orEmpty()
}
