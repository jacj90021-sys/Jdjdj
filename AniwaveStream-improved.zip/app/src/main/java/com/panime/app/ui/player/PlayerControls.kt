package com.panime.app.ui.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.outlined.AspectRatio
import androidx.compose.material.icons.outlined.BrightnessHigh
import androidx.compose.material.icons.outlined.PictureInPictureAlt
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panime.app.R
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.PlexMono

// ---------------------------------------------------------------------------
// Models
// ---------------------------------------------------------------------------

internal data class SeekFlash(val left: Boolean)

internal sealed class GestureHud {
    data class Brightness(val value: Float) : GestureHud()
    data class Volume(val value: Float) : GestureHud()
    data class Scrub(val position: Long, val duration: Long) : GestureHud()
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

internal fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).toInt().coerceAtLeast(0)
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

// ---------------------------------------------------------------------------
// Overlays
// ---------------------------------------------------------------------------

@Composable
internal fun SeekFlashOverlay(flash: SeekFlash?) {
    AnimatedVisibility(
        visible = flash != null,
        enter = fadeIn(tween(80)) + scaleIn(initialScale = 0.7f),
        exit = fadeOut(tween(280)),
        modifier = Modifier.fillMaxSize()
    ) {
        val left = flash?.left == true
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.42f)
                    .align(if (left) Alignment.CenterStart else Alignment.CenterEnd)
                    .background(
                        Brush.horizontalGradient(
                            if (left) {
                                listOf(
                                    Color.White.copy(alpha = 0.14f),
                                    Color.Transparent
                                )
                            } else {
                                listOf(
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.14f)
                                )
                            }
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        if (left) Icons.Filled.Replay10 else Icons.Filled.Forward10,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        if (left) "\u221210" else "+10",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
internal fun BoxScope.GestureHudOverlay(hud: GestureHud?) {
    AnimatedVisibility(
        visible = hud != null,
        modifier = Modifier.align(Alignment.Center),
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        val h = hud
        if (h != null) {
            Column(
                Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 22.dp, vertical = 16.dp)
                    .widthIn(min = 120.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (h) {
                    is GestureHud.Brightness -> {
                        Icon(Icons.Outlined.BrightnessHigh, null, tint = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            stringResource(R.string.brightness),
                            color = Color.White.copy(alpha = 0.8f),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(Modifier.height(8.dp))
                        HudBar(h.value)
                    }
                    is GestureHud.Volume -> {
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, null, tint = Color.White)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            stringResource(R.string.volume),
                            color = Color.White.copy(alpha = 0.8f),
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(Modifier.height(8.dp))
                        HudBar(h.value)
                    }
                    is GestureHud.Scrub -> {
                        Text(
                            formatTime(h.position),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                        Text(
                            "/ ${formatTime(h.duration)}",
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HudBar(fraction: Float) {
    Box(
        Modifier
            .width(120.dp)
            .height(4.dp)
            .clip(RoundedCornerShape(2.dp))
            .background(Color.White.copy(alpha = 0.25f))
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .background(Flame)
        )
    }
}

// ---------------------------------------------------------------------------
// Scrubber
// ---------------------------------------------------------------------------

@Composable
internal fun PremiumScrubber(
    position: Float,
    buffered: Float,
    duration: Float,
    onScrub: (Float) -> Unit,
    onScrubFinished: (Float) -> Unit
) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(position) }
    val shown = if (dragging) dragValue else position
    val posFrac = (shown / duration).coerceIn(0f, 1f)
    val bufFrac = (buffered / duration).coerceIn(0f, 1f)

    Box(
        Modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(duration) {
                detectHorizontalDragGestures(
                    onDragStart = {
                        dragging = true
                        dragValue = position
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        val w = size.width.coerceAtLeast(1)
                        val f = (change.position.x / w).coerceIn(0f, 1f)
                        dragValue = f * duration
                        onScrub(dragValue)
                    },
                    onDragEnd = {
                        dragging = false
                        onScrubFinished(dragValue)
                    },
                    onDragCancel = { dragging = false }
                )
            }
            .pointerInput(duration) {
                detectTapGestures { offset ->
                    val w = size.width.coerceAtLeast(1)
                    val f = (offset.x / w).coerceIn(0f, 1f)
                    val v = f * duration
                    onScrub(v)
                    onScrubFinished(v)
                }
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(if (dragging) 5.dp else 3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.22f))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(bufFrac)
                    .background(Color.White.copy(alpha = 0.35f))
            )
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(posFrac)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Flame.copy(alpha = 0.85f), Flame)
                        )
                    )
            )
        }
        Box(
            Modifier
                .fillMaxWidth(posFrac)
                .padding(end = 0.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Box(
                Modifier
                    .size(if (dragging) 16.dp else 12.dp)
                    .shadow(4.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Color.White)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// Controls bits
// ---------------------------------------------------------------------------

@Composable
internal fun TransportIcon(
    icon: ImageVector,
    size: Dp,
    contentDescription: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    IconButton(onClick = onClick, enabled = enabled) {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = if (enabled) Color.White else Color.White.copy(alpha = 0.28f),
            modifier = Modifier.size(size)
        )
    }
}

@Composable
internal fun BottomAction(
    icon: ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 4.dp, vertical = 2.dp)
            .widthIn(min = 44.dp)
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(2.dp))
        Text(
            label,
            color = tint.copy(alpha = 0.9f),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
internal fun MoreSolidMenu(
    resizeMode: Int,
    speed: Float,
    offline: Boolean = false,
    onFit: () -> Unit,
    onPip: () -> Unit,
    onRotate: () -> Unit,
    onCast: () -> Unit,
    onSpeed: () -> Unit
) {
    val surface = Color(0xFF16181D)
    Column(
        Modifier
            .widthIn(min = 210.dp, max = 250.dp)
            .shadow(24.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(surface)
            .padding(vertical = 8.dp)
    ) {
        val fitLabel = when (resizeMode) {
            0 -> stringResource(R.string.fit_screen)
            1 -> stringResource(R.string.zoom)
            else -> stringResource(R.string.fill)
        }
        MoreMenuRow(
            icon = Icons.Outlined.AspectRatio,
            label = fitLabel,
            active = resizeMode != 0,
            onClick = onFit
        )
        MoreMenuRow(
            icon = Icons.Outlined.PictureInPictureAlt,
            label = stringResource(R.string.picture_in_picture),
            onClick = onPip
        )
        MoreMenuRow(
            icon = Icons.Filled.ScreenRotation,
            label = stringResource(R.string.rotate_screen),
            onClick = onRotate
        )
        // Cast pushes the on-screen stream to another device; a downloaded
        // (offline) episode is stored in the app's private segment cache that a
        // Cast receiver can't access, so casting it isn't functional — hide it.
        if (!offline) {
            MoreMenuRow(
                icon = Icons.Filled.Cast,
                label = stringResource(R.string.cast),
                onClick = onCast
            )
        }
        MoreMenuRow(
            icon = Icons.Outlined.Speed,
            label = if (speed == 1f) {
                stringResource(R.string.playback_speed)
            } else {
                "${stringResource(R.string.playback_speed)} \u00b7 ${speed}x"
            },
            active = speed != 1f,
            onClick = onSpeed
        )
    }
}

@Composable
internal fun MoreMenuRow(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = if (active) Flame else Color.White,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(12.dp))
        Text(
            label,
            color = if (active) Flame else Color.White,
            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
internal fun SnagBanner(
    detail: String?,
    onRetry: () -> Unit
) {
    // Compact bottom banner for transient mid-playback drops — the video stays
    // fully visible; this never takes over the screen. Auto-hides when the
    // player recovers (PlaybackErrorOverlay is reserved for hard failures).
    Box(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp)
            .navigationBarsPadding()
            .padding(bottom = 8.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black.copy(alpha = 0.82f))
                .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(10.dp))
                .padding(start = 12.dp, end = 6.dp, top = 9.dp, bottom = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "\u26A0",
                color = Color.White,
                fontSize = 14.sp,
                modifier = Modifier.padding(end = 10.dp)
            )
            Column(Modifier.weight(1f)) {
                Text(
                    "Playback hiccup — reconnecting…",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.5.sp
                )
                if (!detail.isNullOrBlank()) {
                    Text(
                        detail,
                        color = Color.White.copy(alpha = 0.72f),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Box(
                Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.White.copy(alpha = 0.12f))
                    .clickable(onClick = onRetry)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    "RETRY",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    fontFamily = PlexMono
                )
            }
        }
    }
}

@Composable
internal fun PlaybackErrorOverlay(
    detail: String?,
    onRetry: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.88f))
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            stringResource(R.string.playback_error_title),
            color = Color.White,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.playback_error_message),
            color = Color.White.copy(alpha = 0.75f),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
        if (!detail.isNullOrBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(
                detail,
                color = Color.White.copy(alpha = 0.65f),
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(24.dp))
        Box(
            Modifier
                .border(2.dp, Flame)
                .background(Flame)
                .clickable(onClick = onRetry)
                .padding(horizontal = 32.dp, vertical = 14.dp)
        ) {
            Text(
                stringResource(R.string.retry),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontFamily = PlexMono
            )
        }
    }
}
