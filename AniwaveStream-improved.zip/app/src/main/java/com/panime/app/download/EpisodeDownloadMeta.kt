package com.panime.app.download

import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.offline.DownloadRequest
import org.json.JSONArray
import org.json.JSONObject

/**
 * Application-level metadata for one downloadable episode.
 *
 * This is serialized into [DownloadRequest.data] so it survives process death
 * inside Media3's own persistent DownloadIndex (single source of truth — no
 * duplicate state). It contains EVERYTHING needed to:
 *  - rebuild the request after an expired URL (provider/source/slug/audioType),
 *  - attach provider-required headers to every HTTP request,
 *  - render the UI row without extra lookups,
 *  - re-resolve and re-enqueue with the SAME id/cache key (partial data kept).
 */
data class EpisodeDownloadMeta(
    val id: String,
    val animeId: Int,
    val episode: Int,
    val seasonNumber: Int = 1,
    val title: String,
    val episodeLabel: String,
    val posterUrl: String? = null,
    val quality: String? = null,
    val serverLabel: String? = null,
    val sourceMode: String,
    val audioType: String = "sub",
    val slugHint: String? = null,
    val totalEps: Int = 0,
    val streamUrl: String,
    val format: String? = "hls",
    val headers: Map<String, String> = emptyMap(),
    val subtitles: List<Triple<String, String, String>> = emptyList(),
    val decryptKeyB64: String? = null,
    val createdAtMs: Long = System.currentTimeMillis()
) {
    val mimeType: String
        get() = when {
            format == "mp4" -> MimeTypes.VIDEO_MP4
            format == "dash" || format == "mpd" -> MimeTypes.APPLICATION_MPD
            else -> MimeTypes.APPLICATION_M3U8
        }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("animeId", animeId)
        .put("episode", episode)
        .put("seasonNumber", seasonNumber)
        .put("title", title)
        .put("episodeLabel", episodeLabel)
        .put("posterUrl", posterUrl ?: "")
        .put("quality", quality ?: "")
        .put("serverLabel", serverLabel ?: "")
        .put("sourceMode", sourceMode)
        .put("audioType", audioType)
        .put("slugHint", slugHint ?: "")
        .put("totalEps", totalEps)
        .put("streamUrl", streamUrl)
        .put("format", format ?: "hls")
        .put("headers", JSONObject().apply { headers.forEach { (k, v) -> put(k, v) } })
        .put("subtitles", JSONArray().apply {
            subtitles.forEach { (lang, label, url) ->
                put(JSONObject().put("lang", lang).put("label", label).put("url", url))
            }
        })
        .put("decryptKeyB64", decryptKeyB64 ?: "")
        .put("createdAtMs", createdAtMs)

    companion object {
        /** Stable request/download/cache id — same id keeps partial cache across URL refreshes. */
        fun idFor(animeId: Int, season: Int, episode: Int): String =
            "dl_${animeId}_${season}_${episode}"

        fun fromJson(o: JSONObject): EpisodeDownloadMeta? = runCatching {
            val subs = mutableListOf<Triple<String, String, String>>()
            val sArr = o.optJSONArray("subtitles")
            for (i in 0 until (sArr?.length() ?: 0)) {
                val so = sArr!!.optJSONObject(i) ?: continue
                subs.add(Triple(so.optString("lang"), so.optString("label"), so.optString("url")))
            }
            val headers = mutableMapOf<String, String>()
            o.optJSONObject("headers")?.let { h ->
                h.keys().forEach { k -> headers[k] = h.optString(k) }
            }
            EpisodeDownloadMeta(
                id = o.getString("id"),
                animeId = o.getInt("animeId"),
                episode = o.getInt("episode"),
                seasonNumber = o.optInt("seasonNumber", 1),
                title = o.getString("title"),
                episodeLabel = o.optString("episodeLabel"),
                posterUrl = o.optString("posterUrl").ifBlank { null },
                quality = o.optString("quality").ifBlank { null },
                serverLabel = o.optString("serverLabel").ifBlank { null },
                sourceMode = o.optString("sourceMode"),
                audioType = o.optString("audioType").ifBlank { "sub" },
                slugHint = o.optString("slugHint").ifBlank { null },
                totalEps = o.optInt("totalEps", 0),
                streamUrl = o.getString("streamUrl"),
                format = o.optString("format", "hls"),
                headers = headers,
                subtitles = subs,
                decryptKeyB64 = o.optString("decryptKeyB64").ifBlank { null },
                createdAtMs = o.optLong("createdAtMs", System.currentTimeMillis())
            )
        }.getOrNull()

        fun decode(data: ByteArray?): EpisodeDownloadMeta? =
            data?.let { runCatching { JSONObject(String(it)) }.getOrNull() }?.let(::fromJson)
    }
}

/**
 * Builds the Media3 request.
 *
 * customCacheKey is ONLY legal for progressive media — media3 throws
 * "customCacheKey must be null for type: N" for HLS/DASH/SS. Adaptive streams
 * instead get stable cache identity from PlayerModule.normalizeKeyFactory
 * (query-stripped URI keys), which survives token-in-query URL refreshes.
 */
fun EpisodeDownloadMeta.toDownloadRequest(): DownloadRequest {
    val builder = DownloadRequest.Builder(id, android.net.Uri.parse(streamUrl))
        .setMimeType(mimeType)
        .setData(toJson().toString().toByteArray())
    if (format == "mp4") builder.setCustomCacheKey(id)
    return builder.build()
}
