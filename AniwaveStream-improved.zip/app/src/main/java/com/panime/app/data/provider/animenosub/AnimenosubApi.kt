package com.panime.app.data.provider.animenosub

import android.util.Base64
import android.util.Log
import com.panime.app.data.api.AniwavesApi
import com.panime.app.data.provider.ScraperEngine
import com.panime.app.util.Obf
import kotlinx.serialization.json.*
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * animenosub.to — direct m3u8 stream resolver.
 *
 * Servers that work without a browser:
 *   Moon     -> bysesayeveum.com/e/<CODE>  (API + AES-256-GCM decrypt)
 *   Omega    -> vidmoly.biz/embed-<ID>.html  (JWPlayer, plain m3u8)
 *   Nova     -> nova.upn.one/#<ID>  (AES-128-CBC decrypt + CDN m3u8)
 *
 * RAW-Omega excluded: vidmoly returns "Video Processing" stub.
 */
object AnimenosubApi {

    private const val TAG = "AnimenosubApi"
    private val BASE = Obf.s("Mi4uKilgdXU7NDM3PzQ1KS84dC41")
    private val REFERER = Obf.s("Mi4uKilgdXU7NDM3PzQ1KS84dC41dQ==")
    private const val UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        + "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

    private val MIRROR_RE = Regex("""<option value="([^"]*)"[^>]*>\s*([^<]+)</option>""")
    // Episode rows use both /anime/<slug>/ and direct /<slug>/ URLs.
    // The latter is used by movie pages (e.g. "Episode Movie").
    private val EP_LINK_RE = Regex(Obf.s("Mig/PGd4Mi4uKilgdXU7NDM3PzQ1KS84BnQuNXVyZWA7NDM3P3VzZXIBBHgHcXN1eA=="), RegexOption.IGNORE_CASE)
    private val EP_NUM_RE = Regex("""-episode-(\d+)""", RegexOption.IGNORE_CASE)
    private val CANONICAL_ANIME_RE = Regex(Obf.s("ZjYzNDEBBGQHcSg/NmcBBnh9Bzk7NDU0Mzk7NgEGeH0HAQRkB3EyKD88ZwEGeH0HMi4uKilgdXU7NDM3PzQ1KS84BnQuNXU7NDM3P3VyAQR1Bnh9B3FzdWUBBnh9Bw=="), RegexOption.IGNORE_CASE)
    private val EP_LIST_START_RE = Regex("""<div[^>]+class=[\"'][^\"']*eplister[^\"']*[\"'][^>]*>""", RegexOption.IGNORE_CASE)
    private val EMBED_CODE_RE = Regex(Obf.s("OCMpPyk7Iz8sPy83BnQ5NTd1P3VyARt3ADt3IGp3YwV3B3Fz"), RegexOption.IGNORE_CASE)
    private val M3U8_RE = Regex("""https?://[^"'\s]+\.m3u8[^"'\s)]*""")
    private val SRC_RE = Regex("""src="(https?://[^"]+)" """)
    private val SRC_REL_RE = Regex("""src="(//[^"]+)""")
    private val VIDMOLY_HOSTS = listOf("vidmoly.biz", "vidmoly.net")
    private val TURBOVID_RE = Regex(Obf.s("Mi4uKillYHV1OT40BnQuLyg4NSwzKjY7IwZ0OTU3dQEEeH0GKQdxBnQ3aS9i"))
    private val NOVA_UPN_RE = Regex(Obf.s("NDUsOwZ0Lyo0BnQ1ND91eWVyBi1xcw=="), RegexOption.IGNORE_CASE)
    private val NOVA_UPN_KEY = "kiemtienmua911ca".toByteArray(Charsets.UTF_8)
    private val NOVA_UPN_IV  = "1234567890oiuytr".toByteArray(Charsets.UTF_8)
    private val VIDMOLY_FILE_RE = Regex("""file:\s*'(https?://[^']+\.m3u8[^']*)'""")
    private val VIDMOLY_FILE_RE2 = Regex("""file:\s*"(https?://[^"]+\.m3u8[^"]*)"""")

    fun warmUp() { /* no-op */ }

    // ── Title → slug ──────────────────────────────────────────────────────

    fun titleToSlug(title: String): String {
        return title.trim()
            .lowercase()
            .replace(Regex("[^a-z0-9\\s-]"), "")
            .replace(Regex("\\s+"), "-")
            .replace(Regex("-+"), "-")
            .trim('-')
    }

    // ── Episode list ──────────────────────────────────────────────────────

    // Series pages for long-running shows are huge (One Piece ≈ 580 KB) and
    // the resolve pipeline consults them repeatedly (candidates, retries,
    // audio checks). Cache briefly — 10 min matches a typical viewing session.
    private val epListCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, List<Pair<Int, String>>>>()
    private const val EP_CACHE_TTL_MS = 10 * 60_000L

    fun listEpisodes(seriesSlug: String): List<Pair<Int, String>> {
        val now = System.currentTimeMillis()
        epListCache[seriesSlug]?.let { (at, v) -> if (now - at < EP_CACHE_TTL_MS) return v }
        val html = ScraperEngine.fetchText(
            "$BASE/anime/$seriesSlug/",
            headers = defaultHeaders()
        ) ?: return emptyList()
        val canonicalSlug = canonicalSlugFromHtml(html)
        // Newest DUB releases are listed as "<sub-slug>-episode-N-english-dub"
        // while older ones use "<series>-episode-N" (e.g. one-piece-dub lists
        // 1134+ only in the -english-dub form). Accept both formats when they
        // belong to this series; otherwise the list stops at the format switch
        // (site shows 1155 for one-piece-dub, old regex found only 1133).
        val roots = buildSet {
            add(seriesSlug)
            // The site moves series qualifiers to the END of episode slugs
            // (…-episode-01-bd, …-episode-N-english-dub) instead of keeping
            // them after the series name, so a "-bd"/"-dub"/"-uncensored"
            // series page also matches via its bare series slug.
            var bare = seriesSlug
            for (q in listOf("-bd", "-dub", "-uncensored", "-english-dub")) {
                if (bare.endsWith(q)) bare = bare.removeSuffix(q)
            }
            add(bare)
        }
        val episodeArea = EP_LIST_START_RE.find(html)?.let { start ->
            // Keep everything after the episode-list marker. Restricting to a
            // guessed closing div is unsafe because the list contains nested
            // markup and can truncate valid episode links.
            html.substring(start.range.last + 1)
                .substringBefore("<div class=\"bixbox\"", "")
        }.orEmpty()
        val source = if (episodeArea.isNotBlank()) episodeArea else html
        val seen = mutableMapOf<Int, String>()
        for (match in EP_LINK_RE.findAll(source)) {
            val slug = match.groupValues[1]
            if (roots.none { slug.startsWith("$it-episode-") }) continue
            val m = EP_NUM_RE.find(slug)
            val num = m?.groupValues?.get(1)?.toIntOrNull()
            if (num != null) {
                if (num !in seen) seen[num] = slug
            } else if (slug == seriesSlug || slug.startsWith("$seriesSlug-") ||
                (canonicalSlug != null && (slug == canonicalSlug || slug.startsWith("$canonicalSlug-")))) {
                // Movie/OVA/special pages may expose a single history row named
                // Movie instead of a slug containing -episode-N. It is still the
                // picked source's first playable entry; preserve its real link.
                if (1 !in seen) seen[1] = slug
            }
        }
        val out = seen.keys.sorted().map { it to seen[it]!! }
        if (out.isNotEmpty()) {
            if (epListCache.size > 24) epListCache.clear()
            epListCache[seriesSlug] = now to out
            return out
        }
        // No -episode-N links found (movie/special). Parse the page's own
        // "Episodes: N" count and use the series page itself as the single
        // playable entry — the resolver works directly from the picked slug.
        // Movie/special pages are represented by one playable entry. Do not
        // fabricate a row for every episode count: those rows all point to the
        // same page and make the UI claim availability that does not exist.
        val movieSlug = canonicalSlug ?: seriesSlug
        val fallback = listOf(1 to movieSlug)
        if (epListCache.size > 24) epListCache.clear()
        epListCache[seriesSlug] = now to fallback
        return fallback
    }

    private fun canonicalSlugFromHtml(html: String): String? =
        CANONICAL_ANIME_RE.find(html)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }

    // ── Server list ───────────────────────────────────────────────────────

    /**
     * Does this episode page actually serve the requested audio type?
     * Labels look like "DUB - Moon", "SUB - Omega", "RAW - Nova" (older eps
     * may drop the prefix, e.g. "FileMoon" — treat those as SUB-side extras).
     */
    fun hasAudio(servers: List<Pair<String, String>>, type: String): Boolean {
        return servers.any { (label, _) ->
            val low = label.lowercase()
            when (type) {
                "dub" -> low.startsWith("dub")
                else -> low.startsWith("sub") || low.startsWith("raw") ||
                    (!low.startsWith("dub") && !low.startsWith("select"))
            }
        }
    }

    /**
     * Episode-page URL slugs for a series + episode number. Newest DUB
     * releases of a "-dub" series live on "<sub-slug>-episode-N-english-dub"
     * pages (one-piece-dub-episode-1134 is 404; the site links ep 1134+ as
     * one-piece-episode-1134-english-dub). Same series only — never another
     * series entry.
     */
    fun epSlugs(seriesSlug: String, episode: Int, type: String?): List<String> = buildList {
        add("$seriesSlug-episode-$episode")
        // Zero-padded episode posts (…-episode-01, Re:Zero S3) — the site
        // 301-redirects the unpadded form (…-episode-1) to …-episode-10 and
        // 404s for 2-9, so the padded spelling must be tried too.
        val padded = "%02d".format(episode)
        if (padded != episode.toString()) add("$seriesSlug-episode-$padded")
        // Site moves series qualifiers to the END of episode slugs
        // (…-season-2-episode-01-bd, …-episode-N-english-dub) instead of
        // keeping them after the series name — a "-bd"/"-uncensored" series
        // entry's episode pages are "<bare>-episode-N<qualifier>".
        for (q in listOf("-bd", "-uncensored")) {
            if (seriesSlug.endsWith(q)) {
                val bare = seriesSlug.removeSuffix(q)
                add("$bare-episode-$episode$q")
                if (padded != episode.toString()) add("$bare-episode-$padded$q")
            }
        }
        if (seriesSlug.endsWith("-dub")) {
            val bare = seriesSlug.removeSuffix("-dub")
            add("$bare-episode-$episode-english-dub")
            if (padded != episode.toString()) add("$bare-episode-$padded-english-dub")
        } else if (type == "dub") {
            add("$seriesSlug-episode-$episode-english-dub")
            if (padded != episode.toString()) add("$seriesSlug-episode-$padded-english-dub")
        }
    }.distinct()

    /**
     * [type] is "dub"/"sub"/null. Some series split SUB and DUB into separate
     * site entries (e.g. one-piece vs one-piece-dub). For DUB requests, if the
     * base slug's page has no DUB mirrors, retry the "-dub" / "-english-dub"
     * variants before falling back to site search.
     */
    fun servers(
        title: String,
        episode: Int,
        type: String? = null,
        totalEpisodes: Int = 0,
        seasonNumber: Int = 1,
        year: Int? = null
    ): List<Pair<String, String>> {
        // Try direct slug first (title → slug conversion)
        val directSlug = titleToSlug(title)
        val slugCandidates = if (type == "dub") listOf(directSlug, "$directSlug-dub")
                             else listOf(directSlug)
        for (slug in slugCandidates) {
            // The series page's own episode links are the source of truth for
            // the exact URL spelling (zero-padded, -bd/-uncensored/-english-dub
            // at the end, renamed titles…) — try it before any reconstructed
            // candidate.
            listEpisodes(slug).firstOrNull { it.first == episode }?.second?.let { exact ->
                val got = serversFromSlug(exact, expectedEpisode = episode)
                if (got.isNotEmpty() && (type == null || hasAudio(got, type))) return got
            }
            for (eps in epSlugs(slug, episode, type)) {
                val got = serversFromSlug(eps, expectedEpisode = episode)
                if (got.isEmpty()) continue
                if (type == null || hasAudio(got, type)) return got
            }
        }

        // Cheap existence check BEFORE the expensive site-wide search sweep:
        // if the direct series page(s) loaded fine and don't list this episode
        // at all, it isn't on animenosub — fail fast instead of crawling every
        // fuzzy search candidate (each one a ~580 KB page for long-running
        // series like One Piece).
        val directListed = slugCandidates.any { slug ->
            val l = listEpisodes(slug)
            l.isNotEmpty() && (l.any { it.first == episode } || epSlugs(slug, episode, type)
                .any { serversFromSlug(it, expectedEpisode = episode).isNotEmpty() })
        }
        if (slugCandidates.any { listEpisodes(it).isNotEmpty() } && !directListed) {
            Log.i(TAG, "Episode $episode not listed on animenosub for '$directSlug' — skipping search fallback")
            return emptyList()
        }

        // The site collapses base-series slugs: fetching "/anime/<bare>/"
        // 301-redirects to the real season entry (…-season-3-, …-season-4-),
        // so the bare "<bare>-episode-N" page 404s while the canonical one
        // "<season>-episode-N" exists. Follow that redirect before trusting the
        // ?s= search, whose failure then only surfaces sidebar noise that can
        // land on the WRONG season (Re:Zero season 4 instead of season 3).
        val canonical = canonicalEpisodeSlug(directSlug, episode)
            ?.let { serversFromSlug(it) }
        if (!canonical.isNullOrEmpty()) {
            if (type == null || hasAudio(canonical, type)) return canonical
            Log.i(TAG, "Canonical episode page for '$directSlug' ep $episode found but lacks audio '$type' — falling back to search")
        }

        // Fallback: search the site for the correct slug — verified by episode
        // + year (and season marker) so a bare title can't land on the wrong
        // season or a different anime with the same words.
        val found = searchSlug(title, episode, type, totalEpisodes, seasonNumber, year)
            ?: return emptyList()
        return epSlugs(found, episode, type)
            .firstNotNullOfOrNull { serversFromSlug(it, expectedEpisode = episode).takeIf { s -> s.isNotEmpty() } }
            .orEmpty()
    }

    /**
     * The site 301-redirects bare series slugs to the real season entry (e.g.
     * "rezero-starting-life-in-another-world" → "…-season-3-"), so the direct
     * "<bare>-episode-N" page 404s. Rebuild the actual episode URL from the
     * redirected series page's own episode links instead of guessing a season
     * or falling into the unreliable ?s= search.
     */
    private fun canonicalEpisodeSlug(seriesSlug: String, episode: Int): String? {
        val html = ScraperEngine.fetchText(
            "$BASE/anime/$seriesSlug/",
            headers = defaultHeaders()
        ) ?: return null
        // Every episode link on a series page is "<prefix>-episode-N". Vote on
        // the prefix across the WHOLE list: the most common prefix is this
        // page's own series — whatever the slug redirected to ("…-season-3-",
        // "…-part-2-bd-uncensored-", "berserk-of-gluttony-"). Sidebar links to
        // unrelated shows use other prefixes and lose the vote.
        val byPrefix = HashMap<String, Int>()
        val wanted = LinkedHashMap<String, String>() // prefix -> episode-N slug
        for (m in EP_LINK_RE.findAll(html)) {
            val stub = m.groupValues[2]
            val num = EP_NUM_RE.find(stub)?.groupValues?.get(1)?.toIntOrNull() ?: continue
            val prefix = stub.substringBeforeLast("-episode-", stub)
            byPrefix[prefix] = (byPrefix[prefix] ?: 0) + 1
            if (num == episode) wanted.putIfAbsent(prefix, stub)
        }
        if (wanted.isEmpty()) return null
        val canonical = byPrefix.maxByOrNull { it.value }?.key ?: wanted.keys.first()
        // Prefer the wanted episode under the page's canonical series; fall back
        // to a resolving alias (specials / cour renumbering split prefixes).
        val ordered = (linkedSetOf(canonical) + wanted.keys).distinct()
        for (prefix in ordered) {
            val stub = wanted[prefix] ?: continue
            if (serversFromSlug(stub, expectedEpisode = episode).isNotEmpty()) return stub
        }
        return null
    }

    /**
     * Search animenosub.to for a title and return the best-matching series slug.
     * Verifies the slug has the requested episode — and, when [type] is set,
     * that the page actually serves that audio type — before returning.
     *
     * The site splits multi-season series into separate entries (…-season-2-bd,
     * …-season-3, …), so candidates are ranked by season marker (vs
     * [seasonNumber]), episode count (vs [totalEpisodes]) and the year the
     * series page declares as "Released" (vs [year]). A candidate is accepted
     * only when it has the episode AND agrees on year when the page provides
     * one; if strict verification rejects everything, the legacy first-match
     * behavior is kept so sparse data never breaks playback.
     */
    private fun searchSlug(
        title: String,
        episode: Int = 0,
        type: String? = null,
        totalEpisodes: Int = 0,
        seasonNumber: Int = 1,
        year: Int? = null
    ): String? {
        val results = search(title)
        if (results.isEmpty()) return null
        val wanted = titleToSlug(title)
        // Exact slug match first; for DUB also rank "-dub"-suffixed slugs early.
        val exact = results.firstOrNull { it.first == wanted }?.first
        val dubExact = if (type == "dub") results.firstOrNull { it.first == "$wanted-dub" }?.first else null
        // Partial match — slug contains the wanted slug or vice versa
        val partial = results.firstOrNull {
            it.first.contains(wanted) || wanted.contains(it.first)
        }?.first
        // Rank: exact/dub-exact/partial get a head start, then season + episode
        // count, so a bare "Re:Zero" query can't land on …-season-4 for a
        // season-2 episode.
        val scored = (listOfNotNull(exact, dubExact, partial) + results.map { it.first })
            .distinct()
            .map { c ->
                val bonus = when (c) {
                    exact -> 100
                    dubExact -> 90
                    partial -> 60
                    else -> 0
                }
                c to (bonus + seasonScore(c, seasonNumber) + epCountScore(c, totalEpisodes))
            }
            .sortedByDescending { it.second }
            .map { it.first }

        // Strict pass: episode + audio + year agreement.
        for (candidate in scored) {
            if (episode <= 0) return candidate
            val eps = listEpisodes(candidate)
            if (eps.any { it.first == episode }) {
                if (year != null) {
                    val y = releasedYear(candidate)
                    if (y != null && y != year) {
                        Log.i(TAG, "Year mismatch for '$candidate': $y vs expected $year — skipping")
                        continue
                    }
                }
                if (type != null) {
                    val srv = epSlugs(candidate, episode, type)
                        .firstNotNullOfOrNull { s ->
                            serversFromSlug(s, expectedEpisode = episode).takeIf { it.isNotEmpty() }
                        }
                    if (srv == null || !hasAudio(srv, type)) continue
                }
                return candidate
            }
        }
        // Safety net: strict verification rejected everything (sparse/odd year
        // data) — keep the legacy first-with-episode behavior.
        for (candidate in scored) {
            if (episode <= 0) return candidate
            if (listEpisodes(candidate).any { it.first == episode }) return candidate
        }
        return null
    }

    /** Season number embedded in a site slug (…-season-2-bd → 2); 1 if none. */
    private fun seasonFromSlug(slug: String): Int {
        Regex("""season-([0-9]+)""", RegexOption.IGNORE_CASE).find(slug)
            ?.let { return it.groupValues[1].toIntOrNull() ?: 1 }
        return 1
    }

    private fun seasonScore(slug: String, seasonNumber: Int): Int {
        if (seasonNumber <= 1) return 0
        val s = seasonFromSlug(slug)
        return when {
            s == seasonNumber -> 40
            s > 1 -> -40
            else -> 0
        }
    }

    /** Episode-count agreement with AniList's total (0 = unknown, no penalty). */
    private fun epCountScore(slug: String, totalEpisodes: Int): Int {
        if (totalEpisodes <= 0) return 0
        val n = listEpisodes(slug).size
        if (n == 0) return -10
        val diff = kotlin.math.abs(n - totalEpisodes)
        return when {
            diff <= 1 -> 30
            diff <= 3 -> 15
            diff <= 6 -> 5
            else -> -20
        }
    }

    // Series page declares "Released: YYYY"; cached briefly like the ep list.
    private val yearCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Long, Int?>>()
    private const val YEAR_CACHE_TTL_MS = 10 * 60_000L

    private fun releasedYear(slug: String): Int? {
        val now = System.currentTimeMillis()
        yearCache[slug]?.let { (at, v) -> if (now - at < YEAR_CACHE_TTL_MS) return v }
        val html = ScraperEngine.fetchText("$BASE/anime/$slug/", headers = defaultHeaders())
            ?: return null
        val y = Regex("""<b>Released:</b>\s*([0-9]{4})""", RegexOption.IGNORE_CASE)
            .find(html)?.groupValues?.get(1)?.toIntOrNull()
        if (yearCache.size > 64) yearCache.clear()
        yearCache[slug] = now to y
        return y
    }

    fun serversFromSlug(epSlug: String, expectedEpisode: Int? = null): List<Pair<String, String>> {
        val url = if (epSlug.startsWith("http")) epSlug else "$BASE/$epSlug/"
        val html = ScraperEngine.fetchText(url, headers = defaultHeaders()) ?: return emptyList()
        // Verify the page is actually the requested episode: the site
        // 301-redirects ambiguous unpadded slugs (…-episode-1) to a DIFFERENT
        // episode (…-episode-10), so the parsed mirrors would be the wrong
        // video. Every episode page has <title>Watch <Show> Episode N …</title>
        // — trust it over the requested slug and reject mismatches.
        if (expectedEpisode != null) {
            val title = Regex("""<title[^>]*>([^<]*)</title>""", RegexOption.IGNORE_CASE)
                .find(html)?.groupValues?.get(1).orEmpty()
            val pageEp = Regex("""Episode\s+(\d+)""", RegexOption.IGNORE_CASE)
                .find(title)?.groupValues?.get(1)?.toIntOrNull()
            // Regular episode pages must identify the requested episode. Movie
            // pages often have no "Episode N" in <title>; allow those only for
            // the single movie fallback (episode 1), never for numbered pages.
            if (pageEp != null && pageEp != expectedEpisode) return emptyList()
            if (pageEp == null && expectedEpisode != 1) return emptyList()
        }
        val sel = Regex("""<select[^>]*class="[^"]*mirror[^"]*"[^>]*>.*?</select>""", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.value ?: return emptyList()
        val out = mutableListOf<Pair<String, String>>()
        for (m in MIRROR_RE.findAll(sel)) {
            val (b64val, label) = m.destructured
            val trimmed = label.trim()
            if (b64val.isBlank() || trimmed.lowercase().startsWith("select")) continue
            val low = trimmed.lowercase()
            if ("megaplay" in low) continue
            try {
                val dec = String(Base64.decode(b64val, Base64.DEFAULT), Charsets.UTF_8)
                val srcMatch = SRC_RE.find(dec) ?: SRC_REL_RE.find(dec) ?: continue
                val src = if (srcMatch.groupValues[1].startsWith("//")) {
                    "https:${srcMatch.groupValues[1]}"
                } else srcMatch.groupValues[1]
                if ("nova" in low && "upn.one" in src) {
                    // Keep — resolveNovaUpn() handles these via AES-128-CBC
                }
                out.add(trimmed to src)
            } catch (_: Exception) { }
        }
        return out
    }

    // ── Moon resolver (AES-256-GCM) ──────────────────────────────────────

    fun resolveMoon(embedUrl: String): String? {
        val code = EMBED_CODE_RE.find(embedUrl)?.groupValues?.get(1) ?: return null
        val json = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU4Iyk/KTsjPyw/Lzd0OTU3dTsqM3UsMz4/NSl1") + "$code/",
            headers = defaultHeaders()
        ) ?: return null
        return try {
            val root = Json.parseToJsonElement(json).jsonObject
            val playback = root["playback"]?.jsonObject ?: return null
            val decrypted = decryptMoon(playback) ?: return null
            decrypted["sources"]?.jsonArray
                ?.firstOrNull()?.jsonObject?.get("url")?.jsonPrimitive?.content
        } catch (e: Exception) {
            Log.e(TAG, "Moon decrypt failed: ${e.message}")
            null
        }
    }

    /** Last successfully decrypted Moon playback JSON — its producer is the
     *  same embed stack as wave's BYFMS, whose decrypted JSON carries a
     *  tracks[] array (subtitles). Defensive: empty when absent. */
    @Volatile
    private var moonPlaybackCache: JsonObject? = null

    private fun subsFromPlayback(playback: JsonObject?): List<AniwavesApi.SubtitleTrack> {
        val root = playback ?: return emptyList()
        val seen = mutableSetOf<String>()
        return runCatching {
            root["tracks"]?.jsonArray?.mapNotNull { el ->
                val t = el.jsonObject
                val kind = t["kind"]?.jsonPrimitive?.content ?: "captions"
                if (kind == "thumbnails" || kind == "preview") return@mapNotNull null
                val url = t["file"]?.jsonPrimitive?.content
                    ?: t["url"]?.jsonPrimitive?.content ?: ""
                if (url.isBlank()) return@mapNotNull null
                val label = t["label"]?.jsonPrimitive?.content ?: "Unknown"
                if (!seen.add("$url|$label")) return@mapNotNull null
                AniwavesApi.SubtitleTrack(label.lowercase().replace(Regex("\\s+"), "-"), label, url)
            }
        }.getOrNull() ?: emptyList()
    }

    private fun decryptMoon(playback: JsonObject): JsonObject? {
        val version = playback["version"]?.jsonPrimitive?.content ?: ""
        val n = version.toIntOrNull() ?: 0
        val perm = listOf(n, 31 - n)
        val keyParts = playback["key_parts"]?.jsonArray?.map { it.jsonPrimitive.content } ?: return null
        val selected = perm.filter { it in 1..keyParts.size }.map { keyParts[it - 1] }
        val keyBytes = selected.flatMap { base64UrlDecode(it).toList() }.toByteArray()
        val iv = base64UrlDecode(playback["iv"]?.jsonPrimitive?.content ?: return null)
        val payload = base64UrlDecode(playback["payload"]?.jsonPrimitive?.content ?: return null)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), GCMParameterSpec(128, iv))
        val plain = cipher.doFinal(payload)
        val decrypted = Json.parseToJsonElement(String(plain, Charsets.UTF_8)).jsonObject
        moonPlaybackCache = decrypted
        return decrypted
    }

    private fun base64UrlDecode(s: String): ByteArray {
        var b = s.replace('-', '+').replace('_', '/')
        b += "=".repeat((4 - b.length % 4) % 4)
        return Base64.decode(b, Base64.DEFAULT)
    }

    // ── Omega resolver (plain m3u8 from JWPlayer) ─────────────────────────

    fun resolveOmega(embedUrl: String): String? {
        val html = ScraperEngine.fetchText(embedUrl, headers = defaultHeaders()) ?: return null
        // Try vidmoly single-quoted: file: 'https://...m3u8'
        VIDMOLY_FILE_RE.find(html)?.groupValues?.get(1)?.let { return it }
        // Try vidmoly double-quoted: file: "https://...m3u8"
        VIDMOLY_FILE_RE2.find(html)?.groupValues?.get(1)?.let { return it }
        // Fallback: any m3u8 URL
        M3U8_RE.find(html)?.value?.let { return it }
        return null
    }

    // ── Nova/turbovidhls resolver (m3u8 in HTML) ──────────────────────────

    fun resolveNovaTurbo(embedUrl: String): String? {
        val html = ScraperEngine.fetchText(embedUrl, headers = defaultHeaders()) ?: return null
        return TURBOVID_RE.find(html)?.value
    }

    // ── Nova/upn.one resolver (AES-128-CBC + CDN m3u8) ───────────────────

    fun resolveNovaUpn(embedUrl: String): String? {
        val videoId = NOVA_UPN_RE.find(embedUrl)?.groupValues?.get(1) ?: return null
        val headers = mapOf(
            "User-Agent" to UA,
            "Referer" to Obf.s("Mi4uKilgdXU0NSw7dC8qNHQ1ND91"),
            "Origin" to Obf.s("Mi4uKilgdXU0NSw7dC8qNHQ1ND8="),
            "Accept" to "application/json, text/plain, */*"
        )
        val resp = ScraperEngine.fetchText(
            Obf.s("Mi4uKilgdXU0NSw7dC8qNHQ1ND91OyozdSxrdSwzPj81ZTM+Zw==") + "$videoId" +
                Obf.s("fC1na2NoanwyZ2tqYmp8KGc=") + Obf.s("Mi4uKilgdXU7NDM3PzQ1KS84dC41"),
            headers = headers
        ) ?: return null
        return try {
            val json = decryptNovaUpn(resp) ?: return null
            Log.d(TAG, "Nova upn.one keys: ${json.keys}")
            val pk = json["pk"]?.jsonObject ?: return null
            val pkK = pk["k"]?.jsonPrimitive?.content ?: return null
            val pkKx = pk["kx"]?.jsonPrimitive?.content ?: return null
            val streamingConfig = json["streamingConfig"]?.jsonPrimitive?.content
            val adjust = parseStreamingConfig(streamingConfig)
            // Try each source in order: hlsVideoTiktok, hlsVideoGoogle, cfNative, cf, source
            val sourceFields = listOf("hlsVideoTiktok", "hlsVideoGoogle", "cfNative", "cf", "source")
            val url = sourceFields.firstNotNullOfOrNull { field ->
                val path = json[field]?.jsonPrimitive?.content ?: return@firstNotNullOfOrNull null
                if (path.isBlank()) null
                else buildNovaUpnUrl(path, adjust, pkK, pkKx, field)
            }
            Log.d(TAG, "Nova upn.one m3u8: ${url?.take(120)}")
            url
        } catch (e: Exception) {
            Log.e(TAG, "Nova upn.one resolve failed: ${e.message}")
            null
        }
    }

    private fun decryptNovaUpn(hexCipher: String): JsonObject? {
        val ct = runCatching { hexToBytes(hexCipher.trim()) }.getOrNull() ?: return null
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(NOVA_UPN_KEY, "AES"), IvParameterSpec(NOVA_UPN_IV))
        val plain = cipher.doFinal(ct)
        return Json.parseToJsonElement(String(plain, Charsets.UTF_8)).jsonObject
    }

    private fun parseStreamingConfig(raw: String?): Map<String, JsonObject> {
        if (raw.isNullOrBlank()) return emptyMap()
        return try {
            val obj = Json.parseToJsonElement(raw).jsonObject
            val adjust = obj["adjust"]?.jsonObject ?: return emptyMap()
            adjust.keys.associateWith { k -> adjust[k]?.jsonObject ?: JsonObject(emptyMap()) }
        } catch (_: Exception) { emptyMap() }
    }

    private fun buildNovaUpnUrl(
        path: String, adjust: Map<String, JsonObject>,
        pkK: String, pkKx: String, field: String
    ): String? {
        // path is relative (e.g. /hls/.../master.m3u8) or absolute
        // The JS Ot() resolves it against nova.upn.one, then replaces /hls/ with /hlsmod/{domain}/
        val host = if (path.startsWith("http")) {
            java.net.URI(path).host
        } else Obf.s("NDUsO3QvKjR0NTQ/")
        // Apply /hls/ -> /hlsmod/{domain}/ replacement from the JS Ot() function
        var pathname = if (path.startsWith("http")) java.net.URI(path).path else path
        // Map field name to streamingConfig key
        val sourceType = when (field) {
            "hlsVideoTiktok" -> "Tiktok"
            "hlsVideoGoogle" -> "Google"
            "cfNative" -> "Cloudflare"
            else -> adjust.keys.firstOrNull()
        } ?: ""
        val domain = adjust[sourceType]?.get("domain")?.jsonPrimitive?.content
        if (!domain.isNullOrBlank() && pathname.contains("/hls/")) {
            pathname = pathname.replace("/hls/", "/hlsmod/$domain/", ignoreCase = true)
        }
        // Build base URL
        val scheme = if (path.startsWith("http")) java.net.URI(path).scheme else "https"
        val baseUrl = "$scheme://$host$pathname"
        // Append params from streamingConfig adjust
        val params = mutableMapOf("k" to pkK, "kx" to pkKx)
        adjust[sourceType]?.get("params")?.jsonObject?.forEach { (k, v) ->
            params[k] = v.jsonPrimitive.content
        }
        val query = params.entries.joinToString("&") { "${it.key}=${it.value}" }
        return "$baseUrl?$query"
    }

    private fun hexToBytes(hex: String): ByteArray {
        require(hex.length % 2 == 0) { "Hex string must have even length" }
        return ByteArray(hex.length / 2) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    // ── Unified resolve ───────────────────────────────────────────────────

    data class ResolvedStream(
        val url: String,
        val referer: String,
        val subtitles: List<AniwavesApi.SubtitleTrack> = emptyList()
    )

    fun resolve(label: String, embedUrl: String): ResolvedStream? {
        val low = label.lowercase()
        return when {
            "moon" in low -> resolveMoon(embedUrl)?.let { ResolvedStream(it, Obf.s("Mi4uKilgdXU7NDM3PzQ1KS84dC41dQ=="), subsFromPlayback(moonPlaybackCache)) }
            "omega" in low -> resolveOmega(embedUrl)?.let { ResolvedStream(it, Obf.s("Mi4uKilgdXU7NDM3PzQ1KS84dC41dQ==")) }
            "nova" in low -> {
                val turbo = resolveNovaTurbo(embedUrl)?.let { ResolvedStream(it, Obf.s("Mi4uKilgdXUuLyg4NSwzPjI2KXQ5NTd1")) }
                val upn = resolveNovaUpn(embedUrl)?.let { ResolvedStream(it, Obf.s("Mi4uKilgdXU0NSw7dC8qNHQ1ND91")) }
                turbo ?: upn
            }
            else -> null
        }
    }

    // ── Search (for finding correct slug from AniList title) ──────────────

    fun search(query: String): List<Pair<String, String>> {
        val html = ScraperEngine.fetchText(
            "$BASE/?s=${query.replace(" ", "+")}",
            headers = defaultHeaders()
        ) ?: return emptyList()
        return Regex(Obf.s("Mig/PGd4cjIuLiopYHV1OzQzNz80NSkvOAZ0LjV1OzQzNz91cgEEeAdxc3VzeA=="))
            .findAll(html)
            .map { it.groupValues[2] to it.groupValues[1] }
            .distinctBy { it.first }
            .toList()
    }

    // ── Wrong-title support (additive) ─────────────────────────────────────
    // Full search cards for the picker: every result shown, NO matching.
    // The user's clicked series slug is then used directly everywhere.

    data class SearchCard(val slug: String, val title: String, val posterUrl: String?)

    fun searchCards(query: String): List<SearchCard> {
        val html = ScraperEngine.fetchText(
            "$BASE/?s=${query.replace(" ", "+")}",
            headers = defaultHeaders()
        ) ?: return emptyList()
        val cards = ArrayList<SearchCard>()
        // Search-result cards: <a href="…/anime/<slug>/" itemprop="url"
        // title="<Title>" class="tip" rel="…">. (A recent template move put a
        // class="series" on the *sidebar* popular links, which are unrelated to
        // the query — never match those.)
        val seen = HashSet<String>()
        val cardRe = Regex(
            Obf.s("ZjsBBGQHcDIoPzxneDIuLiopYHV1OzQzNz80NSkvOAZ0LjV1OzQzNz91cgEEBngHcXN1eAEEZAdwMy4/NyooNSpneC8oNngBBGQHcGQ="),
            RegexOption.IGNORE_CASE
        )
        for (m in cardRe.findAll(html)) {
            val slug = m.groupValues[1]
            if (!seen.add(slug)) continue
            // Title from the card's own HTML block: prefer the itemprop="url"
            // title= attribute, fall back to the <h2 itemprop="headline"> text.
            val block = html.substring(m.range.first).take(1600)
            val title = Regex("""itemprop="url"[^>]*title="([^"]*)"""", RegexOption.IGNORE_CASE)
                .find(m.value)?.groupValues?.get(1)?.trim()?.ifBlank { null }
                ?: Regex("""itemprop="headline"[^>]*>([^<]*)<""", RegexOption.IGNORE_CASE)
                    .find(block)?.groupValues?.get(1)?.trim()
                ?: slug
            // Poster: the card's <img itemprop="image"> lives inside the anchor,
            // just before the title block — never the sidebar images.
            val poster = Regex("""<img src="([^"]*\.(?:jpg|jpeg|png|webp))"[^>]*itemprop="image"""", RegexOption.IGNORE_CASE)
                .find(block)?.groupValues?.get(1)?.takeIf { it.startsWith("http") }
            cards.add(SearchCard(slug, title, poster))
        }
        return cards
    }

    private fun defaultHeaders(): Map<String, String> = mapOf(
        "User-Agent" to UA,
        "Referer" to REFERER,
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    )
}
