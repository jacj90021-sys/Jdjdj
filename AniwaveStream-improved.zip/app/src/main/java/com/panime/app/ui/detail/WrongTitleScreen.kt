package com.panime.app.ui.detail

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.panime.app.data.provider.ProviderManager
import com.panime.app.ui.home.PaginationBar
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.Flame
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.Ink
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.SharpCorner
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextMuted
import com.panime.app.ui.theme.TextOnDark
import com.panime.app.ui.theme.TextPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SearchResult(
    val title: String,
    val slug: String,
    val posterUrl: String? = null,
    val totalEpisodes: Int? = null
)

private fun normalize(s: String): String =
    s.lowercase().replace(Regex("[^a-z0-9\\s]"), "").trim()

private fun fuzzyRatio(query: String, target: String): Int {
    val a = normalize(query)
    val b = normalize(target)
    if (a == b) return 100
    if (a.isEmpty() || b.isEmpty()) return 0
    if (a.contains(b) || b.contains(a)) return 85
    val wordsA = a.split("\\s+".toRegex()).toSet()
    val wordsB = b.split("\\s+".toRegex()).toSet()
    val intersection = wordsA.intersect(wordsB).size
    val union = wordsA.union(wordsB).size
    if (union == 0) return 0
    val jaccard = intersection * 100 / union
    val lev = levenshtein(a, b)
    val maxLen = maxOf(a.length, b.length)
    val editScore = ((maxLen - lev) * 100 / maxLen)
    return (jaccard + editScore) / 2
}

private fun levenshtein(a: String, b: String): Int {
    val dp = Array(a.length + 1) { IntArray(b.length + 1) }
    for (i in 0..a.length) dp[i][0] = i
    for (j in 0..b.length) dp[0][j] = j
    for (i in 1..a.length) {
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            dp[i][j] = minOf(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost)
        }
    }
    return dp[a.length][b.length]
}

/**
 * Exact season number written in the picked row's own title ("BoJack Horseman
 * S2" -> 2; "Naruto" -> null). The title IS the truth — no guessing: moviebox
 * hands us one row per season, and we store that season with the pick so play
 * + episode counts target it directly. Range titles ("S1-S6") return null —
 * that's a combined entry handled by the provider's season map.
 */
private fun pickedSeasonFromTitle(title: String): Int? {
    val t = title.trim()
    // Combined range ("S1-S4", "S1-S6") is NOT a single season — its detail
    // API season map handles it. ("S1-S4" also ends in "S4", so the guard
    // must run first or the tail regex would wrongly encode se=4.)
    if (Regex("""S\d+\s*-\s*S?\d+""", RegexOption.IGNORE_CASE).containsMatchIn(t)) return null
    val m = Regex("""\bS(\d+)\s*$""", RegexOption.IGNORE_CASE).find(t) ?: return null
    return m.groupValues[1].toIntOrNull()?.takeIf { it > 0 }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun WrongTitleSheet(
    animeTitle: String,
    knownNames: List<String> = emptyList(),
    onDismiss: () -> Unit,
    onResultSelected: (sourceId: String, slug: String, title: String, totalEpisodes: Int?) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()
    // Capability-filtered: only sources with real search support get a chip.
    val providers = remember { ProviderManager.listSearchableProviders() }
    var selectedProvider by remember { mutableStateOf(providers.firstOrNull()?.first ?: "") }
    var searchQuery by remember { mutableStateOf(animeTitle) }
    var results by remember { mutableStateOf<List<SearchResult>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var hasSearched by remember { mutableStateOf(false) }
    var searchKey by remember { mutableIntStateOf(0) }
    var autoSearched by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(1) }
    var lastPage by remember { mutableIntStateOf(1) }
    // Dantotsu parity: long-press a result to expand its full title.
    var expandedSlugs by remember { mutableStateOf(setOf<String>()) }

    // ── Name gate ────────────────────────────────────────────────────────
    // Only rows that carry one of this anime's real AniList names (romaji /
    // english / native / synonyms) are shown. Porn, hentai and unrelated
    // look-alikes can never appear because none of them carry the name.
    // Empty keys (AniList down / not loaded yet) = gate disabled, fail-open.
    val nameKeysNorm = remember(knownNames) {
        knownNames.mapNotNull { n ->
            n.trim().lowercase()
                .replace(Regex("""[^a-z0-9\p{L}]+"""), " ").trim()
                .takeIf { it.isNotBlank() }
        }.distinct()
    }

    /** Token containment: every (2+ char) word of the row's clean title must
     *  appear in some known name — or vice versa for long names. Numeric-only
     *  keys ("1.0", "009") never gate — they'd either always or never match. */
    fun matchesKeys(rawTitle: String, keys: List<String>): Boolean {
        if (keys.isEmpty()) return true
        // Strip season/dub noise the same way the site writes it:
        // "One Piece [English] S1-S4" -> "one piece s1 s4"
        val t = rawTitle.trim().lowercase()
            .replace(Regex("""\[[^\]]*\]"""), " ")   // [English] / [netflix]
            .replace(Regex("""[^a-z0-9\p{L}]+"""), " ")
        val rowWords = t.split(" ").filter { it.length > 1 }.toSet()
        if (rowWords.isEmpty()) return false
        for (key in keys) {
            if (key.none { it.isDigit() }) {
                val keyWords = key.split(" ").filter { it.length > 1 }.toSet()
                // Containment both ways: "mushoku tensei" row of a 4-word name,
                // or a 2+ word row fully inside a longer name ("re zero" of the
                // Japanese title). A 1-word row ("One") can never match — too noisy.
                if (rowWords.containsAll(keyWords) ||
                    (rowWords.size >= 2 && keyWords.containsAll(rowWords))
                ) return true
            }
        }
        return false
    }

    fun matchesAnimeName(rawTitle: String): Boolean = matchesKeys(rawTitle, nameKeysNorm)

    fun doSearch(target: Int = 1) {
        if (searchQuery.isBlank()) return
        searching = true
        hasSearched = true
        searchKey++
        page = target
        scope.launch {
            val pr = withContext(Dispatchers.IO) {
                ProviderManager.searchPage(selectedProvider, searchQuery.trim(), target)
            }
            // Moviebox gate — THE QUERY decides what may show, on every search:
            // "re zero" -> only Re:ZERO rows (Rei Zero dies), "naruto" -> only
            // Naruto rows, "mushoku tensei" -> only Mushoku rows — junk can
            // never appear no matter which page the picker was opened from.
            // When the query is about the CURRENT anime, its AniList names
            // (synonyms) join the keys so legit alt-title rows survive.
            // Other providers are NEVER gated — their search is untouched.
            val qNorm = searchQuery.trim().lowercase()
                .replace(Regex("""[^a-z0-9\p{L}]+"""), " ").trim()
            val queryIsAboutAnime = matchesKeys(searchQuery.trim(), nameKeysNorm)
            val gateKeys = buildList {
                if (qNorm.split(" ").any { it.length > 1 }) add(qNorm)
                if (queryIsAboutAnime) addAll(nameKeysNorm)
            }.distinct()
            val mapped = pr.items.map { hit ->
                SearchResult(title = hit.title, slug = hit.slug, posterUrl = hit.posterUrl, totalEpisodes = hit.totalEpisodes)
            }.let {
                if (selectedProvider == "moviebox") it.filter { r -> matchesKeys(r.title, gateKeys) } else it
            }
            results = mapped.sortedByDescending { fuzzyRatio(searchQuery, it.title) }
            lastPage = pr.lastPage.coerceAtLeast(1)
            searching = false
        }
    }

    LaunchedEffect(Unit) {
        if (!autoSearched) {
            autoSearched = true
            doSearch()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Surface
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            // Title
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Choose Accurate Title?",
                    color = TextPrimary,
                    fontFamily = Bricolage,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }

            // Provider chips
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                providers.forEach { (id, label) ->
                    val selected = id == selectedProvider
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selected) Flame else SurfaceRaised)
                            .border(1.dp, if (selected) Flame else Hairline, RoundedCornerShape(8.dp))
                            .clickable {
                                selectedProvider = id
                                doSearch(1)
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            label,
                            color = if (selected) TextOnDark else TextMuted,
                            fontFamily = PlexMono,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Search bar
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search anime title...", color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SurfaceRaised,
                        unfocusedContainerColor = SurfaceRaised,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        unfocusedBorderColor = Hairline,
                        focusedBorderColor = Flame,
                        cursorColor = Flame
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(SharpCorner)
                        .background(Flame)
                        .clickable { doSearch(1) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TextOnDark,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // Results
            when {
                searching -> {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Flame)
                    }
                }
                results.isEmpty() && hasSearched -> {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No results found",
                            color = TextMuted,
                            fontFamily = PlexMono,
                            fontSize = 13.sp
                        )
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 200.dp, max = 400.dp)
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Key must be unique per ROW: moviebox returns one row per
                        // season sharing the SAME slug ("BoJack S1".."S6" all point to
                        // one subject) — slug keys would crash the LazyColumn.
                        items(results, key = { "${it.slug}\u0000${it.title}" }) { result ->                            val expanded = result.slug in expandedSlugs
                            Column(
                                Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(SurfaceRaised)
                                    .border(1.dp, Hairline, RoundedCornerShape(10.dp))
                                    .combinedClickable(
                                        onClick = {
                                            // Encode an exact picked season into the
                                            // slug ("subjectId|detailPath|se=2") when
                                            // the row IS one season — play + counts
                                            // then target it directly, no guessing.
                                            val picked = pickedSeasonFromTitle(result.title)
                                            val slug = if (selectedProvider == "moviebox" && picked != null)
                                                "${result.slug}|se=$picked" else result.slug
                                            onResultSelected(selectedProvider, slug, result.title, result.totalEpisodes)
                                        },
                                        onLongClick = {
                                            expandedSlugs = if (expanded) expandedSlugs - result.slug
                                            else expandedSlugs + result.slug
                                        }
                                    ),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                AsyncImage(
                                    model = result.posterUrl,
                                    contentDescription = result.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                                        .background(Ink)
                                )
                                Text(
                                    result.title,
                                    color = TextPrimary,
                                    fontFamily = PlexMono,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 10.sp,
                                    maxLines = if (expanded) Int.MAX_VALUE else 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp)
                                )
                            }
                        }

                        // Pagination footer (full-width) — same placement as the
                        // other screens: last item inside the results grid.
                        if (!searching && lastPage > 1 && results.isNotEmpty()) {
                            item(span = { GridItemSpan(maxLineSpan) }) {
                                PaginationBar(
                                    page = page,
                                    pageCount = lastPage,
                                    onPage = { p -> doSearch(p) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
