package com.panime.app.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.Inter
import com.panime.app.ui.theme.UiCorner
import androidx.compose.ui.draw.clip
import com.panime.app.ui.theme.Ink
import com.panime.app.ui.theme.InkBorder
import com.panime.app.ui.theme.OrangePrimary
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.SharpCorner
import com.panime.app.ui.theme.Surface
import com.panime.app.ui.theme.SurfaceRaised
import com.panime.app.ui.theme.TextOnDark
import com.panime.app.ui.theme.TextPrimary

/**
 * AnimeX primary CTA — sharp corners, 2px red border, red fill, mono label.
 * Spring press physics kept from the previous pill button.
 *
 * @param onMedia when true, uses paper-white label (for dark hero/media).
 *                Default is paper-white on red (works on both light and dark).
 */
@Composable
fun PrimaryPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
    onMedia: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "primary-press"
    )
    val label = if (onMedia) TextOnDark else TextOnDark
    Row(
        modifier
            .scale(scale)
            .clip(UiCorner)
            .background(OrangePrimary)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (leadingIcon != null) {
            Icon(leadingIcon, contentDescription = null, tint = label, modifier = Modifier.size(18.dp))
        }
        Text(
            text,
            color = label,
            fontFamily = Inter,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )
    }
}

/**
 * AnimeX secondary CTA — sharp corners, 2px ink (or paper-white on media) border.
 *
 * @param onMedia true on hero/image overlays (solid dark scrim + light label so the
 *                button stays readable over blur/paper fades — same clarity as home
 *                Watchlist on the dark hero).
 * @param marked  true when the item is already saved (e.g. In List) — stronger border
 *                and check-friendly accent so the state is obvious at a glance.
 */
@Composable
fun SecondaryPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
    onMedia: Boolean = false,
    marked: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "secondary-press"
    )
    // On media: always use a solid dark fill so light labels stay clear over
    // blurred banners and the paper-theme bottom fade (detail My List bug).
    val stroke = when {
        onMedia && marked -> TextOnDark.copy(alpha = 0.85f)
        onMedia -> TextOnDark.copy(alpha = 0.55f)
        marked -> Ink
        else -> Hairline
    }
    val label = if (onMedia) TextOnDark else TextPrimary
    val fill = when {
        onMedia && marked -> Color.White.copy(alpha = 0.28f)
        onMedia -> Color.White.copy(alpha = 0.16f)
        marked -> SurfaceRaised
        else -> Surface
    }
    Row(
        modifier
            .scale(scale)
            .clip(UiCorner)
            .then(if (onMedia) Modifier else Modifier.border(1.dp, stroke, UiCorner))
            .background(fill)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (leadingIcon != null) {
            Icon(leadingIcon, contentDescription = null, tint = label, modifier = Modifier.size(18.dp))
        }
        Text(
            text,
            color = label,
            fontFamily = Inter,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )
    }
}
