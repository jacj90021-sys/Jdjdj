package com.panime.app.util

/**
 * Runtime decoder for obfuscated string literals.
 *
 * Sensitive literals (provider site URLs, API paths, HTML selectors) are stored
 * in the APK as Base64/XOR-encoded blobs and decoded lazily at runtime, so a
 * decompiled APK no longer shows them in plain text. This is friction against
 * casual reverse engineers — it is NOT a security boundary: a determined person
 * can find [s] and recover everything.
 *
 * Encoding scheme (kept in sync with the build tooling that generated the
 * blobs): the plain string is XORed byte-wise with [KEY] and then Base64-encoded
 * without line wrapping. [s] reverses that: Base64-decode, then XOR.
 */
object Obf {

    private const val KEY = 0x5A

    /** Decode an obfuscated blob back to its plain string. */
    fun s(encoded: String): String {
        val raw = android.util.Base64.decode(encoded, android.util.Base64.NO_WRAP)
        val out = CharArray(raw.size)
        for (i in raw.indices) out[i] = (raw[i].toInt() xor KEY).toChar()
        return String(out)
    }

    /**
     * Encode a plain string (used by tooling to generate the constants; the app
     * itself only ever calls [s]). Must stay in sync with [s].
     */
    fun encode(plain: String): String {
        val raw = plain.toByteArray(Charsets.UTF_8)
        for (i in raw.indices) raw[i] = (raw[i].toInt() xor KEY).toByte()
        return android.util.Base64.encodeToString(raw, android.util.Base64.NO_WRAP)
    }
}
