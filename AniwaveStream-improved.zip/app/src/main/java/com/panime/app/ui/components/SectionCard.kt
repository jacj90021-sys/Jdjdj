package com.panime.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panime.app.data.model.Anime
import com.panime.app.ui.theme.Bricolage
import com.panime.app.ui.theme.AnivaveArt
import com.panime.app.ui.theme.Hairline
import com.panime.app.ui.theme.OrangePrimary
import com.panime.app.ui.theme.PlexMono
import com.panime.app.ui.theme.TextOnDark
import com.panime.app.ui.theme.TextPrimary
import com.panime.app.ui.theme.TextSecondary

@Composable
fun SectionHeader(title: String, onSeeAll: (() -> Unit)? = null) {
    // AnimeX section head: Anton title + mono "SEE ALL", with ink hairline rule underneath.
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                title.uppercase(),
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                fontFamily = Bricolage,
                letterSpacing = 0.2.sp
            )
            if (onSeeAll != null) {
                Text(
                    "See all",
                    color = OrangePrimary,
                    fontFamily = com.panime.app.ui.theme.Inter,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clickable(onClick = onSeeAll)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }
        }
    }
}

/**
 * Anivave "section" — a titled card holding a horizontal strip of gradient
 * mini-posters. Used for New Releases / Upcoming rows.
 */
@Composable
fun AnivaveSectionCard(
    title: String,
    items: List<Anime>,
    onItem: (Anime) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        SectionHeader(title)
        Spacer(Modifier.height(4.dp))
        AnivaveSectionRow(items, onItem)
        Spacer(Modifier.height(8.dp))
    }
}

/** Header-less variant (caller renders its own header). */
@Composable
fun AnivaveSectionCardNoHeader(
    items: List<Anime>,
    onItem: (Anime) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        AnivaveSectionRow(items, onItem)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun AnivaveSectionRow(
    items: List<Anime>,
    onItem: (Anime) -> Unit
) {
    if (items.isEmpty()) {
        Text(
            "Nothing here yet.",
            color = TextSecondary,
            fontFamily = PlexMono,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    } else {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(items, key = { it.id }) { anime ->
                Column(
                    Modifier
                        .width(130.dp)
                        .clickable { onItem(anime) }
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, Hairline, RoundedCornerShape(14.dp))
                    ) {
                        AnivaveArt(anime = anime, modifier = Modifier.fillMaxSize())
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        anime.title,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontFamily = PlexMono,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
