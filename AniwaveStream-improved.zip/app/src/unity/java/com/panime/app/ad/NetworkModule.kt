package com.panime.app.ad

/**
 * Returns the compiled-in ad network implementation for the Unity Ads build
 * (`-PadsNetwork=unity`). The AdMob build ships its own NetworkModule in a
 * separate source set.
 */
internal fun provideAdNetwork(): AdNetwork = UnityAdsNetwork