package com.panime.app.ad

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.View
import com.panime.app.BuildConfig
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

/**
 * Unity Ads ([AdNetwork]) implementation (SDK 4.20.0).
 *
 * Unlike AdMob it does NOT need Google Play Services, so it can serve ads on a
 * wider range of devices — including ones without Google Play Services. All
 * three formats are wired: interstitial + rewarded (UnityAds.load/show) and
 * banner (embeddable BannerView, same embed as AdMob's AdView).
 */
internal object UnityAdsNetwork : AdNetwork {
    override val tag = "UnityAds"

    /** True once the SDK reports initialization complete. */
    @Volatile private var sdkReady = false

    /** True once an interstitial has been loaded and is ready to show. */
    @Volatile private var interstitialReady = false

    /** True once a rewarded ad has been loaded and is ready to show. */
    @Volatile private var rewardedReady = false

    // ── AdNetwork ───────────────────────────────────────────────────────────

    // NB: UnityAds.isSupported is a Kotlin property (val), not a function.
    override fun isSupported(context: Context): Boolean = try {
        UnityAds.isSupported
    } catch (t: Throwable) {
        false
    }

    override fun initialize(context: Context) {
        if (sdkReady || isInitializing) return
        isInitializing = true

        val gameId = BuildConfig.UNITY_GAME_ID
        if (gameId.isBlank()) {
            Log.w(tag, "UNITY_GAME_ID is blank — Unity Ads disabled")
            return
        }

        val ctx = context.applicationContext
        // Test mode serves guaranteed test ads (no fill/review needed) so the
        // pipeline can be verified; production builds default to real ads.
        UnityAds.initialize(ctx, gameId, BuildConfig.UNITY_TEST_MODE, object : IUnityAdsInitializationListener {
            override fun onInitializationComplete() {
                sdkReady = true
                isInitializing = false
                Log.i(tag, "Unity Ads initialized")
                preload(ctx)
            }

            override fun onInitializationFailed(
                error: UnityAds.UnityAdsInitializationError,
                message: String
            ) {
                isInitializing = false
                Log.w(tag, "Unity Ads init failed: $error — $message")
            }
        })
    }

    override fun preload(context: Context) {
        if (!sdkReady) return
        loadInterstitial()
        loadRewarded()
    }

    override fun showInterstitial(activity: Activity, onDismissed: () -> Unit): Boolean {
        if (!interstitialReady) return false
        val placement = BuildConfig.UNITY_INTERSTITIAL_ID
        if (placement.isBlank()) return false
        interstitialReady = false
        UnityAds.show(activity, placement, UnityAdsShowOptions(), showListener {
            onDismissed()
            loadInterstitial()
        })
        return true
    }

    override fun showRewarded(
        activity: Activity,
        onReward: () -> Unit,
        onDismissed: () -> Unit
    ): Boolean {
        if (!rewardedReady) return false
        val placement = BuildConfig.UNITY_REWARDED_ID
        if (placement.isBlank()) return false
        rewardedReady = false
        UnityAds.show(activity, placement, UnityAdsShowOptions(), showListener { state ->
            if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) onReward()
            onDismissed()
            loadRewarded()
        })
        return true
    }

    override fun createBanner(context: Context): View? {
        val placement = BuildConfig.UNITY_BANNER_ID
        if (placement.isBlank()) return null

        // BannerView takes an Activity (not Context) per the Unity SDK. In the
        // Compose call-sites this is always the host Activity (HomeScreen /
        // DetailScreen use LocalContext.current). If it isn't one, return null
        // so the layout simply skips the banner.
        val activity = context as? Activity ?: return null

        // Capture OUR log tag OUTSIDE the nested listener. Inside the listener
        // (whose receiver chain includes the BannerView itself), a bare `tag`
        // would resolve to View.getTag() (platform Any!), not our property.
        val logTag = tag

        // Modern embeddable banner: a BannerView (RelativeLayout) that drops
        // straight into the view tree via Compose AndroidView — same embed as
        // AdMob's AdView. The SDK is initialized at app startup (initialize()),
        // so creating + load() eagerly here mirrors the AdMob banner behavior.
        return BannerView(activity, placement, UnityBannerSize.getDynamicSize(context)).apply {
            setListener(object : BannerView.IListener {
                override fun onBannerLoaded(bannerAdView: BannerView) {
                    val placementId: String = bannerAdView.getPlacementId()
                    android.util.Log.i(logTag, "Banner loaded: $placementId")
                }

                override fun onBannerShown(bannerAdView: BannerView) { /* no-op */ }

                override fun onBannerFailedToLoad(bannerAdView: BannerView, errorInfo: BannerErrorInfo) {
                    val message: String = "Banner failed to load: " +
                        errorInfo.errorCode.toString() + " " + errorInfo.errorMessage
                    android.util.Log.w(logTag, message)
                }

                override fun onBannerClick(bannerAdView: BannerView) { /* no-op */ }

                override fun onBannerLeftApplication(bannerAdView: BannerView) { /* no-op */ }
            })
            load()
        }
    }

    // ── Internal ────────────────────────────────────────────────────────────

    @Volatile private var isInitializing = false

    private fun showListener(
        onEnd: (UnityAds.UnityAdsShowCompletionState) -> Unit
    ): IUnityAdsShowListener = object : IUnityAdsShowListener {
        override fun onUnityAdsShowFailure(
            placementId: String,
            error: UnityAds.UnityAdsShowError,
            message: String
        ) {
            Log.w(tag, "Show failed ($placementId): $error — $message")
            // No state is guaranteed on failure — report as dismissed so the
            // caller proceeds with its fallback, then reload for next time.
            onEnd(UnityAds.UnityAdsShowCompletionState.SKIPPED)
        }

        override fun onUnityAdsShowStart(placementId: String) { /* no-op */ }

        override fun onUnityAdsShowClick(placementId: String) { /* no-op */ }

        override fun onUnityAdsShowComplete(
            placementId: String,
            state: UnityAds.UnityAdsShowCompletionState
        ) {
            onEnd(state)
        }
    }

    private fun loadInterstitial() {
        if (!sdkReady) return
        val placement = BuildConfig.UNITY_INTERSTITIAL_ID
        if (placement.isBlank()) return
        UnityAds.load(placement, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String) { interstitialReady = true }
            override fun onUnityAdsFailedToLoad(
                placementId: String,
                error: UnityAds.UnityAdsLoadError,
                message: String
            ) {
                Log.w(tag, "Interstitial load failed: $error — $message")
            }
        })
    }

    private fun loadRewarded() {
        if (!sdkReady) return
        val placement = BuildConfig.UNITY_REWARDED_ID
        if (placement.isBlank()) return
        UnityAds.load(placement, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String) { rewardedReady = true }
            override fun onUnityAdsFailedToLoad(
                placementId: String,
                error: UnityAds.UnityAdsLoadError,
                message: String
            ) {
                Log.w(tag, "Rewarded load failed: $error — $message")
            }
        })
    }
}