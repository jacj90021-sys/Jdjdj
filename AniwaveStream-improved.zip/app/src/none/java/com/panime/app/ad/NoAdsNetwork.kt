package com.panime.app.ad

import android.app.Activity
import android.content.Context
import android.view.View

/**
 * No-ads [AdNetwork] implementation for store builds (`-PadsNetwork=none`).
 *
 * Used for the Amazon Appstore submission: Amazon's content policy rejected
 * the app over ad-network libraries, so the store build ships with NO ad SDK
 * at all — no AdMob, no Unity, nothing to flag in review. Every capability
 * reports unavailable and [AdManager]'s gates short-circuit before any ad
 * code can run.
 */
internal object NoAdsNetwork : AdNetwork {
    override val tag = "NoAds"

    override fun isSupported(context: Context): Boolean = false

    override fun initialize(context: Context) { /* no ad SDK in this build */ }

    override fun preload(context: Context) { /* no ad SDK in this build */ }

    override fun showInterstitial(activity: Activity, onDismissed: () -> Unit): Boolean = false

    override fun showRewarded(
        activity: Activity,
        onReward: () -> Unit,
        onDismissed: () -> Unit
    ): Boolean = false

    override fun createBanner(context: Context): View? = null
}
