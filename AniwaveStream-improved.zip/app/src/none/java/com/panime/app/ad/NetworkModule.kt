package com.panime.app.ad

/**
 * Returns the compiled-in ad network implementation for the no-ads store build
 * (`-PadsNetwork=none`). AdMob and Unity builds each ship their own
 * NetworkModule in separate source sets.
 */
internal fun provideAdNetwork(): AdNetwork = NoAdsNetwork
