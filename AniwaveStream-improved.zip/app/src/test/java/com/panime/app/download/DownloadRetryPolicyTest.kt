package com.panime.app.download

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Pure-JVM tests for the retry decision engine. HTTP-status classification
 * goes through [DownloadRetryPolicy.classifyCode] so no Android/media3 types
 * are needed; cause-chain walking is tested with plain JDK exceptions.
 */
class DownloadRetryPolicyTest {

    // ── HTTP-status classification ───────────────────────────────────────

    @Test
    fun expired_links_map_to_refresh() {
        for (code in intArrayOf(401, 403, 404, 410)) {
            assertEquals(
                DownloadRetryPolicy.Kind.REFRESH_URL,
                DownloadRetryPolicy.classifyCode(code)
            )
        }
    }

    @Test
    fun transient_http_errors_map_to_retry_same_url() {
        for (code in intArrayOf(408, 425, 429, 500, 502, 503, 504)) {
            assertEquals(
                DownloadRetryPolicy.Kind.RETRY_SAME_URL,
                DownloadRetryPolicy.classifyCode(code)
            )
        }
    }

    @Test
    fun permanent_http_errors_give_up() {
        for (code in intArrayOf(400, 402, 405, 451)) {
            assertEquals(
                DownloadRetryPolicy.Kind.GIVE_UP,
                DownloadRetryPolicy.classifyCode(code)
            )
        }
    }

    // ── network-failure classification (cause-chain walking) ─────────────

    @Test
    fun network_failures_map_to_retry_same_url() {
        assertEquals(
            DownloadRetryPolicy.Kind.RETRY_SAME_URL,
            DownloadRetryPolicy.classify(UnknownHostException("no dns"))
        )
        assertEquals(
            DownloadRetryPolicy.Kind.RETRY_SAME_URL,
            DownloadRetryPolicy.classify(SocketTimeoutException("slow"))
        )
        assertEquals(
            DownloadRetryPolicy.Kind.RETRY_SAME_URL,
            DownloadRetryPolicy.classify(ConnectException("refused"))
        )
        assertEquals(
            DownloadRetryPolicy.Kind.RETRY_SAME_URL,
            DownloadRetryPolicy.classify(IOException("mid-stream"))
        )
    }

    @Test
    fun unknown_throwable_gives_up() {
        assertEquals(
            DownloadRetryPolicy.Kind.GIVE_UP,
            DownloadRetryPolicy.classify(IllegalStateException("weird"))
        )
    }

    @Test
    fun mixed_chain_stops_at_first_recognized_cause() {
        // IOException sits at depth 1 → recognized before the inner unknown.
        assertEquals(
            DownloadRetryPolicy.Kind.RETRY_SAME_URL,
            DownloadRetryPolicy.classify(RuntimeException(IOException(IllegalStateException("mixed"))))
        )
    }

    @Test
    fun deep_cause_chain_is_walked() {
        val wrapped = RuntimeException(IOException(SocketTimeoutException("deep")))
        assertEquals(
            DownloadRetryPolicy.Kind.RETRY_SAME_URL,
            DownloadRetryPolicy.classify(wrapped)
        )
    }

    @Test
    fun null_error_defaults_to_transient_retry() {
        val d = DownloadRetryPolicy.decide(null, 0, 0)
        assertEquals(DownloadRetryPolicy.Kind.RETRY_SAME_URL, d.kind)
    }

    // ── decision caps & backoff ──────────────────────────────────────────

    @Test
    fun retry_same_url_backs_off_then_gives_up() {
        val delays = mutableListOf<Long>()
        var kind: DownloadRetryPolicy.Kind = DownloadRetryPolicy.Kind.GIVE_UP
        for (attempt in 0 until 10) {
            val d = DownloadRetryPolicy.decide(SocketTimeoutException("t"), attempt, 0)
            kind = d.kind
            delays.add(d.delayMs)
            if (kind == DownloadRetryPolicy.Kind.GIVE_UP) break
        }
        assertEquals(DownloadRetryPolicy.Kind.GIVE_UP, kind)
        assertEquals(DownloadRetryPolicy.MAX_TRANSIENT_ATTEMPTS + 1, delays.size)
        assertEquals(DownloadRetryPolicy.TRANSIENT_DELAYS_MS[0], delays[0])
        assertEquals(
            DownloadRetryPolicy.TRANSIENT_DELAYS_MS[DownloadRetryPolicy.MAX_TRANSIENT_ATTEMPTS - 1],
            delays[delays.size - 2]
        )
    }

    @Test
    fun refresh_attempts_capped() {
        val allowed = DownloadRetryPolicy.decide(
            DownloadRetryPolicy.Kind.REFRESH_URL, 0,
            DownloadRetryPolicy.MAX_REFRESH_ATTEMPTS - 1
        )
        assertEquals(DownloadRetryPolicy.Kind.REFRESH_URL, allowed.kind)

        val exhausted = DownloadRetryPolicy.decide(
            DownloadRetryPolicy.Kind.REFRESH_URL, 0,
            DownloadRetryPolicy.MAX_REFRESH_ATTEMPTS
        )
        assertEquals(DownloadRetryPolicy.Kind.GIVE_UP, exhausted.kind)
    }
}
