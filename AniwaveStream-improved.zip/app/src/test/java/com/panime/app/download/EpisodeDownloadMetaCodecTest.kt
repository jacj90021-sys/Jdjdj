package com.panime.app.download

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure-JVM tests for the persistent download metadata codec — this JSON blob
 * rides inside DownloadRequest.data and must roundtrip across process death.
 * (DownloadRequest/Uri construction itself needs Android framework classes,
 * so it is covered by device testing instead of JVM unit tests.)
 */
class EpisodeDownloadMetaCodecTest {

    private fun sample() = EpisodeDownloadMeta(
        id = "dl_12345_1_7",
        animeId = 12345,
        episode = 7,
        seasonNumber = 1,
        title = "Naruto",
        episodeLabel = "Episode 7",
        posterUrl = "https://img.example/p.jpg",
        quality = "1080p",
        serverLabel = "HD-1",
        sourceMode = "aniwaves",
        audioType = "sub",
        slugHint = "naruto",
        totalEps = 220,
        streamUrl = "https://cdn.example/master.m3u8",
        format = "hls",
        headers = mapOf("User-Agent" to "UA/1.0", "Referer" to "https://s.example/"),
        subtitles = listOf(Triple("eng", "ENG", "https://cdn.example/sub.vtt")),
        decryptKeyB64 = null
    )

    @Test
    fun json_roundtrip_preserves_every_field() {
        val meta = sample()
        val decoded = EpisodeDownloadMeta.decode(meta.toJson().toString().toByteArray())
            ?: throw AssertionError("decode returned null")
        assertEquals(meta, decoded)
    }

    @Test
    fun decrypt_key_roundtrips() {
        val b64 = java.util.Base64.getEncoder().encodeToString(ByteArray(16) { it.toByte() })
        val meta = sample().copy(decryptKeyB64 = b64)
        val decoded = EpisodeDownloadMeta.decode(meta.toJson().toString().toByteArray())!!
        assertEquals(b64, decoded.decryptKeyB64)
    }

    @Test
    fun decode_rejects_garbage_and_null() {
        assertNull(EpisodeDownloadMeta.decode(null))
        assertNull(EpisodeDownloadMeta.decode(ByteArray(0)))
        assertNull(EpisodeDownloadMeta.decode("not json".toByteArray()))
        // Missing id must not decode to a half-broken meta.
        assertNull(EpisodeDownloadMeta.decode(JSONObject().put("title", "x").toString().toByteArray()))
    }

    @Test
    fun idFor_is_stable_and_collision_free_across_seasons() {
        assertEquals(EpisodeDownloadMeta.idFor(9, 2, 4), EpisodeDownloadMeta.idFor(9, 2, 4))
        assertTrue(EpisodeDownloadMeta.idFor(9, 1, 4) != EpisodeDownloadMeta.idFor(9, 2, 4))
    }

    @Test
    fun headers_and_subtitles_survive_encoding() {
        val meta = sample().copy(
            headers = mapOf("User-Agent" to "A/B", "Referer" to "https://x.y/z?"),
            subtitles = listOf(
                Triple("eng", "ENG", "https://a/b.vtt"),
                Triple("spa", "SPA", "https://c/d.srt")
            )
        )
        assertEquals(meta, EpisodeDownloadMeta.decode(meta.toJson().toString().toByteArray()))
    }
}
