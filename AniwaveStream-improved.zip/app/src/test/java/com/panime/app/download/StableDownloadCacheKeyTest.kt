package com.panime.app.download

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Focused unit tests for the REAL production algorithm, [StableCacheKeyCore]
 * (pure string logic shared by [DownloadCacheRegistry] and
 * [StableDownloadCacheKeyFactory]). Runs on a plain JVM — no Android types.
 *
 * Media3 resumes a segment iff `buildCacheKey(A) == buildCacheKey(B)`. So the
 * decisive check for "10% -> disconnect -> URL expires -> DIFFERENT path ->
 * resume" is whether a URL-B segment's key equals its URL-A equivalent's key.
 *
 * Persistence survival: the mapping lives in [DownloadCacheRegistry]
 * (SharedPreferences, exercised in androidTest). [StableCacheKeyCore] is pure;
 * a fresh process re-hydrates the SAME map, so keys are identical -> resume.
 */
class StableDownloadCacheKeyTest {

    private val id = "dl_1234_1_9"
    private val segIdx = (1..100).toList()
    private val first10 = (1..10).toList()

    private fun segUrl(base: String, idx: Int) = "$base/seg-$idx.ts?token=abc"

    // Manifest (m3u8) URLs for URL A and the rotated URL B.
    private val urlAM3U = "https://cdn.example.com/v1/enc/AAAA/master.m3u8?token=A"
    private val urlBM3U = "https://cdn.example.com/v1/enc/BBBB/master.m3u8?token=B"

    // HLS segments resolve against the manifest's DIRECTORY, not the m3u8 URL.
    private val urlADir = StableCacheKeyCore.baseOf(urlAM3U) // https://cdn.example.com/v1/enc/AAAA
    private val urlBDir = StableCacheKeyCore.baseOf(urlBM3U) // https://cdn.example.com/v1/enc/BBBB

    // Minimal cache: cacheKey -> segmentIndex -> bytes. Faithful to SegmentDownloader:
    // skip fully-cached segment, else fetch only the uncached remainder.
    private class Cache {
        private val m = mutableMapOf<String, MutableMap<Int, Int>>()
        fun cached(k: String, i: Int) = m[k]?.get(i) ?: 0
        fun put(k: String, i: Int, b: Int) = m.getOrPut(k) { mutableMapOf() }[i] = b
        fun total() = m.values.sumOf { it.values.sumOf { x -> x.toLong() } }
    }

    private fun run(cache: Cache, keyFor: (String) -> String, base: String, segs: List<Int>): Pair<Int, Int> {
        var fetched = 0; var reused = 0
        for (i in segs) {
            val url = segUrl(base, i)
            val key = keyFor(url)
            val already = cache.cached(key, i)
            if (already >= 100) reused += 100
            else { fetched += 100 - already; reused += already; cache.put(key, i, 100) }
        }
        return fetched to reused
    }

    private fun keyFor(reg: Map<String, String>): (String) -> String =
        { u -> StableCacheKeyCore.stableKey(u, reg) ?: u }

    // ── The user's exact scenario ─────────────────────────────────────────

    @Test
    fun urlAtenPercent_then_pathRotatedURLb_resume_reusesTenPercent() {
        // Registration stores baseOf(manifest) = the segment directory.
        val regA = mapOf(StableCacheKeyCore.baseOf(urlAM3U) to id)
        val regB = mapOf(StableCacheKeyCore.baseOf(urlBM3U) to id)
        val cache = Cache()

        // Phase 1: URL A downloads first 10 segments (10%).
        run(cache, keyFor(regA), urlADir, first10)
        assertEquals(1000L, cache.total())

        // Phase 2: URL B (different path) resume, whole episode.
        val (fetched, reused) = run(cache, keyFor(regB), urlBDir, segIdx)
        assertEquals(1000, reused)       // the 10% found & reused
        assertEquals(9000, fetched)      // only the remaining 90% fetched
        assertEquals(10_000L, cache.total()) // no duplicate stored
    }

    @Test
    fun keyForUrlA_equals_keyForUrlB_differentPath() {
        val regA = mapOf(StableCacheKeyCore.baseOf(urlAM3U) to id)
        val regB = mapOf(StableCacheKeyCore.baseOf(urlBM3U) to id)
        val kA = StableCacheKeyCore.stableKey(segUrl(urlADir, 1), regA)!!
        val kB = StableCacheKeyCore.stableKey(segUrl(urlBDir, 1), regB)!!
        assertEquals("dl:$id:/seg-1.ts", kA)
        assertEquals(kA, kB)
    }

    // ── Persistence survival (fresh process, same re-hydrated map) ────────

    @Test
    fun persistedRegistry_rehydratedMap_identicalKeys_afterRestart() {
        // Pre-restart map persisted by DownloadCacheRegistry.
        val preRestart = mapOf(StableCacheKeyCore.baseOf(urlAM3U) to id)
        // Fresh process re-hydrates the SAME stored map.
        val reHydrated = mapOf(StableCacheKeyCore.baseOf(urlAM3U) to id)

        assertEquals(
            StableCacheKeyCore.stableKey(segUrl(urlADir, 5), preRestart),
            StableCacheKeyCore.stableKey(segUrl(urlADir, 5), reHydrated)
        )
        // And after restart against a rotated path: still the same key.
        val regB = mapOf(StableCacheKeyCore.baseOf(urlBM3U) to id)
        assertEquals(
            StableCacheKeyCore.stableKey(segUrl(urlADir, 5), preRestart),
            StableCacheKeyCore.stableKey(segUrl(urlBDir, 5), regB)
        )
    }

    // ── Safety properties ─────────────────────────────────────────────────

    @Test
    fun tokenOnlyRotation_samePath_sameKey() {
        val reg = mapOf(StableCacheKeyCore.baseOf("https://c.com/a/ep.m3u8?t=999") to id)
        val k1 = StableCacheKeyCore.stableKey("https://c.com/a/seg-1.ts?token=X", reg)!!
        val k2 = StableCacheKeyCore.stableKey("https://c.com/a/seg-1.ts?token=Y", reg)!!
        assertEquals(k1, k2)
    }

    @Test
    fun unregisteredStream_staysUriKeyed_notMerged() {
        assertNull(StableCacheKeyCore.stableKey("https://stream.site/a/seg-1.ts", emptyMap()))
        assertTrue(
            StableCacheKeyCore.normalizeUrl("https://stream.site/a/seg-1.ts") !=
                StableCacheKeyCore.normalizeUrl("https://stream.site/b/seg-1.ts")
        )
    }

    @Test
    fun noArbitraryTruncation_fullPathPreserved_whenUnregistered() {
        // Full URL minus query — never an arbitrary path chop.
        assertEquals(
            "https://x.com/v1/enc/AAAA/seg-001.ts",
            StableCacheKeyCore.normalizeUrl("https://x.com/v1/enc/AAAA/seg-001.ts?t=1")
        )
    }

    @Test
    fun differentEpisodes_neverShareCache() {
        val reg = mapOf(
            StableCacheKeyCore.baseOf("https://c.com/api/e1/index.m3u8") to "dl_1_9",
            StableCacheKeyCore.baseOf("https://c.com/api/e2/index.m3u8") to "dl_2_1",
        )
        val e1 = StableCacheKeyCore.stableKey("https://c.com/api/e1/seg-1.ts", reg)!!
        val e2 = StableCacheKeyCore.stableKey("https://c.com/api/e2/seg-1.ts", reg)!!
        assertTrue(e1 != e2)
        assertTrue(!e1.contains("dl_2_1"))
    }

    @Test
    fun baseOf_stripsManifestFilename_notPathSegment() {
        assertEquals(
            "https://cdn.example.com/v1/enc/AAAA",
            StableCacheKeyCore.baseOf("https://cdn.example.com/v1/enc/AAAA/master.m3u8?token=A")
        )
    }

    @Test
    fun manifest_staysUriKeyed_whileItsSegments_areIdKeyed() {
        val reg = mapOf(StableCacheKeyCore.baseOf(urlAM3U) to id)
        // A rotated manifest URL must NOT be shadowed by a cached playlist under
        // the stable id (refetch the true rotated URL).
        assertNull(
            StableCacheKeyCore.stableKey("$urlADir/master.m3u8?token=ROTATED", reg)
        )
        // Its media segments join the stable namespace.
        val seg = StableCacheKeyCore.stableKey(segUrl(urlADir, 1), reg)
        assertEquals("dl:$id:/seg-1.ts", seg)
    }
}