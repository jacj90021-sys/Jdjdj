package com.panime.app.data.api

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Pure-JVM tests for the WAVE subtitle-borrow safety decision
 * ([SubtitleHealth.urlsToAttach]).
 *
 * This is the fix for the report: on aniwaves, SUB rows include MyCloud (its
 * getSources carries .srt tracks), DUB rows don't. When the default SUB server
 * (e.g. Vidplay) returned no tracks, the resolver borrowed MyCloud's tracks and
 * glued them onto the playing stream. If the phone couldn't reach the subtitle
 * edge, the attached-but-unreachable track used to make the whole stream fail,
 * which is why every SUB server "wouldn't play" while the DUB fallback (which
 * never borrows subs) always played. These tests pin the new behavior: borrowed
 * subs are attached only when the healthy check passes, otherwise the stream
 * degrades to the same no-subtitle path DUB uses.
 */
class SubtitleHealthTest {

    private val nativeVidplay = listOf("native-eng.srt")
    private val borrowedMyCloud = listOf("sub-eng.srt", "sub-ara.srt")

    // NATIVE tracks (same host as the video) are trusted without a probe.

    @Test
    fun native_tracks_are_kept_without_probing() {
        var probed = false
        val out = SubtitleHealth.urlsToAttach(
            native = nativeVidplay,
            borrowed = emptyList(),
            healthy = { probed = true; false }
        )
        assertEquals(nativeVidplay, out)
        assertTrue("native tracks must not require a probe", !probed)
    }

    // BORROWED tracks (cross-host: MyCloud subs on a Vidplay stream) are
    // attached ONLY when the first one survives the health probe.

    @Test
    fun healthy_borrow_keeps_all_borrowed_tracks() {
        val out = SubtitleHealth.urlsToAttach(
            native = emptyList(),
            borrowed = borrowedMyCloud,
            healthy = { url -> url == borrowedMyCloud.first() }
        )
        assertEquals(borrowedMyCloud, out)
    }

    @Test
    fun native_wins_when_both_present() {
        val out = SubtitleHealth.urlsToAttach(
            native = nativeVidplay,
            borrowed = borrowedMyCloud,
            healthy = { true }
        )
        assertEquals(nativeVidplay, out)
    }

    // THE FIX: unreachable borrowed subs must be dropped so the SUB stream
    // plays exactly like the DUB fallback (plain HLS, no subtitle merge).

    @Test
    fun dead_subtitle_host_drops_borrowed_tracks() {
        val out = SubtitleHealth.urlsToAttach(
            native = emptyList(),
            borrowed = borrowedMyCloud,
            healthy = { false }
        )
        assertTrue("unreachable borrowed subs must be dropped", out.isEmpty())
    }

    @Test
    fun no_borrow_and_no_native_means_no_subtitles() {
        val out = SubtitleHealth.urlsToAttach(
            native = emptyList(),
            borrowed = emptyList(),
            healthy = { false }
        )
        assertTrue(out.isEmpty())
    }

    // DUB: rows have no MyCloud row, so there is never anything to borrow.

    @Test
    fun dub_fallback_never_attaches_subtitles() {
        val out = SubtitleHealth.urlsToAttach(
            native = emptyList(),
            borrowed = emptyList(),
            healthy = { true }
        )
        assertTrue("DUB fallback plays without subtitles", out.isEmpty())
    }

    // Ordering: borrowed tracks keep MyCloud's priority order.

    @Test
    fun borrowed_tracks_preserve_priority_order() {
        var probed = false
        val out = SubtitleHealth.urlsToAttach(
            native = emptyList(),
            borrowed = borrowedMyCloud,
            healthy = { probed = true; true }
        )
        assertEquals(listOf("sub-eng.srt", "sub-ara.srt"), out)
        assertTrue(probed)
    }
}