package com.panime.app.ad

/**
 * Returns the compiled-in ad network implementation for the AdMob build
 * (`-PadsNetwork=admob`, the default). The Unity build ships its own
 * NetworkModule in a separate source set.
 */
internal fun provideAdNetwork(): AdNetwork = AdMobNetwork