package com.panime.app.ad

import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.View
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.panime.app.BuildConfig

/**
 * AdMob ([AdNetwork]) implementation. Shares Google Play Services as a hard
 * dependency, so on Fire OS / GMS-less devices ads are unavailable.
 */
internal object AdMobNetwork : AdNetwork {
    override val tag = "AdManager"

    /** Interstitial preloaded and ready to show. */
    @Volatile private var interstitial: InterstitialAd? = null

    /** Rewarded ad preloaded and ready to show. */
    @Volatile private var rewarded: RewardedAd? = null

    /** True when Google Play Services is present (AdMob's hard dependency). */
    @Volatile private var gmsAvailable = false

    /** True after the SDK has been initialized. */
    @Volatile private var initialized = false

    // ── AdNetwork ───────────────────────────────────────────────────────────

    override fun isSupported(context: Context): Boolean = try {
        GoogleApiAvailability.getInstance()
            .isGooglePlayServicesAvailable(context) == ConnectionResult.SUCCESS
    } catch (t: Throwable) {
        false
    }

    override fun initialize(context: Context) {
        if (initialized) return
        initialized = true

        // Fire OS / devices without Google Play Services cannot serve AdMob ads
        // (the SDK hard-depends on GMS). Detect it once here and keep every ad
        // path off when absent — the SDK is never initialized, nothing renders.
        gmsAvailable = isSupported(context)
        if (!gmsAvailable) {
            Log.w(tag, "Google Play Services not available (Fire OS?) — ads disabled")
            return
        }

        // Configure: tag for child-directed treatment (required by COPPA) and
        // test device for debug builds so the emu / phone shows test ads.
        val config = RequestConfiguration.Builder()
            .setTestDeviceIds(mutableListOf("ABCDEF0123456789")) // placeholder — real test ID added later
            .build()
        com.google.android.gms.ads.MobileAds.setRequestConfiguration(config)

        com.google.android.gms.ads.MobileAds.initialize(context) { status ->
            Log.i(tag, "AdMob initialized: ${status.adapterStatusMap.keys}")
            if (interstitial != null || rewarded != null) return@initialize
            preload(context.applicationContext)
        }
    }

    override fun preload(context: Context) {
        if (!gmsAvailable) return
        preloadInterstitial(context)
        preloadRewarded(context)
    }

    override fun showInterstitial(activity: Activity, onDismissed: () -> Unit): Boolean {
        val ad = interstitial ?: return false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitial = null
                preloadInterstitial(activity.applicationContext)
                onDismissed()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                interstitial = null
                preloadInterstitial(activity.applicationContext)
                onDismissed()
            }
        }
        ad.show(activity)
        return true
    }

    override fun showRewarded(
        activity: Activity,
        onReward: () -> Unit,
        onDismissed: () -> Unit
    ): Boolean {
        val ad = rewarded ?: return false
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewarded = null
                preloadRewarded(activity.applicationContext)
                onDismissed()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                rewarded = null
                preloadRewarded(activity.applicationContext)
                onDismissed()
            }
        }
        ad.show(activity) { onReward() }
        return true
    }

    override fun createBanner(context: Context): View? {
        val id = BuildConfig.ADMOB_BANNER_ID
        if (id.isBlank()) return null
        return AdView(context).apply {
            adUnitId = id
            setAdSize(AdSize.FLUID)
            loadAd(AdRequest.Builder().build())
        }
    }

    // ── Internal ────────────────────────────────────────────────────────────

    private fun preloadInterstitial(context: Context) {
        if (!gmsAvailable) return
        val id = BuildConfig.ADMOB_INTERSTITIAL_ID
        if (id.isBlank()) return
        InterstitialAd.load(context, id, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
                override fun onAdFailedToLoad(err: LoadAdError) {
                    Log.w(tag, "Interstitial preload failed: ${err.message}")
                }
            })
    }

    private fun preloadRewarded(context: Context) {
        if (!gmsAvailable) return
        val id = BuildConfig.ADMOB_REWARDED_ID
        if (id.isBlank()) return
        RewardedAd.load(context, id, AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
                override fun onAdFailedToLoad(err: LoadAdError) {
                    Log.w(tag, "Rewarded preload failed: ${err.message}")
                }
            })
    }
}