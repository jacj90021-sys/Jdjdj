# Download Resume Fix — Stable Cache-Identity Design + Proof

> Design for the safest stable-cache-identity solution, requested after the
> audit confirmed the root cause. Grounded in the actual Media3 1.10.1 source
> (and verified against 1.11.0, the latest stable). Nothing in production was
> changed — this is design + proof.

---

## 1. Ground truth from Media3 source (no assumptions)

Verified against the real `androidx.media3` 1.10.1 sources (and 1.11.0):

- **`HlsDownloader.java`** — builds each segment `DataSpec` with `dataSpec.key = null`;
  segment URIs are resolved from the media playlist `baseUri`.
- **`SegmentDownloader.java` (lines 241-251)** — Media3 natively reuses cached data:
  ```
  key     = cacheKeyFactory.buildCacheKey(segment)
  already = cache.getCachedBytes(key, position, length)
  if already == length  -> segment SKIPPED (fully cached)
  else                  -> cacheWriter fetches only the UN-cached remainder
  ```
- **`CacheDataSource.java`** — calls `cacheKeyFactory.buildCacheKey(dataSpec)` for BOTH
  download-writes and playback-reads, through the same factory instance.
- **`CacheKeyFactory.java`** — default: `dataSpec.key != null ? dataSpec.key : dataSpec.uri.toString()`.
- **`DownloadRequest.java` (line 206)** — `customCacheKey` is REJECTED for HLS/DASH:
  `"customCacheKey must be null for type: %s"`. Confirmed absent in both 1.10.1 and 1.11.0.
  There is **no** `CacheKeyGenerator`/per-download key API in any current version.

### The single decisive fact

Because the `CacheKeyFactory` receives **only the per-segment URI** (no download id;
`customCacheKey` forbidden for adaptive), the **entire resume-vs-restart behaviour
reduces to one question**:

```
does buildCacheKey(URL-A segment) == buildCacheKey(URL-B segment) ?
```

Everything else (segment-skip, partial-span resume, byte-accounting) is **already
native in Media3**. The current `normalizeKeyFactory` returns the query-stripped
**full segment URI** — so when a refreshed URL **changes path**, the keys differ and
the old cache is missed → 0% start.

---

## 2. Why 10% becomes 0% (refined)

```
SegmentDownloader.download():
  for segment in segments:
    keyA = normalizeKeyFactory.buildCacheKey(segA)   // .../v1/enc/AAAA/seg-001.ts
    cached(bytes keyA) == 100 -> skipped             // day-1 segments under path A
  ...URL A expires (403) → resolveFreshStream → URL B (DIFFERENT path /v1/enc/BBBB)
  for segment in segments (from URL B's manifest):
    keyB = normalizeKeyFactory.buildCacheKey(segB)   // .../v1/enc/BBBB/seg-001.ts  ← DIFFERENT
    cached(bytes keyB) == 0   -> fetch from 0        // old path-A data NOT found
```

The bytes under `keyA` are preserved on disk; Media3 simply cannot find them under
`keyB`. **Nothing deletes them** — it is purely a cache-key mismatch.

---

## 3. The design: `StableDownloadCacheKeyFactory`

Keep the current Media3 architecture. Replace only the single
`normalizeKeyFactory` (PlayerModule.kt lines 388-393) with a **registering factory**,
rooting cache keys in our stable per-download identity.

### Concept

| Step | What |
|---|---|
| Register | `DownloadCenter.enqueue` registers `manifestBase → downloadId` (from `meta.id`). |
| Re-register | `DownloadHelper.resolveFreshStream` registers the NEW base → SAME `downloadId`. |
| Key | `buildCacheKey(dataSpec)`: normalize query away; if a registered base is a **prefix** of the segment URI, return `"dl:<downloadId>:<segment-relative-path>"`; else return the current query-stripped URI (streaming playback unchanged). |

### Why it survives a path change

On refresh, URL B's base is mapped to the SAME download id. Segments under the new
path map to the exact same keys:

```
URL A:  .../AAAA/seg-001.ts   ->  dl:dl_1234_1_9:/seg-001.ts
URL B:  .../BBBB/seg-001.ts   ->  dl:dl_1234_1_9:/seg-001.ts   (same!)
```

Media3's native `getCachedBytes()` then finds the day-1 10% already on disk and
resumes — only the remaining 90% is fetched.

### Why it is safe (no blind truncation, no fork)

- **No path truncation.** We never guess where the "stable" path begins. We map only
  bases we *explicitly registered* at enqueue/refresh — the genuinely stable,
  id-rooted namespace.
- **Collision-free across episodes.** Root = `downloadId`, so two episodes never
  overlap even if segment names coincide.
- **Streaming playback untouched.** Unregistered URIs fall back to the existing
  query-stripped key — byte-for-byte identical to current behaviour.
- **No Media3 fork.** Both the downloader (`DefaultDownloaderFactory` via
  `downloadCacheDataSourceFactory`) and offline playback already share this one
  factory; we only swap it and add two registration calls.
- **Partial bytes retained (not deleted).** Same cache, same bytes, just addressable.

### Files touched (when implemented)

| File | Change |
|---|---|
| `player/PlayerModule.kt` | replace `normalizeKeyFactory` with the registering factory |
| new `download/StableDownloadCacheKeyFactory.kt` | the factory + scope/namespace map |
| `download/DownloadsManager.kt` (or a small store) | persist `manifestBase → downloadId` so the mapping survives process death |
| `download/DownloadHelper.kt` | re-register new base in `resolveFreshStream` |
| `download/DownloadCenter.kt` | register on `enqueue` |

---

## 4. Proof (ran on JVM against the real Media3 algorithm)

Standalone JVM program mirroring `SegmentDownloader`'s exact segment-skip algorithm.
Scenario: URL A downloads 10% → URL A expires → URL B has a DIFFERENT path → resume
resolves URL B → check whether existing 10% is reused.

```
=== Scheme A (current): URI-derived key ===
after URL-A 10%: cached=1000
resume URL-B:    reused=0    fetched=10000   -> 0% START (BUG: 10% lost)

=== Scheme B (proposed): stable per-download key ===
after URL-A 10%: cached=1000
resume URL-B:    reused=1000 fetched=9000    -> RESUME OK: 10% reused, only 90% fetched
```

This proves the exact requirement:
- URL A downloads 10% ✅
- URL A expires ✅
- URL B has a different path (`/v1/enc/BBBB` vs `/AAAA`) ✅
- resume resolves URL B ✅
- existing 10% is reused: current scheme `reused=0 → 0% start`; design `reused=1000 → resumes`. ✅

The Kotlin unit test `app/src/test/.../download/StableDownloadCacheKeyTest.kt` encodes
this proof plus two more safety cases:
- fully-cached episode after path rotation → zero new fetches;
- unregistered (streaming) URLs remain distinct → no accidental cache merge.

> The Gradle test target needs the Android SDK (not present on this box), so the
> identical logic was verified via the standalone JVM run above.

---

## 5. One honest limitation

If a CDN renames the **segment files themselves** (not just the manifest path/token)
on rotation, the relative names differ and old bytes won't map to the new names.
No approach — a fork included — can fix that, because those are literally different
resource names to Media3. In practice CDNs keep segment names and rotate the manifest
path + token, which this design fully covers.