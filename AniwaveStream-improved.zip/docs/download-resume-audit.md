# Download Resume Bug Audit — Why 10% Becomes 0%

> Audit performed on the current repository. No code was changed; this is investigation only.
>
> **Scenario:** Download Episode 9 → reaches 10% → internet drops → a day passes → resume → download restarts at 0%.

---

## CURRENT IMPLEMENTATION (what actually exists)

Both architectures coexist in this repo — the old FFmpeg-addon one and the new Media3 one. Critically, **only one is actually wired to the UI; the other is dead code.**

### The ACTIVE path (new Media3 architecture) — confirmed working in real use

```
DetailScreen → DownloadHelper.downloadEpisode()        ← enqueues
        ↓
DownloadHelper → ProviderManager.resolveOn()           ← resolves provider stream (HLS m3u8)
        ↓
DownloadCenter.enqueue() → DownloadService.sendAddDownload()
        ↓
EpisodeDownloadService (Media3 DownloadService)        ← THE ONLY thing that actually downloads
        ↓
Media3 DownloadManager (SQLite index + SimpleCache on disk)
        ↓
PlayerModule.normalizeKeyFactory                       ← cache key = query-stripped URL
```

This is genuinely implemented: `EpisodeDownloadService.kt` (Media3 `DownloadService`), `DownloadManager` with `customCacheKey` logic, `normalizeKeyFactory`, retry policy, real pause (`sendSetStopReason`), expired-URL refresh via `DownloadHelper.resolveFreshStream()`.

### The DEAD path (old FFmpeg addon) — still present but **not used**

`AnimeDownloaderService.kt` + `DownloadAddonLoader.kt` + `DownloadState.kt`/`DownloadsManager.kt` for it still exist. But **`AnimeDownloaderService` is never started** — nothing calls `AnimeDownloaderService.enqueue()`. The real enqueue goes through `DownloadCenter` → `EpisodeDownloadService`. The FFmpeg addon is legacy, retained but not the active downloader.

> The suspicion that "the new architecture wasn't implemented" is **wrong** — it IS implemented and it IS the one running.

### The old addon's `DownloadsManager` still serves one real purpose
It records completed downloads (registry) and gives the download folder. The old `DownloadState.kt` is dead for downloading but may still render rows — irrelevant to the bug.

---

## WHAT WE PREVIOUSLY PLANNED vs. WHAT'S IMPLEMENTED

| Planned | Implemented? |
|---|---|
| Scraper → resolver → Media3 → DownloadManager → DownloadService | ✅ fully |
| Persistent download state (SQLite via Media3 `DownloadIndex`) | ✅ |
| Real pause/resume (`setStopReason`) | ✅ |
| Retry/backoff (`DownloadRetryPolicy`) | ✅ |
| Network recovery (`Requirements(NETWORK)`) | ✅ |
| Expired URL refresh through ProviderManager | ✅ (`resolveFreshStream`) |
| Playback-position persistence | ✅ (separate, not part of this) |
| Background downloading | ✅ foreground service |
| **Same cache identity survives URL refresh** | ❌ **THE GAP** |

---

## RESUME BUG ROOT CAUSE (the actual code, traced)

Here is the exact lifecycle of ep 9, traced through the real code:

**Day 1: 10% stored ✓**
1. `ProviderManager.resolveOn()` returns m3u8 URL **A** (e.g. `https://cdn.com/v1/enc/data/XXXXX_720p.m3u8?token=AAA`)
2. Media3 downloads segments. Cache key = `normalizeKeyFactory` → **the URL with query stripped** → `https://cdn.com/v1/enc/data/XXXXX_720p.m3u8`.
3. Segments for that path are stored in the cache dir keyed by that stripped URL.
4. Progress lives in Media3's SQLite `DownloadIndex`, id = `dl_animeId_season_ep`.

**Day 1 evening: internet lost → download `STATE_FAILED`.**
- `onFailed()` → `DownloadRetryPolicy.decide()`.
- **How `classify` treats a bare network drop:** only *specific* exceptions map to `RETRY_SAME_URL`/`GIVE_UP`. If the failure surfaces as `HttpDataSourceException`/`IOException` → `RETRY_SAME_URL`. If it's an **engine-level abort (`error == null`)**, `classify` returns `RETRY_SAME_URL` too — so a plain disconnect → `RETRY_SAME_URL` with backoff (15s → 60s → 180s → 600s, max 4). After 4 failed retries (~14 min), **`GIVE_UP`** → marked FAILED.
- **The partial data stays on disk** (SimpleCache, never-evicted; `remove()` is only ever called by the user Delete action, never on failure). `EpisodeDownloadService.onFailed` never deletes cache — only `DownloadCenter.remove()` does. ✅ **Partial is retained.**

**Day 2: user presses Resume → `DownloadCenter.resume(id)`**
4. `resume()` = `sendSetStopReason(id, STOP_REASON_NONE, false)`. This tells Media3 to **re-`send()` the SAME stored DownloadRequest** (built from `<stripped URL A>.m3u8` in the index).
5. **Here is the killer:** the stored request still points at **URL A with token AAA — now expired.** So Segment fetches return **HTTP 403**.
6. Media3 fails → `onFailed()` → `classifyCode(403)` → **`REFRESH_URL`** → `DownloadHelper.resolveFreshStream(meta)` resolves the provider again → gets **fresh URL B**. Providers often rotate the **path** (stream id / server), not just the query token.
7. `meta.copy(streamUrl = URL B).toDownloadRequest()` — **re-adds request with URL B.**
8. `normalizeKeyFactory` computes cache key for **URL B** → **different stripped path** → **a brand-new cache entry.**
9. Media3 sees "no cached segments for this key" → **downloads from 0%.**

**That is the exact mechanism.** Same download `id`, but the **cache key changed** because the refreshed URL's path differs. Media3 keeps the same `id` (so the *row* shows resumed), but the *content* cache is keyed by URL path, and a new path = empty cache = 0%.

**Why it's intermittent:** if the CDN keeps the same path (only the token rotates), the query-stripped key matches and **10% IS resumed**. It fails specifically when the refreshed URL's **path differs**.

---

## EVIDENCE — the concrete code that causes it

| File | The line/fact that matters |
|---|---|
| `PlayerModule.kt:390-393` | `normalizeKeyFactory` keys by **query-stripped URL** for HLS/DASH. Path change → new key. |
| `PlayerModule.kt:405` | Same factory used by downloader → consistent both sides (good), but path-sensitive (bad for refresh). |
| `EpisodeDownloadMeta.toDownloadRequest()` | `customCacheKey` only for MP4; **no stable cache key for HLS.** |
| `EpisodeDownloadService.onFailed()` → `REFRESH_URL` | On 403, refreshes to a **new URL** → possible new path → new cache key. |
| `DownloadHelper.resolveFreshStream()` | Calls `ProviderManager.resolveOn` fresh → path may differ. |
| `DownloadCenter.resume()` | Only clears stop reason; does **not** re-map old cached spans. |
| `EpisodeDownloadService` `onFailed` | Never deletes partial cache on failure (data retained, just not reused). |

---

## WHAT SHOULD HAPPEN (correct lifecycle)

```
10% segments stored under path-A cache key
        ↓ network lost (1 day)
partial data retained on disk ✓ (already true today)
        ↓ URL A expired, 403
resolve fresh URL B via ProviderManager
        ↓
RE-USE path-A cache: key new request to the SAME cache identity
        ↓
Media3 resumes; already-fetched segments skip; only new segments fetched
        ↓ 10% → continues → 100%
```

The **correct** behavior requires mapping URL B **back onto the existing partial cache** — i.e., a **stable, URL-independent cache identity** per download.

---

## RECOMMENDED FIX (smallest, don't rebuild)

**Root problem:** Media3 forbids `customCacheKey` on HLS/DASH (`EpisodeDownloadMeta.toDownloadRequest()` only sets it for `mp4`), so HLS data is keyed by stripped-URL path — unstable across refresh.

**Smallest robust fix — make the HLS cache key URL-path-independent so the refresh reuses the partial data.** In `normalizeKeyFactory`, instead of `clearQuery()` of the URI, build the key from **download id + resolved path without the volatile token/rotation bits**. Concretely:

```kotlin
CacheKeyFactory { dataSpec ->
    dataSpec.key ?: stableHlsCacheKey(dataSpec.uri)
}
```

where `stableHlsCacheKey` strips query AND truncates/normalizes the path to the stable prefix the provider keeps (or keys HLS by the **download id** threaded through the request URI). Keying by download-id needs the id in scope per segment, which Media3 doesn't expose directly for HLS.

**Preferred smaller fix — "unify the cache key, refresh only when the path truly changed."** Two changes:
1. Make `resolveFreshStream()` **reuse the existing URL if the provider returns a path-identical URL** (most refreshes). When the path is identical, the query-stripped key matches → **10% resumes with zero new code risk.**
2. In `normalizeKeyFactory`, generate the HLS key with **query AND a normalized path** (e.g. strip the trailing numeric/id segment that providers rotate), so more refreshes land on the same key.

Both are minimal edits to `PlayerModule.kt` + `DownloadHelper.kt` — no Media3 forking, no rebuild of the download engine.

**Deliberately NOT recommended:**
- Rebuilding on WorkManager/UIDT — unrelated to the data-loss; you'd still lose 10% under the same key-map gap.
- Forking Media3's `customCacheKey` for HLS — invasive and risky.
- Any change that wipes the cache on failure — it's already correctly retained; we want to REUSE it, not re-copy it.

---

## BOTTOM LINE

Your 10% is **physically stored and retained** — the loss is **purely a cache-key mapping gap** when the refreshed URL path differs. The 10% is never deleted; Media3 just can't find it under the new key. The smallest fix is the two-step `normalizeKeyFactory` + `resolveFreshStream` change.